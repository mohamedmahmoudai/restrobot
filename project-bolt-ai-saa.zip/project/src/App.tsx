import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Component, useEffect, type ReactNode } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AdminAuthProvider, useAdminAuth } from './contexts/AdminAuthContext';
import { AppProvider } from './contexts/AppContext';
import { SubscriptionProvider } from './contexts/SubscriptionContext';
import { OnboardingProvider, useOnboarding } from './contexts/OnboardingContext';
import { ToastProvider } from './components/Toast';
import { initSentry, initVercelAnalytics, initSpeedInsights } from './lib/monitoring';
import Landing from './pages/Landing';
import Auth from './pages/Auth';
import PlanSelection from './pages/PlanSelection';
import Onboarding from './pages/Onboarding';
import DashboardLayout from './components/DashboardLayout';
import Overview from './pages/dashboard/Overview';
import Cashier from './pages/dashboard/Cashier';
import Menu from './pages/dashboard/Menu';
import Customers from './pages/dashboard/Customers';
import Loyalty from './pages/dashboard/Loyalty';
import LoyaltySettingsPage from './pages/dashboard/LoyaltySettings';
import RewardsManager from './pages/dashboard/RewardsManager';
import TiersManager from './pages/dashboard/TiersManager';
import Analytics from './pages/dashboard/Analytics';
import ActivityLogs from './pages/dashboard/ActivityLogs';
import Settings from './pages/dashboard/Settings';
import Subscription from './pages/dashboard/Subscription';
import AdminLogin from './pages/admin/AdminLogin';
import AdminPanel from './pages/admin/AdminPanel';

class ErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean }> {
  state = { hasError: false };
  static getDerivedStateFromError() { return { hasError: true }; }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center" dir="rtl">
          <div className="text-center">
            <p className="text-lg font-bold text-slate-900 mb-3">حدث خطأ غير متوقع</p>
            <button onClick={() => window.location.reload()} className="btn-primary">إعادة التحميل</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function LoadingSpinner() {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center" dir="rtl">
      <div className="text-center">
        <div className="w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-slate-500 text-sm">جارٍ التحميل...</p>
      </div>
    </div>
  );
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, restaurant, loading, needsPlanSelection } = useAuth();
  if (loading) return <LoadingSpinner />;
  if (!user) return <Navigate to="/login" replace />;
  if (!restaurant) return <LoadingSpinner />;
  if (needsPlanSelection) return <Navigate to="/select-plan" replace />;
  // Check onboarding status - redirect if not completed
  if (restaurant && !restaurant.onboarding_completed) {
    return <Navigate to="/onboarding" replace />;
  }
  return <>{children}</>;
}

function OnboardingRoute() {
  const { user, restaurant, loading, needsPlanSelection } = useAuth();
  if (loading) return <LoadingSpinner />;
  if (!user) return <Navigate to="/login" replace />;
  if (!restaurant) return <LoadingSpinner />;
  if (needsPlanSelection) return <Navigate to="/select-plan" replace />;
  // If onboarding completed, redirect to dashboard
  if (restaurant.onboarding_completed) {
    return <Navigate to="/dashboard" replace />;
  }
  return (
    <OnboardingProvider>
      <Onboarding />
    </OnboardingProvider>
  );
}

function GuestRoute({ children }: { children: React.ReactNode }) {
  const { user, loading, needsPlanSelection } = useAuth();
  if (loading) return <LoadingSpinner />;
  if (!user) return <>{children}</>;
  if (needsPlanSelection) return <Navigate to="/select-plan" replace />;
  return <Navigate to="/dashboard" replace />;
}

function PlanSelectionRoute() {
  const { user, restaurant, loading, markPlanSelected } = useAuth();
  if (loading) return <LoadingSpinner />;
  if (!user || !restaurant) return <Navigate to="/login" replace />;
  return (
    <PlanSelection
      restaurantId={restaurant.id}
      hasUsedTrial={restaurant.has_used_trial || false}
      onComplete={() => {
        markPlanSelected();
        window.location.href = '/dashboard';
      }}
    />
  );
}

// Admin routes - protected by AdminAuthContext
function AdminRoute({ children }: { children: React.ReactNode }) {
  const { isAdmin, loading } = useAdminAuth();
  if (loading) return <LoadingSpinner />;
  if (!isAdmin) return <Navigate to="/admin/login" replace />;
  return <>{children}</>;
}

function AdminGuestRoute({ children }: { children: React.ReactNode }) {
  const { isAdmin, loading } = useAdminAuth();
  if (loading) return <LoadingSpinner />;
  if (isAdmin) return <Navigate to="/admin/dashboard" replace />;
  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<GuestRoute><Auth /></GuestRoute>} />
      <Route path="/register" element={<GuestRoute><Auth /></GuestRoute>} />
      <Route path="/select-plan" element={<PlanSelectionRoute />} />
      <Route path="/onboarding" element={<OnboardingRoute />} />

      {/* Restaurant Dashboard Routes */}
      <Route path="/dashboard" element={<ProtectedRoute><DashboardLayout><Overview /></DashboardLayout></ProtectedRoute>} />
      <Route path="/dashboard/cashier" element={<ProtectedRoute><DashboardLayout><Cashier /></DashboardLayout></ProtectedRoute>} />
      <Route path="/dashboard/menu" element={<ProtectedRoute><DashboardLayout><Menu /></DashboardLayout></ProtectedRoute>} />
      <Route path="/dashboard/customers" element={<ProtectedRoute><DashboardLayout><Customers /></DashboardLayout></ProtectedRoute>} />
      <Route path="/dashboard/loyalty" element={<ProtectedRoute><DashboardLayout><Loyalty /></DashboardLayout></ProtectedRoute>} />
      <Route path="/dashboard/loyalty/settings" element={<ProtectedRoute><DashboardLayout><LoyaltySettingsPage /></DashboardLayout></ProtectedRoute>} />
      <Route path="/dashboard/loyalty/rewards" element={<ProtectedRoute><DashboardLayout><RewardsManager /></DashboardLayout></ProtectedRoute>} />
      <Route path="/dashboard/loyalty/tiers" element={<ProtectedRoute><DashboardLayout><TiersManager /></DashboardLayout></ProtectedRoute>} />
      <Route path="/dashboard/analytics" element={<ProtectedRoute><DashboardLayout><Analytics /></DashboardLayout></ProtectedRoute>} />
      <Route path="/dashboard/settings" element={<ProtectedRoute><DashboardLayout><Settings /></DashboardLayout></ProtectedRoute>} />
      <Route path="/dashboard/subscription" element={<ProtectedRoute><DashboardLayout><Subscription /></DashboardLayout></ProtectedRoute>} />
      <Route path="/dashboard/activity" element={<ProtectedRoute><DashboardLayout><ActivityLogs /></DashboardLayout></ProtectedRoute>} />

      {/* Admin Routes */}
      <Route path="/admin" element={<AdminGuestRoute><AdminLogin /></AdminGuestRoute>} />
      <Route path="/admin/login" element={<AdminGuestRoute><AdminLogin /></AdminGuestRoute>} />
      <Route path="/admin/dashboard" element={<AdminRoute><AdminPanel /></AdminRoute>} />
      <Route path="/admin/restaurants" element={<AdminRoute><AdminPanel /></AdminRoute>} />
      <Route path="/admin/subscriptions" element={<AdminRoute><AdminPanel /></AdminRoute>} />
      <Route path="/admin/plans" element={<AdminRoute><AdminPanel /></AdminRoute>} />
      <Route path="/admin/support" element={<AdminRoute><AdminPanel /></AdminRoute>} />
      <Route path="/admin/announcements" element={<AdminRoute><AdminPanel /></AdminRoute>} />
      <Route path="/admin/audit" element={<AdminRoute><AdminPanel /></AdminRoute>} />
      <Route path="/admin/health" element={<AdminRoute><AdminPanel /></AdminRoute>} />
      <Route path="/admin/security" element={<AdminRoute><AdminPanel /></AdminRoute>} />
      <Route path="/admin/settings" element={<AdminRoute><AdminPanel /></AdminRoute>} />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function AppInit() {
  useEffect(() => {
    initSentry();
    initVercelAnalytics();
    initSpeedInsights();
  }, []);
  return null;
}

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <AdminAuthProvider>
            <SubscriptionProvider>
              <AppProvider>
                <ErrorBoundary>
                  <AppInit />
                  <AppRoutes />
                </ErrorBoundary>
              </AppProvider>
            </SubscriptionProvider>
          </AdminAuthProvider>
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  );
}
