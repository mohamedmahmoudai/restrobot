import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bot, LayoutDashboard, ShoppingBag, UtensilsCrossed,
  Users, Star, BarChart3, Settings, LogOut,
  Menu, X, Gift, Lock, CheckCircle, Phone, Search, CreditCard, Activity,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import { supabase } from '../lib/supabase';
import NotificationCenter from './NotificationCenter';
import type { ReactNode } from 'react';

const navItems = [
  { path: '/dashboard', label: 'نظرة عامة', icon: LayoutDashboard },
  { path: '/dashboard/cashier', label: 'الكاشير', icon: ShoppingBag },
  { path: '/dashboard/menu', label: 'المنيو', icon: UtensilsCrossed },
  { path: '/dashboard/customers', label: 'العملاء', icon: Users },
  { path: '/dashboard/loyalty', label: 'المكافآت', icon: Star },
  { path: '/dashboard/analytics', label: 'التحليلات', icon: BarChart3 },
  { path: '/dashboard/activity', label: 'النشاطات', icon: Activity },
  { path: '/dashboard/subscription', label: 'الاشتراك', icon: CreditCard },
  { path: '/dashboard/settings', label: 'الإعدادات', icon: Settings },
];

interface Props { children: ReactNode }

export default function DashboardLayout({ children }: Props) {
  const location = useLocation();
  const { signOut, restaurant, user, loading } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showTrialBanner, setShowTrialBanner] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [planSubmitting, setPlanSubmitting] = useState(false);
  const [trialExpired, setTrialExpired] = useState(false);
  const [systemPlans, setSystemPlans] = useState<Array<{ id: string; plan_name: string; type: string; price: number; features: string[] }>>([]);

  const currentPlan = restaurant?.subscription_plan || 'trial';
  const expirationDate = restaurant?.subscription_expires_at ? new Date(restaurant.subscription_expires_at) : null;
  const hasUsedTrial = restaurant?.has_used_trial ?? false;
  const isSuspended = (restaurant as any)?.is_suspended === true;
  const { subscriptionStatus } = useSubscription();
  const isTrialPlan = currentPlan === 'trial' || subscriptionStatus?.isTrialPlan === true;

  const now = new Date();
  const isSubscriptionExpired = !isTrialPlan && expirationDate && now > expirationDate;

  // Pages allowed when suspended: Menu + Settings + Subscription
  const allowedWhenSuspended = ['/dashboard/menu', '/dashboard/settings', '/dashboard/subscription'];
  // Pages allowed when expired: Menu + Settings + Subscription
  const allowedWhenExpired = ['/dashboard/menu', '/dashboard/settings', '/dashboard/subscription'];

  const isLocked = isSuspended || isSubscriptionExpired;
  const isPageAllowed = isSuspended
    ? allowedWhenSuspended.some(p => location.pathname.startsWith(p))
    : isSubscriptionExpired
      ? allowedWhenExpired.some(p => location.pathname.startsWith(p))
      : true;

  useEffect(() => {
    if (!restaurant) return;
    const now = new Date();
    const isExpiredSubscription = !isTrialPlan && expirationDate && now > expirationDate;
    const trialExpired = isTrialPlan && expirationDate && now > expirationDate;
    if (trialExpired || isExpiredSubscription) {
      setTrialExpired(true);
      setShowTrialBanner(false);
    } else if (isTrialPlan && expirationDate && now <= expirationDate) {
      setTrialExpired(false);
      setShowTrialBanner(true);
    } else {
      setTrialExpired(false);
      setShowTrialBanner(false);
    }
  }, [currentPlan, expirationDate, restaurant, isTrialPlan]);

  useEffect(() => {
    supabase.from('system_plans').select('*').order('price', { ascending: true }).then(({ data }) => {
      if (data) setSystemPlans(data as typeof systemPlans);
    });
  }, []);

  async function selectPlan(plan: string) {
    if (!restaurant || plan === 'enterprise') return;
    setPlanSubmitting(true);
    await supabase.from('restaurants').update({
      subscription_plan: plan,
      has_used_trial: true,
    }).eq('id', restaurant.id);
    setSelectedPlan(plan);
    setPlanSubmitting(false);
  }

  async function handleLogout() {
    await signOut();
    window.location.href = '/login';
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-slate-500 text-sm">جارٍ تحميل البيانات...</p>
        </div>
      </div>
    );
  }

  if (!user) return null;

  if (!restaurant) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <Bot className="w-12 h-12 mx-auto mb-4 text-primary-600" />
          <p className="text-lg font-bold text-slate-900 mb-2">لا يوجد حساب مطعم مرتبط</p>
          <p className="text-slate-500 text-sm mb-4">هذا الحساب ليس مرتبطاً بمطعم.</p>
          <button onClick={handleLogout} className="btn-primary">تسجيل الخروج</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50" dir="rtl">
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar - Desktop */}
      <aside className="fixed top-0 right-0 h-screen w-[260px] bg-white border-l border-slate-200 z-50 flex-col hidden lg:flex">
        {/* Logo */}
        <div className="flex-shrink-0 px-5 py-5 border-b border-slate-100">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
              <Bot className="w-4.5 h-4.5 text-white" />
            </div>
            <div>
              <div className="text-sm font-bold text-slate-900">RestroBot</div>
              <div className="text-[11px] text-slate-400">المنصة الذكية</div>
            </div>
          </Link>
        </div>

        {/* User */}
        <div className="flex-shrink-0 px-5 py-4 border-b border-slate-100">
          <div className="flex items-center gap-3 bg-slate-50 rounded-xl px-3 py-2.5 border border-slate-100">
            <div className="w-8 h-8 bg-primary-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <UtensilsCrossed className="w-4 h-4 text-primary-600" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-slate-900 truncate">{restaurant.name}</p>
              <p className="text-xs text-slate-400 truncate">{user.email}</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto overflow-x-hidden px-3 py-4 space-y-0.5 scrollbar-hide">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2">القائمة</div>
          {navItems.map((item) => {
            const active = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`group relative flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-150 text-sm font-medium ${
                  active
                    ? 'bg-primary-50 text-primary-700'
                    : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <Icon className={`w-[18px] h-[18px] flex-shrink-0 ${active ? 'text-primary-600' : ''}`} />
                <span className="flex-1">{item.label}</span>
                {active && <div className="w-1 h-5 bg-primary-500 rounded-full absolute left-0" />}
              </Link>
            );
          })}
        </nav>

        {/* Logout */}
        <div className="flex-shrink-0 px-3 py-4 border-t border-slate-100">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500 hover:text-danger-600 hover:bg-danger-50 transition-all duration-150"
          >
            <LogOut className="w-[18px] h-[18px] flex-shrink-0" />
            <span>تسجيل الخروج</span>
          </button>
        </div>
      </aside>

      {/* Mobile Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 400, damping: 40 }}
            className="fixed top-0 right-0 h-screen w-[280px] bg-white border-l border-slate-200 z-50 flex flex-col lg:hidden"
          >
            <div className="flex-shrink-0 px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <Link to="/" className="flex items-center gap-2.5">
                <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
                  <Bot className="w-4.5 h-4.5 text-white" />
                </div>
                <div className="text-sm font-bold text-slate-900">RestroBot</div>
              </Link>
              <button onClick={() => setSidebarOpen(false)} className="p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-50">
                <X className="w-5 h-5" />
              </button>
            </div>

            {restaurant && user && (
              <div className="flex-shrink-0 px-5 py-4 border-b border-slate-100">
                <div className="flex items-center gap-3 bg-slate-50 rounded-xl px-3 py-2.5 border border-slate-100">
                  <div className="w-8 h-8 bg-primary-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <UtensilsCrossed className="w-4 h-4 text-primary-600" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-slate-900 truncate">{restaurant.name}</p>
                    <p className="text-xs text-slate-400 truncate">{user.email}</p>
                  </div>
                </div>
              </div>
            )}

            <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2">القائمة</div>
              {navItems.map((item) => {
                const active = location.pathname === item.path;
                const Icon = item.icon;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setSidebarOpen(false)}
                    className={`group relative flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-150 text-sm font-medium ${
                      active
                        ? 'bg-primary-50 text-primary-700'
                        : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    <Icon className={`w-[18px] h-[18px] flex-shrink-0 ${active ? 'text-primary-600' : ''}`} />
                    <span className="flex-1">{item.label}</span>
                  </Link>
                );
              })}
            </nav>

            <div className="flex-shrink-0 px-3 py-4 border-t border-slate-100">
              <button onClick={handleLogout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500 hover:text-danger-600 hover:bg-danger-50 transition-all">
                <LogOut className="w-[18px] h-[18px] flex-shrink-0" />
                <span>تسجيل الخروج</span>
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Trial Expired Modal */}
      <AnimatePresence>
        {trialExpired && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4" dir="rtl">
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
              <div className="bg-slate-900 px-6 py-5 text-center">
                <Lock className="w-10 h-10 text-white mx-auto mb-2" />
                <h2 className="text-lg font-bold text-white">
                  {isTrialPlan ? 'انتهت الفترة التجريبية' : 'انتهى اشتراكك'}
                </h2>
                <p className="text-sm text-slate-300 mt-1">
                  {isTrialPlan
                    ? 'يرجى اختيار باقة لتفعيل حسابك'
                    : 'يرجى تجديد اشتراكك لمتابعة استخدام النظام'}
                </p>
              </div>
              {!selectedPlan ? (
                <div className="p-6 space-y-4">
                  <p className="text-slate-500 text-center text-sm">يرجى اختيار باقة لتفعيل حسابك.</p>
                  <div className="space-y-3">
                    {systemPlans.filter(p => !(p.type === 'trial' && hasUsedTrial)).map(p => (
                      <motion.button key={p.type} onClick={() => p.type === 'enterprise' ? window.open('https://wa.me/201234567890', '_blank') : selectPlan(p.type)} disabled={planSubmitting} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }} className={`w-full p-4 rounded-xl border text-right transition-all ${p.type === 'enterprise' ? 'border-slate-200 bg-slate-50' : 'border-primary-200 hover:border-primary-300 bg-white'}`}>
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="font-bold text-slate-900">{p.plan_name}</div>
                            <div className="text-xs text-slate-500 mt-1">{p.price > 0 ? `${p.price} ج.م / شهر` : p.type === 'enterprise' ? 'تواصل معنا' : 'مجاني'}</div>
                          </div>
                          {p.type === 'enterprise' ? <Phone className="w-5 h-5 text-slate-400" /> : <CheckCircle className="w-5 h-5 text-primary-600" />}
                        </div>
                      </motion.button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-6 text-center">
                  <CheckCircle className="w-14 h-14 text-success-500 mx-auto mb-3" />
                  <h3 className="text-base font-bold text-slate-900">تم تسجيل اختيارك بنجاح</h3>
                  <p className="text-sm text-slate-500 mt-2">الحساب بانتظار تفعيل الأدمن</p>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Trial Banner */}
      <AnimatePresence>
        {showTrialBanner && !trialExpired && (
          <motion.div initial={{ y: -40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -40, opacity: 0 }} className="fixed top-0 left-0 right-0 z-[90] bg-slate-900 text-white py-2.5 px-4" dir="rtl">
            <div className="max-w-7xl mx-auto flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Gift className="w-4 h-4 text-primary-400" />
                <span className="text-sm font-medium">3 أيام تجريبية مجانية لاستكشاف جميع المميزات</span>
              </div>
              <button onClick={() => setShowTrialBanner(false)} className="text-white/60 hover:text-white"><X className="w-4 h-4" /></button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="lg:mr-[260px] min-h-screen flex flex-col">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-slate-200 px-6 py-3 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3 flex-1">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
              <Menu className="w-5 h-5" />
            </button>
            <div className="hidden sm:flex items-center gap-2 bg-slate-100 rounded-xl px-3 py-2 flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400" />
              <input type="text" placeholder="بحث..." className="bg-transparent text-sm text-slate-700 placeholder:text-slate-400 outline-none flex-1" />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <NotificationCenter />
          </div>
        </header>

        {/* Page Content */}
        <motion.main
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="flex-1 w-full overflow-y-auto overflow-x-hidden p-6 relative"
        >
          <div className={isLocked && !isPageAllowed ? 'blur-sm pointer-events-none select-none' : ''}>
            {children}
          </div>

          {/* Lock overlay when suspended or expired */}
          <AnimatePresence>
            {isLocked && !isPageAllowed && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 z-50 flex items-center justify-center p-6"
                dir="rtl"
              >
                <div className="bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-200 p-8 max-w-md text-center">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${isSuspended ? 'bg-danger-100' : 'bg-warning-100'}`}>
                    {isSuspended ? <Lock className="w-8 h-8 text-danger-600" /> : <AlertCircle className="w-8 h-8 text-warning-600" />}
                  </div>
                  <h2 className="text-lg font-bold text-slate-900 mb-2">
                    {isSuspended ? 'تم إيقاف المطعم' : 'انتهى اشتراكك'}
                  </h2>
                  <p className="text-sm text-slate-500 mb-6">
                    {isSuspended
                      ? 'يرجى التواصل مع الدعم لمزيد من المعلومات.'
                      : 'يرجى تجديد اشتراكك لمتابعة استخدام النظام.'}
                  </p>
                  {!isSuspended && (
                    <Link to="/dashboard/subscription" className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary-600 text-white rounded-xl text-sm font-medium hover:bg-primary-700 transition-colors">
                      <CreditCard className="w-4 h-4" />
                      تجديد الاشتراك
                    </Link>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.main>
      </div>
    </div>
  );
}
