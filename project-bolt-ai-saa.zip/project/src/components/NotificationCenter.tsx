import { useEffect, useState, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion } from 'framer-motion';
import { Bell, X, ShoppingBag, Star, CreditCard, AlertTriangle, Info, CheckCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface Notification {
  id: string;
  type: string;
  title: string;
  body: string;
  is_read: boolean;
  created_at: string;
}

const typeIcon: Record<string, React.FC<{ className?: string }>> = {
  order:       ShoppingBag,
  loyalty:     Star,
  subscription: CreditCard,
  warning:     AlertTriangle,
  info:        Info,
};

const typeColor: Record<string, string> = {
  order:       'bg-blue-100 text-blue-600',
  loyalty:     'bg-amber-100 text-amber-600',
  subscription:'bg-emerald-100 text-emerald-600',
  warning:     'bg-red-100 text-red-600',
  info:        'bg-slate-100 text-slate-500',
};

export default function NotificationCenter() {
  const { restaurant } = useAuth();
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  const unread = notifications.filter(n => !n.is_read).length;

  // Track processed notification IDs to prevent duplicates
  const processedNotificationsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!restaurant) return;
    fetchNotifications();

    const channel = supabase
      .channel(`notifications-${restaurant.id}`, {
        config: {
          broadcast: { self: false },
        }
      })
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'notifications',
        filter: `restaurant_id=eq.${restaurant.id}`,
      }, (payload) => {
        const newNotification = payload.new as Notification;

        // Prevent duplicate processing
        if (processedNotificationsRef.current.has(newNotification.id)) {
          return;
        }
        processedNotificationsRef.current.add(newNotification.id);

        setNotifications(prev => {
          // Double-check we don't already have this notification
          if (prev.some(n => n.id === newNotification.id)) return prev;
          return [newNotification, ...prev].slice(0, 50);
        });

        // Play notification sound for new orders
        if (newNotification.type === 'order') {
          try {
            const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.frequency.value = 880;
            gain.gain.value = 0.1;
            osc.start();
            osc.stop(ctx.currentTime + 0.15);
            setTimeout(() => {
              const osc2 = ctx.createOscillator();
              const gain2 = ctx.createGain();
              osc2.connect(gain2);
              gain2.connect(ctx.destination);
              osc2.frequency.value = 1100;
              gain2.gain.value = 0.1;
              osc2.start();
              osc2.stop(ctx.currentTime + 0.15);
            }, 180);
          } catch { /* ignore */ }
        }
      })
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [restaurant?.id]);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      const target = e.target as Node;
      const clickedInsidePanel = panelRef.current?.contains(target);
      const clickedButton = buttonRef.current?.contains(target);
      if (!clickedInsidePanel && !clickedButton) {
        setOpen(false);
      }
    }
    if (open) {
      document.addEventListener('mousedown', handleClick);
    }
    return () => document.removeEventListener('mousedown', handleClick);
  }, [open]);

  async function fetchNotifications() {
    if (!restaurant) return;
    const { data } = await supabase
      .from('notifications')
      .select('*')
      .eq('restaurant_id', restaurant.id)
      .order('created_at', { ascending: false })
      .limit(30);
    if (data) setNotifications(data as Notification[]);
  }

  async function markAllRead() {
    if (!restaurant) return;
    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('restaurant_id', restaurant.id)
      .eq('is_read', false);
    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
  }

  async function markRead(id: string) {
    await supabase.from('notifications').update({ is_read: true }).eq('id', id);
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
  }

  async function deleteNotification(id: string) {
    await supabase.from('notifications').delete().eq('id', id);
    setNotifications(prev => prev.filter(n => n.id !== id));
  }

  function timeAgo(dateStr: string) {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'الآن';
    if (mins < 60) return `منذ ${mins} د`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `منذ ${hrs} س`;
    return `منذ ${Math.floor(hrs / 24)} ي`;
  }

  // Calculate portal panel position from button bounding rect
  function getPanelStyle(): React.CSSProperties {
    const PANEL_WIDTH = 320;
    if (!buttonRef.current) return { position: 'fixed', top: 60, left: 16, zIndex: 99999 };
    const rect = buttonRef.current.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    // Position panel below the bell button, aligned to its left edge
    let left = rect.left;
    // Clamp so the panel never overflows the viewport
    if (left + PANEL_WIDTH > viewportWidth - 8) {
      left = viewportWidth - PANEL_WIDTH - 8;
    }
    if (left < 8) left = 8;
    return {
      position: 'fixed',
      top: rect.bottom + 8,
      left,
      zIndex: 99999,
    };
  }

  return (
    <div className="relative">
      <button
        ref={buttonRef}
        onClick={() => setOpen(o => !o)}
        className="relative p-2 text-slate-500 hover:bg-slate-100 rounded-xl transition-colors"
      >
        <Bell className="w-5 h-5" />
        {unread > 0 && (
          <span className="absolute top-1 right-1 min-w-[16px] h-4 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center px-0.5 border-2 border-white">
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>

      {open && createPortal(
        <motion.div
          ref={panelRef}
          initial={{ opacity: 0, y: 8, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.15 }}
          style={getPanelStyle()}
          className="w-80 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden"
          dir="rtl"
        >
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-slate-600" />
                <span className="font-bold text-slate-800 text-sm">الإشعارات</span>
                {unread > 0 && (
                  <span className="text-[10px] font-bold bg-red-100 text-red-600 px-1.5 py-0.5 rounded-full">{unread}</span>
                )}
              </div>
              <div className="flex items-center gap-1">
                {unread > 0 && (
                  <button onClick={markAllRead} className="text-[11px] text-primary-600 hover:text-primary-700 font-medium px-2 py-1 rounded-lg hover:bg-primary-50">
                    قراءة الكل
                  </button>
                )}
                <button onClick={() => setOpen(false)} className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-50">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="max-h-[360px] overflow-y-auto divide-y divide-slate-50">
              {notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-center px-4">
                  <CheckCircle className="w-8 h-8 text-slate-200 mb-2" />
                  <p className="text-sm text-slate-400">لا توجد إشعارات</p>
                </div>
              ) : (
                notifications.map(n => {
                  const Icon = typeIcon[n.type] ?? Info;
                  const colorClass = typeColor[n.type] ?? typeColor.info;
                  return (
                    <div
                      key={n.id}
                      onClick={() => markRead(n.id)}
                      className={`flex items-start gap-3 px-4 py-3 cursor-pointer transition-colors hover:bg-slate-50 ${!n.is_read ? 'bg-blue-50/40' : ''}`}
                    >
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${colorClass}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-1">
                          <p className={`text-sm font-medium truncate ${!n.is_read ? 'text-slate-900' : 'text-slate-600'}`}>{n.title}</p>
                          <span className="text-[10px] text-slate-400 flex-shrink-0 mt-0.5">{timeAgo(n.created_at)}</span>
                        </div>
                        {n.body && <p className="text-xs text-slate-400 mt-0.5 line-clamp-2">{n.body}</p>}
                      </div>
                      <button
                        onClick={(e) => { e.stopPropagation(); deleteNotification(n.id); }}
                        className="p-0.5 text-slate-300 hover:text-red-400 rounded flex-shrink-0 mt-0.5"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          </motion.div>,
          document.body
        )}
    </div>
  );
}
