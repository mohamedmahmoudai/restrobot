import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, CheckCircle, XCircle, Gift, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface ValidationResult {
  valid: boolean;
  reward?: { name: string; points_used: number; reward_type: string; reward_value: number; reward_item_name: string | null };
  customer?: { name: string; phone: string };
  message: string;
}

export default function RewardValidator() {
  const { restaurant } = useAuth();
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ValidationResult | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  async function validateCode() {
    if (!restaurant || !code.trim()) return;
    setLoading(true);
    setResult(null);

    const { data: redemption } = await supabase
      .from('reward_redemptions')
      .select('*, reward_catalog(name, reward_type, reward_value, reward_item_name), customers(name, phone)')
      .eq('restaurant_id', restaurant.id)
      .eq('redemption_code', code.trim())
      .maybeSingle();

    if (!redemption) {
      setResult({ valid: false, message: 'كود غير صالح أو غير موجود' });
      setLoading(false);
      return;
    }

    if (redemption.status !== 'pending') {
      setResult({ valid: false, message: `هذا الكود تم ${redemption.status === 'approved' ? 'الاستخدام' : 'الرفض'} مسبقاً` });
      setLoading(false);
      return;
    }

    const r = redemption as any;
    setResult({
      valid: true,
      reward: {
        name: r.reward_catalog?.name ?? '',
        points_used: r.points_used,
        reward_type: r.reward_catalog?.reward_type ?? '',
        reward_value: r.reward_catalog?.reward_value ?? 0,
        reward_item_name: r.reward_catalog?.reward_item_name ?? null,
      },
      customer: {
        name: r.customers?.name ?? '',
        phone: r.customers?.phone ?? '',
      },
      message: 'كود صالح',
    });
    setLoading(false);
  }

  async function approveRedemption() {
    if (!restaurant || !result?.valid) return;
    setActionLoading(true);

    const { data: redemption } = await supabase
      .from('reward_redemptions')
      .select('id')
      .eq('restaurant_id', restaurant.id)
      .eq('redemption_code', code.trim())
      .maybeSingle();

    if (redemption) {
      await supabase.from('reward_redemptions').update({
        status: 'approved',
        redeemed_at: new Date().toISOString(),
      }).eq('id', redemption.id);

      // Record transaction
      await supabase.from('points_transactions').insert({
        restaurant_id: restaurant.id,
        customer_id: (await supabase.from('reward_redemptions').select('customer_id').eq('id', redemption.id).single()).data?.customer_id,
        redemption_id: redemption.id,
        type: 'redeemed_used',
        points: 0,
        balance_after: 0,
        notes: `استخدام كود: ${code.trim()}`,
      });
    }

    setResult({ valid: true, message: 'تم الموافقة على الاستبدال بنجاح!' });
    setActionLoading(false);
    setCode('');
  }

  async function rejectRedemption() {
    if (!restaurant || !result?.valid) return;
    setActionLoading(true);

    const { data: redemption } = await supabase
      .from('reward_redemptions')
      .select('id, customer_id, points_used')
      .eq('restaurant_id', restaurant.id)
      .eq('redemption_code', code.trim())
      .maybeSingle();

    if (redemption) {
      // Refund points
      const wallet = await supabase.from('customer_points_wallet').select('id, current_points').eq('restaurant_id', restaurant.id).eq('customer_id', redemption.customer_id).maybeSingle();
      if (wallet?.data) {
        await supabase.from('customer_points_wallet').update({
          current_points: wallet.data.current_points + redemption.points_used,
          updated_at: new Date().toISOString(),
        }).eq('id', wallet.data.id);
      }

      await supabase.from('reward_redemptions').update({ status: 'rejected' }).eq('id', redemption.id);
    }

    setResult({ valid: false, message: 'تم رفض الاستبدال وإعادة النقاط' });
    setActionLoading(false);
    setCode('');
  }

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="أدخل كود المكافأة..."
            value={code}
            onChange={e => setCode(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && validateCode()}
            className="input-field pr-10 font-mono"
          />
        </div>
        <button onClick={validateCode} disabled={loading || !code.trim()} className="btn-primary text-sm px-4">
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
          تحقق
        </button>
      </div>

      <AnimatePresence mode="wait">
        {result && (
          <motion.div
            key={result.message}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className={`card p-5 ${result.valid ? 'border-r-4 border-r-success-500' : 'border-r-4 border-r-danger-500'}`}
          >
            <div className="flex items-center gap-2 mb-3">
              {result.valid ? <CheckCircle className="w-5 h-5 text-success-600" /> : <XCircle className="w-5 h-5 text-danger-600" />}
              <span className={`font-bold text-sm ${result.valid ? 'text-success-700' : 'text-danger-700'}`}>{result.message}</span>
            </div>

            {result.valid && result.reward && result.customer && (
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-primary-50 rounded-xl">
                  <Gift className="w-5 h-5 text-primary-600" />
                  <div>
                    <p className="font-bold text-slate-900 text-sm">{result.reward.name}</p>
                    <p className="text-xs text-slate-500">
                      {result.reward.reward_type === 'free_item' && result.reward.reward_item_name ? `منتج مجاني: ${result.reward.reward_item_name}` :
                       result.reward.reward_type === 'discount_percentage' ? `خصم ${result.reward.reward_value}%` :
                       result.reward.reward_type === 'discount_fixed' ? `خصم ${result.reward.reward_value} ج.م` : ''}
                    </p>
                  </div>
                  <div className="mr-auto text-right">
                    <span className="text-xs text-slate-400">النقاط المستخدمة</span>
                    <p className="font-bold text-primary-600">{result.reward.points_used}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <span className="font-medium">العميل:</span>
                  <span>{result.customer.name}</span>
                  <span className="text-slate-400 font-mono">{result.customer.phone}</span>
                </div>

                <div className="flex gap-3 pt-2">
                  <button onClick={approveRedemption} disabled={actionLoading} className="btn-primary flex-1 text-sm">
                    {actionLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                    موافقة
                  </button>
                  <button onClick={rejectRedemption} disabled={actionLoading} className="btn-danger flex-1 text-sm">
                    {actionLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />}
                    رفض
                  </button>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
