// Reusable skeleton and empty-state components

interface SkeletonProps { className?: string }

export function Skeleton({ className = '' }: SkeletonProps) {
  return <div className={`animate-pulse bg-slate-200 rounded-lg ${className}`} />;
}

export function SkeletonCard() {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
      <Skeleton className="h-4 w-1/3" />
      <Skeleton className="h-8 w-1/2" />
      <Skeleton className="h-3 w-2/3" />
    </div>
  );
}

export function SkeletonRow() {
  return (
    <div className="flex items-center gap-4 py-3 border-b border-slate-100">
      <Skeleton className="h-9 w-9 rounded-xl flex-shrink-0" />
      <div className="flex-1 space-y-2">
        <Skeleton className="h-3.5 w-2/5" />
        <Skeleton className="h-3 w-1/4" />
      </div>
      <Skeleton className="h-6 w-16 rounded-md" />
    </div>
  );
}

export function SkeletonTable({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-0">
      {Array.from({ length: rows }).map((_, i) => <SkeletonRow key={i} />)}
    </div>
  );
}

export function SkeletonGrid({ cols = 3, rows = 1 }: { cols?: number; rows?: number }) {
  return (
    <div className={`grid grid-cols-1 md:grid-cols-${cols} gap-4`}>
      {Array.from({ length: cols * rows }).map((_, i) => <SkeletonCard key={i} />)}
    </div>
  );
}

interface EmptyStateProps {
  icon: React.FC<{ className?: string }>;
  title: string;
  description?: string;
  action?: { label: string; onClick: () => void };
}

export function EmptyState({ icon: Icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center" dir="rtl">
      <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center mb-4">
        <Icon className="w-7 h-7 text-slate-400" />
      </div>
      <h3 className="text-base font-bold text-slate-700 mb-1">{title}</h3>
      {description && <p className="text-sm text-slate-400 max-w-xs">{description}</p>}
      {action && (
        <button onClick={action.onClick} className="mt-4 btn-primary text-sm px-4 py-2">
          {action.label}
        </button>
      )}
    </div>
  );
}

interface RetryProps { onRetry: () => void; message?: string }

export function RetryError({ onRetry, message = 'حدث خطأ أثناء تحميل البيانات' }: RetryProps) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center" dir="rtl">
      <div className="w-12 h-12 bg-red-50 rounded-2xl flex items-center justify-center mb-3">
        <span className="text-2xl">⚠️</span>
      </div>
      <p className="text-sm text-slate-600 mb-3">{message}</p>
      <button onClick={onRetry} className="btn-secondary text-sm px-4 py-2">إعادة المحاولة</button>
    </div>
  );
}
