import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bot, CheckCircle, AlertCircle, Loader2, ExternalLink,
  Wifi, WifiOff, RefreshCw, Eye, EyeOff, Trash2, X
} from 'lucide-react';
import { supabase } from '../lib/supabase';

type WebhookStatus = 'not_configured' | 'pending' | 'active' | 'error' | 'token_invalid';

interface Props {
  restaurant: any;
  onRefresh: () => Promise<void>;
}

export default function TelegramSettingsPanel({ restaurant, onRefresh }: Props) {
  const [botToken, setBotToken] = useState(restaurant?.telegram_bot_token ?? '');
  const [showToken, setShowToken] = useState(false);
  const [status, setStatus] = useState<'idle' | 'loading' | 'done' | 'error'>('idle');
  const [webhookStatus, setWebhookStatus] = useState<WebhookStatus>(
    restaurant?.telegram_webhook_status ?? 'not_configured'
  );
  const [botUsername, setBotUsername] = useState(restaurant?.telegram_bot_username ?? '');
  const [ownerChatIdSet, setOwnerChatIdSet] = useState(!!restaurant?.telegram_owner_chat_id);
  const [ownerStartUrl, setOwnerStartUrl] = useState(() => {
    const u = restaurant?.telegram_bot_username;
    return u ? `https://t.me/${u}?start=owner_${restaurant?.id}` : '';
  });
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [removing, setRemoving] = useState(false);

  const isConnected = webhookStatus === 'active';

  async function getAuthHeaders() {
    const { data: { session } } = await supabase.auth.getSession();
    return session ? { Authorization: `Bearer ${session.access_token}` } : null;
  }

  async function callSetup(body: object) {
    const headers = await getAuthHeaders();
    if (!headers) throw new Error('Session expired');
    const res = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/telegram-setup`,
      { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body) }
    );
    return res.json();
  }

  async function handleSetup() {
    if (!botToken.trim()) { setError('الرجاء إدخال توكن البوت'); return; }
    setError(''); setSuccessMsg(''); setTestResult(null);
    setStatus('loading');
    try {
      const result = await callSetup({ action: 'setup', bot_token: botToken.trim(), restaurant_id: restaurant.id });
      await onRefresh();
      if (result.ok) {
        setWebhookStatus('active');
        setBotUsername(result.bot_username ?? '');
        setOwnerStartUrl(result.owner_start_url ?? '');
        setSuccessMsg(`تم ربط @${result.bot_username} بنجاح!`);
        setStatus('done');
      } else {
        setWebhookStatus(result.step === 'validate_token' ? 'token_invalid' : 'error');
        setError(result.error ?? 'فشل الإعداد');
        setStatus('error');
      }
    } catch (e) {
      setError('حدث خطأ في الاتصال'); setStatus('error');
    }
  }

  async function handleTest() {
    setTesting(true); setTestResult(null);
    try {
      const result = await callSetup({ action: 'test', restaurant_id: restaurant.id });
      if (result.ok) {
        setOwnerChatIdSet(true);
        await onRefresh();
      }
      setTestResult({ ok: result.ok, message: result.ok ? 'تم إرسال رسالة اختبارية بنجاح!' : result.error ?? 'فشل الاختبار' });
    } catch { setTestResult({ ok: false, message: 'فشل الاتصال بالخادم' }); }
    finally { setTesting(false); }
  }

  async function handleRemove() {
    if (!confirm('هل تريد إزالة ربط البوت نهائياً؟')) return;
    setRemoving(true);
    try {
      await callSetup({ action: 'remove', restaurant_id: restaurant.id });
      await onRefresh();
      setWebhookStatus('not_configured');
      setBotToken(''); setBotUsername(''); setOwnerStartUrl('');
      setOwnerChatIdSet(false); setSuccessMsg(''); setError('');
    } catch { setError('فشل إزالة البوت'); }
    finally { setRemoving(false); }
  }

  const statusMap: Record<WebhookStatus, { label: string; color: string; Icon: any }> = {
    not_configured: { label: 'غير مُضبط',         color: 'text-slate-500  bg-slate-50   border-slate-200',  Icon: WifiOff     },
    pending:        { label: 'في الانتظار',        color: 'text-amber-600  bg-amber-50   border-amber-200',  Icon: AlertCircle },
    active:         { label: 'متصل ونشط',          color: 'text-success-700 bg-success-50 border-success-200', Icon: CheckCircle },
    error:          { label: 'خطأ في الويب هوك',  color: 'text-danger-600  bg-danger-50  border-danger-200',  Icon: AlertCircle },
    token_invalid:  { label: 'توكن غير صالح',      color: 'text-danger-600  bg-danger-50  border-danger-200',  Icon: X           },
  };
  const { label, color, Icon } = statusMap[webhookStatus];

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-bold text-slate-900 text-sm">تكامل بوت تيليجرام</h3>
          <p className="text-xs text-slate-500 mt-0.5">ربط بوت لاستقبال الطلبات — فقط أدخل التوكن</p>
        </div>
        {isConnected && (
          <button onClick={handleRemove} disabled={removing} className="flex items-center gap-1.5 text-xs text-danger-600 hover:text-danger-800 transition-colors">
            {removing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
            إزالة الربط
          </button>
        )}
      </div>

      {/* Status badge */}
      <div className={`flex items-center gap-2.5 px-4 py-3 rounded-xl border text-sm font-medium ${color}`}>
        <Icon className="w-4 h-4 flex-shrink-0" />
        <span>{label}</span>
        {botUsername && isConnected && (
          <span className="mr-auto font-mono text-xs opacity-70">@{botUsername}</span>
        )}
      </div>

      <AnimatePresence>
        {error && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="bg-danger-50 border border-danger-200 text-danger-700 text-sm px-4 py-3 rounded-xl flex items-start gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" /><span>{error}</span>
          </motion.div>
        )}
        {successMsg && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="bg-success-50 border border-success-200 text-success-700 text-sm px-4 py-3 rounded-xl flex items-start gap-2">
            <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5" /><span>{successMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Token input */}
      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Telegram Bot Token {!isConnected && <span className="text-danger-500">*</span>}
        </label>
        <div className="relative">
          <Bot className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type={showToken ? 'text' : 'password'}
            value={botToken}
            onChange={e => { setBotToken(e.target.value); setError(''); }}
            placeholder="123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
            className="input-field pr-10 pl-10 font-mono text-xs"
            dir="ltr"
            disabled={status === 'loading'}
          />
          <button type="button" onClick={() => setShowToken(v => !v)}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors">
            {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
        <p className="text-xs text-slate-400 mt-1">احصل على التوكن من <span className="font-mono">@BotFather</span> في تيليجرام</p>
      </div>

      {/* After connection */}
      {isConnected && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
          className="bg-success-50 border border-success-200 rounded-xl p-4 space-y-3">
          <p className="text-sm font-semibold text-success-800 flex items-center gap-2">
            <CheckCircle className="w-4 h-4" /> البوت مرتبط بنجاح
          </p>

          {/* Owner activation link */}
          {ownerStartUrl && (
            <div className="space-y-2">
              <p className="text-xs text-success-700 font-medium">لاستقبال إشعارات الطلبات على هاتفك:</p>
              <a href={ownerStartUrl} target="_blank" rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-success-600 hover:bg-success-700 text-white rounded-xl text-sm font-semibold transition-colors">
                <ExternalLink className="w-3.5 h-3.5" />
                فتح @{botUsername} وتفعيل الإشعارات
              </a>
              <p className="text-xs text-success-600">
                {ownerChatIdSet
                  ? '✅ تم تفعيل الإشعارات — ستصل الطلبات الجديدة لهاتفك'
                  : 'اضغط الزر أعلاه ثم أرسل /start لتفعيل إشعارات الطلبات'}
              </p>
            </div>
          )}

          {/* Test button */}
          <div className="pt-1 border-t border-success-200">
            <button onClick={handleTest} disabled={testing || !ownerChatIdSet}
              className="flex items-center gap-2 text-sm font-medium text-success-700 hover:text-success-900 transition-colors disabled:opacity-50">
              {testing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wifi className="w-4 h-4" />}
              {testing ? 'جاري اختبار الاتصال...' : 'اختبار الاتصال (إرسال رسالة تجريبية)'}
            </button>
            {!ownerChatIdSet && (
              <p className="text-xs text-slate-500 mt-1">فعّل الإشعارات أولاً بالضغط على الزر أعلاه وإرسال /start</p>
            )}
            <AnimatePresence>
              {testResult && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  className={`mt-2 text-xs px-3 py-2 rounded-lg ${testResult.ok ? 'bg-success-100 text-success-800' : 'bg-danger-50 text-danger-700'}`}>
                  {testResult.ok ? <CheckCircle className="w-3 h-3 inline ml-1" /> : <AlertCircle className="w-3 h-3 inline ml-1" />}
                  {testResult.message}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      )}

      {/* Setup / Re-setup button */}
      <button
        onClick={handleSetup}
        disabled={status === 'loading' || !botToken.trim()}
        className="btn-primary w-full py-3"
      >
        {status === 'loading' ? (
          <><Loader2 className="w-4 h-4 animate-spin" /> جاري الإعداد التلقائي...</>
        ) : isConnected ? (
          <><RefreshCw className="w-4 h-4" /> إعادة تسجيل الويب هوك</>
        ) : (
          <><Bot className="w-4 h-4" /> ربط البوت تلقائياً</>
        )}
      </button>

      {/* Info box */}
      <div className="bg-slate-50 rounded-xl p-4 text-xs text-slate-600 space-y-1.5">
        <p className="font-semibold text-slate-700">ما يحدث عند الضغط على "ربط البوت":</p>
        {['التحقق من صحة التوكن عبر Telegram API', 'تسجيل Webhook تلقائياً', 'حفظ اسم البوت', 'تفعيل استقبال الطلبات فوراً'].map((s, i) => (
          <div key={i} className="flex items-center gap-2">
            <span className="w-4 h-4 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center font-bold text-[10px] flex-shrink-0">{i + 1}</span>
            {s}
          </div>
        ))}
      </div>
    </div>
  );
}
