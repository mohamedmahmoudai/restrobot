import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, CreditCard as Edit2, Trash2, Check, X, FolderOpen, Loader2, AlertCircle } from 'lucide-react';
import { useOnboarding } from '../../contexts/OnboardingContext';

const SUGGESTED_CATEGORIES = [
  { name: 'مشويات', nameAr: 'مشويات' },
  { name: 'بيتزا', nameAr: 'بيتزا' },
  { name: 'برجر', nameAr: 'برجر' },
  { name: 'مشروبات', nameAr: 'مشروبات' },
  { name: 'حلويات', nameAr: 'حلويات' },
  { name: 'مقبلات', nameAr: 'مقبلات' },
  { name: 'أطباق رئيسية', nameAr: 'أطباق رئيسية' },
  { name: 'سندوتشات', nameAr: 'سندوتشات' },
];

export default function StepCategories() {
  const { state, addCategory, updateCategory, deleteCategory, completeAndAdvance } = useOnboarding();

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [categoryName, setCategoryName] = useState('');
  const [categoryNameAr, setCategoryNameAr] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  function resetForm() {
    setCategoryName('');
    setCategoryNameAr('');
    setShowForm(false);
    setEditingId(null);
    setError('');
  }

  async function handleAdd() {
    if (!categoryName.trim() || !categoryNameAr.trim()) {
      setError('يرجى إدخال اسم الفئة باللغتين');
      return;
    }

    setLoading(true);
    setError('');

    const result = await addCategory(categoryName.trim(), categoryNameAr.trim());

    if (result.error) {
      setError(result.error);
    } else {
      resetForm();
    }

    setLoading(false);
  }

  async function handleUpdate() {
    if (!editingId || !categoryName.trim() || !categoryNameAr.trim()) {
      setError('يرجى إدخال اسم الفئة باللغتين');
      return;
    }

    setLoading(true);
    setError('');

    const result = await updateCategory(editingId, categoryName.trim(), categoryNameAr.trim());

    if (result.error) {
      setError(result.error);
    } else {
      resetForm();
    }

    setLoading(false);
  }

  async function handleDelete(id: string) {
    if (!confirm('هل أنت متأكد من حذف هذه الفئة؟')) return;
    await deleteCategory(id);
  }

  function startEdit(id: string, name: string, nameAr: string) {
    setEditingId(id);
    setCategoryName(name);
    setCategoryNameAr(nameAr);
    setShowForm(true);
  }

  async function handleContinue() {
    if (state.categories.length === 0) {
      setError('يجب إضافة فئة واحدة على الأقل');
      return;
    }

    await completeAndAdvance(2);
  }

  function addSuggested(name: string, nameAr: string) {
    setCategoryName(name);
    setCategoryNameAr(nameAr);
    setShowForm(true);
  }

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <FolderOpen className="w-12 h-12 text-primary-600 mx-auto mb-3" />
        <p className="text-slate-600">أضف فئات المنيو (التيكات)</p>
      </div>

      {error && (
        <div className="bg-danger-50 border border-danger-200 text-danger-600 text-sm px-4 py-3 rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      {/* Suggested Categories */}
      {state.categories.length === 0 && !showForm && (
        <div className="mb-6">
          <p className="text-xs text-slate-500 mb-3">اقتراحات سريعة:</p>
          <div className="flex flex-wrap gap-2">
            {SUGGESTED_CATEGORIES.map((cat) => (
              <button
                key={cat.name}
                onClick={() => addSuggested(cat.name, cat.nameAr)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm rounded-lg transition-colors"
              >
                {cat.nameAr}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Categories List */}
      <div className="space-y-3">
        <AnimatePresence>
          {state.categories.map((cat, index) => (
            <motion.div
              key={cat.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ delay: index * 0.05 }}
              className="flex items-center justify-between p-4 bg-slate-50 rounded-xl"
            >
              <div>
                <p className="font-semibold text-slate-900">{cat.name_ar}</p>
                <p className="text-xs text-slate-400">{cat.name}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => startEdit(cat.id, cat.name, cat.name_ar)}
                  className="p-2 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(cat.id)}
                  className="p-2 text-slate-400 hover:text-danger-600 hover:bg-danger-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {state.categories.length === 0 && !showForm && (
          <div className="text-center py-8 text-slate-400">
            <FolderOpen className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>لم تضاف أي فئات بعد</p>
          </div>
        )}
      </div>

      {/* Add/Edit Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-slate-50 rounded-xl p-4 space-y-3"
          >
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">الاسم (عربي)</label>
                <input
                  type="text"
                  value={categoryNameAr}
                  onChange={(e) => setCategoryNameAr(e.target.value)}
                  placeholder="مشويات"
                  className="input-field text-sm"
                  disabled={loading}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">الاسم (EN)</label>
                <input
                  type="text"
                  value={categoryName}
                  onChange={(e) => setCategoryName(e.target.value)}
                  placeholder="Grill"
                  className="input-field text-sm"
                  disabled={loading}
                />
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={resetForm}
                className="flex-1 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-sm font-medium transition-colors"
              >
                <X className="w-4 h-4 inline ml-1" />
                إلغاء
              </button>
              <button
                onClick={editingId ? handleUpdate : handleAdd}
                disabled={loading}
                className="flex-1 py-2 btn-primary text-sm"
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin mx-auto" />
                ) : (
                  <>
                    <Check className="w-4 h-4 inline ml-1" />
                    {editingId ? 'تحديث' : 'إضافة'}
                  </>
                )}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Button */}
      {!showForm && (
        <button
          onClick={() => setShowForm(true)}
          className="w-full py-3 border-2 border-dashed border-slate-300 hover:border-primary-400 hover:bg-primary-50 text-slate-600 hover:text-primary-600 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          إضافة فئة جديدة
        </button>
      )}

      {/* Continue Button */}
      {state.categories.length > 0 && (
        <div className="pt-4">
          <button
            onClick={handleContinue}
            disabled={state.categories.length === 0 || loading}
            className="w-full btn-primary py-3"
          >
            <Check className="w-4 h-4" />
            حفظ ومتابعة ({state.categories.length} فئات)
          </button>
        </div>
      )}
    </div>
  );
}
