import { useState } from 'react';
import { motion } from 'framer-motion';
import { PartyPopper, CheckCircle, UtensilsCrossed, FolderOpen, MapPin, Bot, ArrowRight, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useOnboarding } from '../../contexts/OnboardingContext';
import { useAuth } from '../../contexts/AuthContext';

export default function StepComplete() {
  const { state, completeOnboarding } = useOnboarding();
  const { refreshRestaurant } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  async function handleFinish() {
    setLoading(true);
    await completeOnboarding();
    await refreshRestaurant();
    setLoading(false);
    navigate('/dashboard');
  }

  const stats = [
    {
      icon: FolderOpen,
      label: 'الفئات',
      value: state.categories.length,
      color: 'bg-primary-100 text-primary-600',
    },
    {
      icon: UtensilsCrossed,
      label: 'المنتجات',
      value: state.products.length,
      color: 'bg-success-100 text-success-600',
    },
    {
      icon: MapPin,
      label: 'مناطق التوصيل',
      value: state.deliveryZones.length,
      color: 'bg-amber-100 text-amber-600',
    },
    {
      icon: Bot,
      label: 'البوت',
      value: state.completedSteps.includes(5) ? 'متصل' : 'غير متصل',
      color: state.completedSteps.includes(5) ? 'bg-primary-100 text-primary-600' : 'bg-slate-100 text-slate-400',
    },
  ];

  return (
    <div className="space-y-6 text-center">
      {/* Success Icon */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', stiffness: 200, damping: 15 }}
        className="relative mx-auto w-24 h-24"
      >
        <div className="absolute inset-0 bg-success-500/20 rounded-full animate-ping" />
        <div className="relative w-24 h-24 bg-success-500 rounded-full flex items-center justify-center">
          <PartyPopper className="w-10 h-10 text-white" />
        </div>
      </motion.div>

      {/* Title */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <h2 className="text-2xl font-bold text-slate-900 mb-2">
          مطعمك جاهز الآن!
        </h2>
        <p className="text-slate-500">
          تم إعداد المطعم بنجاح. يمكنك البدء في استقبال الطلبات
        </p>
      </motion.div>

      {/* Stats Grid */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="grid grid-cols-2 gap-3 pt-4"
      >
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 + index * 0.1 }}
            className="bg-slate-50 rounded-xl p-4 text-center"
          >
            <div className={`w-10 h-10 ${stat.color} rounded-xl flex items-center justify-center mx-auto mb-2`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <p className="text-xl font-bold text-slate-900">{stat.value}</p>
            <p className="text-xs text-slate-500">{stat.label}</p>
          </motion.div>
        ))}
      </motion.div>

      {/* Checklist */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-slate-50 rounded-xl p-4 text-right"
      >
        <p className="text-sm font-semibold text-slate-900 mb-3">تم بنجاح:</p>
        <div className="space-y-2">
          {[
            'تسجيل بيانات المطعم',
            'إنشاء فئات المنيو',
            'إضافة المنتجات الأولى',
            'تحديد مناطق التوصيل',
            state.completedSteps.includes(5) ? 'ربط بوت تيليجرام' : 'تخطي ربط تيليجرام',
          ].map((item, index) => (
            <div key={index} className="flex items-center gap-2 text-sm text-slate-600">
              <CheckCircle className="w-4 h-4 text-success-500 flex-shrink-0" />
              {item}
            </div>
          ))}
        </div>
      </motion.div>

      {/* Finish Button */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="pt-4"
      >
        <button
          onClick={handleFinish}
          disabled={loading}
          className="w-full btn-primary py-4 text-base"
        >
          {loading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              جارٍ الإنهاء...
            </>
          ) : (
            <>
              الانتقال إلى لوحة التحكم
              <ArrowRight className="w-5 h-5" />
            </>
          )}
        </button>
      </motion.div>
    </div>
  );
}
