import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, CreditCard as Edit2, Trash2, Check, X, MapPin, Loader2, AlertCircle, Truck } from 'lucide-react';
import { useOnboarding } from '../../contexts/OnboardingContext';

const SUGGESTED_ZONES = [
  { name: 'المعادي', price: 50 },
  { name: 'مدينة نصر', price: 40 },
  { name: 'التجمع', price: 70 },
  { name: 'مصر الجديدة', price: 45 },
  { name: 'القاهرة الجديدة', price: 80 },
  { name: 'الزمالك', price: 35 },
  { name: 'الدقي', price: 40 },
  { name: 'المهندسين', price: 45 },
];

export default function StepDelivery() {
  const { state, addDeliveryZone, updateDeliveryZone, deleteDeliveryZone, completeAndAdvance } = useOnboarding();

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [zoneName, setZoneName] = useState('');
  const [zonePrice, setZonePrice] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  function resetForm() {
    setZoneName('');
    setZonePrice('');
    setShowForm(false);
    setEditingId(null);
    setError('');
  }

  function startEdit(id: string, name: string, price: number) {
    setEditingId(id);
    setZoneName(name);
    setZonePrice(price.toString());
    setShowForm(true);
  }

  async function handleAdd() {
    if (!zoneName.trim() || !zonePrice) {
      setError('يرجى إدخال اسم المنطقة وسعر التوصيل');
      return;
    }

    setLoading(true);
    setError('');

    const result = await addDeliveryZone(zoneName.trim(), parseFloat(zonePrice) || 0);

    if (result.error) {
      setError(result.error);
    } else {
      resetForm();
    }

    setLoading(false);
  }

  async function handleUpdate() {
    if (!editingId || !zoneName.trim() || !zonePrice) {
      setError('يرجى إدخال اسم المنطقة وسعر التوصيل');
      return;
    }

    setLoading(true);
    setError('');

    const result = await updateDeliveryZone(editingId, zoneName.trim(), parseFloat(zonePrice) || 0);

    if (result.error) {
      setError(result.error);
    } else {
      resetForm();
    }

    setLoading(false);
  }

  async function handleDelete(id: string) {
    if (!confirm('هل أنت متأكد من حذف هذه المنطقة؟')) return;
    await deleteDeliveryZone(id);
  }

  async function handleContinue() {
    if (state.deliveryZones.length === 0) {
      setError('يجب إضافة منطقة توصيل واحدة على الأقل');
      return;
    }

    await completeAndAdvance(4);
  }

  function addSuggested(name: string, price: number) {
    setZoneName(name);
    setZonePrice(price.toString());
    setShowForm(true);
  }

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <Truck className="w-12 h-12 text-primary-600 mx-auto mb-3" />
        <p className="text-slate-600">حدد مناطق التوصيل والأسعار</p>
      </div>

      {error && (
        <div className="bg-danger-50 border border-danger-200 text-danger-600 text-sm px-4 py-3 rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      {/* Suggested Zones */}
      {state.deliveryZones.length === 0 && !showForm && (
        <div className="mb-6">
          <p className="text-xs text-slate-500 mb-3">اقتراحات سريعة:</p>
          <div className="flex flex-wrap gap-2">
            {SUGGESTED_ZONES.map((zone) => (
              <button
                key={zone.name}
                onClick={() => addSuggested(zone.name, zone.price)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm rounded-lg transition-colors"
              >
                {zone.name} ({zone.price} ج.م)
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Zones List */}
      <div className="space-y-3">
        <AnimatePresence>
          {state.deliveryZones.map((zone, index) => (
            <motion.div
              key={zone.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ delay: index * 0.05 }}
              className="flex items-center justify-between p-4 bg-slate-50 rounded-xl"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-primary-600" />
                </div>
                <div>
                  <p className="font-semibold text-slate-900">{zone.name}</p>
                  <p className="text-xl font-bold text-primary-600">{zone.price} ج.م</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => startEdit(zone.id, zone.name, zone.price)}
                  className="p-2 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(zone.id)}
                  className="p-2 text-slate-400 hover:text-danger-600 hover:bg-danger-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {state.deliveryZones.length === 0 && !showForm && (
          <div className="text-center py-8 text-slate-400">
            <MapPin className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>لم تضاف أي مناطق توصيل بعد</p>
          </div>
        )}
      </div>

      {/* Add/Edit Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-slate-50 rounded-xl p-4 space-y-3"
          >
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">اسم المنطقة</label>
                <input
                  type="text"
                  value={zoneName}
                  onChange={(e) => setZoneName(e.target.value)}
                  placeholder="المعادي"
                  className="input-field text-sm"
                  disabled={loading}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">سعر التوصيل (ج.م)</label>
                <input
                  type="number"
                  value={zonePrice}
                  onChange={(e) => setZonePrice(e.target.value)}
                  placeholder="50"
                  className="input-field text-sm"
                  disabled={loading}
                />
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={resetForm}
                className="flex-1 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-sm font-medium transition-colors"
              >
                <X className="w-4 h-4 inline ml-1" />
                إلغاء
              </button>
              <button
                onClick={editingId ? handleUpdate : handleAdd}
                disabled={loading}
                className="flex-1 py-2 btn-primary text-sm"
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin mx-auto" />
                ) : (
                  <>
                    <Check className="w-4 h-4 inline ml-1" />
                    {editingId ? 'تحديث' : 'إضافة'}
                  </>
                )}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Button */}
      {!showForm && (
        <button
          onClick={() => setShowForm(true)}
          className="w-full py-3 border-2 border-dashed border-slate-300 hover:border-primary-400 hover:bg-primary-50 text-slate-600 hover:text-primary-600 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          إضافة منطقة جديدة
        </button>
      )}

      {/* Continue Button */}
      {state.deliveryZones.length > 0 && (
        <div className="pt-4">
          <button
            onClick={handleContinue}
            disabled={state.deliveryZones.length === 0 || loading}
            className="w-full btn-primary py-3"
          >
            <Check className="w-4 h-4" />
            حفظ ومتابعة ({state.deliveryZones.length} مناطق)
          </button>
        </div>
      )}
    </div>
  );
}
