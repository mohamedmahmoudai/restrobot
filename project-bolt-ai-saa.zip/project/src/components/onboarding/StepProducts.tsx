import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, CreditCard as Edit2, Trash2, Check, X, UtensilsCrossed, Loader2, AlertCircle, Image } from 'lucide-react';
import { useOnboarding } from '../../contexts/OnboardingContext';
import type { MenuItem } from '../../lib/database.types';

export default function StepProducts() {
  const { state, addProduct, updateProduct, deleteProduct, completeAndAdvance } = useOnboarding();

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [productName, setProductName] = useState('');
  const [productNameAr, setProductNameAr] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [productCategory, setProductCategory] = useState('');
  const [productDescription, setProductDescription] = useState('');
  const [productImage, setProductImage] = useState('');
  const [productAvailable, setProductAvailable] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  function resetForm() {
    setProductName('');
    setProductNameAr('');
    setProductPrice('');
    setProductCategory('');
    setProductDescription('');
    setProductImage('');
    setProductAvailable(true);
    setShowForm(false);
    setEditingId(null);
    setError('');
  }

  function startEdit(product: MenuItem) {
    setEditingId(product.id);
    setProductName(product.name);
    setProductNameAr(product.name_ar);
    setProductPrice(product.price.toString());
    setProductCategory(product.category_id || '');
    setProductDescription(product.description || '');
    setProductImage(product.image_url || '');
    setProductAvailable(product.is_available);
    setShowForm(true);
  }

  async function handleAdd() {
    if (!productNameAr.trim() || !productPrice) {
      setError('يرجى إدخال اسم المنتج والسعر');
      return;
    }

    setLoading(true);
    setError('');

    const result = await addProduct({
      name: productName.trim() || productNameAr.trim(),
      name_ar: productNameAr.trim(),
      price: parseFloat(productPrice) || 0,
      category_id: productCategory || null,
      description: productDescription || null,
      image_url: productImage || null,
      is_available: productAvailable,
    });

    if (result.error) {
      setError(result.error);
    } else {
      resetForm();
    }

    setLoading(false);
  }

  async function handleUpdate() {
    if (!editingId || !productNameAr.trim() || !productPrice) {
      setError('يرجى إدخال اسم المنتج والسعر');
      return;
    }

    setLoading(true);
    setError('');

    const result = await updateProduct(editingId, {
      name: productName.trim() || productNameAr.trim(),
      name_ar: productNameAr.trim(),
      price: parseFloat(productPrice) || 0,
      category_id: productCategory || null,
      description: productDescription || null,
      image_url: productImage || null,
      is_available: productAvailable,
    });

    if (result.error) {
      setError(result.error);
    } else {
      resetForm();
    }

    setLoading(false);
  }

  async function handleDelete(id: string) {
    if (!confirm('هل أنت متأكد من حذف هذا المنتج؟')) return;
    await deleteProduct(id);
  }

  async function handleContinue() {
    if (state.products.length === 0) {
      setError('يجب إضافة منتج واحد على الأقل');
      return;
    }

    await completeAndAdvance(3);
  }

  const getCategoryName = (categoryId: string | null) => {
    if (!categoryId) return 'غير مصنف';
    const cat = state.categories.find(c => c.id === categoryId);
    return cat?.name_ar || 'غير مصنف';
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <UtensilsCrossed className="w-12 h-12 text-primary-600 mx-auto mb-3" />
        <p className="text-slate-600">أضف منتجاتك الأولى</p>
      </div>

      {error && (
        <div className="bg-danger-50 border border-danger-200 text-danger-600 text-sm px-4 py-3 rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      {/* Products Grid */}
      <div className="grid grid-cols-2 gap-3">
        <AnimatePresence>
          {state.products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ delay: index * 0.05 }}
              className={`relative rounded-xl overflow-hidden border ${
                product.is_available ? 'border-slate-200 bg-white' : 'border-slate-100 bg-slate-50 opacity-60'
              }`}
            >
              <div className="aspect-square relative">
                {product.image_url ? (
                  <img
                    src={product.image_url}
                    alt={product.name_ar}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-slate-100 flex items-center justify-center">
                    <Image className="w-8 h-8 text-slate-300" />
                  </div>
                )}
                <div className="absolute top-2 left-2 flex gap-1">
                  <button
                    onClick={() => startEdit(product)}
                    className="p-1.5 bg-white/90 hover:bg-white text-slate-600 rounded-lg shadow-sm backdrop-blur-sm"
                  >
                    <Edit2 className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => handleDelete(product.id)}
                    className="p-1.5 bg-white/90 hover:bg-danger-50 text-danger-600 rounded-lg shadow-sm backdrop-blur-sm"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
              <div className="p-3">
                <p className="font-semibold text-slate-900 text-sm truncate">{product.name_ar}</p>
                <p className="text-xs text-slate-400 mb-1">{getCategoryName(product.category_id)}</p>
                <p className="text-primary-600 font-bold">{product.price} ج.م</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Add Product Card */}
        {!showForm && (
          <motion.button
            onClick={() => setShowForm(true)}
            className="aspect-square rounded-xl border-2 border-dashed border-slate-300 hover:border-primary-400 bg-slate-50 hover:bg-primary-50 flex items-center justify-center transition-all"
          >
            <div className="text-center">
              <Plus className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm text-slate-500">إضافة منتج</p>
            </div>
          </motion.button>
        )}
      </div>

      {/* Add/Edit Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-slate-50 rounded-xl p-4 space-y-3"
          >
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">الاسم (عربي)</label>
                <input
                  type="text"
                  value={productNameAr}
                  onChange={(e) => setProductNameAr(e.target.value)}
                  placeholder="برجر لحم"
                  className="input-field text-sm"
                  disabled={loading}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">الاسم (EN)</label>
                <input
                  type="text"
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  placeholder="Beef Burger"
                  className="input-field text-sm"
                  disabled={loading}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">السعر (ج.م)</label>
                <input
                  type="number"
                  value={productPrice}
                  onChange={(e) => setProductPrice(e.target.value)}
                  placeholder="50"
                  className="input-field text-sm"
                  disabled={loading}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">الفئة</label>
                <select
                  value={productCategory}
                  onChange={(e) => setProductCategory(e.target.value)}
                  className="input-field text-sm"
                  disabled={loading}
                >
                  <option value="">غير مصنف</option>
                  {state.categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name_ar}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">الوصف (اختياري)</label>
              <textarea
                value={productDescription}
                onChange={(e) => setProductDescription(e.target.value)}
                placeholder="وصف قصير للمنتج..."
                className="input-field text-sm min-h-[60px] resize-none"
                disabled={loading}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">رابط الصورة (اختياري)</label>
              <input
                type="url"
                value={productImage}
                onChange={(e) => setProductImage(e.target.value)}
                placeholder="https://..."
                className="input-field text-sm"
                disabled={loading}
              />
            </div>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={productAvailable}
                onChange={(e) => setProductAvailable(e.target.checked)}
                className="w-4 h-4 rounded border-slate-300 text-primary-600 focus:ring-primary-500"
                disabled={loading}
              />
              <span className="text-sm text-slate-700">متوفر</span>
            </label>

            <div className="flex gap-2 pt-2">
              <button
                onClick={resetForm}
                className="flex-1 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-sm font-medium transition-colors"
              >
                <X className="w-4 h-4 inline ml-1" />
                إلغاء
              </button>
              <button
                onClick={editingId ? handleUpdate : handleAdd}
                disabled={loading}
                className="flex-1 py-2 btn-primary text-sm"
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin mx-auto" />
                ) : (
                  <>
                    <Check className="w-4 h-4 inline ml-1" />
                    {editingId ? 'تحديث' : 'إضافة'}
                  </>
                )}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Continue Button */}
      {state.products.length > 0 && !showForm && (
        <div className="pt-4">
          <button
            onClick={handleContinue}
            disabled={loading}
            className="w-full btn-primary py-3"
          >
            <Check className="w-4 h-4" />
            حفظ ومتابعة ({state.products.length} منتجات)
          </button>
        </div>
      )}
    </div>
  );
}
