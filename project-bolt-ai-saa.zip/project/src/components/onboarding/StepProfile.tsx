import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Building2, Phone, MapPin, ChefHat, Upload, Loader2, Check } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useOnboarding } from '../../contexts/OnboardingContext';
import { supabase } from '../../lib/supabase';

const CUISINE_TYPES = [
  { value: 'grill', label: 'مشويات', labelEn: 'Grill' },
  { value: 'pizza', label: 'بيتزا', labelEn: 'Pizza' },
  { value: 'fast_food', label: 'وجبات سريعة', labelEn: 'Fast Food' },
  { value: 'cafe', label: 'كافيه', labelEn: 'Cafe' },
  { value: 'desserts', label: 'حلويات', labelEn: 'Desserts' },
  { value: 'seafood', label: 'مأكولات بحرية', labelEn: 'Seafood' },
  { value: 'oriental', label: 'مأكولات شرقية', labelEn: 'Oriental' },
  { value: 'mixed', label: 'متنوع', labelEn: 'Mixed' },
];

export default function StepProfile() {
  const { restaurant, refreshRestaurant } = useAuth();
  const { completeAndAdvance } = useOnboarding();

  const [name, setName] = useState(restaurant?.name || '');
  const [logoUrl, setLogoUrl] = useState(restaurant?.logo_url || '');
  const [phone, setPhone] = useState(restaurant?.phone || '');
  const [address, setAddress] = useState(restaurant?.address || '');
  const [cuisineType, setCuisineType] = useState(restaurant?.cuisine_type || '');
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (restaurant) {
      setName(restaurant.name || '');
      setLogoUrl(restaurant.logo_url || '');
      setPhone(restaurant.phone || '');
      setAddress(restaurant.address || '');
      setCuisineType(restaurant.cuisine_type || '');
    }
  }, [restaurant]);

  async function handleSave() {
    if (!restaurant) return;
    if (!name.trim()) {
      alert('يرجى إدخال اسم المطعم');
      return;
    }

    setLoading(true);

    const { error } = await supabase
      .from('restaurants')
      .update({
        name: name.trim(),
        logo_url: logoUrl || null,
        phone: phone || null,
        address: address || null,
        cuisine_type: cuisineType || null,
      })
      .eq('id', restaurant.id);

    setLoading(false);

    if (error) {
      alert('حدث خطأ أثناء الحفظ');
      return;
    }

    setSaved(true);
    await refreshRestaurant();
    await completeAndAdvance(1);
    setSaved(false);
  }

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <Building2 className="w-12 h-12 text-primary-600 mx-auto mb-3" />
        <p className="text-slate-600">أدخل بيانات مطعمك الأساسية</p>
      </div>

      <div className="space-y-4">
        {/* Restaurant Name */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">اسم المطعم</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="مطعم الفخامة"
            className="input-field"
          />
        </div>

        {/* Logo */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">شعار المطعم</label>
          <div className="flex items-center gap-4">
            {logoUrl ? (
              <img
                src={logoUrl}
                alt="Logo"
                className="w-16 h-16 rounded-xl object-cover border border-slate-200"
              />
            ) : (
              <div className="w-16 h-16 rounded-xl bg-slate-100 flex items-center justify-center">
                <Building2 className="w-6 h-6 text-slate-400" />
              </div>
            )}
            <input
              type="url"
              value={logoUrl}
              onChange={(e) => setLogoUrl(e.target.value)}
              placeholder="رابط الصورة"
              className="input-field flex-1"
            />
          </div>
          <p className="text-xs text-slate-400 mt-1">
            أدخل رابط صورة الشعار (يمكنك رفع الصورة على موقع استضافة)
          </p>
        </div>

        {/* Phone */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">رقم الهاتف</label>
          <div className="relative">
            <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+20 1 234 5678"
              className="input-field pr-10"
              dir="ltr"
            />
          </div>
        </div>

        {/* Address */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">العنوان</label>
          <div className="relative">
            <MapPin className="absolute right-3 top-3 w-4 h-4 text-slate-400" />
            <textarea
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="القاهرة، مصر الجديدة، شارع الحجاز"
              className="input-field pr-10 min-h-[80px] resize-none"
            />
          </div>
        </div>

        {/* Cuisine Type */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">نوع المطبخ</label>
          <div className="relative">
            <ChefHat className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <select
              value={cuisineType}
              onChange={(e) => setCuisineType(e.target.value)}
              className="input-field pr-10 appearance-none"
            >
              <option value="">اختر نوع المطبخ</option>
              {CUISINE_TYPES.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="pt-4">
        <button
          onClick={handleSave}
          disabled={loading || !name.trim()}
          className="w-full btn-primary py-3"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              جارٍ الحفظ...
            </>
          ) : saved ? (
            <>
              <Check className="w-4 h-4" />
              تم الحفظ بنجاح
            </>
          ) : (
            'حفظ ومتابعة'
          )}
        </button>
      </div>
    </div>
  );
}
