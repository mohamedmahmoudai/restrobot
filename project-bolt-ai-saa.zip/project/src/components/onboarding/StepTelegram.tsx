import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bot, Check, Loader2, AlertCircle, ExternalLink, HelpCircle,
  CheckCircle, Wifi, WifiOff, RefreshCw, Eye, EyeOff, X
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useOnboarding } from '../../contexts/OnboardingContext';
import { supabase } from '../../lib/supabase';

type SetupStatus = 'idle' | 'validating' | 'registering' | 'done' | 'error';
type WebhookStatus = 'not_configured' | 'pending' | 'active' | 'error' | 'token_invalid';

interface SetupResult {
  ok: boolean;
  step?: string;
  error?: string;
  bot_username?: string;
  bot_first_name?: string;
  webhook_url?: string;
  message?: string;
}

export default function StepTelegram() {
  const { restaurant, refreshRestaurant } = useAuth();
  const { completeAndAdvance } = useOnboarding();

  const [botToken, setBotToken] = useState(restaurant?.telegram_bot_token || '');
  const [showToken, setShowToken] = useState(false);
  const [setupStatus, setSetupStatus] = useState<SetupStatus>('idle');
  const [webhookStatus, setWebhookStatus] = useState<WebhookStatus>(
    (restaurant as any)?.telegram_webhook_status ?? 'not_configured'
  );
  const [botUsername, setBotUsername] = useState((restaurant as any)?.telegram_bot_username ?? '');
  const [error, setError] = useState('');
  const [setupMsg, setSetupMsg] = useState('');
  const [showHelp, setShowHelp] = useState(false);
  const [ownerStartUrl, setOwnerStartUrl] = useState(() => {
    const u = (restaurant as any)?.telegram_bot_username;
    return u ? `https://t.me/${u}?start=owner_${restaurant?.id}` : '';
  });
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message?: string } | null>(null);

  async function handleSetup() {
    if (!restaurant || !botToken.trim()) {
      setError('الرجاء إدخال توكن البوت');
      return;
    }
    setError('');
    setSetupMsg('');
    setTestResult(null);
    setSetupStatus('validating');

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) { setError('انتهت الجلسة، يرجى تسجيل الدخول مجدداً'); setSetupStatus('error'); return; }

    setSetupStatus('registering');

    try {
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/telegram-setup`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({
            action: 'setup',
            bot_token: botToken.trim(),
            restaurant_id: restaurant.id,
          }),
        }
      );

      const result: SetupResult = await res.json();
      await refreshRestaurant();

      if (result.ok) {
        setWebhookStatus('active');
        setBotUsername(result.bot_username ?? '');
        setOwnerStartUrl(result.owner_start_url ?? `https://t.me/${result.bot_username}?start=owner_${restaurant.id}`);
        setSetupStatus('done');
        setSetupMsg(result.message ?? 'تم الربط بنجاح!');
      } else {
        if (result.step === 'validate_token') {
          setWebhookStatus('token_invalid');
          setError(`توكن غير صالح: ${result.error}`);
        } else {
          setWebhookStatus('error');
          setError(`فشل تسجيل الويب هوك: ${result.error}`);
        }
        setSetupStatus('error');
      }
    } catch (e) {
      setError('حدث خطأ في الاتصال بالخادم');
      setSetupStatus('error');
    }
  }

  async function handleTest() {
    if (!restaurant) return;
    setTesting(true);
    setTestResult(null);

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) { setTesting(false); return; }

    try {
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/telegram-setup`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({
            action: 'test',
            restaurant_id: restaurant.id,
          }),
        }
      );
      const result = await res.json();
      setTestResult({ ok: result.ok, message: result.ok ? 'تم إرسال رسالة اختبارية بنجاح!' : result.error });
    } catch {
      setTestResult({ ok: false, message: 'فشل الاتصال بالخادم' });
    } finally {
      setTesting(false);
    }
  }

  async function handleSkip() {
    await completeAndAdvance(5);
  }

  async function handleContinue() {
    await completeAndAdvance(5);
  }

  const statusConfig: Record<WebhookStatus, { label: string; color: string; icon: typeof CheckCircle }> = {
    not_configured: { label: 'غير مُضبط', color: 'text-slate-500 bg-slate-50 border-slate-200', icon: WifiOff },
    pending:        { label: 'في الانتظار', color: 'text-amber-600 bg-amber-50 border-amber-200', icon: AlertCircle },
    active:         { label: 'متصل ونشط', color: 'text-success-700 bg-success-50 border-success-200', icon: CheckCircle },
    error:          { label: 'خطأ في الويب هوك', color: 'text-danger-600 bg-danger-50 border-danger-200', icon: AlertCircle },
    token_invalid:  { label: 'توكن غير صالح', color: 'text-danger-600 bg-danger-50 border-danger-200', icon: X },
  };

  const sc = statusConfig[webhookStatus];
  const StatusIcon = sc.icon;

  const isLoading = setupStatus === 'validating' || setupStatus === 'registering';

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="text-center">
        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-3 transition-colors ${isConnected ? 'bg-success-100' : 'bg-primary-100'}`}>
          <Bot className={`w-7 h-7 ${isConnected ? 'text-success-600' : 'text-primary-600'}`} />
        </div>
        <p className="text-slate-600 text-sm">اربط بوت تيليجرام — فقط أدخل التوكن وسنتولى الباقي</p>
      </div>

      {/* Status Badge */}
      <div className={`flex items-center gap-2.5 px-4 py-3 rounded-xl border text-sm font-medium ${sc.color}`}>
        <StatusIcon className="w-4 h-4 flex-shrink-0" />
        <span>{sc.label}</span>
        {botUsername && webhookStatus === 'active' && (
          <span className="mr-auto font-mono text-xs opacity-70">@{botUsername}</span>
        )}
      </div>

      {/* Error Banner */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className="bg-danger-50 border border-danger-200 text-danger-700 text-sm px-4 py-3 rounded-xl flex items-start gap-2"
          >
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Success Banner */}
      <AnimatePresence>
        {setupMsg && (
          <motion.div
            initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className="bg-success-50 border border-success-200 text-success-700 text-sm px-4 py-3 rounded-xl flex items-start gap-2"
          >
            <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{setupMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Help Toggle */}
      <button
        onClick={() => setShowHelp(!showHelp)}
        className="w-full flex items-center justify-between p-3.5 bg-primary-50 border border-primary-100 rounded-xl text-primary-700 hover:bg-primary-100 transition-colors"
      >
        <div className="flex items-center gap-2">
          <HelpCircle className="w-4 h-4" />
          <span className="text-sm font-medium">كيف أحصل على توكن البوت؟</span>
        </div>
        <ExternalLink className="w-4 h-4" />
      </button>

      <AnimatePresence>
        {showHelp && (
          <motion.div
            initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
            className="bg-slate-50 rounded-xl p-4 space-y-3 text-sm text-slate-600 overflow-hidden"
          >
            <p className="font-semibold text-slate-900">خطوات إنشاء البوت:</p>
            <ol className="list-decimal list-inside space-y-1.5 mr-2">
              <li>افتح تيليجرام وابحث عن <code className="bg-slate-200 px-1.5 rounded text-xs">@BotFather</code></li>
              <li>أرسل <code className="bg-slate-200 px-1.5 rounded text-xs">/newbot</code></li>
              <li>اختر اسماً واسم مستخدم للبوت</li>
              <li>انسخ التوكن والصقه أدناه</li>
            </ol>
            <p className="text-xs text-slate-500">لا تحتاج إلى Chat ID — النظام يسجله تلقائياً عندما ترسل /start للبوت.</p>
            <a
              href="https://t.me/BotFather"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 py-2 px-4 bg-primary-600 hover:bg-primary-700 text-white rounded-lg text-sm font-medium transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              فتح BotFather
            </a>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Token Input */}
      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          توكن البوت <span className="text-danger-500">*</span>
        </label>
        <div className="relative">
          <Bot className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type={showToken ? 'text' : 'password'}
            value={botToken}
            onChange={e => { setBotToken(e.target.value); setError(''); setSetupMsg(''); }}
            placeholder="123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
            className="input-field pr-10 pl-10 font-mono text-xs"
            dir="ltr"
            disabled={isLoading}
          />
          <button
            type="button"
            onClick={() => setShowToken(v => !v)}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
          >
            {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
        <p className="text-xs text-slate-400 mt-1">الصق التوكن الذي حصلت عليه من @BotFather</p>
      </div>

      {/* What happens after setup */}
      {!isConnected && (
        <div className="bg-slate-50 rounded-xl p-4 space-y-2">
          <p className="text-xs font-semibold text-slate-700 mb-2">بعد الضغط على "ربط البوت" سيتم تلقائياً:</p>
          <div className="space-y-1.5">
            {[
              'التحقق من صحة التوكن عبر Telegram API',
              'تسجيل Webhook تلقائياً',
              'حفظ اسم البوت',
              'تفعيل استقبال الطلبات فوراً',
            ].map((step, i) => (
              <div key={i} className="flex items-center gap-2 text-xs text-slate-600">
                <span className="w-5 h-5 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center font-bold text-[10px] flex-shrink-0">{i + 1}</span>
                {step}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* After connection: instructions to send /start */}
      {isConnected && (
        <motion.div
          initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
          className="bg-success-50 border border-success-200 rounded-xl p-4 space-y-3"
        >
          <p className="text-sm font-semibold text-success-800 flex items-center gap-2">
            <CheckCircle className="w-4 h-4" /> البوت مرتبط بنجاح!
          </p>
          <div className="text-xs text-success-700 space-y-1.5">
            <p>لاستقبال إشعارات الطلبات على هاتفك:</p>
            <ol className="list-decimal list-inside space-y-1 mr-2">
              <li>اضغط الزر أدناه لفتح بوتك في تيليجرام</li>
              <li>أرسل <code className="bg-success-100 px-1 rounded">/start</code> أو اضغط Start</li>
              <li>ستصل إشعارات الطلبات الجديدة مباشرةً لك</li>
            </ol>
          </div>
          <a
            href={ownerStartUrl || `https://t.me/${botUsername}?start=owner_${restaurant?.id}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 bg-success-600 hover:bg-success-700 text-white rounded-xl text-sm font-semibold transition-colors"
          >
            <ExternalLink className="w-4 h-4" />
            فتح @{botUsername} والتفعيل
          </a>
          {/* Test button */}
          <button
            onClick={handleTest}
            disabled={testing}
            className="flex items-center gap-2 text-xs font-semibold text-success-700 hover:text-success-900 transition-colors"
          >
            {testing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Wifi className="w-3.5 h-3.5" />}
            {testing ? 'جاري اختبار الاتصال...' : 'اختبار الاتصال (إرسال رسالة تجريبية)'}
          </button>
          <AnimatePresence>
            {testResult && (
              <motion.div
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className={`text-xs px-3 py-2 rounded-lg ${testResult.ok ? 'bg-success-100 text-success-800' : 'bg-danger-50 text-danger-700'}`}
              >
                {testResult.ok ? <CheckCircle className="w-3 h-3 inline ml-1" /> : <AlertCircle className="w-3 h-3 inline ml-1" />}
                {testResult.message}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}

      {/* Loading steps */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex items-center gap-3 p-4 bg-primary-50 border border-primary-100 rounded-xl"
          >
            <Loader2 className="w-5 h-5 text-primary-600 animate-spin flex-shrink-0" />
            <div>
              <p className="text-sm font-semibold text-primary-800">
                {setupStatus === 'validating' ? 'جاري التحقق من التوكن...' : 'جاري تسجيل الويب هوك...'}
              </p>
              <p className="text-xs text-primary-600 mt-0.5">
                {setupStatus === 'validating' ? 'التحقق من صحة التوكن عبر Telegram API' : 'تسجيل الويب هوك لاستقبال الطلبات'}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Actions */}
      <div className="space-y-3 pt-2">
        {!isConnected ? (
          <button
            onClick={handleSetup}
            disabled={isLoading || !botToken.trim()}
            className="w-full btn-primary py-3"
          >
            {isLoading ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> جاري الربط...</>
            ) : (
              <><RefreshCw className="w-4 h-4" /> ربط البوت تلقائياً</>
            )}
          </button>
        ) : (
          <button
            onClick={handleContinue}
            className="w-full btn-primary py-3"
          >
            <Check className="w-4 h-4" />
            متابعة للخطوة التالية
          </button>
        )}

        <button
          onClick={handleSkip}
          disabled={isLoading}
          className="w-full py-2 text-slate-500 hover:text-slate-700 text-sm transition-colors"
        >
          تخطي هذه الخطوة مؤقتاً
        </button>
      </div>
    </div>
  );
}
