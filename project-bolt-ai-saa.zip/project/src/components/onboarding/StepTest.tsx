import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Check, X, Loader2, AlertCircle, Bot, RefreshCw, MessageCircle, ArrowRight } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useOnboarding } from '../../contexts/OnboardingContext';

export default function StepTest() {
  const { restaurant } = useAuth();
  const { testTelegram, completeAndAdvance } = useOnboarding();

  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; error?: string } | null>(null);

  async function handleTest() {
    if (!restaurant) return;

    setTesting(true);
    setTestResult(null);

    const result = await testTelegram();

    setTestResult(result);
    setTesting(false);

    if (result.success) {
      await completeAndAdvance(5);
    }
  }

  async function handleContinue() {
    await completeAndAdvance(6);
  }

  const isConfigured = !!(restaurant?.telegram_bot_token && (restaurant as any)?.telegram_webhook_status === 'active');

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <MessageCircle className="w-12 h-12 text-primary-600 mx-auto mb-3" />
        <p className="text-slate-600">اختبر اتصال البوت</p>
      </div>

      {/* Configuration Status */}
      <div className={`p-4 rounded-xl border ${
        isConfigured
          ? 'bg-success-50 border-success-200'
          : 'bg-warning-50 border-warning-200'
      }`}>
        <div className="flex items-center gap-3">
          {isConfigured ? (
            <>
              <Check className="w-5 h-5 text-success-600" />
              <div>
                <p className="font-semibold text-success-800">البوت مُعد بشكل صحيح</p>
                <p className="text-sm text-success-600">التوكن ومعرف الدردشة موجودان</p>
              </div>
            </>
          ) : (
            <>
              <AlertCircle className="w-5 h-5 text-warning-600" />
              <div>
                <p className="font-semibold text-warning-800">البوت غير مُعد</p>
                <p className="text-sm text-warning-600">لم يتم إدخال بيانات تيليجرام</p>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Test Button */}
      {isConfigured && (
        <button
          onClick={handleTest}
          disabled={testing}
          className="w-full py-4 bg-primary-50 hover:bg-primary-100 border border-primary-200 rounded-xl text-primary-700 font-semibold transition-all flex items-center justify-center gap-2"
        >
          {testing ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              جارٍ إرسال الرسالة التجريبية...
            </>
          ) : (
            <>
              <Send className="w-5 h-5" />
              إرسال رسالة اختبار
            </>
          )}
        </button>
      )}

      {/* Test Result */}
      <AnimatePresence>
        {testResult && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`p-4 rounded-xl ${
              testResult.success
                ? 'bg-success-50 border border-success-200'
                : 'bg-danger-50 border border-danger-200'
            }`}
          >
            <div className="flex items-start gap-3">
              {testResult.success ? (
                <>
                  <Check className="w-5 h-5 text-success-600 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-success-800">تم إرسال الرسالة بنجاح!</p>
                    <p className="text-sm text-success-600 mt-1">
                      تحقق من وجود الرسالة في تيليجرام
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <X className="w-5 h-5 text-danger-600 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-danger-800">فشل إرسال الرسالة</p>
                    <p className="text-sm text-danger-600 mt-1">{testResult.error}</p>
                  </div>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Troubleshooting Tips */}
      {!isConfigured || testResult?.error ? (
        <div className="bg-slate-50 rounded-xl p-4 space-y-3">
          <p className="text-sm font-semibold text-slate-900">نصائح لحل المشاكل:</p>
          <ul className="text-sm text-slate-600 space-y-2 mr-4">
            <li className="flex items-start gap-2">
              <span className="text-primary-600">•</span>
              تأكد من صحة توكن البوت (من @BotFather)
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary-600">•</span>
              تأكد من أن Chat ID صحيح (ابدأ بـ -100 للمجموعات)
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary-600">•</span>
              تأكد من أن البوت عضو في المجموعة/القناة
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary-600">•</span>
              للمجموعات، البوت يجب أن يكون مشرفاً
            </li>
          </ul>
        </div>
      ) : null}

      {/* Continue */}
      <div className="pt-4">
        <button
          onClick={handleContinue}
          className="w-full btn-primary py-3"
        >
          {testResult?.success ? (
            <>
              <Check className="w-4 h-4" />
              تم الاتصال بنجاح، متابعة
            </>
          ) : (
            <>
              متابعة
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
}
