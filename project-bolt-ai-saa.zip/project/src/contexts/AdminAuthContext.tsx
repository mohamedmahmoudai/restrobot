import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { User, Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

export interface PlatformAdminProfile {
  id: string;
  user_id: string;
  email: string | null;
  full_name: string | null;
  role: 'admin' | 'super_admin' | 'support' | 'viewer';
  is_active: boolean;
  last_login: string | null;
  created_at: string;
  updated_at: string | null;
}

interface AdminAuthContextType {
  user: User | null;
  session: Session | null;
  adminProfile: PlatformAdminProfile | null;
  loading: boolean;
  isAdmin: boolean;
  signIn: (email: string, password: string, rememberMe?: boolean) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  hasPermission: (permission: AdminPermission) => boolean;
}

export type AdminPermission =
  | 'view_restaurants'
  | 'manage_restaurants'
  | 'view_subscriptions'
  | 'manage_subscriptions'
  | 'view_payments'
  | 'manage_payments'
  | 'view_plans'
  | 'manage_plans'
  | 'view_support'
  | 'manage_support'
  | 'view_announcements'
  | 'manage_announcements'
  | 'view_audit_logs'
  | 'view_security'
  | 'view_system_health'
  | 'manage_settings';

const ROLE_PERMISSIONS: Record<string, AdminPermission[]> = {
  super_admin: [
    'view_restaurants', 'manage_restaurants',
    'view_subscriptions', 'manage_subscriptions',
    'view_payments', 'manage_payments',
    'view_plans', 'manage_plans',
    'view_support', 'manage_support',
    'view_announcements', 'manage_announcements',
    'view_audit_logs', 'view_security',
    'view_system_health', 'manage_settings'
  ],
  admin: [
    'view_restaurants', 'manage_restaurants',
    'view_subscriptions', 'manage_subscriptions',
    'view_payments', 'manage_payments',
    'view_plans', 'manage_plans',
    'view_support', 'manage_support',
    'view_announcements', 'manage_announcements',
    'view_audit_logs', 'view_security',
    'view_system_health'
  ],
  support: [
    'view_restaurants', 'view_subscriptions',
    'view_support', 'manage_support',
    'view_announcements'
  ],
  viewer: [
    'view_restaurants', 'view_subscriptions',
    'view_support'
  ]
};

const AdminAuthContext = createContext<AdminAuthContextType | null>(null);

export function AdminAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [adminProfile, setAdminProfile] = useState<PlatformAdminProfile | null>(null);
  const [initialized, setInitialized] = useState(false);

  const loading = !initialized;
  const isAdmin = !!adminProfile && adminProfile.is_active;

  async function fetchAdminProfile(userId: string): Promise<PlatformAdminProfile | null> {
    console.log('[ADMIN_AUTH] fetchAdminProfile called with userId:', userId);

    const { data, error } = await supabase.rpc('get_platform_admin_profile');

    console.log('[ADMIN_AUTH] get_platform_admin_profile RPC result:', { data, error, dataType: typeof data, isArray: Array.isArray(data) });

    if (error) {
      console.error('[ADMIN_AUTH] RPC error:', error.message, error.details, error.hint, error.code);
      return null;
    }

    // RPC returning TABLE() returns an array in PostgREST
    const profile = Array.isArray(data) ? data[0] : data;

    if (!profile) {
      console.warn('[ADMIN_AUTH] RPC returned null/empty data - user may not be in platform_admins or is inactive');
      return null;
    }

    console.log('[ADMIN_AUTH] Profile found:', { id: profile.id, role: profile.role, is_active: profile.is_active });
    return profile as PlatformAdminProfile;
  }

  async function refreshProfile() {
    if (user) {
      const profile = await fetchAdminProfile(user.id);
      setAdminProfile(profile);
    }
  }

  function resetAuthState() {
    setUser(null);
    setSession(null);
    setAdminProfile(null);
    setInitialized(true);
  }

  useEffect(() => {
    let mounted = true;

    console.log('[ADMIN_AUTH] Initializing auth state...');

    supabase.auth.getSession().then(({ data: { session }, error }) => {
      if (!mounted) return;
      console.log('[ADMIN_AUTH] getSession result:', { hasSession: !!session, userId: session?.user?.id, error });

      setSession(session);
      setUser(session?.user ?? null);

      if (session?.user) {
        console.log('[ADMIN_AUTH] Session found, fetching profile for:', session.user.id);
        fetchAdminProfile(session.user.id).then(profile => {
          if (mounted) {
            console.log('[ADMIN_AUTH] Initial profile loaded:', profile);
            setAdminProfile(profile);
            setInitialized(true);
          }
        });
      } else {
        console.log('[ADMIN_AUTH] No session, initialization complete');
        setInitialized(true);
      }
    }).catch((err) => {
      console.error('[ADMIN_AUTH] getSession error:', err);
      if (mounted) setInitialized(true);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!mounted) return;
      console.log('[ADMIN_AUTH] Auth state changed:', { event: _event, userId: session?.user?.id });

      setSession(session);
      setUser(session?.user ?? null);

      if (session?.user) {
        fetchAdminProfile(session.user.id).then(profile => {
          if (mounted) {
            console.log('[ADMIN_AUTH] Profile refreshed:', profile);
            setAdminProfile(profile);
          }
        });
      } else {
        setAdminProfile(null);
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  async function signIn(email: string, password: string, rememberMe = false) {
    console.log('[ADMIN_AUTH] signIn called for:', email);

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
      options: {
        persistSession: rememberMe
      }
    });

    if (error) {
      console.error('[ADMIN_AUTH] signInWithPassword error:', error.message);
      return { error: error.message };
    }

    console.log('[ADMIN_AUTH] signInWithPassword success, getting user...');

    // Verify the user is a platform admin
    const { data: { user: authUser }, error: getUserError } = await supabase.auth.getUser();
    console.log('[ADMIN_AUTH] getUser result:', { userId: authUser?.id, error: getUserError?.message });

    if (!authUser) {
      console.error('[ADMIN_AUTH] No user after successful signIn');
      return { error: 'Authentication failed - no user returned' };
    }

    console.log('[ADMIN_AUTH] Checking is_platform_admin RPC...');
    const { data: isAdminResult, error: isAdminError } = await supabase.rpc('is_platform_admin');
    console.log('[ADMIN_AUTH] is_platform_admin result:', { isAdminResult, error: isAdminError });

    if (isAdminError) {
      console.error('[ADMIN_AUTH] is_platform_admin RPC error:', isAdminError.message, isAdminError.details, isAdminError.hint);
      await supabase.auth.signOut();
      return { error: `Database error: ${isAdminError.message}` };
    }

    if (!isAdminResult) {
      console.warn('[ADMIN_AUTH] is_platform_admin returned false - user not in platform_admins or inactive');
      await supabase.auth.signOut();
      return { error: 'Access denied. You are not a platform administrator.' };
    }

    console.log('[ADMIN_AUTH] Fetching admin profile...');
    const profile = await fetchAdminProfile(authUser.id);
    console.log('[ADMIN_AUTH] Profile result:', profile);

    if (!profile) {
      console.error('[ADMIN_AUTH] No profile returned from get_platform_admin_profile');
      await supabase.auth.signOut();
      return { error: 'Admin profile not found. Please contact support.' };
    }

    if (!profile.is_active) {
      console.error('[ADMIN_AUTH] Profile exists but is_active is false');
      await supabase.auth.signOut();
      return { error: 'Your admin account is not active.' };
    }

    console.log('[ADMIN_AUTH] Sign in complete, profile active:', profile.role);
    return { error: null };
  }

  async function signOut() {
    await supabase.auth.signOut();
    resetAuthState();
    localStorage.clear();
    sessionStorage.clear();
  }

  function hasPermission(permission: AdminPermission): boolean {
    if (!adminProfile || !adminProfile.is_active) return false;
    const permissions = ROLE_PERMISSIONS[adminProfile.role] || [];
    return permissions.includes(permission);
  }

  return (
    <AdminAuthContext.Provider value={{
      user,
      session,
      adminProfile,
      loading,
      isAdmin,
      signIn,
      signOut,
      refreshProfile,
      hasPermission
    }}>
      {children}
    </AdminAuthContext.Provider>
  );
}

export function useAdminAuth() {
  const ctx = useContext(AdminAuthContext);
  if (!ctx) throw new Error('useAdminAuth must be used within AdminAuthProvider');
  return ctx;
}
