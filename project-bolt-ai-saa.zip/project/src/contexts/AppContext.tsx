import { createContext, useContext, useEffect, useReducer, type ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';
import type { DeliveryZone } from '../utils/delivery';

// ── State ──────────────────────────────────────────────────────────────────────

interface AppState {
  deliveryZones: DeliveryZone[];
  defaultDeliveryFee: number;
  zonesLoading: boolean;
  zonesError: string | null;
}

const initialState: AppState = {
  deliveryZones: [],
  defaultDeliveryFee: 0,
  zonesLoading: true,
  zonesError: null,
};

// ── Actions ────────────────────────────────────────────────────────────────────

type AppAction =
  | { type: 'SET_DELIVERY_ZONES'; payload: DeliveryZone[] }
  | { type: 'ADD_DELIVERY_ZONE'; payload: DeliveryZone }
  | { type: 'UPDATE_DELIVERY_ZONE'; payload: DeliveryZone }
  | { type: 'DELETE_DELIVERY_ZONE'; payload: string }
  | { type: 'SET_DEFAULT_DELIVERY_FEE'; payload: number }
  | { type: 'SET_ZONES_LOADING'; payload: boolean }
  | { type: 'SET_ZONES_ERROR'; payload: string | null };

// ── Reducer ────────────────────────────────────────────────────────────────────

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_DELIVERY_ZONES':
      return { ...state, deliveryZones: action.payload, zonesLoading: false, zonesError: null };
    case 'ADD_DELIVERY_ZONE':
      return { ...state, deliveryZones: [...state.deliveryZones, action.payload] };
    case 'UPDATE_DELIVERY_ZONE':
      return {
        ...state,
        deliveryZones: state.deliveryZones.map(z =>
          z.id === action.payload.id ? action.payload : z
        ),
      };
    case 'DELETE_DELIVERY_ZONE':
      return {
        ...state,
        deliveryZones: state.deliveryZones.filter(z => z.id !== action.payload),
      };
    case 'SET_DEFAULT_DELIVERY_FEE':
      return { ...state, defaultDeliveryFee: action.payload };
    case 'SET_ZONES_LOADING':
      return { ...state, zonesLoading: action.payload };
    case 'SET_ZONES_ERROR':
      return { ...state, zonesError: action.payload, zonesLoading: false };
    default:
      return state;
  }
}

// ── Context ────────────────────────────────────────────────────────────────────

interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  fetchZones: () => Promise<void>;
  addZone: (restaurantId: string, name: string, price: number) => Promise<void>;
  updateZone: (zone: DeliveryZone) => Promise<void>;
  deleteZone: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const { restaurant } = useAuth();
  const [state, dispatch] = useReducer(appReducer, initialState);

  async function fetchZones() {
    if (!restaurant) return;
    dispatch({ type: 'SET_ZONES_LOADING', payload: true });
    try {
      const { data, error } = await supabase
        .from('delivery_zones')
        .select('*')
        .eq('restaurant_id', restaurant.id)
        .order('created_at', { ascending: true });

      if (error) throw error;
      dispatch({
        type: 'SET_DELIVERY_ZONES',
        payload: (data ?? []).map(d => ({ id: d.id, name: d.name, price: Number(d.price) })),
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'خطأ في تحميل مناطق التوصيل';
      dispatch({ type: 'SET_ZONES_ERROR', payload: msg });
    }
  }

  async function addZone(restaurantId: string, name: string, price: number) {
    try {
      const { data, error } = await supabase
        .from('delivery_zones')
        .insert({ restaurant_id: restaurantId, name, price })
        .select()
        .single();

      if (error) throw error;
      if (data) {
        dispatch({
          type: 'ADD_DELIVERY_ZONE',
          payload: { id: data.id, name: data.name, price: Number(data.price) },
        });
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'خطأ في إضافة المنطقة';
      dispatch({ type: 'SET_ZONES_ERROR', payload: msg });
    }
  }

  async function updateZone(zone: DeliveryZone) {
    try {
      const { error } = await supabase
        .from('delivery_zones')
        .update({ name: zone.name, price: zone.price })
        .eq('id', zone.id);

      if (error) throw error;
      dispatch({ type: 'UPDATE_DELIVERY_ZONE', payload: zone });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'خطأ في تحديث المنطقة';
      dispatch({ type: 'SET_ZONES_ERROR', payload: msg });
    }
  }

  async function deleteZone(id: string) {
    try {
      const { error } = await supabase
        .from('delivery_zones')
        .delete()
        .eq('id', id);

      if (error) throw error;
      dispatch({ type: 'DELETE_DELIVERY_ZONE', payload: id });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'خطأ في حذف المنطقة';
      dispatch({ type: 'SET_ZONES_ERROR', payload: msg });
    }
  }

  useEffect(() => {
    if (restaurant) fetchZones();
  }, [restaurant]);

  return (
    <AppContext.Provider value={{ state, dispatch, fetchZones, addZone, updateZone, deleteZone }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
