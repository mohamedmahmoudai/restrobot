import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { User, Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import type { Restaurant } from '../lib/database.types';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  restaurant: Restaurant | null;
  loading: boolean;
  needsPlanSelection: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string, restaurantName: string) => Promise<{ error: string | null; needsPlanSelection?: boolean }>;
  signOut: () => Promise<void>;
  refreshRestaurant: () => Promise<void>;
  markPlanSelected: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [initialized, setInitialized] = useState(false);
  const [needsPlanSelection, setNeedsPlanSelection] = useState(false);

  const loading: boolean = !initialized;

  async function fetchRestaurant(userId: string): Promise<Restaurant | null> {
    const { data } = await supabase
      .from('restaurants')
      .select('*')
      .eq('owner_id', userId)
      .maybeSingle();
    return data;
  }

  async function refreshRestaurant() {
    if (user) {
      const data = await fetchRestaurant(user.id);
      setRestaurant(data);
    }
  }

  function resetAuthState() {
    setUser(null);
    setSession(null);
    setRestaurant(null);
    setInitialized(true);
  }

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!mounted) return;
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchRestaurant(session.user.id).then(data => {
          if (mounted) {
            setRestaurant(data);
            setInitialized(true);
          }
        });
      } else {
        setInitialized(true);
      }
    }).catch(() => {
      if (mounted) setInitialized(true);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!mounted) return;
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchRestaurant(session.user.id).then(data => mounted && setRestaurant(data));
      } else {
        setRestaurant(null);
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  async function signIn(email: string, password: string) {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { error: error.message };
    return { error: null };
  }

  async function signUp(email: string, password: string, restaurantName: string) {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) return { error: error.message };
    if (!data.user) return { error: 'فشل إنشاء الحساب' };

    const { error: rError } = await supabase.from('restaurants').insert({
      owner_id: data.user.id,
      name: restaurantName,
      subscription_plan: null,
      subscription_expires_at: null,
      is_active: false,
      has_used_trial: false,
    });
    if (rError) return { error: rError.message };

    setNeedsPlanSelection(true);
    return { error: null, needsPlanSelection: true };
  }

  function markPlanSelected() {
    setNeedsPlanSelection(false);
  }

  async function signOut() {
    await supabase.auth.signOut();
    resetAuthState();
    localStorage.clear();
    sessionStorage.clear();
  }

  return (
    <AuthContext.Provider value={{ user, session, restaurant, loading, needsPlanSelection, signIn, signUp, signOut, refreshRestaurant, markPlanSelected }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
