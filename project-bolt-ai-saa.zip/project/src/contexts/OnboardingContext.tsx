import { createContext, useContext, useEffect, useState, useCallback, useRef, type ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';
import { triggerSync } from '../lib/useAutoSync';
import type { OnboardingProgress, MenuCategory, MenuItem, DeliveryZone } from '../lib/database.types';

interface OnboardingState {
  currentStep: number;
  completedSteps: number[];
  stepData: Record<string, any>;
  isCompleted: boolean;
  loading: boolean;
  saving: boolean;
  categories: MenuCategory[];
  products: MenuItem[];
  deliveryZones: DeliveryZone[];
}

interface OnboardingContextType {
  state: OnboardingState;
  progress: OnboardingProgress | null;
  nextStep: () => Promise<void>;
  prevStep: () => void;
  goToStep: (step: number) => void;
  saveStepData: (step: number, data: Record<string, any>) => Promise<void>;
  completeStep: (step: number) => Promise<void>;
  completeAndAdvance: (step: number) => Promise<void>;
  completeOnboarding: () => Promise<void>;
  refreshData: () => Promise<void>;
  fetchCategories: () => Promise<void>;
  fetchProducts: () => Promise<void>;
  fetchDeliveryZones: () => Promise<void>;
  addCategory: (name: string, nameAr: string) => Promise<{ error: string | null; data?: MenuCategory }>;
  updateCategory: (id: string, name: string, nameAr: string) => Promise<{ error: string | null }>;
  deleteCategory: (id: string) => Promise<{ error: string | null }>;
  addProduct: (product: Partial<MenuItem>) => Promise<{ error: string | null; data?: MenuItem }>;
  updateProduct: (id: string, product: Partial<MenuItem>) => Promise<{ error: string | null }>;
  deleteProduct: (id: string) => Promise<{ error: string | null }>;
  addDeliveryZone: (name: string, price: number) => Promise<{ error: string | null; data?: DeliveryZone }>;
  updateDeliveryZone: (id: string, name: string, price: number) => Promise<{ error: string | null }>;
  deleteDeliveryZone: (id: string) => Promise<{ error: string | null }>;
  testTelegram: () => Promise<{ success: boolean; error?: string }>;
}

const OnboardingContext = createContext<OnboardingContextType | null>(null);

export const ONBOARDING_STEPS = [
  { id: 1, title: 'بيانات المطعم', titleEn: 'Restaurant Profile' },
  { id: 2, title: 'إضافة الفئات', titleEn: 'Menu Categories' },
  { id: 3, title: 'إضافة المنتجات', titleEn: 'First Products' },
  { id: 4, title: 'مناطق التوصيل', titleEn: 'Delivery Zones' },
  { id: 5, title: 'ربط تيليجرام', titleEn: 'Telegram Connection' },
  { id: 6, title: 'اختبار الاتصال', titleEn: 'Bot Test' },
  { id: 7, title: 'الإعداد مكتمل', titleEn: 'Setup Complete' },
];

export function OnboardingProvider({ children }: { children: ReactNode }) {
  const { restaurant } = useAuth();
  const [progress, setProgress] = useState<OnboardingProgress | null>(null);
  const [state, setState] = useState<OnboardingState>({
    currentStep: 1,
    completedSteps: [],
    stepData: {},
    isCompleted: false,
    loading: true,
    saving: false,
    categories: [],
    products: [],
    deliveryZones: [],
  });

  // Ref holds the current progress ID so updateProgress never uses a stale closure
  const progressIdRef = useRef<string | null>(null);
  const stateRef = useRef(state);
  stateRef.current = state;

  const fetchProgress = useCallback(async () => {
    if (!restaurant) return;

    const { data, error } = await supabase
      .from('onboarding_progress')
      .select('*')
      .eq('restaurant_id', restaurant.id)
      .maybeSingle();

    if (error) {
      console.error('Error fetching onboarding progress:', error);
      // Still mark loading as done so UI doesn't hang
      setState(prev => ({ ...prev, loading: false }));
      return;
    }

    if (data) {
      progressIdRef.current = data.id;
      setProgress(data as OnboardingProgress);
      setState(prev => ({
        ...prev,
        currentStep: data.current_step,
        completedSteps: data.completed_steps || [],
        stepData: (data.step_data as Record<string, any>) || {},
        isCompleted: data.is_completed,
        loading: false,
      }));
    } else {
      // Row doesn't exist — create it
      const { data: newProgress, error: createError } = await supabase
        .from('onboarding_progress')
        .insert({
          restaurant_id: restaurant.id,
          current_step: 1,
          completed_steps: [],
          is_completed: false,
          step_data: {},
        })
        .select()
        .single();

      if (!createError && newProgress) {
        progressIdRef.current = newProgress.id;
        setProgress(newProgress as OnboardingProgress);
        setState(prev => ({
          ...prev,
          currentStep: 1,
          completedSteps: [],
          loading: false,
        }));
      } else {
        console.error('Failed to create onboarding progress row:', createError);
        setState(prev => ({ ...prev, loading: false }));
      }
    }
  }, [restaurant]);

  const fetchCategories = useCallback(async () => {
    if (!restaurant) return;
    const { data } = await supabase
      .from('menu_categories')
      .select('*')
      .eq('restaurant_id', restaurant.id)
      .order('sort_order', { ascending: true });
    if (data) setState(prev => ({ ...prev, categories: data as MenuCategory[] }));
  }, [restaurant]);

  const fetchProducts = useCallback(async () => {
    if (!restaurant) return;
    const { data } = await supabase
      .from('menu_items')
      .select('*')
      .eq('restaurant_id', restaurant.id)
      .order('sort_order', { ascending: true });
    if (data) setState(prev => ({ ...prev, products: data as MenuItem[] }));
  }, [restaurant]);

  const fetchDeliveryZones = useCallback(async () => {
    if (!restaurant) return;
    const { data } = await supabase
      .from('delivery_zones')
      .select('*')
      .eq('restaurant_id', restaurant.id);
    if (data) setState(prev => ({ ...prev, deliveryZones: data as DeliveryZone[] }));
  }, [restaurant]);

  const refreshData = useCallback(async () => {
    setState(prev => ({ ...prev, loading: true }));
    await Promise.all([fetchProgress(), fetchCategories(), fetchProducts(), fetchDeliveryZones()]);
    setState(prev => ({ ...prev, loading: false }));
  }, [fetchProgress, fetchCategories, fetchProducts, fetchDeliveryZones]);

  useEffect(() => {
    if (restaurant) {
      refreshData();
    }
  }, [restaurant, refreshData]);

  // Core update function — uses progressIdRef so it's never stale
  const updateProgress = useCallback(async (updates: Partial<OnboardingProgress>) => {
    const id = progressIdRef.current;
    if (!restaurant || !id) {
      console.warn('updateProgress called before progress row was loaded', { restaurant: !!restaurant, id });
      return;
    }

    setState(prev => ({ ...prev, saving: true }));

    const { error } = await supabase
      .from('onboarding_progress')
      .update(updates)
      .eq('id', id);

    if (error) {
      console.error('updateProgress error:', error);
      setState(prev => ({ ...prev, saving: false }));
      return;
    }

    setProgress(prev => prev ? { ...prev, ...updates } as OnboardingProgress : null);
    setState(prev => {
      const next = { ...prev, saving: false };
      if (updates.current_step !== undefined) next.currentStep = updates.current_step as number;
      if (updates.completed_steps !== undefined) next.completedSteps = updates.completed_steps as number[];
      if (updates.step_data !== undefined) next.stepData = updates.step_data as Record<string, any>;
      if (updates.is_completed !== undefined) next.isCompleted = updates.is_completed as boolean;
      return next;
    });
  }, [restaurant]); // intentionally omits `progress` — uses ref instead

  const saveStepData = useCallback(async (step: number, data: Record<string, any>) => {
    await updateProgress({
      step_data: { ...stateRef.current.stepData, [`step_${step}`]: data },
    });
  }, [updateProgress]);

  const completeStep = useCallback(async (step: number) => {
    const completedSteps = [...new Set([...stateRef.current.completedSteps, step])];
    await updateProgress({ completed_steps: completedSteps });
  }, [updateProgress]);

  const nextStep = useCallback(async () => {
    const newStep = Math.min(stateRef.current.currentStep + 1, ONBOARDING_STEPS.length);
    await updateProgress({ current_step: newStep });
  }, [updateProgress]);

  // Atomic: mark step complete AND advance to next — avoids two-call race
  const completeAndAdvance = useCallback(async (step: number) => {
    const completedSteps = [...new Set([...stateRef.current.completedSteps, step])];
    const newStep = Math.min(stateRef.current.currentStep + 1, ONBOARDING_STEPS.length);
    await updateProgress({ completed_steps: completedSteps, current_step: newStep });
  }, [updateProgress]);

  const prevStep = useCallback(() => {
    const newStep = Math.max(stateRef.current.currentStep - 1, 1);
    updateProgress({ current_step: newStep });
  }, [updateProgress]);

  const goToStep = useCallback((step: number) => {
    if (step >= 1 && step <= ONBOARDING_STEPS.length) {
      updateProgress({ current_step: step });
    }
  }, [updateProgress]);

  const completeOnboarding = useCallback(async () => {
    if (!restaurant) return;

    await updateProgress({
      is_completed: true,
      completed_at: new Date().toISOString(),
    });

    await supabase
      .from('restaurants')
      .update({ onboarding_completed: true })
      .eq('id', restaurant.id);
  }, [restaurant, updateProgress]);

  const addCategory = useCallback(async (name: string, nameAr: string) => {
    if (!restaurant) return { error: 'المطعم غير موجود' };

    const { data, error } = await supabase
      .from('menu_categories')
      .insert({
        restaurant_id: restaurant.id,
        name,
        name_ar: nameAr,
        sort_order: stateRef.current.categories.length,
        is_active: true,
      })
      .select()
      .single();

    if (error) return { error: error.message };
    await fetchCategories();
    triggerSync(restaurant.id, 'categories').catch(() => {});
    return { error: null, data: data as MenuCategory };
  }, [restaurant, fetchCategories]);

  const updateCategory = useCallback(async (id: string, name: string, nameAr: string) => {
    const { error } = await supabase
      .from('menu_categories')
      .update({ name, name_ar: nameAr })
      .eq('id', id);

    if (error) return { error: error.message };
    await fetchCategories();
    if (restaurant) triggerSync(restaurant.id, 'categories').catch(() => {});
    return { error: null };
  }, [fetchCategories, restaurant]);

  const deleteCategory = useCallback(async (id: string) => {
    const { error } = await supabase
      .from('menu_categories')
      .delete()
      .eq('id', id);

    if (error) return { error: error.message };
    await fetchCategories();
    if (restaurant) triggerSync(restaurant.id, 'categories').catch(() => {});
    return { error: null };
  }, [fetchCategories, restaurant]);

  const addProduct = useCallback(async (product: Partial<MenuItem>) => {
    if (!restaurant) return { error: 'المطعم غير موجود' };

    const { data, error } = await supabase
      .from('menu_items')
      .insert({
        restaurant_id: restaurant.id,
        ...product,
        sort_order: stateRef.current.products.length,
        is_available: product.is_available ?? true,
      })
      .select()
      .single();

    if (error) return { error: error.message };
    await fetchProducts();
    triggerSync(restaurant.id, 'products').catch(() => {});
    return { error: null, data: data as MenuItem };
  }, [restaurant, fetchProducts]);

  const updateProduct = useCallback(async (id: string, product: Partial<MenuItem>) => {
    const { error } = await supabase
      .from('menu_items')
      .update(product)
      .eq('id', id);

    if (error) return { error: error.message };
    await fetchProducts();
    if (restaurant) triggerSync(restaurant.id, 'products').catch(() => {});
    return { error: null };
  }, [fetchProducts, restaurant]);

  const deleteProduct = useCallback(async (id: string) => {
    const { error } = await supabase
      .from('menu_items')
      .delete()
      .eq('id', id);

    if (error) return { error: error.message };
    await fetchProducts();
    if (restaurant) triggerSync(restaurant.id, 'products').catch(() => {});
    return { error: null };
  }, [fetchProducts, restaurant]);

  const addDeliveryZone = useCallback(async (name: string, price: number) => {
    if (!restaurant) return { error: 'المطعم غير موجود' };

    const { data, error } = await supabase
      .from('delivery_zones')
      .insert({
        restaurant_id: restaurant.id,
        name,
        price,
      })
      .select()
      .single();

    if (error) return { error: error.message };
    await fetchDeliveryZones();
    triggerSync(restaurant.id, 'delivery_zones').catch(() => {});
    return { error: null, data: data as DeliveryZone };
  }, [restaurant, fetchDeliveryZones]);

  const updateDeliveryZone = useCallback(async (id: string, name: string, price: number) => {
    const { error } = await supabase
      .from('delivery_zones')
      .update({ name, price })
      .eq('id', id);

    if (error) return { error: error.message };
    await fetchDeliveryZones();
    if (restaurant) triggerSync(restaurant.id, 'delivery_zones').catch(() => {});
    return { error: null };
  }, [fetchDeliveryZones, restaurant]);

  const deleteDeliveryZone = useCallback(async (id: string) => {
    const { error } = await supabase
      .from('delivery_zones')
      .delete()
      .eq('id', id);

    if (error) return { error: error.message };
    await fetchDeliveryZones();
    if (restaurant) triggerSync(restaurant.id, 'delivery_zones').catch(() => {});
    return { error: null };
  }, [fetchDeliveryZones, restaurant]);

  const testTelegram = useCallback(async (): Promise<{ success: boolean; error?: string }> => {
    if (!restaurant) return { success: false, error: 'لا يوجد مطعم' };

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return { success: false, error: 'انتهت الجلسة' };

    try {
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/telegram-setup`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
          body: JSON.stringify({ action: 'test', restaurant_id: restaurant.id }),
        }
      );
      const data = await res.json();
      return { success: !!data.ok, error: data.error };
    } catch {
      return { success: false, error: 'حدث خطأ في الاتصال' };
    }
  }, [restaurant]);

  return (
    <OnboardingContext.Provider value={{
      state,
      progress,
      nextStep,
      prevStep,
      goToStep,
      saveStepData,
      completeStep,
      completeAndAdvance,
      completeOnboarding,
      refreshData,
      fetchCategories,
      fetchProducts,
      fetchDeliveryZones,
      addCategory,
      updateCategory,
      deleteCategory,
      addProduct,
      updateProduct,
      deleteProduct,
      addDeliveryZone,
      updateDeliveryZone,
      deleteDeliveryZone,
      testTelegram,
    }}>
      {children}
    </OnboardingContext.Provider>
  );
}

export function useOnboarding() {
  const ctx = useContext(OnboardingContext);
  if (!ctx) throw new Error('useOnboarding must be used within OnboardingProvider');
  return ctx;
}
