import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';
import type { SystemPlan, RestaurantSubscription, SubscriptionRequest } from '../lib/database.types';

export type BillingCycle = 'monthly';

export interface SubscriptionStatus {
  status: string;
  planName: string;
  planNameAr: string;
  expiresAt: string;
  daysRemaining: number;
  ordersUsed: number;
  maxOrders: number | null;
  maxBranches: number | null;
  maxUsers: number | null;
  canCreateOrder: boolean;
  isTrialPlan: boolean;
  features: string[];
  billingCycle: BillingCycle;
}

interface SubscriptionContextType {
  plans: SystemPlan[];
  currentSubscription: RestaurantSubscription | null;
  subscriptionStatus: SubscriptionStatus | null;
  subscriptionRequests: SubscriptionRequest[];
  loading: boolean;
  hasUsedTrial: boolean;
  hasUsedFreePlan: boolean;
  fetchPlans: () => Promise<void>;
  fetchSubscription: () => Promise<void>;
  fetchSubscriptionRequests: () => Promise<void>;
  activateTrial: () => Promise<{ error: string | null }>;
  activateFreePlan: () => Promise<{ error: string | null }>;
  requestSubscription: (planId: string, paymentProofUrl: string, notes?: string) => Promise<{ error: string | null }>;
  canPerformAction: (action: 'new_order' | 'menu_edit' | 'loyalty' | 'telegram_bot' | 'analytics' | 'customers') => boolean;
  isSubscriptionActive: boolean;
  isSuspended: boolean;
  isExpired: boolean;
  refreshSubscription: () => Promise<void>;
}

const SubscriptionContext = createContext<SubscriptionContextType | null>(null);

const BILLING_DAYS: Record<BillingCycle, number> = { monthly: 30 };

function getPriceForCycle(plan: SystemPlan): number {
  return plan.price_monthly ?? 0;
}

export function SubscriptionProvider({ children }: { children: ReactNode }) {
  const { restaurant } = useAuth();
  const [plans, setPlans] = useState<SystemPlan[]>([]);
  const [currentSubscription, setCurrentSubscription] = useState<RestaurantSubscription | null>(null);
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus | null>(null);
  const [subscriptionRequests, setSubscriptionRequests] = useState<SubscriptionRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasUsedTrial, setHasUsedTrial] = useState(false);
  const [hasUsedFreePlan, setHasUsedFreePlan] = useState(false);
  const [isSuspended, setIsSuspended] = useState(false);
  const [isExpired, setIsExpired] = useState(false);

  const fetchPlans = useCallback(async () => {
    const { data, error } = await supabase
      .from('system_plans')
      .select('*')
      .eq('is_active', true)
      .order('sort_order', { ascending: true });

    if (!error && data) {
      setPlans(data as SystemPlan[]);
    }
  }, []);

  const fetchSubscription = useCallback(async () => {
    if (!restaurant) return;

    setLoading(true);

    const { data: subscription } = await supabase
      .from('restaurant_subscriptions')
      .select('*')
      .eq('restaurant_id', restaurant.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (subscription) {
      setCurrentSubscription(subscription as RestaurantSubscription);

      const plan = plans.find(p => p.id === subscription.plan_id);
      if (plan) {
        const expiresAt = new Date(subscription.expires_at);
        const now = new Date();
        const daysRemaining = Math.max(0, Math.ceil((expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
        const canCreateOrder = subscription.status === 'active' &&
          expiresAt > now &&
          (plan.max_orders === null || subscription.orders_used < plan.max_orders);

        setSubscriptionStatus({
          status: subscription.status,
          planName: plan.plan_name,
          planNameAr: plan.name_ar || plan.plan_name,
          expiresAt: subscription.expires_at,
          daysRemaining,
          ordersUsed: subscription.orders_used,
          maxOrders: plan.max_orders,
          maxBranches: plan.max_branches,
          maxUsers: plan.max_users,
          canCreateOrder,
          isTrialPlan: plan.is_trial,
          features: (plan.features as string[]) || [],
          billingCycle: (subscription.billing_cycle as BillingCycle) || 'monthly',
        });
      }
    } else {
      setCurrentSubscription(null);
      setSubscriptionStatus(null);
    }

    const { data: restaurantData } = await supabase
      .from('restaurants')
      .select('has_used_trial, is_suspended, subscription_expires_at')
      .eq('id', restaurant.id)
      .maybeSingle();

    if (restaurantData) {
      setHasUsedTrial(restaurantData.has_used_trial || false);
      setIsSuspended(restaurantData.is_suspended || false);
      const subExpiry = restaurantData.subscription_expires_at;
      setIsExpired(subExpiry ? new Date(subExpiry) < new Date() : false);
    }

    // Check if free plan was ever used (lifetime check)
    const { data: freePlanSubs } = await supabase
      .from('restaurant_subscriptions')
      .select('id')
      .eq('restaurant_id', restaurant.id)
      .in('plan_id', plans.filter(p => p.plan_type === 'free' || p.is_trial).map(p => p.id))
      .limit(1);
    setHasUsedFreePlan((freePlanSubs && freePlanSubs.length > 0) || false);

    setLoading(false);
  }, [restaurant, plans]);

  const fetchSubscriptionRequests = useCallback(async () => {
    if (!restaurant) return;

    const { data, error } = await supabase
      .from('subscription_requests')
      .select('*')
      .eq('restaurant_id', restaurant.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setSubscriptionRequests(data as SubscriptionRequest[]);
    }
  }, [restaurant]);

  const refreshSubscription = useCallback(async () => {
    await fetchSubscription();
  }, [fetchSubscription]);

  useEffect(() => {
    fetchPlans();
  }, [fetchPlans]);

  useEffect(() => {
    if (restaurant && plans.length > 0) {
      fetchSubscription();
      fetchSubscriptionRequests();
    }
  }, [restaurant, plans.length, fetchSubscription, fetchSubscriptionRequests]);

  const activateTrial = useCallback(async (): Promise<{ error: string | null }> => {
    if (!restaurant) return { error: 'المطعم غير موجود' };

    const trialPlan = plans.find(p => p.is_trial);
    if (!trialPlan) return { error: 'الباقة التجريبية غير متوفرة' };

    if (hasUsedTrial) return { error: 'لقد استخدمت الباقة التجريبية من قبل' };

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + (trialPlan.duration_days || 3));

    const { error: subError } = await supabase
      .from('restaurant_subscriptions')
      .insert({
        restaurant_id: restaurant.id,
        plan_id: trialPlan.id,
        billing_cycle: 'monthly',
        status: 'active',
        starts_at: new Date().toISOString(),
        expires_at: expiresAt.toISOString(),
        trial_used: true,
        payment_status: 'approved',
      });

    if (subError) return { error: subError.message };

    await supabase
      .from('restaurants')
      .update({
        has_used_trial: true,
        subscription_plan: 'trial',
        subscription_expires_at: expiresAt.toISOString(),
        is_active: true,
      })
      .eq('id', restaurant.id);

    await fetchSubscription();
    return { error: null };
  }, [restaurant, plans, hasUsedTrial, fetchSubscription]);

  const activateFreePlan = useCallback(async (): Promise<{ error: string | null }> => {
    if (!restaurant) return { error: 'المطعم غير موجود' };

    const freePlan = plans.find(p => p.plan_type === 'free');
    if (!freePlan) return { error: 'الباقة المجانية غير متوفرة' };

    if (hasUsedFreePlan) {
      return { error: 'لقد استخدمت الباقة المجانية من قبل. يرجى اختيار أحد الباقات المدفوعة.' };
    }

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + (freePlan.duration_days || 30));

    const { error: subError } = await supabase
      .from('restaurant_subscriptions')
      .insert({
        restaurant_id: restaurant.id,
        plan_id: freePlan.id,
        billing_cycle: 'monthly',
        status: 'active',
        starts_at: new Date().toISOString(),
        expires_at: expiresAt.toISOString(),
        trial_used: true,
        payment_status: 'approved',
      });

    if (subError) return { error: subError.message };

    await supabase
      .from('restaurants')
      .update({
        has_used_trial: true,
        subscription_plan: freePlan.plan_name.toLowerCase(),
        subscription_expires_at: expiresAt.toISOString(),
        is_active: true,
      })
      .eq('id', restaurant.id);

    await fetchSubscription();
    return { error: null };
  }, [restaurant, plans, hasUsedFreePlan, fetchSubscription]);

  const requestSubscription = useCallback(async (
    planId: string,
    paymentProofUrl: string,
    notes?: string
  ): Promise<{ error: string | null }> => {
    if (!restaurant) return { error: 'المطعم غير موجود' };

    const plan = plans.find(p => p.id === planId);
    if (!plan) return { error: 'الباقة غير موجودة' };

    if (plan.is_trial) {
      return activateTrial();
    }

    if (plan.plan_type === 'free') {
      return activateFreePlan();
    }

    const durationDays = BILLING_DAYS.monthly;
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + durationDays);

    const amount = getPriceForCycle(plan);

    const { error: subError } = await supabase
      .from('restaurant_subscriptions')
      .insert({
        restaurant_id: restaurant.id,
        plan_id: plan.id,
        billing_cycle: 'monthly',
        status: 'pending_payment',
        starts_at: new Date().toISOString(),
        expires_at: expiresAt.toISOString(),
        payment_status: 'pending',
        payment_proof_url: paymentProofUrl,
        payment_notes: notes || null,
      });

    if (subError) return { error: subError.message };

    const { error: reqError } = await supabase
      .from('subscription_requests')
      .insert({
        restaurant_id: restaurant.id,
        plan_id: plan.id,
        billing_cycle: 'monthly',
        amount,
        currency: 'ج.م',
        payment_proof_url: paymentProofUrl,
        notes: notes || null,
        status: 'pending',
      });

    if (reqError) return { error: reqError.message };

    await fetchSubscription();
    await fetchSubscriptionRequests();
    return { error: null };
  }, [restaurant, plans, activateTrial, activateFreePlan, fetchSubscription, fetchSubscriptionRequests]);

  const isSubscriptionActive = subscriptionStatus?.status === 'active' &&
    new Date(subscriptionStatus.expiresAt) > new Date();

  const canPerformAction = useCallback((action: 'new_order' | 'menu_edit' | 'loyalty' | 'telegram_bot' | 'analytics' | 'customers'): boolean => {
    if (!subscriptionStatus) return false;
    if (subscriptionStatus.status === 'suspended') return false;
    if (new Date(subscriptionStatus.expiresAt) < new Date()) return false;

    switch (action) {
      case 'new_order':
        return subscriptionStatus.canCreateOrder;
      case 'menu_edit':
      case 'loyalty':
      case 'telegram_bot':
        return subscriptionStatus.status === 'active';
      case 'analytics':
      case 'customers':
        return true;
      default:
        return false;
    }
  }, [subscriptionStatus]);

  return (
    <SubscriptionContext.Provider value={{
      plans,
      currentSubscription,
      subscriptionStatus,
      subscriptionRequests,
      loading,
      hasUsedTrial,
      hasUsedFreePlan,
      isSuspended,
      isExpired,
      fetchPlans,
      fetchSubscription,
      fetchSubscriptionRequests,
      activateTrial,
      activateFreePlan,
      requestSubscription,
      canPerformAction,
      isSubscriptionActive,
      refreshSubscription,
    }}>
      {children}
    </SubscriptionContext.Provider>
  );
}

export function useSubscription() {
  const ctx = useContext(SubscriptionContext);
  if (!ctx) throw new Error('useSubscription must be used within SubscriptionProvider');
  return ctx;
}
