// Activity log helper — call from anywhere to record user actions
import { supabase } from './supabase';

interface LogParams {
  restaurantId: string;
  userId: string;
  userEmail: string;
  action: string;
  entityType: string;
  entityId?: string;
  entityName?: string;
  metadata?: Record<string, unknown>;
}

export async function logActivity(params: LogParams) {
  const { error } = await supabase.from('activity_logs').insert({
    restaurant_id: params.restaurantId,
    user_id: params.userId,
    user_email: params.userEmail,
    action: params.action,
    entity_type: params.entityType,
    entity_id: params.entityId ?? null,
    entity_name: params.entityName ?? null,
    metadata: params.metadata ?? {},
  });
  if (error) console.error('[activity_log]', error.message);
}
