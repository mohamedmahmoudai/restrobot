export type Json = string | number | boolean | null | { [key: string]: Json } | Json[];

interface RestaurantRow {
  id: string;
  owner_id: string;
  name: string;
  logo_url: string | null;
  phone: string | null;
  address: string | null;
  telegram_bot_token: string | null;
  telegram_chat_id: string | null;
  whatsapp_webhook_url: string | null;
  n8n_webhook_url: string | null;
  currency: string | null;
  timezone: string | null;
  is_active: boolean;
  loyalty_enabled: boolean;
  subscription_plan: string | null;
  subscription_expires_at: string | null;
  is_suspended: boolean;
  has_used_trial: boolean;
  onboarding_completed: boolean;
  cuisine_type: string | null;
  email?: string | null;
  created_at: string;
  updated_at: string;
}

interface MenuCategoryRow {
  id: string;
  restaurant_id: string;
  name: string;
  name_ar: string;
  sort_order: number;
  is_active: boolean;
  created_at: string;
}

interface MenuItemRow {
  id: string;
  restaurant_id: string;
  category_id: string | null;
  name: string;
  name_ar: string;
  description: string | null;
  description_ar: string | null;
  price: number;
  image_url: string | null;
  is_available: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

interface CustomerRow {
  id: string;
  restaurant_id: string;
  name: string;
  phone: string;
  telegram_id: string | null;
  whatsapp_id: string | null;
  channel: string | null;
  address: string | null;
  notes: string | null;
  status: string;
  total_orders: number;
  total_spent: number;
  loyalty_points: number;
  created_at: string;
  updated_at: string;
}

interface OrderRow {
  id: string;
  restaurant_id: string;
  customer_id: string | null;
  order_number: string;
  status: string;
  channel: string;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  delivery_fee: number;
  notes: string | null;
  delivery_address: string | null;
  payment_method: string;
  payment_status: string;
  raw_payload: Json;
  created_at: string;
  updated_at: string;
}

interface OrderItemRow {
  id: string;
  order_id: string;
  menu_item_id: string | null;
  name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  notes: string | null;
  created_at: string;
}

interface LoyaltyRewardRow {
  id: string;
  restaurant_id: string;
  name: string;
  description: string | null;
  points_required: number;
  reward_type: string;
  reward_value: number;
  is_active: boolean;
  created_at: string;
}

interface LoyaltyTransactionRow {
  id: string;
  restaurant_id: string;
  customer_id: string;
  order_id: string | null;
  reward_id: string | null;
  type: string;
  points: number;
  notes: string | null;
  created_at: string;
}

interface LoyaltySettingsRow {
  id: string;
  restaurant_id: string;
  rule_type: string;
  orders_threshold: number;
  orders_points: number;
  amount_threshold: number;
  amount_points: number;
  points_per_currency_unit: number;
  currency_unit: number;
  points_expiration_days: number;
  min_redemption_points: number;
  max_redemption_per_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface CustomerPointsWalletRow {
  id: string;
  restaurant_id: string;
  customer_id: string;
  current_points: number;
  lifetime_points: number;
  redeemed_points: number;
  current_tier: string;
  points_expiry_date: string | null;
  created_at: string;
  updated_at: string;
}

interface RewardCatalogRow {
  id: string;
  restaurant_id: string;
  name: string;
  description: string | null;
  points_required: number;
  reward_type: string;
  reward_value: number;
  reward_item_name: string | null;
  is_active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

interface RewardRedemptionRow {
  id: string;
  restaurant_id: string;
  customer_id: string;
  reward_id: string;
  points_used: number;
  redemption_code: string;
  status: string;
  redeemed_at: string | null;
  expires_at: string | null;
  created_at: string;
}

interface CustomerTierRow {
  id: string;
  restaurant_id: string;
  tier_name: string;
  tier_label_ar: string;
  min_points: number;
  max_points: number | null;
  color_hex: string;
  benefits: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

interface PointsTransactionRow {
  id: string;
  restaurant_id: string;
  customer_id: string;
  order_id: string | null;
  reward_id: string | null;
  redemption_id: string | null;
  type: string;
  points: number;
  balance_after: number;
  notes: string | null;
  created_at: string;
}

interface NotificationRow {
  id: string;
  restaurant_id: string;
  type: string;
  title: string;
  body: string;
  data: Json;
  is_read: boolean;
  created_at: string;
}

interface AnalyticsSnapshotRow {
  id: string;
  restaurant_id: string;
  snapshot_date: string;
  total_orders: number;
  total_revenue: number;
  avg_order_value: number;
  new_customers: number;
  returning_customers: number;
  top_items: Json;
  orders_by_hour: Json;
  created_at: string;
}

interface TelegramSessionRow {
  id: string;
  restaurant_id: string;
  telegram_user_id: string;
  state: string;
  current_category_id: string | null;
  cart: Json;
  checkout_data: Json;
  message_id: string | null;
  created_at: string;
  updated_at: string;
}

interface DeliveryZoneRow {
  id: string;
  restaurant_id: string;
  name: string;
  price: number;
  created_at: string;
}

interface SystemPlanRow {
  id: string;
  plan_name: string;
  name_ar: string | null;
  type: string;
  price: number;
  price_weekly: number;
  price_monthly: number;
  price_yearly: number;
  duration_days: number;
  max_orders: number | null;
  max_branches: number | null;
  max_users: number | null;
  max_menu_items: number | null;
  features: Json;
  is_active: boolean;
  is_trial: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
  internal_code: string | null;
  description: string | null;
  plan_color: string | null;
  plan_icon: string | null;
  badge: string | null;
  show_on_landing: boolean;
  can_subscribe: boolean;
  plan_type: string;
  supports_weekly: boolean;
  supports_monthly: boolean;
  supports_yearly: boolean;
  trial_days: number;
  auto_renew: boolean;
  max_categories: number | null;
  max_customers: number | null;
  max_telegram_bots: number | null;
  max_storage_gb: number | null;
  max_daily_messages: number | null;
  max_ai_requests: number | null;
  max_qr_menus: number | null;
  max_tables: number | null;
  max_loyalty_campaigns: number | null;
  max_coupons: number | null;
  enterprise_notes: string | null;
}

interface PlanRow {
  id: string;
  name: string;
  name_ar: string;
  price: number;
  currency: string;
  duration_days: number;
  max_orders: number | null;
  max_staff: number | null;
  max_branches: number | null;
  features: Json;
  is_trial: boolean;
  is_active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

interface RestaurantSubscriptionRow {
  id: string;
  restaurant_id: string;
  plan_id: string;
  billing_cycle: 'monthly';
  status: 'active' | 'expired' | 'pending_payment' | 'suspended' | 'cancelled';
  starts_at: string;
  expires_at: string;
  orders_used: number;
  trial_used: boolean;
  payment_status: 'pending' | 'approved' | 'rejected';
  payment_proof_url: string | null;
  payment_notes: string | null;
  admin_notes: string | null;
  rejection_reason: string | null;
  created_at: string;
  updated_at: string;
}

interface PaymentRequestRow {
  id: string;
  restaurant_id: string;
  plan_id: string;
  status: 'pending' | 'approved' | 'rejected';
  amount: number;
  currency: string;
  payment_proof_url: string;
  notes: string | null;
  admin_notes: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
  updated_at: string;
}

interface FeatureDefinitionRow {
  id: string;
  key: string;
  label_ar: string;
  label_en: string;
  category: string;
  icon: string | null;
  sort_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface PlanFeatureRow {
  id: string;
  plan_id: string;
  feature_id: string;
  created_at: string;
}

interface SubscriptionRequestRow {
  id: string;
  restaurant_id: string;
  plan_id: string;
  billing_cycle: string;
  amount: number;
  currency: string;
  status: 'pending' | 'approved' | 'rejected';
  rejection_reason: string | null;
  payment_proof_url: string | null;
  notes: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
  updated_at: string;
}

interface SubscriptionHistoryRow {
  id: string;
  restaurant_id: string;
  subscription_id: string | null;
  plan_id: string | null;
  action: string;
  old_status: string | null;
  new_status: string | null;
  notes: string | null;
  performed_by: string | null;
  created_at: string;
}

interface OnboardingProgressRow {
  id: string;
  restaurant_id: string;
  current_step: number;
  completed_steps: number[];
  is_completed: boolean;
  completed_at: string | null;
  step_data: Json;
  created_at: string;
  updated_at: string;
}

interface TelegramBotRow {
  id: string;
  restaurant_id: string;
  bot_token: string | null;
  chat_id: string | null;
  is_connected: boolean;
  last_sync_at: string | null;
  sync_status: string;
  sync_error: string | null;
  created_at: string;
  updated_at: string;
}

interface TelegramSyncLogRow {
  id: string;
  restaurant_id: string;
  sync_type: string;
  status: string;
  items_synced: number;
  error_message: string | null;
  created_at: string;
}

interface TelegramMenuCacheRow {
  id: string;
  restaurant_id: string;
  cache_type: string;
  cache_data: Json;
  hash: string | null;
  updated_at: string;
}

interface OrderEventRow {
  id: string;
  restaurant_id: string;
  order_id: string;
  event_type: string;
  old_status: string | null;
  new_status: string;
  user_id: string | null;
  user_email: string | null;
  notes: string | null;
  metadata: Json;
  created_at: string;
}

interface SupportTicketRow {
  id: string;
  restaurant_id: string;
  type: string;
  subject: string;
  body: string;
  status: string;
  priority: string;
  admin_reply: string | null;
  replied_at: string | null;
  replied_by: string | null;
  created_at: string;
  updated_at: string;
}

interface PlatformSettingRow {
  id: string;
  key: string;
  value: string;
  description: string | null;
  updated_at: string;
}

interface AnnouncementRow {
  id: string;
  title: string;
  body: string;
  type: string;
  is_active: boolean;
  target_audience: string;
  start_date: string | null;
  end_date: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

interface AdminAuditLogRow {
  id: string;
  admin_id: string;
  admin_email: string | null;
  action: string;
  target_type: string;
  target_id: string | null;
  target_name: string | null;
  details: Json;
  ip_address: string | null;
  created_at: string;
}

interface PlatformAdminRow {
  id: string;
  user_id: string;
  email: string | null;
  full_name: string | null;
  role: string;
  is_active: boolean;
  last_login: string | null;
  created_at: string;
  updated_at: string | null;
}

export interface Database {
  public: {
    Tables: {
      restaurants: {
        Row: RestaurantRow;
        Insert: Partial<Omit<RestaurantRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<RestaurantRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      menu_categories: {
        Row: MenuCategoryRow;
        Insert: Partial<Omit<MenuCategoryRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<MenuCategoryRow, 'id' | 'created_at'>>;
      };
      menu_items: {
        Row: MenuItemRow;
        Insert: Partial<Omit<MenuItemRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<MenuItemRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      customers: {
        Row: CustomerRow;
        Insert: Partial<Omit<CustomerRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<CustomerRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      orders: {
        Row: OrderRow;
        Insert: Partial<Omit<OrderRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<OrderRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      order_items: {
        Row: OrderItemRow;
        Insert: Partial<Omit<OrderItemRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<OrderItemRow, 'id' | 'created_at'>>;
      };
      loyalty_rewards: {
        Row: LoyaltyRewardRow;
        Insert: Partial<Omit<LoyaltyRewardRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<LoyaltyRewardRow, 'id' | 'created_at'>>;
      };
      loyalty_transactions: {
        Row: LoyaltyTransactionRow;
        Insert: Partial<Omit<LoyaltyTransactionRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<LoyaltyTransactionRow, 'id' | 'created_at'>>;
      };
      loyalty_settings: {
        Row: LoyaltySettingsRow;
        Insert: Partial<Omit<LoyaltySettingsRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<LoyaltySettingsRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      customer_points_wallet: {
        Row: CustomerPointsWalletRow;
        Insert: Partial<Omit<CustomerPointsWalletRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<CustomerPointsWalletRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      reward_catalog: {
        Row: RewardCatalogRow;
        Insert: Partial<Omit<RewardCatalogRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<RewardCatalogRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      reward_redemptions: {
        Row: RewardRedemptionRow;
        Insert: Partial<Omit<RewardRedemptionRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<RewardRedemptionRow, 'id' | 'created_at'>>;
      };
      customer_tiers: {
        Row: CustomerTierRow;
        Insert: Partial<Omit<CustomerTierRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<CustomerTierRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      points_transactions: {
        Row: PointsTransactionRow;
        Insert: Partial<Omit<PointsTransactionRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<PointsTransactionRow, 'id' | 'created_at'>>;
      };
      notifications: {
        Row: NotificationRow;
        Insert: Partial<Omit<NotificationRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<NotificationRow, 'id' | 'created_at'>>;
      };
      analytics_snapshots: {
        Row: AnalyticsSnapshotRow;
        Insert: Partial<Omit<AnalyticsSnapshotRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<AnalyticsSnapshotRow, 'id' | 'created_at'>>;
      };
      telegram_sessions: {
        Row: TelegramSessionRow;
        Insert: Partial<Omit<TelegramSessionRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<TelegramSessionRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      delivery_zones: {
        Row: DeliveryZoneRow;
        Insert: Partial<Omit<DeliveryZoneRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<DeliveryZoneRow, 'id' | 'created_at'>>;
      };
      system_plans: {
        Row: SystemPlanRow;
        Insert: Partial<Omit<SystemPlanRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<SystemPlanRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      plans: {
        Row: PlanRow;
        Insert: Partial<Omit<PlanRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<PlanRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      restaurant_subscriptions: {
        Row: RestaurantSubscriptionRow;
        Insert: Partial<Omit<RestaurantSubscriptionRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<RestaurantSubscriptionRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      payment_requests: {
        Row: PaymentRequestRow;
        Insert: Partial<Omit<PaymentRequestRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<PaymentRequestRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      feature_definitions: {
        Row: FeatureDefinitionRow;
        Insert: Partial<Omit<FeatureDefinitionRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<FeatureDefinitionRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      plan_features: {
        Row: PlanFeatureRow;
        Insert: Partial<Omit<PlanFeatureRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<PlanFeatureRow, 'id' | 'created_at'>>;
      };
      subscription_requests: {
        Row: SubscriptionRequestRow;
        Insert: Partial<Omit<SubscriptionRequestRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<SubscriptionRequestRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      subscription_history: {
        Row: SubscriptionHistoryRow;
        Insert: Partial<Omit<SubscriptionHistoryRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<SubscriptionHistoryRow, 'id' | 'created_at'>>;
      };
      onboarding_progress: {
        Row: OnboardingProgressRow;
        Insert: Partial<Omit<OnboardingProgressRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<OnboardingProgressRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      telegram_bots: {
        Row: TelegramBotRow;
        Insert: Partial<Omit<TelegramBotRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<TelegramBotRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      telegram_sync_logs: {
        Row: TelegramSyncLogRow;
        Insert: Partial<Omit<TelegramSyncLogRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<TelegramSyncLogRow, 'id' | 'created_at'>>;
      };
      telegram_menu_cache: {
        Row: TelegramMenuCacheRow;
        Insert: Partial<Omit<TelegramMenuCacheRow, 'id' | 'updated_at'>>;
        Update: Partial<Omit<TelegramMenuCacheRow, 'id' | 'updated_at'>>;
      };
      order_events: {
        Row: OrderEventRow;
        Insert: Partial<Omit<OrderEventRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<OrderEventRow, 'id' | 'created_at'>>;
      };
      support_tickets: {
        Row: SupportTicketRow;
        Insert: Partial<Omit<SupportTicketRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<SupportTicketRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      platform_settings: {
        Row: PlatformSettingRow;
        Insert: Partial<Omit<PlatformSettingRow, 'id' | 'updated_at'>>;
        Update: Partial<Omit<PlatformSettingRow, 'id' | 'updated_at'>>;
      };
      announcements: {
        Row: AnnouncementRow;
        Insert: Partial<Omit<AnnouncementRow, 'id' | 'created_at' | 'updated_at'>>;
        Update: Partial<Omit<AnnouncementRow, 'id' | 'created_at' | 'updated_at'>>;
      };
      admin_audit_logs: {
        Row: AdminAuditLogRow;
        Insert: Partial<Omit<AdminAuditLogRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<AdminAuditLogRow, 'id' | 'created_at'>>;
      };
      platform_admins: {
        Row: PlatformAdminRow;
        Insert: Partial<Omit<PlatformAdminRow, 'id' | 'created_at'>>;
        Update: Partial<Omit<PlatformAdminRow, 'id' | 'created_at'>>;
      };
      rls_coverage: {
        Row: { table_name: string; rls_enabled: boolean; policy_count: number };
        Insert: never;
        Update: never;
      };
    };
    Functions: {
      is_platform_admin: {
        Args: Record<string, never>;
        Returns: boolean;
      };
    };
  };
}

export type Restaurant = RestaurantRow;
export type MenuCategory = MenuCategoryRow;
export type MenuItem = MenuItemRow;
export type Customer = CustomerRow;
export type Order = OrderRow;
export type OrderItem = OrderItemRow;
export type LoyaltyReward = LoyaltyRewardRow;
export type LoyaltyTransaction = LoyaltyTransactionRow;
export type LoyaltySettings = LoyaltySettingsRow;
export type CustomerPointsWallet = CustomerPointsWalletRow;
export type RewardCatalog = RewardCatalogRow;
export type RewardRedemption = RewardRedemptionRow;
export type CustomerTier = CustomerTierRow;
export type PointsTransaction = PointsTransactionRow;
export type Notification = NotificationRow;
export type AnalyticsSnapshot = AnalyticsSnapshotRow;
export type TelegramSession = TelegramSessionRow;
export type DeliveryZone = DeliveryZoneRow;
export type SystemPlan = SystemPlanRow;
export type Plan = PlanRow;
export type RestaurantSubscription = RestaurantSubscriptionRow;
export type PaymentRequest = PaymentRequestRow;
export type FeatureDefinition = FeatureDefinitionRow;
export type PlanFeature = PlanFeatureRow;
export type SubscriptionRequest = SubscriptionRequestRow;
export type SubscriptionHistory = SubscriptionHistoryRow;
export type OnboardingProgress = OnboardingProgressRow;
export type TelegramBot = TelegramBotRow;
export type TelegramSyncLog = TelegramSyncLogRow;
export type TelegramMenuCache = TelegramMenuCacheRow;
export type OrderEvent = OrderEventRow;
export type SupportTicket = SupportTicketRow;
export type PlatformSetting = PlatformSettingRow;
export type Announcement = AnnouncementRow;
export type AdminAuditLog = AdminAuditLogRow;
export type PlatformAdmin = PlatformAdminRow;
