// CSV export utility — tenant-scoped
import { supabase } from '../lib/supabase';

function downloadCsv(rows: string[][], filename: string) {
  const bom = '\uFEFF'; // UTF-8 BOM for Arabic in Excel
  const csv = bom + rows.map(r => r.map(cell =>
    `"${String(cell ?? '').replace(/"/g, '""')}"`
  ).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export async function exportOrders(restaurantId: string, currencySymbol: string) {
  const { data, error } = await supabase
    .from('orders')
    .select('order_number,status,channel,total,subtotal,discount,payment_method,payment_status,delivery_address,notes,created_at')
    .eq('restaurant_id', restaurantId)
    .order('created_at', { ascending: false });

  if (error || !data) throw error;

  const headers = ['رقم الطلب', 'الحالة', 'القناة', `الإجمالي (${currencySymbol})`, `المجموع الفرعي (${currencySymbol})`, `الخصم (${currencySymbol})`, 'طريقة الدفع', 'حالة الدفع', 'عنوان التوصيل', 'ملاحظات', 'التاريخ'];
  const rows = data.map(o => [
    o.order_number, o.status, o.channel,
    String(o.total), String(o.subtotal), String(o.discount),
    o.payment_method, o.payment_status,
    o.delivery_address ?? '', o.notes ?? '',
    new Date(o.created_at).toLocaleString('ar-EG'),
  ]);
  downloadCsv([headers, ...rows], `orders_${new Date().toISOString().split('T')[0]}.csv`);
}

export async function exportCustomers(restaurantId: string) {
  const { data, error } = await supabase
    .from('customers')
    .select('name,phone,telegram_id,channel,address,total_orders,total_spent,loyalty_points,status,created_at')
    .eq('restaurant_id', restaurantId)
    .order('created_at', { ascending: false });

  if (error || !data) throw error;

  const headers = ['الاسم', 'الهاتف', 'تيليجرام ID', 'القناة', 'العنوان', 'إجمالي الطلبات', 'إجمالي الإنفاق', 'نقاط الولاء', 'الحالة', 'تاريخ التسجيل'];
  const rows = data.map(c => [
    c.name, c.phone ?? '', c.telegram_id ?? '', c.channel ?? '',
    c.address ?? '', String(c.total_orders), String(c.total_spent),
    String(c.loyalty_points), c.status ?? 'new',
    new Date(c.created_at).toLocaleString('ar-EG'),
  ]);
  downloadCsv([headers, ...rows], `customers_${new Date().toISOString().split('T')[0]}.csv`);
}

export async function exportProducts(restaurantId: string, currencySymbol: string) {
  const { data, error } = await supabase
    .from('menu_items')
    .select('name,name_ar,price,is_available,sort_order,created_at,menu_categories(name)')
    .eq('restaurant_id', restaurantId)
    .order('sort_order', { ascending: true });

  if (error || !data) throw error;

  const headers = ['الاسم', 'الاسم بالعربي', 'الفئة', `السعر (${currencySymbol})`, 'متاح', 'الترتيب', 'تاريخ الإضافة'];
  const rows = data.map((p: any) => [
    p.name, p.name_ar ?? '', p.menu_categories?.name ?? '',
    String(p.price), p.is_available ? 'نعم' : 'لا',
    String(p.sort_order),
    new Date(p.created_at).toLocaleString('ar-EG'),
  ]);
  downloadCsv([headers, ...rows], `products_${new Date().toISOString().split('T')[0]}.csv`);
}

export async function exportLoyalty(restaurantId: string) {
  const { data, error } = await supabase
    .from('points_transactions')
    .select('type,points,balance_after,notes,created_at,customers(name,phone)')
    .eq('restaurant_id', restaurantId)
    .order('created_at', { ascending: false });

  if (error || !data) throw error;

  const headers = ['العميل', 'الهاتف', 'النوع', 'النقاط', 'الرصيد بعد', 'ملاحظات', 'التاريخ'];
  const rows = data.map((t: any) => [
    t.customers?.name ?? '', t.customers?.phone ?? '',
    t.type, String(t.points), String(t.balance_after),
    t.notes ?? '',
    new Date(t.created_at).toLocaleString('ar-EG'),
  ]);
  downloadCsv([headers, ...rows], `loyalty_${new Date().toISOString().split('T')[0]}.csv`);
}
