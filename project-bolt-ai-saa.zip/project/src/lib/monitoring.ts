// Monitoring integration — Sentry + Vercel Analytics + Speed Insights
// All integrations are opt-in via environment variables. No paid plan required.
// Packages are NOT required — missing packages are silently skipped.

declare global {
  interface Window { _sentryLoaded?: boolean }
}

// ── Sentry ──────────────────────────────────────────────────────────────────
// Set VITE_SENTRY_DSN in .env to enable.
export function initSentry() {
  const dsn = import.meta.env.VITE_SENTRY_DSN as string | undefined;
  if (!dsn || window._sentryLoaded) return;
  // Load from CDN — zero bundle impact, no npm package needed
  const script = document.createElement('script');
  script.src = 'https://browser.sentry-cdn.com/7.99.0/bundle.min.js';
  script.crossOrigin = 'anonymous';
  script.onload = () => {
    window._sentryLoaded = true;
    (window as any).Sentry?.init({
      dsn,
      environment: import.meta.env.MODE,
      tracesSampleRate: 0.2,
    });
  };
  document.head.appendChild(script);
}

export function captureError(error: unknown, context?: Record<string, unknown>) {
  const sentry = (window as any).Sentry;
  if (!sentry) return;
  if (context) sentry.setContext('extra', context);
  sentry.captureException(error);
}

// ── Vercel Analytics + Speed Insights ────────────────────────────────────────
// Auto-injected by Vercel on deployment. No action needed unless running locally.
// Set VITE_ENABLE_VERCEL_ANALYTICS=true to inject the script in dev.
export function initVercelAnalytics() {
  if (!import.meta.env.VITE_ENABLE_VERCEL_ANALYTICS) return;
  // Vercel auto-injects this on *.vercel.app — skip if already present
  if (document.querySelector('script[data-vercel-analytics]')) return;
  const script = document.createElement('script');
  script.defer = true;
  script.setAttribute('data-vercel-analytics', 'true');
  script.src = '/_vercel/insights/script.js';
  document.head.appendChild(script);
}

export function initSpeedInsights() {
  if (!import.meta.env.VITE_ENABLE_VERCEL_ANALYTICS) return;
  if (document.querySelector('script[data-vercel-speed-insights]')) return;
  const script = document.createElement('script');
  script.defer = true;
  script.setAttribute('data-vercel-speed-insights', 'true');
  script.src = '/_vercel/speed-insights/script.js';
  document.head.appendChild(script);
}

// ── Custom event tracking ─────────────────────────────────────────────────────
export function trackEvent(name: string, properties?: Record<string, unknown>) {
  const sentry = (window as any).Sentry;
  if (sentry) sentry.addBreadcrumb({ message: name, data: properties, level: 'info' });
  if (import.meta.env.DEV) console.info(`[analytics] ${name}`, properties ?? '');
}
