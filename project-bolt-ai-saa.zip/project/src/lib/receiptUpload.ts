import { supabase } from './supabase';

const BUCKET_NAME = 'payment-receipts';
let bucketEnsured = false;

export async function ensureReceiptBucket(): Promise<void> {
  if (bucketEnsured) return;
  try {
    const { error } = await supabase.storage.createBucket(BUCKET_NAME, {
      public: true,
      fileSizeLimit: '10MB',
      allowedMimeTypes: ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'application/pdf'],
    });
    if (error && !error.message.includes('already exists')) {
      console.warn('Could not create bucket:', error.message);
    }
    bucketEnsured = true;
  } catch (err) {
    console.warn('Bucket creation attempt failed:', err);
    bucketEnsured = true;
  }
}

export async function uploadReceipt(file: File, restaurantId: string): Promise<string> {
  await ensureReceiptBucket();
  const ext = file.name.split('.').pop() || 'bin';
  const fileName = `receipts/${restaurantId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
  const { error: uploadError } = await supabase.storage
    .from(BUCKET_NAME)
    .upload(fileName, file, { upsert: false });
  if (uploadError) throw uploadError;
  const { data: urlData } = supabase.storage.from(BUCKET_NAME).getPublicUrl(fileName);
  return urlData.publicUrl;
}

export async function deleteReceipt(url: string): Promise<void> {
  try {
    const pathMatch = url.match(/\/payment-receipts\/(.+)$/);
    if (pathMatch) {
      await supabase.storage.from(BUCKET_NAME).remove([pathMatch[1]]);
    }
  } catch {
    // ignore
  }
}
