// Telegram sync stubs — the webhook reads directly from DB on every message,
// so no frontend-initiated cache sync is required. These stubs exist to avoid
// breaking call sites that were referencing the old sync functions.

import { supabase } from './supabase';

export interface SyncResult { success: boolean; itemsSynced: number; error?: string }

export interface TelegramSyncStatus {
  isConnected: boolean;
  lastSync: string | null;
  botUsername: string | null;
  webhookUrl: string | null;
  error?: string;
}

export async function syncCategories(_restaurantId: string): Promise<SyncResult> {
  return { success: true, itemsSynced: 0 };
}
export async function syncProducts(_restaurantId: string): Promise<SyncResult> {
  return { success: true, itemsSynced: 0 };
}
export async function syncDeliveryZones(_restaurantId: string): Promise<SyncResult> {
  return { success: true, itemsSynced: 0 };
}
export async function syncLoyaltyRewards(_restaurantId: string): Promise<SyncResult> {
  return { success: true, itemsSynced: 0 };
}
export async function syncTelegramBot(_restaurantId: string): Promise<SyncResult> {
  return { success: true, itemsSynced: 0 };
}

export async function getSyncStatus(restaurantId: string): Promise<TelegramSyncStatus> {
  const { data } = await supabase
    .from('restaurants')
    .select('telegram_bot_token, telegram_bot_username, telegram_webhook_status, telegram_owner_chat_id')
    .eq('id', restaurantId)
    .maybeSingle();
  return {
    isConnected: data?.telegram_webhook_status === 'active',
    lastSync: null,
    botUsername: data?.telegram_bot_username ?? null,
    webhookUrl: null,
  };
}

export async function getSyncLogs(_restaurantId: string): Promise<any[]> {
  return [];
}

export async function testTelegramConnection(botToken: string): Promise<{ success: boolean; username?: string; error?: string }> {
  try {
    const res = await fetch(`https://api.telegram.org/bot${botToken}/getMe`);
    const data = await res.json();
    if (data.ok) return { success: true, username: data.result?.username };
    return { success: false, error: data.description };
  } catch (e) {
    return { success: false, error: 'Network error' };
  }
}

export async function createOrUpdateTelegramBot(
  restaurantId: string,
  botToken: string
): Promise<{ success: boolean; error?: string }> {
  const test = await testTelegramConnection(botToken);
  if (!test.success) return { success: false, error: test.error };

  const { error } = await supabase
    .from('restaurants')
    .update({ telegram_bot_token: botToken })
    .eq('id', restaurantId);

  if (error) return { success: false, error: error.message };
  return { success: true };
}
