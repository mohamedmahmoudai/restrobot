import { supabase } from './supabase';
import { syncCategories, syncProducts, syncDeliveryZones, syncLoyaltyRewards } from './telegramSync';

export async function triggerSync(restaurantId: string, type: 'categories' | 'products' | 'delivery_zones' | 'loyalty') {
  // Check if restaurant has telegram bot configured
  const { data: restaurant } = await supabase
    .from('restaurants')
    .select('telegram_bot_token, telegram_chat_id')
    .eq('id', restaurantId)
    .maybeSingle();

  if (!restaurant?.telegram_bot_token || !restaurant.telegram_chat_id) {
    // Bot not configured, skip sync
    return;
  }

  // Trigger sync based on type
  switch (type) {
    case 'categories':
      await syncCategories(restaurantId);
      break;
    case 'products':
      await syncProducts(restaurantId);
      break;
    case 'delivery_zones':
      await syncDeliveryZones(restaurantId);
      break;
    case 'loyalty':
      await syncLoyaltyRewards(restaurantId);
      break;
  }
}

export function withAutoSync<T extends (...args: any[]) => Promise<any>>(
  fn: T,
  getRestaurantId: (...args: Parameters<T>) => string,
  syncType: 'categories' | 'products' | 'delivery_zones' | 'loyalty'
): T {
  return (async (...args: Parameters<T>) => {
    const result = await fn(...args);
    const restaurantId = getRestaurantId(...args);
    await triggerSync(restaurantId, syncType);
    return result;
  }) as T;
}
