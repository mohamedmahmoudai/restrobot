import { useState } from 'react';
import { Link, useNavigate, useLocation }  from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, Eye, EyeOff, AlertCircle, Loader2, ArrowRight, Check } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function Auth() {
  const location = useLocation();
  const isLogin = location.pathname === '/login';

  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginShowPassword, setLoginShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);

  const [restaurantName, setRestaurantName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [registerConfirm, setRegisterConfirm] = useState('');
  const [registerShowPassword, setRegisterShowPassword] = useState(false);
  const [registerError, setRegisterError] = useState('');
  const [registerLoading, setRegisterLoading] = useState(false);

  const { signIn, signUp } = useAuth();
  const navigate = useNavigate();

  const passwordStrength = registerPassword.length >= 8 && /[A-Z]/.test(registerPassword) && /[0-9]/.test(registerPassword);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      setLoginError('يرجى ملء جميع الحقول');
      return;
    }
    setLoginLoading(true);
    setLoginError('');
    const { error } = await signIn(loginEmail, loginPassword);
    setLoginLoading(false);
    if (error) {
      setLoginError(error);
      return;
    }
    navigate('/dashboard');
  }

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    if (!restaurantName || !registerEmail || !registerPassword || !registerConfirm) {
      setRegisterError('يرجى ملء جميع الحقول');
      return;
    }
    if (registerPassword !== registerConfirm) {
      setRegisterError('كلمتا المرور غير متطابقتين');
      return;
    }
    if (registerPassword.length < 6) {
      setRegisterError('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
      return;
    }
    setRegisterLoading(true);
    setRegisterError('');
    const { error, needsPlanSelection } = await signUp(registerEmail, registerPassword, restaurantName);
    setRegisterLoading(false);
    if (error) {
      setRegisterError(error);
      return;
    }
    if (needsPlanSelection) {
      navigate('/select-plan');
    } else {
      navigate('/dashboard');
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4 py-12" dir="rtl">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-3 justify-center mb-6 group">
            <div className="w-12 h-12 bg-primary-600 rounded-2xl flex items-center justify-center shadow-lg shadow-primary-500/20 group-hover:shadow-primary-500/30 transition-shadow">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-slate-900">RestroBot</span>
          </Link>
        </div>

        <AnimatePresence mode="wait">
          {isLogin ? (
            <motion.div
              key="login"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 1, y: -12 }}
              transition={{ duration: 0.25 }}
              className="card p-8"
            >
              <div className="mb-6">
                <h1 className="text-2xl font-bold text-slate-900 mb-1">مرحباً بعودتك</h1>
                <p className="text-sm text-slate-500">سجّل دخولك لإدارة مطعمك</p>
              </div>

              <form onSubmit={handleLogin} className="space-y-4">
                {loginError && (
                  <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 bg-danger-50 border border-danger-200 text-danger-600 text-sm px-4 py-3 rounded-xl">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    {loginError}
                  </motion.div>
                )}

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">البريد الإلكتروني</label>
                  <input
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="you@restaurant.com"
                    className="input-field"
                    disabled={loginLoading}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">كلمة المرور</label>
                  <div className="relative">
                    <input
                      type={loginShowPassword ? 'text' : 'password'}
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••"
                      className="input-field pl-10"
                      disabled={loginLoading}
                    />
                    <button
                      type="button"
                      onClick={() => setLoginShowPassword(!loginShowPassword)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors p-1"
                      tabIndex={-1}
                    >
                      {loginShowPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <input type="checkbox" className="w-4 h-4 rounded border-slate-300 text-primary-600 focus:ring-primary-500" />
                    <span className="text-slate-500 group-hover:text-slate-700 transition-colors">تذكرني</span>
                  </label>
                  <a href="#" className="text-slate-500 hover:text-primary-600 transition-colors">
                    نسيت كلمة المرور؟
                  </a>
                </div>

                <button type="submit" disabled={loginLoading} className="w-full btn-primary py-3">
                  {loginLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      جارٍ الدخول...
                    </>
                  ) : (
                    <>
                      تسجيل الدخول
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200" />
                </div>
                <div className="relative flex justify-center">
                  <span className="bg-white px-4 text-xs text-slate-400">أو</span>
                </div>
              </div>

              <div className="text-center text-sm">
                <span className="text-slate-500">ليس لديك حساب؟</span>{' '}
                <Link to="/register" className="text-primary-600 hover:text-primary-700 font-semibold transition-colors">
                  أنشئ حساباً
                </Link>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="register"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.25 }}
              className="card p-8"
            >
              <div className="mb-6">
                <h1 className="text-2xl font-bold text-slate-900 mb-1">أنشئ مطعمك الرقمي</h1>
                <p className="text-sm text-slate-500">دقيقة واحدة للبدء باستقبال الطلبات</p>
              </div>

              <form onSubmit={handleRegister} className="space-y-4">
                {registerError && (
                  <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 bg-danger-50 border border-danger-200 text-danger-600 text-sm px-4 py-3 rounded-xl">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    {registerError}
                  </motion.div>
                )}

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">اسم المطعم</label>
                  <input
                    type="text"
                    value={restaurantName}
                    onChange={(e) => setRestaurantName(e.target.value)}
                    placeholder="مطعم الفخامة"
                    className="input-field"
                    disabled={registerLoading}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">البريد الإلكتروني</label>
                  <input
                    type="email"
                    value={registerEmail}
                    onChange={(e) => setRegisterEmail(e.target.value)}
                    placeholder="you@restaurant.com"
                    className="input-field"
                    disabled={registerLoading}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">كلمة المرور</label>
                  <div className="relative">
                    <input
                      type={registerShowPassword ? 'text' : 'password'}
                      value={registerPassword}
                      onChange={(e) => setRegisterPassword(e.target.value)}
                      placeholder="••••••••"
                      className="input-field pl-10"
                      disabled={registerLoading}
                    />
                    <button
                      type="button"
                      onClick={() => setRegisterShowPassword(!registerShowPassword)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors p-1"
                      tabIndex={-1}
                    >
                      {registerShowPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {registerPassword && (
                    <div className={`flex items-center gap-1.5 mt-2 text-xs ${passwordStrength ? 'text-success-600' : 'text-slate-400'}`}>
                      <Check className="w-3 h-3" />
                      {passwordStrength ? 'كلمة مرور قوية' : '8 أحرف على الأقل مع أرقام وحروف كبيرة'}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">تأكيد كلمة المرور</label>
                  <input
                    type="password"
                    value={registerConfirm}
                    onChange={(e) => setRegisterConfirm(e.target.value)}
                    placeholder="••••••••"
                    className="input-field"
                    disabled={registerLoading}
                  />
                </div>

                <button type="submit" disabled={registerLoading} className="w-full btn-primary py-3">
                  {registerLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      جارٍ إنشاء الحساب...
                    </>
                  ) : (
                    <>
                      إنشاء الحساب والبدء
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              <p className="text-center text-slate-400 text-xs mt-5">
                بإنشاء حساب، أنت توافق على{' '}
                <a href="#" className="text-slate-500 hover:text-primary-600 transition-colors">سياسة الخصوصية</a>
                {' '}و{' '}
                <a href="#" className="text-slate-500 hover:text-primary-600 transition-colors">شروط الاستخدام</a>
              </p>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200" />
                </div>
                <div className="relative flex justify-center">
                  <span className="bg-white px-4 text-xs text-slate-400">أو</span>
                </div>
              </div>

              <div className="text-center text-sm">
                <span className="text-slate-500">لديك حساب بالفعل؟</span>{' '}
                <Link to="/login" className="text-primary-600 hover:text-primary-700 font-semibold transition-colors">
                  تسجيل الدخول
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Stats */}
        <div className="mt-8 grid grid-cols-3 gap-4 max-w-sm mx-auto">
          {['+500 مطعم', '99% دقة', '24/7 دعم'].map((stat) => (
            <div key={stat} className="text-center">
              <div className="text-lg font-bold text-primary-600">{stat.split(' ')[0]}</div>
              <div className="text-xs text-slate-400">{stat.split(' ').slice(1).join(' ')}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
