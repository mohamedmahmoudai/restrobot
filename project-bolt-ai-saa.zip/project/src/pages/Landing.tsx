import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import {
  BarChart3, Users, Star, Globe, Check, MessageCircle,
  TrendingUp, ArrowRight, Zap, Layers, Shield, Clock,
  Bot, Sparkles, Crown, Building2
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { SystemPlan } from '../lib/database.types';

interface LandingPlan extends SystemPlan {
  feature_labels: string[];
}

const fadeIn = { initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.5, ease: [0.25, 0.1, 0.25, 1] } };
const stagger = { animate: { transition: { staggerChildren: 0.08 } } };

export default function Landing() {
  const [plans, setPlans] = useState<LandingPlan[]>([]);

  useEffect(() => { fetchPlans(); }, []);

  async function fetchPlans() {
    const { data: plansData } = await supabase
      .from('system_plans')
      .select('*')
      .eq('is_active', true)
      .eq('show_on_landing', true)
      .order('sort_order', { ascending: true });

    if (!plansData || plansData.length === 0) return;

    const planIds = plansData.map(p => p.id);
    const { data: pfData } = await supabase
      .from('plan_features')
      .select('plan_id, feature_id')
      .in('plan_id', planIds);

    const featureIds = [...new Set((pfData ?? []).map(pf => pf.feature_id))];
    const { data: featuresData } = await supabase
      .from('feature_definitions')
      .select('id, label_ar')
      .in('id', featureIds);

    const featureMap: Record<string, string> = {};
    (featuresData ?? []).forEach(f => { featureMap[f.id] = f.label_ar; });

    const enriched: LandingPlan[] = plansData.map(plan => {
      const planFeatureIds = (pfData ?? []).filter(pf => pf.plan_id === plan.id).map(pf => pf.feature_id);
      const featureLabels = planFeatureIds.map(fid => featureMap[fid]).filter(Boolean);
      const inlineFeatures = Array.isArray(plan.features) ? (plan.features as unknown as string[]) : [];
      return { ...(plan as SystemPlan), feature_labels: [...featureLabels, ...inlineFeatures] };
    });

    setPlans(enriched);
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900" dir="rtl">
      <motion.nav initial={{ y: -12, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.4 }} className="fixed top-0 inset-x-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200/60">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
              <Bot className="w-4.5 h-4.5 text-white" />
            </div>
            <span className="font-bold text-base tracking-tight text-slate-900">RestroBot</span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm text-slate-500 hover:text-slate-900 transition-colors font-medium">الميزات</a>
            <a href="#how-it-works" className="text-sm text-slate-500 hover:text-slate-900 transition-colors font-medium">كيف يعمل</a>
            <a href="#pricing" className="text-sm text-slate-500 hover:text-slate-900 transition-colors font-medium">الأسعار</a>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/login" className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors px-4 py-2 rounded-xl hover:bg-slate-100">
              تسجيل الدخول
            </Link>
            <Link to="/register" className="btn-primary text-sm px-4 py-2">
              إنشاء حساب
            </Link>
          </div>
        </div>
      </motion.nav>

      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        <div className="max-w-6xl mx-auto">
          <motion.div initial="initial" animate="animate" variants={stagger} className="text-center max-w-3xl mx-auto">
            <motion.div variants={fadeIn} className="inline-flex items-center gap-2 bg-primary-50 border border-primary-100 text-primary-700 text-xs font-semibold px-4 py-1.5 rounded-full mb-6">
              <Sparkles className="w-3.5 h-3.5" />
              <span>أول نظام مطاعم ذكي في المنطقة</span>
            </motion.div>

            <motion.h1 variants={fadeIn} className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.1] mb-5 tracking-tight text-balance">
              <span className="text-slate-900">حوّل مطعمك إلى</span>{' '}
              <span className="text-primary-600">نسخة رقمية متكاملة</span>
            </motion.h1>

            <motion.p variants={fadeIn} className="text-lg text-slate-500 max-w-xl mx-auto mb-8 leading-relaxed text-balance">
              استقبل الطلبات تلقائياً عبر تيليجرام، أدر المطبخ والعملاء، وحسّن مبيعاتك مع تحليلات ذكية.
            </motion.p>

            <motion.div variants={fadeIn} className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link to="/register" className="btn-primary text-base px-8 py-3">
                إنشاء حساب
                <ArrowRight className="w-4 h-4" />
              </Link>
              <a href="#how-it-works" className="btn-secondary text-base px-8 py-3">
                شاهد كيف يعمل
              </a>
            </motion.div>

            <motion.div variants={fadeIn} className="mt-16 relative">
              <div className="relative rounded-2xl border border-slate-200 bg-white shadow-xl overflow-hidden">
                <div className="flex items-center gap-2 px-4 py-3 border-b border-slate-100 bg-slate-50/50">
                  <div className="flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                    <div className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                    <div className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                  </div>
                </div>
                <div className="p-6 grid grid-cols-12 gap-4">
                  <div className="col-span-3 bg-slate-50 rounded-xl p-4 space-y-3">
                    <div className="w-8 h-2 bg-slate-200 rounded" />
                    <div className="w-full h-2 bg-slate-100 rounded" />
                    <div className="w-full h-2 bg-slate-100 rounded" />
                    <div className="w-3/4 h-2 bg-slate-100 rounded" />
                  </div>
                  <div className="col-span-9 space-y-4">
                    <div className="grid grid-cols-4 gap-3">
                      {[1,2,3,4].map(i => (
                        <div key={i} className="bg-slate-50 rounded-xl p-4">
                          <div className="w-6 h-6 bg-primary-100 rounded-lg mb-2" />
                          <div className="w-8 h-3 bg-slate-200 rounded mb-1" />
                          <div className="w-full h-2 bg-slate-100 rounded" />
                        </div>
                      ))}
                    </div>
                    <div className="bg-slate-50 rounded-xl p-4 h-32" />
                  </div>
                </div>
              </div>
              <div className="absolute -bottom-4 inset-x-0 h-24 bg-gradient-to-t from-slate-50 to-transparent pointer-events-none" />
            </motion.div>
          </motion.div>
        </div>
      </section>

      <section className="py-20 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-14">
            <h2 className="text-3xl font-bold text-slate-900 mb-3 text-balance">لماذا RestroBot؟</h2>
            <p className="text-slate-500 text-lg max-w-lg mx-auto text-balance">المطاعم التقليدية تواجه تحديات يومية يمكن حلها بالأتمتة الذكية</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: Clock, title: 'فقدان الوقت', desc: 'الطلبات اليدوية تستهلك وقت طاقم العمل وتؤخر الخدمة', accent: 'bg-rose-50 text-rose-600' },
              { icon: Layers, title: 'تشتت البيانات', desc: 'عملاء متفرقون على منصات مختلفة بدون قاعدة بيانات موحدة', accent: 'bg-amber-50 text-amber-600' },
              { icon: Shield, title: 'الحل الذكي', desc: 'منصة واحدة تجمع الطلبات والعملاء والتحليلات في مكان واحد', accent: 'bg-primary-50 text-primary-600' },
            ].map((item, i) => (
              <motion.div key={item.title} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="card p-6 card-hover">
                <div className={`w-10 h-10 ${item.accent} rounded-xl flex items-center justify-center mb-4`}>
                  <item.icon className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900 mb-2">{item.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="how-it-works" className="py-20 px-6 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-14">
            <h2 className="text-3xl font-bold text-slate-900 mb-3">كيف يعمل النظام؟</h2>
            <p className="text-slate-500 text-lg">خطوات بسيطة لمطعم أذكى</p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { step: '01', title: 'يرسل الزبون طلبه', desc: 'عبر بوت تيليجرام بضغطة زر واحدة', icon: MessageCircle },
              { step: '02', title: 'الطلب يُحوّل تلقائياً', desc: 'للوحة التحكم مع جميع التفاصيل', icon: Zap },
              { step: '03', title: 'إشعار فوري', desc: 'للمطبخ والكاشير والمالك', icon: Bell },
              { step: '04', title: 'تتبع حتى التسليم', desc: 'حالة الطلب في الوقت الحقيقي', icon: Check },
            ].map((item, i) => (
              <motion.div key={item.step} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="card p-6 card-hover relative">
                <div className="absolute top-4 left-4 text-xs font-mono font-bold text-slate-200">{item.step}</div>
                <div className="w-10 h-10 bg-primary-50 text-primary-600 rounded-xl flex items-center justify-center mb-4">
                  <item.icon className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900 mb-2">{item.title}</h3>
                <p className="text-sm text-slate-500">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="features" className="py-20 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-14">
            <h2 className="text-3xl font-bold text-slate-900 mb-3">كل ما تحتاجه في مكان واحد</h2>
            <p className="text-slate-500 text-lg">نظام متكامل لإدارة مطعمك بالكامل</p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: BarChart3, title: 'تحليلات متقدمة', desc: 'تقارير مفصلة عن المبيعات والأصناف الأكثر طلباً' },
              { icon: Users, title: 'إدارة العملاء', desc: 'قاعدة بيانات كاملة للعملاء مع سجل الطلبات' },
              { icon: Star, title: 'برنامج الولاء', desc: 'نظام نقاط وجوائز يشجع العملاء على العودة' },
              { icon: Globe, title: 'إدارة القائمة', desc: 'أضف وعدّل الأصناف والأسعار بسهولة تامة' },
              { icon: TrendingUp, title: 'لوحة الكاشير', desc: 'إدارة الطلبات الحية مع طباعة الفواتير' },
              { icon: Shield, title: 'متعدد المطاعم', desc: 'أدر عدة مطاعم من حساب واحد مع عزل كامل' },
            ].map((f, i) => (
              <motion.div key={f.title} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }} className="card p-6 card-hover">
                <div className="w-10 h-10 bg-primary-50 text-primary-600 rounded-xl flex items-center justify-center mb-4">
                  <f.icon className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900 mb-2">{f.title}</h3>
                <p className="text-sm text-slate-500">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 px-6 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-14">
            <h2 className="text-3xl font-bold text-slate-900 mb-3">خطط تناسب كل مطعم</h2>
            <p className="text-slate-500 text-lg">اشتراك شهري — أسعار مناسبة للسوق المصري</p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {plans.map((plan, i) => {
              const isHighlighted = plan.badge === 'most_popular' || plan.badge === 'recommended';
              const isEnterprise = plan.plan_type === 'enterprise';
              const isFree = plan.plan_type === 'free' || plan.price_monthly === 0;

              function getPlanIcon() {
                if (plan.badge === 'enterprise' || isEnterprise) return <Building2 className="w-5 h-5 text-slate-600" />;
                if (plan.badge === 'recommended' || isHighlighted) return <Crown className="w-5 h-5 text-amber-600" />;
                if (isFree) return <Zap className="w-5 h-5 text-success-600" />;
                return <Star className="w-5 h-5 text-slate-400" />;
              }

              return (
                <motion.div
                  key={plan.id}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className={`card p-6 flex flex-col relative ${isHighlighted ? 'ring-2 ring-primary-500' : ''}`}
                >
                  {plan.badge && (
                    <div className="absolute -top-3 right-6 bg-primary-600 text-white text-xs font-bold px-3 py-1 rounded-full">
                      {plan.badge === 'most_popular' ? 'الأكثر شعبية' : plan.badge === 'recommended' ? 'موصى به' : plan.badge === 'enterprise' ? 'مؤسسات' : plan.badge === 'new' ? 'جديد' : plan.badge === 'free' ? 'مجاني' : plan.badge}
                    </div>
                  )}
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isFree ? 'bg-success-50' : isHighlighted ? 'bg-primary-50' : isEnterprise ? 'bg-slate-50' : 'bg-slate-50'}`}>
                      {getPlanIcon()}
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-slate-900">{plan.name_ar || plan.plan_name}</h3>
                      {plan.description && <p className="text-xs text-slate-400 line-clamp-1">{plan.description}</p>}
                    </div>
                  </div>
                  <div className="mb-4">
                    {isEnterprise ? (
                      <div className="text-lg font-bold text-slate-900">تواصل معنا</div>
                    ) : isFree ? (
                      <div className="text-lg font-bold text-success-600">مجاني</div>
                    ) : (
                      <>
                        <div className="flex items-baseline gap-1">
                          <span className="text-3xl font-bold text-slate-900">{plan.price_monthly}</span>
                          <span className="text-sm text-slate-400">ج.م/شهر</span>
                        </div>
                        {plan.max_orders != null && (
                          <p className="text-xs text-slate-500 mt-1">{plan.max_orders} طلب شهرياً</p>
                        )}
                      </>
                    )}
                  </div>
                  <ul className="space-y-2 mb-6 flex-1">
                    {plan.feature_labels.map((f, j) => (
                      <li key={j} className="flex items-start gap-2 text-sm text-slate-600">
                        <Check className="w-4 h-4 text-success-500 flex-shrink-0 mt-0.5" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                  <Link
                    to="/register"
                    className={`w-full text-center py-2.5 rounded-xl font-semibold text-sm transition-all flex items-center justify-center gap-2 ${
                      isHighlighted
                        ? 'btn-primary'
                        : isEnterprise
                        ? 'btn-secondary'
                        : isFree
                        ? 'bg-success-500 hover:bg-success-600 text-white'
                        : 'bg-primary-50 hover:bg-primary-100 text-primary-600'
                    }`}
                  >
                    {isEnterprise ? 'تواصل معنا' : isFree ? 'ابدأ مجاناً' : 'اشترك الآن'}
                    {!isEnterprise && <ArrowRight className="w-4 h-4" />}
                  </Link>
                </motion.div>
              );
            })}
          </div>
          {plans.length === 0 && (
            <div className="text-center py-12 text-slate-400">
              <p>جارٍ تحميل الخطط...</p>
            </div>
          )}
        </div>
      </section>

      <section className="py-20 px-6 bg-white">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">ابدأ رحلتك مع RestroBot اليوم</h2>
            <p className="text-slate-500 text-lg mb-8">انضم لـ +500 مطعم يستخدمون RestroBot لتحسين عملياتهم</p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link to="/register" className="btn-primary text-base px-8 py-3">
                إنشاء حساب مجاني
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link to="/login" className="btn-secondary text-base px-8 py-3">
                تسجيل الدخول
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <footer className="py-10 px-6 bg-slate-50 border-t border-slate-200">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-primary-600 rounded-lg flex items-center justify-center">
              <Bot className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="font-bold text-slate-900 text-sm">RestroBot</span>
          </div>
          <div className="text-slate-400 text-sm">جميع الحقوق محفوظة 2024</div>
        </div>
      </footer>
    </div>
  );
}

function Bell({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
      <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
    </svg>
  );
}
