import { motion, AnimatePresence } from 'framer-motion';
import { Bot, Check, ArrowRight, ArrowLeft, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useOnboarding, ONBOARDING_STEPS } from '../contexts/OnboardingContext';
import StepProfile from '../components/onboarding/StepProfile';
import StepCategories from '../components/onboarding/StepCategories';
import StepProducts from '../components/onboarding/StepProducts';
import StepDelivery from '../components/onboarding/StepDelivery';
import StepTelegram from '../components/onboarding/StepTelegram';
import StepTest from '../components/onboarding/StepTest';
import StepComplete from '../components/onboarding/StepComplete';

function StepIndicator() {
  const { state } = useOnboarding();

  return (
    <div className="flex items-center justify-center gap-1 mb-8">
      {ONBOARDING_STEPS.map((step, index) => (
        <div key={step.id} className="flex items-center">
          <div
            className={`relative flex items-center justify-center w-8 h-8 rounded-full text-xs font-bold transition-all ${
              state.completedSteps.includes(step.id)
                ? 'bg-success-500 text-white'
                : state.currentStep === step.id
                ? 'bg-primary-600 text-white'
                : 'bg-slate-200 text-slate-400'
            }`}
          >
            {state.completedSteps.includes(step.id) ? (
              <Check className="w-4 h-4" />
            ) : (
              step.id
            )}
          </div>
          {index < ONBOARDING_STEPS.length - 1 && (
            <div
              className={`w-8 h-0.5 ${
                state.completedSteps.includes(step.id) ? 'bg-success-500' : 'bg-slate-200'
              }`}
            />
          )}
        </div>
      ))}
    </div>
  );
}

function ProgressBar() {
  const { state } = useOnboarding();
  const completedCount = state.completedSteps.length;
  const totalSteps = ONBOARDING_STEPS.length - 1;
  const percentage = Math.round((completedCount / totalSteps) * 100);

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
        <span>{percentage}% مكتمل</span>
        <span>الخطوة {state.currentStep} من {ONBOARDING_STEPS.length}</span>
      </div>
      <div className="w-full bg-slate-200 rounded-full h-1.5">
        <motion.div
          className="h-1.5 bg-primary-600 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.3 }}
        />
      </div>
    </div>
  );
}

export default function Onboarding() {
  const { state, nextStep, prevStep, completeAndAdvance } = useOnboarding();

  const currentStepData = ONBOARDING_STEPS.find(s => s.id === state.currentStep);

  const renderStep = () => {
    switch (state.currentStep) {
      case 1:
        return <StepProfile />;
      case 2:
        return <StepCategories />;
      case 3:
        return <StepProducts />;
      case 4:
        return <StepDelivery />;
      case 5:
        return <StepTelegram />;
      case 6:
        return <StepTest />;
      case 7:
        return <StepComplete />;
      default:
        return <StepProfile />;
    }
  };

  if (state.loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="w-10 h-10 border-2 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-slate-500">جارٍ تحميل بيانات الإعداد...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4 py-8" dir="rtl">
      <div className="w-full max-w-2xl">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-3 justify-center mb-6 group">
            <div className="w-12 h-12 bg-primary-600 rounded-2xl flex items-center justify-center shadow-lg shadow-primary-500/20 group-hover:shadow-primary-500/30 transition-shadow">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-slate-900">RestroBot</span>
          </Link>
        </div>

        {/* Main Card */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="card p-8"
        >
          {/* Step Title */}
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-slate-900">{currentStepData?.title}</h1>
            <p className="text-slate-500 mt-1">{currentStepData?.titleEn}</p>
          </div>

          {/* Progress */}
          <ProgressBar />
          <StepIndicator />

          {/* Step Content */}
          <AnimatePresence mode="wait">
            <motion.div
              key={state.currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {renderStep()}
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          {state.currentStep < 7 && (
            <div className="flex items-center justify-between mt-8 pt-6 border-t border-slate-100">
              <button
                onClick={prevStep}
                disabled={state.currentStep === 1 || state.saving}
                className="btn-secondary text-sm disabled:opacity-50"
              >
                <ArrowRight className="w-4 h-4" />
                السابق
              </button>

              {state.saving ? (
                <div className="flex items-center gap-2 text-primary-600 text-sm">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  جارٍ الحفظ...
                </div>
              ) : null}

              {state.currentStep < 6 && (
                <button
                  onClick={() => completeAndAdvance(state.currentStep)}
                  disabled={state.saving}
                  className="btn-primary text-sm"
                >
                  التالي
                  <ArrowLeft className="w-4 h-4" />
                </button>
              )}
            </div>
          )}
        </motion.div>

        {/* Footer */}
        <div className="mt-6 text-center">
          <p className="text-xs text-slate-400">
            يمكنك حفظ التقدم والعودة لاحقاً
          </p>
        </div>
      </div>
    </div>
  );
}
