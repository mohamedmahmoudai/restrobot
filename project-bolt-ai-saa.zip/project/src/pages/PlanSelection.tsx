import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Check, Zap, Loader2, Bot, ArrowRight, Info, Crown, Building2, Star, Upload, X, Image as ImageIcon } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { uploadReceipt } from '../lib/receiptUpload';
import type { SystemPlan } from '../lib/database.types';

interface PlanSelectionProps {
  restaurantId: string;
  hasUsedTrial: boolean;
  onComplete: () => void;
}

interface EnrichedPlan extends SystemPlan {
  feature_labels: string[];
}

export default function PlanSelection({ restaurantId, hasUsedTrial, onComplete }: PlanSelectionProps) {
  const [plans, setPlans] = useState<EnrichedPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPlan, setSelectedPlan] = useState<EnrichedPlan | null>(null);
  const [paymentProofUrl, setPaymentProofUrl] = useState('');
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [step, setStep] = useState<'select' | 'payment'>('select');
  const [hasUsedFreePlan, setHasUsedFreePlan] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { fetchPlans(); checkFreePlanUsed(); }, []);

  async function fetchPlans() {
    setLoading(true);
    const { data: plansData } = await supabase
      .from('system_plans')
      .select('*')
      .eq('is_active', true)
      .eq('can_subscribe', true)
      .order('sort_order', { ascending: true });

    if (!plansData) { setLoading(false); return; }

    const filtered = hasUsedTrial
      ? plansData.filter(p => !p.is_trial)
      : plansData;

    const planIds = filtered.map(p => p.id);
    const { data: pfData } = await supabase
      .from('plan_features')
      .select('plan_id, feature_id')
      .in('plan_id', planIds);

    const featureIds = [...new Set((pfData ?? []).map(pf => pf.feature_id))];
    const { data: featuresData } = await supabase
      .from('feature_definitions')
      .select('id, label_ar')
      .in('id', featureIds);

    const featureMap: Record<string, string> = {};
    (featuresData ?? []).forEach(f => { featureMap[f.id] = f.label_ar; });

    const enriched: EnrichedPlan[] = filtered.map(plan => {
      const planFeatureIds = (pfData ?? []).filter(pf => pf.plan_id === plan.id).map(pf => pf.feature_id);
      const featureLabels = planFeatureIds.map(fid => featureMap[fid]).filter(Boolean);
      const inlineFeatures = Array.isArray(plan.features) ? (plan.features as unknown as string[]) : [];
      return { ...(plan as SystemPlan), feature_labels: [...featureLabels, ...inlineFeatures] };
    });

    setPlans(enriched);
    setLoading(false);
  }

  async function checkFreePlanUsed() {
    const { data: freePlanSubs } = await supabase
      .from('restaurant_subscriptions')
      .select('id')
      .eq('restaurant_id', restaurantId)
      .eq('trial_used', true)
      .limit(1);
    setHasUsedFreePlan((freePlanSubs && freePlanSubs.length > 0) || false);
  }

  function handleSelectPlan(plan: EnrichedPlan) {
    setSelectedPlan(plan);
    if (plan.is_trial) {
      handleActivateTrial(plan);
    } else if (plan.plan_type === 'free') {
      if (hasUsedFreePlan) {
        setError('لقد استخدمت الباقة المجانية من قبل. يرجى اختيار أحد الباقات المدفوعة.');
        return;
      }
      handleActivateFree(plan);
    } else if (plan.plan_type === 'enterprise') {
      window.open('mailto:sales@restrobot.com?subject=Enterprise Plan Inquiry', '_blank');
    } else {
      setStep('payment');
    }
  }

  async function handleActivateFree(plan: EnrichedPlan) {
    setSubmitting(true);
    setError('');

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + plan.duration_days);

    const { error: subError } = await supabase
      .from('restaurant_subscriptions')
      .insert({
        restaurant_id: restaurantId,
        plan_id: plan.id,
        billing_cycle: 'monthly',
        status: 'active',
        starts_at: new Date().toISOString(),
        expires_at: expiresAt.toISOString(),
        payment_status: 'approved',
      });

    if (subError) { setError(subError.message); setSubmitting(false); return; }

    await supabase.from('restaurants').update({
      is_active: true,
      subscription_plan: plan.plan_name.toLowerCase(),
      subscription_expires_at: expiresAt.toISOString(),
    }).eq('id', restaurantId);

    setSubmitting(false);
    onComplete();
  }

  async function handleActivateTrial(plan: EnrichedPlan) {
    setSubmitting(true);
    setError('');

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + plan.duration_days);

    const { error: subError } = await supabase
      .from('restaurant_subscriptions')
      .insert({
        restaurant_id: restaurantId,
        plan_id: plan.id,
        billing_cycle: 'monthly',
        status: 'active',
        starts_at: new Date().toISOString(),
        expires_at: expiresAt.toISOString(),
        trial_used: true,
        payment_status: 'approved',
      });

    if (subError) { setError(subError.message); setSubmitting(false); return; }

    await supabase.from('restaurants').update({
      has_used_trial: true,
      subscription_plan: 'trial',
      subscription_expires_at: expiresAt.toISOString(),
      is_active: true,
    }).eq('id', restaurantId);

    setSubmitting(false);
    onComplete();
  }

  async function handleFileUpload(file: File | null) {
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      setError('حجم الملف يجب ألا يتجاوز 10 ميجابايت');
      return;
    }
    setUploading(true);
    setError('');
    try {
      const publicUrl = await uploadReceipt(file, restaurantId);
      setPaymentProofUrl(publicUrl);
      setReceiptFile(file);
    } catch (err: any) {
      setError('فشل رفع الملف: ' + err.message);
    } finally {
      setUploading(false);
    }
  }

  async function handleSubmitPayment() {
    if (!selectedPlan || !paymentProofUrl.trim()) {
      setError('يرجى رفع إيصال الدفع');
      return;
    }

    setSubmitting(true);
    setError('');

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + selectedPlan.duration_days);

    const { error: subError } = await supabase
      .from('restaurant_subscriptions')
      .insert({
        restaurant_id: restaurantId,
        plan_id: selectedPlan.id,
        billing_cycle: 'monthly',
        status: 'pending_payment',
        starts_at: new Date().toISOString(),
        expires_at: expiresAt.toISOString(),
        payment_status: 'pending',
        payment_proof_url: paymentProofUrl,
        payment_notes: notes || null,
      });

    if (subError) { setError(subError.message); setSubmitting(false); return; }

    await supabase.from('subscription_requests').insert({
      restaurant_id: restaurantId,
      plan_id: selectedPlan.id,
      billing_cycle: 'monthly',
      amount: selectedPlan.price_monthly,
      currency: 'ج.م',
      payment_proof_url: paymentProofUrl,
      notes: notes || null,
      status: 'pending',
    });

    setSubmitting(false);
    onComplete();
  }

  function getPlanIcon(plan: EnrichedPlan) {
    if (plan.is_trial) return <Zap className="w-5 h-5" />;
    if (plan.badge === 'recommended' || plan.badge === 'most_popular') return <Crown className="w-5 h-5" />;
    if (plan.plan_type === 'enterprise') return <Building2 className="w-5 h-5" />;
    if (plan.plan_type === 'free') return <Zap className="w-5 h-5" />;
    return <Star className="w-5 h-5" />;
  }

  function getPlanAccent(plan: EnrichedPlan) {
    if (plan.is_trial || plan.plan_type === 'free') return 'bg-success-50 text-success-600 border-success-200';
    if (plan.badge === 'recommended' || plan.badge === 'most_popular') return 'bg-primary-50 text-primary-600 border-primary-200 ring-2 ring-primary-500';
    if (plan.plan_type === 'enterprise') return 'bg-slate-50 text-slate-600 border-slate-200';
    return 'bg-slate-50 text-slate-600 border-slate-200';
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="w-10 h-10 border-2 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-slate-500">جارٍ تحميل الخطط...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4 py-12" dir="rtl">
      <div className="w-full max-w-5xl">
        <div className="text-center mb-10">
          <Link to="/" className="inline-flex items-center gap-3 justify-center mb-6 group">
            <div className="w-12 h-12 bg-primary-600 rounded-2xl flex items-center justify-center shadow-lg shadow-primary-500/20 group-hover:shadow-primary-500/30 transition-shadow">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-slate-900">RestroBot</span>
          </Link>
          <h1 className="text-2xl font-bold text-slate-900 mb-2">اختر الباقة المناسبة</h1>
          <p className="text-slate-500">اشتراك شهري فقط — اختر الخطة التي تناسب احتياجات مطعمك</p>
        </div>

        {step === 'select' && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {plans.map((plan, index) => {
              const isFree = plan.plan_type === 'free' || (plan.price_monthly === 0 && !plan.is_trial);
              const isEnterprise = plan.plan_type === 'enterprise';
              const isHighlighted = plan.badge === 'recommended' || plan.badge === 'most_popular';

              return (
                <motion.div
                  key={plan.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`relative card p-5 flex flex-col ${isHighlighted ? 'ring-2 ring-primary-500' : ''}`}
                >
                  {plan.badge && (
                    <div className="absolute -top-3 right-6 bg-primary-600 text-white text-xs font-bold px-3 py-1 rounded-full">
                      {plan.badge === 'most_popular' ? 'الأكثر شعبية' : plan.badge === 'recommended' ? 'موصى به' : plan.badge === 'enterprise' ? 'مؤسسات' : plan.badge === 'new' ? 'جديد' : plan.badge === 'free' ? 'مجاني' : plan.badge}
                    </div>
                  )}

                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${getPlanAccent(plan)} border`}>
                    {getPlanIcon(plan)}
                  </div>

                  <h3 className="text-base font-bold text-slate-900 mb-1">{plan.name_ar || plan.plan_name}</h3>
                  {plan.description && <p className="text-xs text-slate-400 mb-3 line-clamp-2">{plan.description}</p>}

                  <div className="mb-4">
                    {isEnterprise ? (
                      <div className="text-lg font-bold text-slate-900">تواصل معنا</div>
                    ) : isFree ? (
                      <div className="text-lg font-bold text-success-600">مجاني</div>
                    ) : plan.is_trial ? (
                      <div className="text-lg font-bold text-success-600">مجاني {plan.duration_days} أيام</div>
                    ) : (
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl font-bold text-slate-900">{plan.price_monthly}</span>
                        <span className="text-sm text-slate-400">ج.م/شهر</span>
                      </div>
                    )}
                  </div>

                  {plan.max_orders != null && (
                    <div className="text-xs text-slate-500 mb-2 flex items-center gap-1">
                      <Info className="w-3.5 h-3.5" />
                      {plan.max_orders} طلب/شهر كحد أقصى
                    </div>
                  )}

                  <ul className="space-y-2 mb-6 flex-1">
                    {plan.feature_labels.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                        <Check className=" from-slate-400 w-4 h-4 text-success-500 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <button
                    onClick={() => handleSelectPlan(plan)}
                    disabled={submitting}
                    className={`w-full py-2.5 rounded-xl font-semibold text-sm transition-all flex items-center justify-center gap-2 ${
                      plan.is_trial
                        ? 'bg-success-500 hover:bg-success-600 text-white'
                        : isFree
                        ? 'bg-success-500 hover:bg-success-600 text-white'
                        : isEnterprise
                        ? 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        : isHighlighted
                        ? 'btn-primary'
                        : 'bg-primary-50 hover:bg-primary-100 text-primary-600'
                    }`}
                  >
                    {(plan.is_trial || isFree) && submitting ? (
                      <><Loader2 className="w-4 h-4 animate-spin" /> جارٍ التفعيل...</>
                    ) : plan.is_trial ? (
                      <>تفعيل التجربة المجانية <ArrowRight className="w-4 h-4" /></>
                    ) : isFree ? (
                      <>ابدأ مجاناً <ArrowRight className="w-4 h-4" /></>
                    ) : isEnterprise ? (
                      'تواصل معنا'
                    ) : (
                      'اشترك الآن'
                    )}
                  </button>
                </motion.div>
              );
            })}
          </motion.div>
        )}

        {step === 'payment' && selectedPlan && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-lg mx-auto card p-8"
          >
            <button
              onClick={() => setStep('select')}
              className="text-sm text-slate-500 hover:text-slate-700 mb-6 flex items-center gap-1"
            >
              <ArrowRight className="w-4 h-4 rotate-180" />
              العودة للخطط
            </button>

            <div className="bg-primary-50 border border-primary-100 rounded-xl p-4 mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-900">{selectedPlan.name_ar || selectedPlan.plan_name}</h3>
                  <p className="text-sm text-slate-500">{selectedPlan.duration_days} يوم — اشتراك شهري</p>
                </div>
                <div className="text-left">
                  <p className="text-2xl font-bold text-slate-900">{selectedPlan.price_monthly}</p>
                  <p className="text-sm text-slate-400">ج.م/شهر</p>
                </div>
              </div>
            </div>

            {error && (
              <div className="bg-danger-50 border border-danger-200 text-danger-600 text-sm px-4 py-3 rounded-xl mb-4">
                {error}
              </div>
            )}

            <form onSubmit={(e) => { e.preventDefault(); handleSubmitPayment(); }} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">رفع إيصال الدفع (إلزامي)</label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,application/pdf"
                  onChange={(e) => handleFileUpload(e.target.files?.[0] || null)}
                  className="hidden"
                  disabled={submitting || uploading}
                />
                {!paymentProofUrl ? (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={submitting || uploading}
                    className="w-full border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-primary-400 hover:bg-primary-50 transition-all"
                  >
                    {uploading ? (
                      <><Loader2 className="w-6 h-6 mx-auto mb-2 text-primary-500 animate-spin" /><p className="text-sm text-slate-500">جارٍ الرفع...</p></>
                    ) : (
                      <><Upload className="w-6 h-6 mx-auto mb-2 text-slate-400" /><p className="text-sm text-slate-500">اضغط لرفع صورة الإيصال</p><p className="text-xs text-slate-400 mt-1">PNG, JPG, PDF — حتى 10MB</p></>
                    )}
                  </button>
                ) : (
                  <div className="flex items-center gap-3 bg-success-50 border border-success-200 rounded-xl p-3">
                    <ImageIcon className="w-5 h-5 text-success-600 flex-shrink-0" />
                    <span className="text-sm text-success-700 flex-1 truncate">{receiptFile?.name || 'تم رفع الإيصال'}</span>
                    <button type="button" onClick={() => { setPaymentProofUrl(''); setReceiptFile(null); }} className="text-slate-400 hover:text-danger-500">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">ملاحظات (اختياري)</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="أي ملاحظات تود إضافتها..."
                  className="input-field min-h-[80px]"
                  disabled={submitting}
                />
              </div>

              <div className="bg-slate-50 rounded-xl p-4 text-sm text-slate-600">
                <p className="font-semibold mb-2">معلومات الدفع:</p>
                <ul className="space-y-1 text-xs">
                  <li>• سيتم مراجعة طلبك خلال 24 ساعة</li>
                  <li>• ستتلقى إشعاراً عند الموافقة على الدفع</li>
                  <li>• يمكنك استخدام النظام بعد الموافقة</li>
                </ul>
              </div>

              <button
                type="submit"
                disabled={submitting || uploading || !paymentProofUrl.trim()}
                className="w-full btn-primary py-3"
              >
                {submitting ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> جارٍ الإرسال...</>
                ) : (
                  <>إرسال طلب الاشتراك <ArrowRight className="w-4 h-4" /></>
                )}
              </button>
            </form>
          </motion.div>
        )}

        <div className="mt-8 text-center">
          <p className="text-xs text-slate-400">
            بإكمال الاشتراك، أنت توافق على{' '}
            <a href="#" className="text-slate-500 hover:text-primary-600">شروط الاستخدام</a>
            {' '}و{' '}
            <a href="#" className="text-slate-500 hover:text-primary-600">سياسة الخصوصية</a>
          </p>
        </div>
      </div>
    </div>
  );
}
