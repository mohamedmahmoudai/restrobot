import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Bot, Eye, EyeOff, AlertCircle, Check, UtensilsCrossed } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function Register() {
  const [restaurantName, setRestaurantName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { signUp } = useAuth();
  const navigate = useNavigate();

  const passwordStrength = password.length >= 8 && /[A-Z]/.test(password) && /[0-9]/.test(password);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!restaurantName || !email || !password || !confirm) { setError('يرجى ملء جميع الحقول'); return; }
    if (password !== confirm) { setError('كلمتا المرور غير متطابقتين'); return; }
    if (password.length < 6) { setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل'); return; }
    setLoading(true);
    setError('');
    const { error } = await signUp(email, password, restaurantName);
    setLoading(false);
    if (error) { setError(error); return; }
    navigate('/dashboard');
  }

  return (
    <div className="min-h-screen bg-[#0B1020] flex" dir="rtl">
      {/* Left Side - Form */}
      <div className="flex-1 flex items-center justify-center px-6 py-12 relative">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:64px_64px] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,#000_70%,transparent_100%)]" />
        <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-violet-500/5 rounded-full blur-[150px] pointer-events-none" />

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="w-full max-w-md relative">
          {/* Logo */}
          <div className="text-center mb-8">
            <Link to="/" className="inline-flex items-center gap-3 justify-center mb-6 group">
              <div className="w-12 h-12 bg-gradient-to-br from-violet-500 to-violet-600 rounded-xl flex items-center justify-center shadow-lg shadow-violet-500/30 group-hover:shadow-violet-500/50 transition-shadow">
                <Bot className="w-7 h-7 text-white" />
              </div>
              <span className="text-xl font-black">RestroBot</span>
            </Link>
            <h1 className="text-3xl font-black mb-2">أنشئ مطعمك الرقمي</h1>
            <p className="text-white/40 text-sm">دقيقة واحدة للبدء باستقبال الطلبات</p>
          </div>

          {/* Form Card */}
          <div className="glass-strong rounded-2xl p-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-violet-500/10 rounded-full blur-3xl pointer-events-none" />

            <form onSubmit={handleSubmit} className="relative space-y-4">
              {error && (
                <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-sm px-4 py-3 rounded-xl">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  {error}
                </motion.div>
              )}

              {/* Restaurant Name */}
              <div>
                <label className="block text-sm font-medium text-white/60 mb-2">اسم المطعم</label>
                <input
                  type="text"
                  value={restaurantName}
                  onChange={(e) => setRestaurantName(e.target.value)}
                  placeholder="مطعم الفخامة"
                  className="w-full premium-input"
                  disabled={loading}
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-white/60 mb-2">البريد الإلكتروني</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@restaurant.com"
                  className="w-full premium-input"
                  disabled={loading}
                />
              </div>

              {/* Password */}
              <div>
                <label className="block text-sm font-medium text-white/60 mb-2">كلمة المرور</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full premium-input pl-11"
                    disabled={loading}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors p-1"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {password && (
                  <div className={`flex items-center gap-1.5 mt-2 text-xs ${passwordStrength ? 'text-emerald-400' : 'text-white/30'}`}>
                    <Check className="w-3 h-3" />
                    {passwordStrength ? 'كلمة مرور قوية' : '8 أحرف على الأقل مع أرقام وحروف كبيرة'}
                  </div>
                )}
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-sm font-medium text-white/60 mb-2">تأكيد كلمة المرور</label>
                <input
                  type="password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  placeholder="••••••••"
                  className="w-full premium-input"
                  disabled={loading}
                />
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-violet-600 to-violet-500 hover:from-violet-500 hover:to-violet-400 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-3.5 rounded-xl transition-all glow-violet disabled:shadow-none flex items-center justify-center gap-2 mt-2"
              >
                {loading ? 'جارٍ إنشاء الحساب...' : 'إنشاء الحساب والبدء'}
              </button>
            </form>

            {/* Terms */}
            <p className="text-center text-white/20 text-xs mt-6">
              بإنشاء حساب، أنت توافق على{' '}
              <a href="#" className="text-white/40 hover:text-white/60 transition-colors">سياسة الخصوصية</a>
              {' '}و{' '}
              <a href="#" className="text-white/40 hover:text-white/60 transition-colors">شروط الاستخدام</a>
            </p>

            {/* Divider */}
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-white/[0.06]" />
              </div>
              <div className="relative flex justify-center">
                <span className="bg-[#18233A] px-4 text-xs text-white/30">أو</span>
              </div>
            </div>

            {/* Login Link */}
            <div className="text-center text-sm text-white/40">
              لديك حساب بالفعل؟{' '}
              <Link to="/login" className="text-violet-400 hover:text-violet-300 font-medium transition-colors">
                تسجيل الدخول
              </Link>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Right Side - Decorative */}
      <div className="hidden lg:flex flex-1 bg-gradient-to-br from-violet-500/10 via-transparent to-cyan-500/5 items-center justify-center p-12 relative overflow-hidden">
        <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-violet-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-48 h-48 bg-cyan-500/20 rounded-full blur-2xl" />

        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2, duration: 0.6 }} className="relative text-center">
          <div className="w-24 h-24 bg-gradient-to-br from-violet-500 to-violet-600 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-violet-500/30">
            <UtensilsCrossed className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-3xl font-black mb-4">ابدأ رحلتك</h2>
          <p className="text-white/50 max-w-sm leading-relaxed mb-8">
            في أقل من دقيقة، ستتمكن من استقبال الطلبات تلقائياً وإدارة مطعمك بذكاء
          </p>
          <div className="space-y-3 text-right max-w-xs mx-auto">
            {[
              { text: 'لوحة تحكم فورية' },
              { text: 'بوت تيليجرام' },
              { text: 'تحليلات المبيعات' },
            ].map((item) => (
              <div key={item.text} className="flex items-center gap-3 text-white/60">
                <div className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
                  <Check className="w-3 h-3 text-emerald-400" />
                </div>
                {item.text}
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
