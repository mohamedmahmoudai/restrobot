import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Store, CreditCard, Megaphone,
  Settings, Shield, LogOut, Menu, X, MessageSquare,
  ClipboardList, Layers, ShieldCheck, RefreshCw, Server, Activity
} from 'lucide-react';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import SuperAdminDashboard from './SuperAdminDashboard';
import SuperAdminRestaurants from './SuperAdminRestaurants';
import SuperAdminSubscriptions from './SuperAdminSubscriptions';
import SuperAdminPlans from './SuperAdminPlans';
import SuperAdminSupport from './SuperAdminSupport';
import SuperAdminAnnouncements from './SuperAdminAnnouncements';
import SuperAdminAuditLogs from './SuperAdminAuditLogs';
import SuperAdminSettings from './SuperAdminSettings';
import SuperAdminSecurity from './SuperAdminSecurity';
import SuperAdminHealth from './SuperAdminHealth';

type TabKey = 'dashboard' | 'restaurants' | 'subscriptions' | 'plans' | 'support' | 'announcements' | 'audit' | 'settings' | 'security' | 'health';

const TABS: { key: TabKey; label: string; icon: React.FC<any>; path: string }[] = [
  { key: 'dashboard', label: 'الرئيسية', icon: LayoutDashboard, path: '/admin' },
  { key: 'restaurants', label: 'المطاعم', icon: Store, path: '/admin/restaurants' },
  { key: 'subscriptions', label: 'الاشتراكات', icon: CreditCard, path: '/admin/subscriptions' },
  { key: 'plans', label: 'الباقات', icon: Layers, path: '/admin/plans' },
  { key: 'support', label: 'الدعم', icon: MessageSquare, path: '/admin/support' },
  { key: 'announcements', label: 'الإعلانات', icon: Megaphone, path: '/admin/announcements' },
  { key: 'audit', label: 'سجل الأحداث', icon: ClipboardList, path: '/admin/audit' },
  { key: 'health', label: 'صحة النظام', icon: Server, path: '/admin/health' },
  { key: 'security', label: 'الأمان', icon: ShieldCheck, path: '/admin/security' },
  { key: 'settings', label: 'الإعدادات', icon: Settings, path: '/admin/settings' },
];

export default function AdminPanel() {
  const { user, adminProfile, signOut, loading, isAdmin } = useAdminAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  // Determine active tab from URL
  const currentTab = TABS.find(tab => location.pathname === tab.path || (tab.path === '/admin' && location.pathname === '/admin/dashboard'))?.key ||
    (location.pathname.startsWith('/admin/restaurants') ? 'restaurants' :
     location.pathname.startsWith('/admin/subscriptions') ? 'subscriptions' :
     location.pathname.startsWith('/admin/plans') ? 'plans' :
     location.pathname.startsWith('/admin/support') ? 'support' :
     location.pathname.startsWith('/admin/announcements') ? 'announcements' :
     location.pathname.startsWith('/admin/audit') ? 'audit' :
     location.pathname.startsWith('/admin/health') ? 'health' :
     location.pathname.startsWith('/admin/security') ? 'security' :
     location.pathname.startsWith('/admin/settings') ? 'settings' : 'dashboard');

  useEffect(() => {
    if (!loading && !isAdmin) {
      navigate('/admin/login', { replace: true });
    }
  }, [loading, isAdmin, navigate]);

  async function handleLogout() {
    await signOut();
    window.location.href = '/admin/login';
  }

  const handleTabClick = (path: string) => {
    navigate(path);
    setMobileOpen(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <RefreshCw className="w-8 h-8 text-slate-300 animate-spin" />
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  const renderContent = () => {
    switch (currentTab) {
      case 'dashboard': return <SuperAdminDashboard />;
      case 'restaurants': return <SuperAdminRestaurants />;
      case 'subscriptions': return <SuperAdminSubscriptions />;
      case 'plans': return <SuperAdminPlans />;
      case 'support': return <SuperAdminSupport />;
      case 'announcements': return <SuperAdminAnnouncements />;
      case 'audit': return <SuperAdminAuditLogs />;
      case 'health': return <SuperAdminHealth />;
      case 'settings': return <SuperAdminSettings />;
      case 'security': return <SuperAdminSecurity />;
      default: return <SuperAdminDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex" dir="rtl">
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 right-0 z-40 w-64 bg-slate-900 text-white transition-transform duration-300 lg:static lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}`}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-5 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-sm">RestroBot Admin</h1>
                <p className="text-[10px] text-slate-400">لوحة تحكم المدير العام</p>
              </div>
            </div>
          </div>

          {/* Nav */}
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            {TABS.map(tab => {
              const Icon = tab.icon;
              const isActive = currentTab === tab.key;
              return (
                <button
                  key={tab.key}
                  onClick={() => handleTabClick(tab.path)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-gradient-to-l from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </nav>

          {/* Profile & Footer */}
          <div className="p-3 border-t border-slate-800">
            <div className="flex items-center gap-3 px-3 py-2 mb-2">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full flex items-center justify-center text-white text-xs font-bold">
                {adminProfile?.email?.charAt(0).toUpperCase() || 'A'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-white truncate">{adminProfile?.full_name || adminProfile?.email}</p>
                <p className="text-[10px] text-slate-400 capitalize">{adminProfile?.role?.replace('_', ' ')}</p>
              </div>
            </div>
            <button onClick={handleLogout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-400 hover:text-white hover:bg-slate-800 transition-all">
              <LogOut className="w-4 h-4" />
              تسجيل الخروج
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setMobileOpen(false)} />
      )}

      {/* Main Content */}
      <main className="flex-1 min-w-0">
        {/* Top bar */}
        <div className="sticky top-0 z-20 bg-slate-50/80 backdrop-blur-md border-b border-slate-200 px-4 py-3 lg:px-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => setMobileOpen(!mobileOpen)} className="lg:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg">
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <h2 className="text-base font-bold text-slate-900">
              {TABS.find(t => t.key === currentTab)?.label}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <span className={`px-2 py-1 rounded-full text-[10px] font-medium ${
              adminProfile?.role === 'super_admin' ? 'bg-emerald-100 text-emerald-700' :
              adminProfile?.role === 'admin' ? 'bg-blue-100 text-blue-700' :
              'bg-slate-100 text-slate-600'
            }`}>
              {adminProfile?.role?.replace('_', ' ')}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 lg:p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
