import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Megaphone, Plus, Trash2, CreditCard as Edit3, CheckCircle, X, Loader2, AlertCircle, Info, Calendar } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import type { Announcement } from '../../lib/database.types';

export default function SuperAdminAnnouncements() {
  const { user } = useAuth();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [form, setForm] = useState({
    title: '',
    body: '',
    type: 'info' as 'info' | 'warning' | 'success' | 'maintenance',
    target_audience: 'all' as 'all' | 'restaurants' | 'admins',
    start_date: '',
    end_date: '',
    is_active: true,
  });

  useEffect(() => {
    fetchAnnouncements();
  }, []);

  async function fetchAnnouncements() {
    setLoading(true);
    const { data } = await supabase.from('announcements').select('*').order('created_at', { ascending: false });
    setAnnouncements((data ?? []) as Announcement[]);
    setLoading(false);
  }

  function resetForm() {
    setForm({ title: '', body: '', type: 'info', target_audience: 'all', start_date: '', end_date: '', is_active: true });
    setEditingId(null);
  }

  async function handleSave() {
    if (!form.title.trim() || !form.body.trim()) return;
    setSaving(true);

    const payload = {
      title: form.title.trim(),
      body: form.body.trim(),
      type: form.type,
      target_audience: form.target_audience,
      start_date: form.start_date || null,
      end_date: form.end_date || null,
      is_active: form.is_active,
    };

    if (editingId) {
      await supabase.from('announcements').update(payload).eq('id', editingId);
    } else {
      await supabase.from('announcements').insert(payload);
    }

    await logAction(editingId ? 'update_announcement' : 'create_announcement', 'announcement', editingId || 'new', form.title, {});

    setSaving(false);
    setShowForm(false);
    resetForm();
    fetchAnnouncements();
  }

  async function handleDelete(id: string, title: string) {
    if (!confirm('هل أنت متأكد من حذف هذا الإعلان؟')) return;
    await supabase.from('announcements').delete().eq('id', id);
    await logAction('delete_announcement', 'announcement', id, title, {});
    fetchAnnouncements();
  }

  async function toggleActive(id: string, current: boolean, title: string) {
    await supabase.from('announcements').update({ is_active: !current }).eq('id', id);
    await logAction('toggle_announcement', 'announcement', id, title, { active: !current });
    fetchAnnouncements();
  }

  async function logAction(action: string, targetType: string, targetId: string, targetName: string, details: object) {
    await supabase.from('admin_audit_logs').insert({
      admin_id: user?.id, admin_email: user?.email, action, target_type: targetType, target_id: targetId, target_name: targetName, details,
    });
  }

  function startEdit(a: Announcement) {
    setForm({
      title: a.title,
      body: a.body,
      type: a.type as any,
      target_audience: a.target_audience as any,
      start_date: a.start_date ? a.start_date.slice(0, 16) : '',
      end_date: a.end_date ? a.end_date.slice(0, 16) : '',
      is_active: a.is_active,
    });
    setEditingId(a.id);
    setShowForm(true);
  }

  const typeConfig: Record<string, { label: string; icon: any; color: string }> = {
    info: { label: 'معلومات', icon: Info, color: 'bg-blue-50 text-blue-700 border-blue-200' },
    warning: { label: 'تحذير', icon: AlertCircle, color: 'bg-amber-50 text-amber-700 border-amber-200' },
    success: { label: 'نجاح', icon: CheckCircle, color: 'bg-success-50 text-success-700 border-success-200' },
    maintenance: { label: 'صيانة', icon: Calendar, color: 'bg-slate-50 text-slate-700 border-slate-200' },
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96" dir="rtl">
        <div className="w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-5" dir="rtl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Megaphone className="w-5 h-5 text-primary-600" />
          <h2 className="text-lg font-bold text-slate-900">الإعلانات</h2>
        </div>
        <button onClick={() => { resetForm(); setShowForm(true); }} className="btn-primary text-sm">
          <Plus className="w-4 h-4" /> إعلان جديد
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {announcements.map((a) => {
          const config = typeConfig[a.type] || typeConfig.info;
          const Icon = config.icon;
          return (
            <motion.div key={a.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className={`card p-5 border-r-4 ${a.is_active ? 'border-r-primary-500' : 'border-r-slate-300'}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${config.color.split(' ')[0]}`}>
                    <Icon className="w-4 h-4" style={{ color: 'inherit' }} />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{a.title}</h3>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${config.color}`}>{config.label}</span>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => toggleActive(a.id, a.is_active, a.title)} className={`p-1.5 rounded-lg transition-colors ${a.is_active ? 'bg-success-50 text-success-600' : 'bg-slate-100 text-slate-400'}`} title={a.is_active ? 'تعطيل' : 'تفعيل'}>
                    {a.is_active ? <CheckCircle className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
                  </button>
                  <button onClick={() => startEdit(a)} className="p-1.5 bg-primary-50 hover:bg-primary-100 text-primary-600 rounded-lg transition-colors"><Edit3 className="w-3.5 h-3.5" /></button>
                  <button onClick={() => handleDelete(a.id, a.title)} className="p-1.5 bg-danger-50 hover:bg-danger-100 text-danger-600 rounded-lg transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed line-clamp-3">{a.body}</p>
              <div className="flex items-center gap-3 mt-3 text-xs text-slate-400">
                <span>{a.target_audience === 'all' ? 'الجميع' : a.target_audience === 'restaurants' ? 'المطاعم' : 'المدراء'}</span>
                <span>•</span>
                <span>{new Date(a.created_at).toLocaleDateString('ar-EG')}</span>
              </div>
            </motion.div>
          );
        })}
        {announcements.length === 0 && (
          <div className="card p-12 text-center md:col-span-2">
            <Megaphone className="w-12 h-12 text-slate-200 mx-auto mb-3" />
            <p className="text-slate-400 text-sm">لا توجد إعلانات</p>
          </div>
        )}
      </div>

      {/* Form Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
            <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }} onClick={e => e.stopPropagation()} className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-modal max-h-[90vh] overflow-y-auto">
              <h3 className="text-lg font-bold text-slate-900 mb-4">{editingId ? 'تعديل إعلان' : 'إعلان جديد'}</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">العنوان</label>
                  <input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} className="input-field" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">المحتوى</label>
                  <textarea value={form.body} onChange={e => setForm(p => ({ ...p, body: e.target.value }))} rows={4} className="input-field resize-none" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">النوع</label>
                    <select value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value as any }))} className="input-field">
                      <option value="info">معلومات</option>
                      <option value="warning">تحذير</option>
                      <option value="success">نجاح</option>
                      <option value="maintenance">صيانة</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">الجمهور</label>
                    <select value={form.target_audience} onChange={e => setForm(p => ({ ...p, target_audience: e.target.value as any }))} className="input-field">
                      <option value="all">الجميع</option>
                      <option value="restaurants">المطاعم</option>
                      <option value="admins">المدراء</option>
                    </select>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                  <span className="text-sm font-medium text-slate-700">نشط</span>
                  <button onClick={() => setForm(p => ({ ...p, is_active: !p.is_active }))} className={`relative w-12 h-7 rounded-full transition-colors ${form.is_active ? 'bg-primary-600' : 'bg-slate-300'}`}>
                    <motion.div layout className="absolute top-1 w-5 h-5 bg-white rounded-full shadow" animate={{ left: form.is_active ? '1.5rem' : '0.25rem' }} transition={{ type: 'spring', stiffness: 500, damping: 30 }} />
                  </button>
                </div>
                <div className="flex gap-3 pt-2">
                  <button onClick={() => setShowForm(false)} className="btn-secondary flex-1 text-sm">إلغاء</button>
                  <button onClick={handleSave} disabled={saving || !form.title.trim() || !form.body.trim()} className="btn-primary flex-1 text-sm">
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                    {saving ? 'جارٍ الحفظ...' : 'حفظ'}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
