import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FileText, Search, CreditCard, Settings, Megaphone, MessageSquare, CheckCircle, Ban, Trash2, CreditCard as Edit3, Plus, AlertCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import type { AdminAuditLog } from '../../lib/database.types';

const ACTION_ICONS: Record<string, React.FC<any>> = {
  toggle_suspension: Ban,
  activate: CheckCircle,
  delete: Trash2,
  update_plan: Edit3,
  create_plan: Plus,
  approve_payment: CheckCircle,
  reject_payment: Ban,
  reply_ticket: MessageSquare,
  change_ticket_status: Edit3,
  create_announcement: Megaphone,
  update_announcement: Edit3,
  delete_announcement: Trash2,
  toggle_announcement: CheckCircle,
  update_setting: Settings,
  extend_subscription: CreditCard,
};

const ACTION_LABELS: Record<string, string> = {
  toggle_suspension: 'تبديل الإيقاف',
  activate: 'تفعيل',
  delete: 'حذف',
  update_plan: 'تحديث باقة',
  create_plan: 'إنشاء باقة',
  approve_payment: 'موافقة دفع',
  reject_payment: 'رفض دفع',
  reply_ticket: 'رد على تذكرة',
  change_ticket_status: 'تغيير حالة تذكرة',
  create_announcement: 'إنشاء إعلان',
  update_announcement: 'تحديث إعلان',
  delete_announcement: 'حذف إعلان',
  toggle_announcement: 'تبديل إعلان',
  update_setting: 'تحديث إعداد',
  extend_subscription: 'تجديد اشتراك',
};

export default function SuperAdminAuditLogs() {
  const [logs, setLogs] = useState<AdminAuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterAction, setFilterAction] = useState('all');

  useEffect(() => {
    fetchLogs();
  }, []);

  async function fetchLogs() {
    setLoading(true);
    const { data } = await supabase
      .from('admin_audit_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(200);
    setLogs((data ?? []) as AdminAuditLog[]);
    setLoading(false);
  }

  const filtered = logs.filter(l => {
    const matchSearch = (l.target_name?.includes(search) ?? false) || l.action.includes(search) || (l.admin_email?.includes(search) ?? false);
    const matchAction = filterAction === 'all' || l.action === filterAction;
    return matchSearch && matchAction;
  });

  const uniqueActions = [...new Set(logs.map(l => l.action))];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96" dir="rtl">
        <div className="w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-5" dir="rtl">
      <div className="flex items-center gap-2">
        <FileText className="w-5 h-5 text-primary-600" />
        <h2 className="text-lg font-bold text-slate-900">سجل الأحداث</h2>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="ابحث..." className="input-field pr-10" />
        </div>
        <select value={filterAction} onChange={e => setFilterAction(e.target.value)} className="input-field w-auto">
          <option value="all">كل الإجراءات</option>
          {uniqueActions.map(a => (
            <option key={a} value={a}>{ACTION_LABELS[a] || a}</option>
          ))}
        </select>
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">الإجراء</th>
                <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">الهدف</th>
                <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">المدير</th>
                <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">التاريخ</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((log, idx) => {
                const Icon = ACTION_ICONS[log.action] || AlertCircle;
                return (
                  <motion.tr key={log.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: idx * 0.01 }} className="border-b border-slate-50 hover:bg-slate-50/50">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 bg-primary-50 rounded-lg flex items-center justify-center">
                          <Icon className="w-3.5 h-3.5 text-primary-600" />
                        </div>
                        <span className="font-medium text-slate-900 text-sm">{ACTION_LABELS[log.action] || log.action}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div>
                        <span className="text-xs text-slate-400">{log.target_type}</span>
                        <p className="text-sm text-slate-700">{log.target_name || log.target_id?.slice(0, 8) + '...'}</p>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500">{log.admin_email || '-'}</td>
                    <td className="px-4 py-3 text-xs text-slate-400 font-mono">{new Date(log.created_at).toLocaleString('ar-EG')}</td>
                  </motion.tr>
                );
              })}
              {filtered.length === 0 && (
                <tr><td colSpan={4} className="px-4 py-8 text-center text-slate-400">لا توجد سجلات</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
