import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  Store, TrendingUp, Clock, CheckCircle, Zap,
  DollarSign, Users, ShoppingBag, BarChart3, ArrowUpRight,
  Activity
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';

interface DashboardStats {
  totalRestaurants: number;
  activeRestaurants: number;
  expiredRestaurants: number;
  trialRestaurants: number;
  pendingActivations: number;
  totalCustomers: number;
  totalOrders: number;
  dailyOrders: number;
  dailyRevenue: number;
  totalRevenue: number;
  mrr: number;
  arr: number;
  monthlyRevenue: number;
  newRestaurantsThisMonth: number;
}

interface TrendData {
  date: string;
  orders: number;
  revenue: number;
}

interface TopRestaurant {
  id: string;
  name: string;
  orders: number;
  revenue: number;
}

export default function SuperAdminDashboard() {
  useAuth();
  const [stats, setStats] = useState<DashboardStats>({
    totalRestaurants: 0, activeRestaurants: 0, expiredRestaurants: 0,
    trialRestaurants: 0, pendingActivations: 0, totalCustomers: 0,
    totalOrders: 0, dailyOrders: 0, dailyRevenue: 0,
    totalRevenue: 0, mrr: 0, arr: 0,
    monthlyRevenue: 0, newRestaurantsThisMonth: 0,
  });
  const [trendData, setTrendData] = useState<TrendData[]>([]);
  const [topRestaurants, setTopRestaurants] = useState<TopRestaurant[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = useCallback(async () => {
    setLoading(true);
    try {
      const now = new Date();
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
      const fourteenDaysAgo = new Date();
      fourteenDaysAgo.setDate(fourteenDaysAgo.getDate() - 14);

      // Batch all independent queries in parallel
      const [
        { count: totalRestaurants },
        { count: totalCustomers },
        { count: totalOrders },
        { count: dailyOrders },
        { data: dailyOrdersData },
        { count: pendingActivations },
        { count: newRestaurantsThisMonth },
        { data: monthlyRevData },
        { data: totalRevData },
        { data: trendOrders },
        { data: subsData },
        { data: plansData },
      ] = await Promise.all([
        supabase.from('restaurants').select('*', { count: 'exact', head: true }),
        supabase.from('customers').select('*', { count: 'exact', head: true }),
        supabase.from('orders').select('*', { count: 'exact', head: true }),
        supabase.from('orders').select('*', { count: 'exact', head: true }).gte('created_at', todayStart),
        supabase.from('orders').select('total').gte('created_at', todayStart).eq('status', 'delivered'),
        supabase.from('subscription_requests').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('restaurants').select('*', { count: 'exact', head: true }).gte('created_at', monthStart),
        supabase.from('orders').select('total').eq('status', 'delivered').gte('created_at', monthStart),
        supabase.from('orders').select('total').eq('status', 'delivered'),
        supabase.from('orders').select('created_at, total, status').gte('created_at', fourteenDaysAgo.toISOString()).eq('status', 'delivered'),
        supabase.from('restaurant_subscriptions').select('restaurant_id, plan_id, status, payment_status, expires_at'),
        supabase.from('system_plans').select('id, is_trial, price_monthly'),
      ]);

      // Compute daily revenue
      const dailyRevenue = (dailyOrdersData || []).reduce((sum, o) => sum + Number(o.total || 0), 0);

      // Compute monthly + total revenue
      const monthlyRevenue = (monthlyRevData || []).reduce((sum, o) => sum + Number(o.total || 0), 0);
      const totalRevenue = (totalRevData || []).reduce((sum, o) => sum + Number(o.total || 0), 0);

      // Compute subscription-based stats
      const plans = plansData || [];
      const trialPlanId = plans.find(p => p.is_trial)?.id;
      const subs = subsData || [];

      const nowMs = now.getTime();
      const activeRestaurantIds = new Set<string>();
      const expiredRestaurantIds = new Set<string>();
      const trialRestaurantIds = new Set<string>();

      let mrr = 0;
      for (const sub of subs) {
        const isApproved = sub.payment_status === 'approved';
        const isActive = sub.status === 'active' && new Date(sub.expires_at).getTime() > nowMs;
        const plan = plans.find(p => p.id === sub.plan_id);

        if (isApproved && isActive) {
          activeRestaurantIds.add(sub.restaurant_id);
          if (plan && !plan.is_trial) {
            mrr += Number(plan.price_monthly || 0);
          }
          if (plan?.is_trial || sub.plan_id === trialPlanId) {
            trialRestaurantIds.add(sub.restaurant_id);
          }
        } else if (isApproved && sub.expires_at && new Date(sub.expires_at).getTime() <= nowMs) {
          if (sub.plan_id !== trialPlanId) {
            expiredRestaurantIds.add(sub.restaurant_id);
          }
        }
      }

      const arr = mrr * 12;

      // Build 14-day trend
      const dayMap: Record<string, { orders: number; revenue: number }> = {};
      for (let i = 13; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const key = d.toISOString().slice(0, 10);
        dayMap[key] = { orders: 0, revenue: 0 };
      }
      for (const o of trendOrders || []) {
        const key = (o.created_at as string).slice(0, 10);
        if (dayMap[key]) {
          dayMap[key].orders += 1;
          dayMap[key].revenue += Number(o.total || 0);
        }
      }
      const trend = Object.entries(dayMap).map(([date, v]) => ({ date, ...v }));

      // Fetch top 10 restaurants by revenue — use a single query with aggregation
      // We fetch all delivered orders grouped by restaurant
      const { data: topData } = await supabase
        .from('orders')
        .select('restaurant_id, total')
        .eq('status', 'delivered');

      const restaurantAgg: Record<string, { orders: number; revenue: number }> = {};
      for (const o of topData || []) {
        const rid = o.restaurant_id as string;
        if (!restaurantAgg[rid]) restaurantAgg[rid] = { orders: 0, revenue: 0 };
        restaurantAgg[rid].orders += 1;
        restaurantAgg[rid].revenue += Number(o.total || 0);
      }

      // Fetch restaurant names for top 10
      const topIds = Object.entries(restaurantAgg)
        .sort((a, b) => b[1].revenue - a[1].revenue)
        .slice(0, 10)
        .map(([id]) => id);

      let topRests: TopRestaurant[] = [];
      if (topIds.length > 0) {
        const { data: topRestaurantsData } = await supabase
          .from('restaurants')
          .select('id, name')
          .in('id', topIds);

        const nameMap = new Map((topRestaurantsData || []).map(r => [r.id, r.name]));
        topRests = topIds.map(id => ({
          id,
          name: nameMap.get(id) || 'غير معروف',
          orders: restaurantAgg[id].orders,
          revenue: restaurantAgg[id].revenue,
        }));
      }

      setStats({
        totalRestaurants: totalRestaurants || 0,
        activeRestaurants: activeRestaurantIds.size,
        expiredRestaurants: expiredRestaurantIds.size,
        trialRestaurants: trialRestaurantIds.size,
        pendingActivations: pendingActivations || 0,
        totalCustomers: totalCustomers || 0,
        totalOrders: totalOrders || 0,
        dailyOrders: dailyOrders || 0,
        dailyRevenue,
        totalRevenue,
        mrr,
        arr,
        monthlyRevenue,
        newRestaurantsThisMonth: newRestaurantsThisMonth || 0,
      });
      setTrendData(trend);
      setTopRestaurants(topRests);
    } catch (err) {
      console.error('Admin dashboard error:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchDashboardData(); }, [fetchDashboardData]);

  const maxRevenue = Math.max(...trendData.map(d => d.revenue), 1);
  const maxOrders = Math.max(...trendData.map(d => d.orders), 1);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96" dir="rtl">
        <div className="w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        {[
          { label: 'إجمالي المطاعم', value: stats.totalRestaurants, icon: Store, color: 'bg-slate-800', change: `+${stats.newRestaurantsThisMonth} هذا الشهر` },
          { label: 'نشطة', value: stats.activeRestaurants, icon: CheckCircle, color: 'bg-success-500', change: null },
          { label: 'منتهية', value: stats.expiredRestaurants, icon: Clock, color: 'bg-warning-500', change: null },
          { label: 'تجريبية', value: stats.trialRestaurants, icon: Zap, color: 'bg-primary-600', change: null },
          { label: 'بانتظار التفعيل', value: stats.pendingActivations, icon: Activity, color: 'bg-amber-500', change: null },
          { label: 'إجمالي العملاء', value: stats.totalCustomers, icon: Users, color: 'bg-blue-600', change: null },
          { label: 'إجمالي الطلبات', value: stats.totalOrders, icon: ShoppingBag, color: 'bg-purple-600', change: null },
          { label: 'طلبات اليوم', value: stats.dailyOrders, icon: ShoppingBag, color: 'bg-indigo-600', change: null },
          { label: 'إيرادات اليوم', value: `${stats.dailyRevenue.toFixed(0)} ج.م`, icon: DollarSign, color: 'bg-emerald-600', change: null },
          { label: 'MRR', value: `${stats.mrr.toFixed(0)} ج.م`, icon: TrendingUp, color: 'bg-rose-600', change: null },
          { label: 'ARR', value: `${stats.arr.toFixed(0)} ج.م`, icon: BarChart3, color: 'bg-cyan-600', change: null },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }} className="card p-4 card-hover">
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-7 h-7 ${s.color} rounded-lg flex items-center justify-center`}>
                <s.icon className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="text-xs text-slate-500 font-medium">{s.label}</span>
            </div>
            <p className="text-xl font-bold text-slate-900">{s.value}</p>
            {s.change && <p className="text-[10px] text-success-600 mt-1">{s.change}</p>}
          </motion.div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Revenue Trend */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-900 text-sm">الإيرادات اليومية (14 يوم)</h3>
            <div className="flex items-center gap-1 text-xs text-success-600 font-medium">
              <ArrowUpRight className="w-3.5 h-3.5" />
              {stats.dailyRevenue.toFixed(0)} ج.م اليوم
            </div>
          </div>
          <div className="flex items-end gap-1 h-40">
            {trendData.map((d, i) => {
              const h = (d.revenue / maxRevenue) * 100;
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-1 group">
                  <div className="opacity-0 group-hover:opacity-100 text-[10px] text-slate-500 transition-opacity">{d.revenue.toFixed(0)}</div>
                  <div className="w-full bg-primary-100 rounded-t" style={{ height: `${Math.max(h, 4)}%` }}>
                    <div className="w-full h-full bg-primary-500 rounded-t opacity-80 hover:opacity-100 transition-opacity" />
                  </div>
                  <span className="text-[9px] text-slate-400">{d.date.slice(5)}</span>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Orders Trend */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-900 text-sm">الطلبات اليومية (14 يوم)</h3>
            <div className="flex items-center gap-1 text-xs text-primary-600 font-medium">
              {trendData.reduce((s, d) => s + d.orders, 0)} طلب
            </div>
          </div>
          <div className="flex items-end gap-1 h-40">
            {trendData.map((d, i) => {
              const h = (d.orders / maxOrders) * 100;
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-1 group">
                  <div className="opacity-0 group-hover:opacity-100 text-[10px] text-slate-500 transition-opacity">{d.orders}</div>
                  <div className="w-full bg-success-100 rounded-t" style={{ height: `${Math.max(h, 4)}%` }}>
                    <div className="w-full h-full bg-success-500 rounded-t opacity-80 hover:opacity-100 transition-opacity" />
                  </div>
                  <span className="text-[9px] text-slate-400">{d.date.slice(5)}</span>
                </div>
              );
            })}
          </div>
        </motion.div>
      </div>

      {/* Top Restaurants + Monthly Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="lg:col-span-2 card p-5">
          <h3 className="font-bold text-slate-900 text-sm mb-4">أفضل المطاعم</h3>
          {topRestaurants.length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-8">لا توجد بيانات</p>
          ) : (
            <div className="space-y-3">
              {topRestaurants.map((r, i) => (
                <div key={r.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                  <div className="w-8 h-8 bg-primary-50 rounded-lg flex items-center justify-center text-xs font-bold text-primary-600">
                    #{i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-slate-900 text-sm truncate">{r.name}</p>
                    <p className="text-xs text-slate-400">{r.orders} طلب</p>
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-slate-900 text-sm">{r.revenue.toFixed(0)} ج.م</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }} className="card p-5 space-y-4">
          <h3 className="font-bold text-slate-900 text-sm">ملخص الشهر</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-primary-50 rounded-xl">
              <span className="text-sm text-primary-700">إيرادات الشهر</span>
              <span className="font-bold text-primary-700">{stats.monthlyRevenue.toFixed(0)} ج.م</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-success-50 rounded-xl">
              <span className="text-sm text-success-700">مطاعم جديدة</span>
              <span className="font-bold text-success-700">{stats.newRestaurantsThisMonth}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-amber-50 rounded-xl">
              <span className="text-sm text-amber-700">معدل النمو</span>
              <span className="font-bold text-amber-700">
                {stats.totalRestaurants > 0 ? ((stats.newRestaurantsThisMonth / stats.totalRestaurants) * 100).toFixed(1) : 0}%
              </span>
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
              <span className="text-sm text-slate-700">متوسط الإيراد/مطعم</span>
              <span className="font-bold text-slate-700">
                {stats.totalRestaurants > 0 ? (stats.monthlyRevenue / stats.totalRestaurants).toFixed(0) : 0} ج.م
              </span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
