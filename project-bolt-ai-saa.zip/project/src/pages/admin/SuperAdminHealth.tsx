import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Activity, Store, ShoppingBag, DollarSign, Users,
  AlertTriangle, CheckCircle, RefreshCw, Zap, TrendingUp,
  Clock, Server, Wifi
} from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface HealthStats {
  activeRestaurants: number;
  suspendedRestaurants: number;
  totalRestaurants: number;
  ordersToday: number;
  revenueToday: number;
  activeSubscriptions: number;
  trialRestaurants: number;
  expiredRestaurants: number;
  newRestaurantsToday: number;
  totalOrders: number;
  totalCustomers: number;
}

interface EdgeFnStatus {
  name: string;
  url: string;
  status: 'checking' | 'ok' | 'error';
  latency?: number;
}

export default function SuperAdminHealth() {
  const [stats, setStats] = useState<HealthStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const [edgeFns, setEdgeFns] = useState<EdgeFnStatus[]>([
    { name: 'order-intake', url: `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/order-intake`, status: 'checking' },
    { name: 'telegram-webhook', url: `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/telegram-webhook`, status: 'checking' },
    { name: 'telegram-notify', url: `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/telegram-notify`, status: 'checking' },
  ]);

  useEffect(() => {
    fetchHealth();
    checkEdgeFunctions();
    const interval = setInterval(fetchHealth, 60000);
    return () => clearInterval(interval);
  }, []);

  async function fetchHealth() {
    setLoading(true);
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const [restsRes, ordersRes, customersRes, ordersAllRes] = await Promise.all([
        supabase.from('restaurants').select('id,is_active,is_suspended,subscription_plan,subscription_expires_at,created_at'),
        supabase.from('orders').select('id,total,status,restaurant_id').gte('created_at', today.toISOString()),
        supabase.from('customers').select('id', { count: 'exact', head: true }),
        supabase.from('orders').select('id', { count: 'exact', head: true }),
      ]);

      const rests = restsRes.data ?? [];
      const orders = ordersRes.data ?? [];
      const now = new Date();

      const activeRestaurants = rests.filter(r => r.is_active && !r.is_suspended).length;
      const suspendedRestaurants = rests.filter(r => r.is_suspended).length;
      const trialRestaurants = rests.filter(r => r.subscription_plan === 'trial').length;
      const expiredRestaurants = rests.filter(r => {
        if (!r.subscription_expires_at) return false;
        return new Date(r.subscription_expires_at) < now;
      }).length;
      const activeSubscriptions = rests.filter(r =>
        r.subscription_plan !== 'trial' &&
        r.is_active &&
        (!r.subscription_expires_at || new Date(r.subscription_expires_at) > now)
      ).length;
      const newRestaurantsToday = rests.filter(r => new Date(r.created_at) >= today).length;
      const completedOrders = orders.filter(o => o.status === 'delivered' || o.status === 'ready');
      const revenueToday = completedOrders.reduce((s, o) => s + Number(o.total), 0);

      setStats({
        activeRestaurants,
        suspendedRestaurants,
        totalRestaurants: rests.length,
        ordersToday: orders.length,
        revenueToday,
        activeSubscriptions,
        trialRestaurants,
        expiredRestaurants,
        newRestaurantsToday,
        totalOrders: ordersAllRes.count ?? 0,
        totalCustomers: customersRes.count ?? 0,
      });
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setLastRefresh(new Date());
    }
  }

  async function checkEdgeFunctions() {
    setEdgeFns(prev => prev.map(fn => ({ ...fn, status: 'checking' })));
    const results = await Promise.allSettled(
      edgeFns.map(async (fn) => {
        const start = performance.now();
        try {
          const res = await fetch(fn.url, { method: 'OPTIONS', signal: AbortSignal.timeout(5000) });
          const latency = Math.round(performance.now() - start);
          return { name: fn.name, status: (res.status < 500 ? 'ok' : 'error') as 'ok' | 'error', latency };
        } catch {
          return { name: fn.name, status: 'error' as const, latency: undefined };
        }
      })
    );

    setEdgeFns(prev => prev.map(fn => {
      const result = results.find((_, i) => edgeFns[i].name === fn.name);
      if (result?.status === 'fulfilled') return { ...fn, ...result.value };
      return { ...fn, status: 'error' };
    }));
  }

  const overallHealth = !stats
    ? 0
    : stats.expiredRestaurants === 0 && stats.suspendedRestaurants === 0
      ? 100
      : Math.max(0, 100 - stats.expiredRestaurants * 5 - stats.suspendedRestaurants * 10);

  function StatCard({ label, value, icon: Icon, color, sub }: {
    label: string; value: string | number; icon: React.FC<any>; color: string; sub?: string
  }) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-slate-500">{label}</span>
          <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${color}`}>
            <Icon className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="text-2xl font-bold text-slate-900">{value}</div>
        {sub && <div className="text-xs text-slate-400 mt-0.5">{sub}</div>}
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Server className="w-5 h-5 text-slate-600" />
            صحة النظام
          </h2>
          {lastRefresh && (
            <p className="text-xs text-slate-400 mt-0.5">آخر تحديث: {lastRefresh.toLocaleTimeString('ar-EG')}</p>
          )}
        </div>
        <button onClick={() => { fetchHealth(); checkEdgeFunctions(); }} disabled={loading} className="btn-secondary text-sm px-3 py-2">
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          تحديث
        </button>
      </div>

      {/* Overall Health */}
      <div className={`rounded-2xl border p-5 ${overallHealth >= 90 ? 'bg-emerald-50 border-emerald-200' : overallHealth >= 70 ? 'bg-amber-50 border-amber-200' : 'bg-red-50 border-red-200'}`}>
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${overallHealth >= 90 ? 'bg-emerald-100' : overallHealth >= 70 ? 'bg-amber-100' : 'bg-red-100'}`}>
            {overallHealth >= 90
              ? <CheckCircle className="w-6 h-6 text-emerald-600" />
              : <AlertTriangle className={`w-6 h-6 ${overallHealth >= 70 ? 'text-amber-600' : 'text-red-600'}`} />
            }
          </div>
          <div>
            <div className="font-bold text-slate-800">
              {overallHealth >= 90 ? 'النظام يعمل بشكل مثالي' : overallHealth >= 70 ? 'النظام يعمل مع تحذيرات' : 'النظام يحتاج انتباه'}
            </div>
            <div className="text-sm text-slate-500">صحة النظام: {overallHealth}%</div>
          </div>
          <div className="mr-auto text-3xl font-black text-slate-700">{overallHealth}%</div>
        </div>
        <div className="mt-3 h-2 bg-white/60 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${overallHealth}%` }}
            transition={{ duration: 1, ease: 'easeOut' }}
            className={`h-full rounded-full ${overallHealth >= 90 ? 'bg-emerald-500' : overallHealth >= 70 ? 'bg-amber-400' : 'bg-red-500'}`}
          />
        </div>
      </div>

      {/* Stats Grid */}
      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="bg-white rounded-xl border border-slate-200 p-4 animate-pulse">
              <div className="h-3 bg-slate-100 rounded w-1/2 mb-3" />
              <div className="h-7 bg-slate-100 rounded w-1/3" />
            </div>
          ))}
        </div>
      ) : stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard label="مطاعم نشطة" value={stats.activeRestaurants} icon={Store} color="bg-emerald-100 text-emerald-600" sub={`من ${stats.totalRestaurants} إجمالي`} />
          <StatCard label="طلبات اليوم" value={stats.ordersToday} icon={ShoppingBag} color="bg-blue-100 text-blue-600" />
          <StatCard label="إيرادات اليوم" value={`${stats.revenueToday.toFixed(0)}`} icon={DollarSign} color="bg-emerald-100 text-emerald-600" />
          <StatCard label="اشتراكات فعالة" value={stats.activeSubscriptions} icon={Zap} color="bg-amber-100 text-amber-600" />
          <StatCard label="تجربة مجانية" value={stats.trialRestaurants} icon={Clock} color="bg-slate-100 text-slate-600" />
          <StatCard label="منتهية الصلاحية" value={stats.expiredRestaurants} icon={AlertTriangle} color="bg-red-100 text-red-600" />
          <StatCard label="إجمالي العملاء" value={stats.totalCustomers.toLocaleString()} icon={Users} color="bg-violet-100 text-violet-600" />
          <StatCard label="إجمالي الطلبات" value={stats.totalOrders.toLocaleString()} icon={TrendingUp} color="bg-primary-100 text-primary-600" />
        </div>
      )}

      {/* Edge Function Status */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-slate-800 flex items-center gap-2"><Wifi className="w-4 h-4 text-slate-500" />حالة Edge Functions</h3>
          <button onClick={checkEdgeFunctions} className="text-xs text-primary-600 hover:text-primary-700">إعادة الفحص</button>
        </div>
        <div className="space-y-2">
          {edgeFns.map(fn => (
            <div key={fn.name} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
              <div className={`w-2 h-2 rounded-full flex-shrink-0 ${fn.status === 'ok' ? 'bg-emerald-500' : fn.status === 'error' ? 'bg-red-500' : 'bg-amber-400 animate-pulse'}`} />
              <span className="font-mono text-sm text-slate-700 flex-1">{fn.name}</span>
              <div className="flex items-center gap-2">
                {fn.latency !== undefined && (
                  <span className="text-xs text-slate-400">{fn.latency}ms</span>
                )}
                <span className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                  fn.status === 'ok' ? 'bg-emerald-100 text-emerald-700' :
                  fn.status === 'error' ? 'bg-red-100 text-red-700' :
                  'bg-amber-100 text-amber-700'
                }`}>
                  {fn.status === 'ok' ? 'يعمل' : fn.status === 'error' ? 'خطأ' : 'فحص...'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Activity snapshot */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Activity className="w-4 h-4 text-slate-500" />نشاط المنصة اليوم</h3>
        {stats && (
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-slate-900">{stats.newRestaurantsToday}</div>
              <div className="text-xs text-slate-400 mt-0.5">مطاعم جديدة</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">{stats.ordersToday}</div>
              <div className="text-xs text-slate-400 mt-0.5">طلب</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">{stats.suspendedRestaurants}</div>
              <div className="text-xs text-slate-400 mt-0.5">موقوف</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
