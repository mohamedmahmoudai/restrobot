import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Pencil, X, Check, Loader2, Eye, EyeOff, Search, AlertCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import type { SystemPlan, FeatureDefinition, PlanFeature } from '../../lib/database.types';

type Plan = SystemPlan & {
  features_list?: string[];
};

const BADGES = [
  { key: 'most_popular', label: 'الأكثر شعبية' },
  { key: 'recommended', label: 'موصى به' },
  { key: 'enterprise', label: 'مؤسسات' },
  { key: 'new', label: 'جديد' },
  { key: 'free', label: 'مجاني' },
];

const PLAN_TYPES = [
  { key: 'free', label: 'مجاني' },
  { key: 'paid', label: 'مدفوع' },
  { key: 'enterprise', label: 'مؤسسات' },
  { key: 'custom', label: 'تسعير مخصص' },
];

const LIMIT_FIELDS = [
  { key: 'max_orders', label: 'الحد الأقصى للطلبات' },
  { key: 'max_branches', label: 'الحد الأقصى للفروع' },
  { key: 'max_users', label: 'الحد الأقصى للمستخدمين' },
  { key: 'max_menu_items', label: 'الحد الأقصى للمنتجات' },
  { key: 'max_categories', label: 'الحد الأقصى للفئات' },
  { key: 'max_customers', label: 'الحد الأقصى للعملاء' },
  { key: 'max_telegram_bots', label: 'الحد الأقصى لبوتات تيليجرام' },
  { key: 'max_storage_gb', label: 'الحد الأقصى للتخزين (GB)' },
  { key: 'max_daily_messages', label: 'الحد الأقصى للرسائل اليومية' },
  { key: 'max_ai_requests', label: 'الحد الأقصى لطلبات الذكاء الاصطناعي' },
  { key: 'max_qr_menus', label: 'الحد الأقصى لقوائم QR' },
  { key: 'max_tables', label: 'الحد الأقصى للطاولات' },
  { key: 'max_loyalty_campaigns', label: 'الحد الأقصى لحملات الولاء' },
  { key: 'max_coupons', label: 'الحد الأقصى للكوبونات' },
] as const;

const FEATURE_CATEGORIES = [
  { key: 'core', label: 'المميزات الأساسية' },
  { key: 'analytics', label: 'التحليلات والتقارير' },
  { key: 'support', label: 'الدعم' },
  { key: 'advanced', label: 'مميزات متقدمة' },
];

export default function SuperAdminPlans() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [features, setFeatures] = useState<FeatureDefinition[]>([]);
  const [planFeaturesMap, setPlanFeaturesMap] = useState<Record<string, string[]>>({});
  const [loading, setLoading] = useState(true);
  const [editingPlan, setEditingPlan] = useState<Plan | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Plan | null>(null);
  const [deleteSubCount, setDeleteSubCount] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddFeature, setShowAddFeature] = useState(false);
  const [newFeatureLabel, setNewFeatureLabel] = useState('');

  const showMessage = (msg: string) => {
    setMessage(msg);
    setTimeout(() => setMessage(null), 3000);
  };

  const loadData = useCallback(async () => {
    setLoading(true);
    const [{ data: plansData }, { data: featuresData }, { data: pfData }] = await Promise.all([
      supabase.from('system_plans').select('*').order('sort_order'),
      supabase.from('feature_definitions').select('*').order('sort_order'),
      supabase.from('plan_features').select('plan_id, feature_id'),
    ]);

    const pfMap: Record<string, string[]> = {};
    for (const pf of (pfData ?? []) as PlanFeature[]) {
      if (!pfMap[pf.plan_id]) pfMap[pf.plan_id] = [];
      pfMap[pf.plan_id].push(pf.feature_id);
    }

    setPlans((plansData ?? []) as Plan[]);
    setFeatures((featuresData ?? []) as FeatureDefinition[]);
    setPlanFeaturesMap(pfMap);
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  function startCreate() {
    setEditingPlan({
      id: '', plan_name: '', name_ar: '', type: 'paid', price: 0,
      price_weekly: 0, price_monthly: 0, price_yearly: 0, duration_days: 30,
      max_orders: null, max_branches: null, max_users: null, max_menu_items: null,
      features: [], is_active: true, is_trial: false, sort_order: plans.length + 1,
      created_at: '', updated_at: '',
      internal_code: '', description: '', plan_color: '#3b82f6', plan_icon: 'Package',
      badge: null, show_on_landing: true, can_subscribe: true, plan_type: 'paid',
      supports_weekly: false, supports_monthly: true, supports_yearly: false,
      trial_days: 0, auto_renew: false,
      max_categories: null, max_customers: null, max_telegram_bots: null,
      max_storage_gb: null, max_daily_messages: null, max_ai_requests: null,
      max_qr_menus: null, max_tables: null, max_loyalty_campaigns: null,
      max_coupons: null, enterprise_notes: null,
    });
    setIsCreating(true);
  }

  async function savePlan(plan: Plan, selectedFeatureIds: string[]) {
    setSaving(true);
    try {
      const payload: Record<string, unknown> = {
        plan_name: plan.plan_name,
        name_ar: plan.name_ar || plan.plan_name,
        type: plan.plan_type === 'free' ? 'free' : plan.plan_type === 'enterprise' ? 'enterprise' : 'paid',
        plan_type: plan.plan_type,
        internal_code: plan.internal_code || null,
        description: plan.description || null,
        price: plan.price_monthly,
        price_weekly: 0,
        price_monthly: plan.price_monthly,
        price_yearly: 0,
        duration_days: plan.duration_days,
        is_active: plan.is_active,
        is_trial: plan.is_trial,
        sort_order: plan.sort_order,
        badge: plan.badge || null,
        plan_color: plan.plan_color || null,
        plan_icon: plan.plan_icon || null,
        show_on_landing: plan.show_on_landing,
        can_subscribe: plan.can_subscribe,
        supports_weekly: false,
        supports_monthly: true,
        supports_yearly: false,
        trial_days: plan.trial_days,
        auto_renew: plan.auto_renew,
        max_orders: plan.max_orders,
        max_branches: plan.max_branches,
        max_users: plan.max_users,
        max_menu_items: plan.max_menu_items,
        max_categories: plan.max_categories,
        max_customers: plan.max_customers,
        max_telegram_bots: plan.max_telegram_bots,
        max_storage_gb: plan.max_storage_gb,
        max_daily_messages: plan.max_daily_messages,
        max_ai_requests: plan.max_ai_requests,
        max_qr_menus: plan.max_qr_menus,
        max_tables: plan.max_tables,
        max_loyalty_campaigns: plan.max_loyalty_campaigns,
        max_coupons: plan.max_coupons,
        enterprise_notes: plan.enterprise_notes || null,
        features: selectedFeatureIds.map(id => features.find(f => f.id === id)?.label_ar).filter(Boolean),
      };

      let planId = plan.id;
      if (isCreating) {
        const { data, error } = await supabase.from('system_plans').insert(payload).select('id').maybeSingle();
        if (error) throw error;
        planId = data!.id;
      } else {
        const { error } = await supabase.from('system_plans').update(payload).eq('id', plan.id);
        if (error) throw error;
        await supabase.from('plan_features').delete().eq('plan_id', plan.id);
      }

      if (selectedFeatureIds.length > 0) {
        await supabase.from('plan_features').insert(
          selectedFeatureIds.map(fid => ({ plan_id: planId, feature_id: fid }))
        );
      }

      showMessage(isCreating ? 'تم إنشاء الخطة بنجاح' : 'تم تحديث الخطة بنجاح');
      setEditingPlan(null);
      setIsCreating(false);
      loadData();
    } catch {
      showMessage('فشل حفظ الخطة');
    } finally {
      setSaving(false);
    }
  }

  async function requestDelete(plan: Plan) {
    const { count } = await supabase.from('restaurant_subscriptions')
      .select('id', { count: 'exact', head: true })
      .eq('plan_id', plan.id);
    setDeleteSubCount(count ?? 0);
    setDeleteTarget(plan);
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setSaving(true);
    try {
      await supabase.from('plan_features').delete().eq('plan_id', deleteTarget.id);
      await supabase.from('restaurant_subscriptions').delete().eq('plan_id', deleteTarget.id);
      await supabase.from('subscription_requests').delete().eq('plan_id', deleteTarget.id);
      await supabase.from('system_plans').delete().eq('id', deleteTarget.id);
      showMessage('تم حذف الخطة');
      setDeleteTarget(null);
      loadData();
    } catch {
      showMessage('فشل حذف الخطة');
    } finally {
      setSaving(false);
    }
  }

  async function toggleActive(plan: Plan) {
    await supabase.from('system_plans').update({ is_active: !plan.is_active }).eq('id', plan.id);
    loadData();
  }

  async function addCustomFeature() {
    if (!newFeatureLabel.trim()) return;
    const key = newFeatureLabel.trim().toLowerCase().replace(/\s+/g, '_');
    const { data, error } = await supabase.from('feature_definitions')
      .insert({ key, label_ar: newFeatureLabel.trim(), label_en: newFeatureLabel.trim(), category: 'core', sort_order: 999 })
      .select('*').maybeSingle();
    if (!error && data) {
      setFeatures(prev => [...prev, data as FeatureDefinition]);
      setShowAddFeature(false);
      setNewFeatureLabel('');
      showMessage('تم إضافة الميزة');
    } else {
      showMessage('فشل إضافة الميزة');
    }
  }

  const filteredPlans = plans.filter(p =>
    p.plan_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (p.name_ar ?? '').includes(searchQuery) ||
    (p.internal_code ?? '').includes(searchQuery)
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 animate-spin text-primary-500" />
      </div>
    );
  }

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900">إدارة الخطط</h1>
          <p className="text-sm text-slate-500 mt-0.5">{plans.length} خطة — اشتراك شهري فقط</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input type="text" placeholder="بحث..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="input-field !py-2 !pr-9 !w-40 text-sm" />
          </div>
          <button onClick={startCreate} className="btn-primary px-4 py-2 text-sm flex items-center gap-1.5">
            <Plus className="w-4 h-4" /> خطة جديدة
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredPlans.map(plan => (
          <motion.div key={plan.id} layout initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="card p-4 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: (plan.plan_color ?? '#3b82f6') + '20' }}>
                  <span className="text-xs font-bold" style={{ color: plan.plan_color ?? '#3b82f6' }}>{plan.plan_name[0]}</span>
                </div>
                <div>
                  <p className="font-bold text-sm text-slate-900">{plan.name_ar || plan.plan_name}</p>
                  <p className="text-xs text-slate-400 font-mono">{plan.internal_code || plan.type}</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => toggleActive(plan)} className={`p-1.5 rounded-lg transition-colors ${plan.is_active ? 'bg-success-50 text-success-600' : 'bg-slate-100 text-slate-400'}`}>
                  {plan.is_active ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                </button>
                <button onClick={() => { setEditingPlan(plan); setIsCreating(false); }} className="p-1.5 rounded-lg bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors">
                  <Pencil className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => requestDelete(plan)} className="p-1.5 rounded-lg bg-danger-50 text-danger-500 hover:bg-danger-100 transition-colors">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {plan.badge && (
              <span className="inline-block px-2 py-0.5 rounded-full text-xs font-semibold bg-primary-50 text-primary-700">
                {BADGES.find(b => b.key === plan.badge)?.label ?? plan.badge}
              </span>
            )}

            {plan.description && <p className="text-xs text-slate-500 line-clamp-2">{plan.description}</p>}

            <div className="flex gap-2 flex-wrap">
              <span className="text-xs bg-slate-50 px-2 py-0.5 rounded-md text-slate-600">
                {plan.plan_type === 'enterprise' ? 'تواصل معنا' : `${plan.price_monthly} ج.م/شهر`}
              </span>
              <span className="text-xs bg-slate-50 px-2 py-0.5 rounded-md text-slate-600">{plan.duration_days} يوم</span>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-100">
              <span>{(planFeaturesMap[plan.id] ?? []).length} ميزة</span>
              <span>{plan.show_on_landing ? 'ظاهر في الرئيسية' : 'مخفي'}</span>
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {editingPlan && (
          <PlanEditor
            plan={editingPlan}
            features={features}
            selectedFeatureIds={planFeaturesMap[editingPlan.id] ?? []}
            isCreating={isCreating}
            saving={saving}
            onSave={savePlan}
            onClose={() => { setEditingPlan(null); setIsCreating(false); }}
            onAddFeature={() => setShowAddFeature(true)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAddFeature && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 modal-overlay flex items-center justify-center p-4 z-50" onClick={() => setShowAddFeature(false)}>
            <motion.div initial={{ scale: 0.95, y: 12 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 12 }} onClick={e => e.stopPropagation()} className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-modal space-y-4">
              <h2 className="text-lg font-bold text-slate-900">إضافة ميزة جديدة</h2>
              <input type="text" placeholder="اسم الميزة" value={newFeatureLabel} onChange={e => setNewFeatureLabel(e.target.value)} autoFocus className="input-field" />
              <div className="flex gap-2">
                <button onClick={() => setShowAddFeature(false)} className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-sm">إلغاء</button>
                <button onClick={addCustomFeature} className="flex-1 py-2.5 btn-primary text-sm">إضافة</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {deleteTarget && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 modal-overlay flex items-center justify-center p-4 z-50">
            <motion.div initial={{ scale: 0.95, y: 12 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 12 }} className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-modal space-y-4 text-center">
              <div className="w-10 h-10 bg-danger-50 rounded-full flex items-center justify-center mx-auto"><Trash2 className="w-5 h-5 text-danger-500" /></div>
              <h2 className="text-base font-bold text-slate-900">حذف الخطة؟</h2>
              <p className="text-sm text-slate-500">سيتم حذف "{deleteTarget.name_ar || deleteTarget.plan_name}" نهائياً.</p>
              {deleteSubCount > 0 && (
                <div className="bg-warning-50 border border-warning-200 rounded-xl p-3 flex items-center gap-2 text-warning-700">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <p className="text-xs font-semibold">يوجد {deleteSubCount} مطعم مشترك في هذه الخطة. سيتم حذف اشتراكاتهم أيضاً.</p>
                </div>
              )}
              <div className="flex gap-2">
                <button onClick={() => setDeleteTarget(null)} className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-sm">تراجع</button>
                <button onClick={confirmDelete} disabled={saving} className="flex-1 py-2.5 btn-danger text-sm">
                  {saving ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'تأكيد الحذف'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {message && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }} className="fixed bottom-6 right-6 bg-success-500 text-white px-4 py-3 rounded-xl shadow-lg font-semibold text-sm z-50">
            {message}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function PlanEditor({ plan, features, selectedFeatureIds, isCreating, saving, onSave, onClose, onAddFeature }: {
  plan: Plan;
  features: FeatureDefinition[];
  selectedFeatureIds: string[];
  isCreating: boolean;
  saving: boolean;
  onSave: (plan: Plan, featureIds: string[]) => void;
  onClose: () => void;
  onAddFeature: () => void;
}) {
  const [form, setForm] = useState<Plan>(plan);
  const [selectedFeatures, setSelectedFeatures] = useState<Set<string>>(new Set(selectedFeatureIds));

  function update<K extends keyof Plan>(key: K, value: Plan[K]) {
    setForm(prev => ({ ...prev, [key]: value }));
  }

  function toggleFeature(id: string) {
    setSelectedFeatures(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  function toggleLimitUnlimited(field: typeof LIMIT_FIELDS[number]['key']) {
    update(field, form[field] === null ? 0 : null);
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 overflow-y-auto" dir="rtl">
      <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 20, opacity: 0 }} className="min-h-screen flex items-start justify-center p-4 py-8">
        <div className="bg-white rounded-2xl shadow-modal max-w-3xl w-full space-y-6">
          <div className="flex items-center justify-between p-6 border-b border-slate-100 sticky top-0 bg-white rounded-t-2xl z-10">
            <div>
              <h2 className="text-lg font-bold text-slate-900">{isCreating ? 'إنشاء خطة جديدة' : 'تعديل الخطة'}</h2>
              <p className="text-sm text-slate-500 mt-0.5">{form.name_ar || form.plan_name || 'خطة بدون اسم'}</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg transition-colors"><X className="w-5 h-5 text-slate-400" /></button>
          </div>

          <div className="px-6 pb-6 space-y-6">
            {/* Section 1: General */}
            <div className="card p-4 space-y-3">
              <h3 className="font-bold text-sm text-slate-900">المعلومات العامة</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">اسم الخطة (إنجليزي)</label>
                  <input type="text" value={form.plan_name} onChange={e => update('plan_name', e.target.value)} className="input-field" placeholder="Starter" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">الاسم بالعربي</label>
                  <input type="text" value={form.name_ar ?? ''} onChange={e => update('name_ar', e.target.value)} className="input-field" placeholder="البداية" />
                </div>
                <div className="space-y-1 col-span-2">
                  <label className="text-xs font-semibold text-slate-600">الوصف</label>
                  <textarea value={form.description ?? ''} onChange={e => update('description', e.target.value)} className="input-field min-h-[50px]" placeholder="وصف مختصر" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">ترتيب العرض</label>
                  <input type="number" value={form.sort_order} onChange={e => update('sort_order', parseInt(e.target.value) || 0)} className="input-field" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">الشارة (اختياري)</label>
                  <select value={form.badge ?? ''} onChange={e => update('badge', e.target.value || null)} className="input-field">
                    <option value="">بدون</option>
                    {BADGES.map(b => <option key={b.key} value={b.key}>{b.label}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">اللون</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={form.plan_color ?? '#3b82f6'} onChange={e => update('plan_color', e.target.value)} className="w-10 h-10 rounded-lg border border-slate-200 cursor-pointer" />
                    <input type="text" value={form.plan_color ?? ''} onChange={e => update('plan_color', e.target.value)} className="input-field flex-1" placeholder="#3b82f6" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">الأيقونة (Lucide)</label>
                  <input type="text" value={form.plan_icon ?? ''} onChange={e => update('plan_icon', e.target.value)} className="input-field" placeholder="Rocket" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">نوع الخطة</label>
                  <select value={form.plan_type} onChange={e => { update('plan_type', e.target.value); if (e.target.value === 'free') { update('price_monthly', 0); update('price', 0); } }} className="input-field">
                    {PLAN_TYPES.map(t => <option key={t.key} value={t.key}>{t.label}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">السعر الشهري (ج.م)</label>
                  <input type="number" value={form.price_monthly} onChange={e => { update('price_monthly', parseFloat(e.target.value) || 0); update('price', parseFloat(e.target.value) || 0); }} className="input-field" disabled={form.plan_type === 'free' || form.plan_type === 'enterprise'} />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">المدة (أيام)</label>
                  <input type="number" value={form.duration_days} onChange={e => update('duration_days', parseInt(e.target.value) || 30)} className="input-field" />
                </div>
              </div>
              <div className="flex gap-4 flex-wrap mt-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={form.show_on_landing} onChange={e => update('show_on_landing', e.target.checked)} className="w-4 h-4 rounded border-slate-300 text-primary-600 focus:ring-primary-500" />
                  <span className="text-xs font-semibold text-slate-600">ظاهر في الصفحة الرئيسية</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={form.can_subscribe} onChange={e => update('can_subscribe', e.target.checked)} className="w-4 h-4 rounded border-slate-300 text-primary-600 focus:ring-primary-500" />
                  <span className="text-xs font-semibold text-slate-600">متاح للاشتراك</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={form.plan_type === 'free'} onChange={e => { if (e.target.checked) { update('plan_type', 'free'); update('price_monthly', 0); update('price', 0); } else { update('plan_type', 'paid'); } }} className="w-4 h-4 rounded border-slate-300 text-primary-600 focus:ring-primary-500" />
                  <span className="text-xs font-semibold text-slate-600">خطة مجانية</span>
                </label>
              </div>
            </div>

            {/* Section 2: Limits */}
            <div className="card p-4 space-y-3">
              <h3 className="font-bold text-sm text-slate-900">الحدود</h3>
              <div className="grid grid-cols-2 gap-3">
                {LIMIT_FIELDS.map(field => (
                  <div key={field.key} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-slate-600">{field.label}</label>
                      <button onClick={() => toggleLimitUnlimited(field.key)} className={`text-xs font-semibold transition-colors ${form[field.key] === null ? 'text-success-600' : 'text-slate-400'}`}>
                        {form[field.key] === null ? 'غير محدود ✓' : 'غير محدود'}
                      </button>
                    </div>
                    <input type="number" disabled={form[field.key] === null} value={form[field.key] ?? ''} onChange={e => update(field.key, parseInt(e.target.value) || 0)} className="input-field disabled:bg-slate-50 disabled:text-slate-300" placeholder={form[field.key] === null ? 'غير محدود' : '0'} />
                  </div>
                ))}
              </div>
            </div>

            {/* Section 3: Features */}
            <div className="card p-4 space-y-3">
              <h3 className="font-bold text-sm text-slate-900">المميزات</h3>
              <div className="space-y-4">
                {FEATURE_CATEGORIES.map(cat => {
                  const catFeatures = features.filter(f => f.category === cat.key && f.is_active);
                  if (catFeatures.length === 0) return null;
                  return (
                    <div key={cat.key}>
                      <p className="text-xs font-bold text-slate-500 mb-2">{cat.label}</p>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        {catFeatures.map(f => {
                          const checked = selectedFeatures.has(f.id);
                          return (
                            <button key={f.id} onClick={() => toggleFeature(f.id)} className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold transition-all border ${checked ? 'bg-primary-50 text-primary-700 border-primary-200' : 'bg-slate-50 text-slate-600 border-slate-100 hover:border-slate-200'}`}>
                              <span className={`w-4 h-4 rounded flex items-center justify-center border transition-colors ${checked ? 'bg-primary-600 border-primary-600' : 'border-slate-300'}`}>
                                {checked && <Check className="w-3 h-3 text-white" />}
                              </span>
                              {f.label_ar}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
              <button onClick={onAddFeature} className="mt-3 flex items-center gap-1.5 text-sm text-primary-600 hover:text-primary-700 font-semibold">
                <Plus className="w-4 h-4" /> إضافة ميزة جديدة
              </button>
            </div>

            {/* Enterprise notes */}
            {form.plan_type === 'enterprise' && (
              <div className="card p-4 space-y-3">
                <h3 className="font-bold text-sm text-slate-900">ملاحظات المؤسسات</h3>
                <textarea value={form.enterprise_notes ?? ''} onChange={e => update('enterprise_notes', e.target.value)} className="input-field min-h-[80px]" placeholder="يتم التواصل مع فريق المبيعات..." />
              </div>
            )}
          </div>

          <div className="flex items-center justify-between p-6 border-t border-slate-100 sticky bottom-0 bg-white rounded-b-2xl">
            <div className="text-sm text-slate-500">{selectedFeatures.size} ميزة مفعّلة</div>
            <div className="flex gap-2">
              <button onClick={onClose} className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-sm transition-all">إلغاء</button>
              <button onClick={() => onSave(form, Array.from(selectedFeatures))} disabled={saving || !form.plan_name} className="px-6 py-2.5 btn-primary text-sm flex items-center gap-1.5">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                {isCreating ? 'إنشاء' : 'حفظ'}
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
