import { useEffect, useState } from 'react';
import {
  ShieldCheck, Shield, CheckCircle, XCircle,
  RefreshCw, AlertTriangle, Lock, Unlock, Database,
  FileText, TrendingUp
} from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface TableSecurity {
  table_name: string;
  rls_enabled: boolean;
  policy_count: number;
}

interface SecurityIssue {
  severity: 'critical' | 'warning' | 'info';
  title: string;
  description: string;
  table?: string;
}

const EXPECTED_PROTECTED = [
  'restaurants', 'menu_categories', 'menu_items', 'customers', 'orders',
  'order_items', 'loyalty_rewards', 'loyalty_transactions', 'notifications',
  'analytics_snapshots', 'telegram_sessions', 'delivery_zones', 'loyalty_settings',
  'customer_points_wallet', 'reward_catalog', 'reward_redemptions', 'customer_tiers',
  'points_transactions', 'order_events', 'support_tickets', 'platform_settings',
  'announcements', 'admin_audit_logs', 'system_plans', 'platform_admins',
];

export default function SuperAdminSecurity() {
  const [tables, setTables] = useState<TableSecurity[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastScanned, setLastScanned] = useState<Date | null>(null);

  useEffect(() => { scan(); }, []);

  async function scan() {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('rls_coverage').select('*');
      if (error) throw error;
      setTables((data || []) as TableSecurity[]);
      setLastScanned(new Date());
    } catch (err) {
      console.error('Security scan error:', err);
    } finally {
      setLoading(false);
    }
  }

  const protectedTables = tables.filter(t => t.rls_enabled);
  const unprotectedTables = tables.filter(t => !t.rls_enabled);
  const totalPolicies = tables.reduce((s, t) => s + t.policy_count, 0);
  const tablesWithNoPolicies = tables.filter(t => t.rls_enabled && t.policy_count === 0);

  const issues: SecurityIssue[] = [
    ...unprotectedTables.map(t => ({
      severity: 'critical' as const,
      title: `RLS غير مفعّل: ${t.table_name}`,
      description: 'الجدول مكشوف لجميع المستخدمين بدون تحقق من الملكية.',
      table: t.table_name,
    })),
    ...tablesWithNoPolicies.map(t => ({
      severity: 'critical' as const,
      title: `بدون سياسات: ${t.table_name}`,
      description: 'RLS مفعّل لكن لا توجد سياسات — الجدول مقفل تماماً.',
      table: t.table_name,
    })),
    ...tables.filter(t => t.rls_enabled && t.policy_count < 4 && t.policy_count > 0 && !['telegram_sessions', 'platform_admins', 'rls_coverage'].includes(t.table_name)).map(t => ({
      severity: 'warning' as const,
      title: `سياسات ناقصة: ${t.table_name}`,
      description: `الجدول يحتوي على ${t.policy_count} سياسة فقط. يُنصح بـ 4 (SELECT/INSERT/UPDATE/DELETE).`,
      table: t.table_name,
    })),
  ];

  const criticalCount = issues.filter(i => i.severity === 'critical').length;
  const warningCount = issues.filter(i => i.severity === 'warning').length;

  const securityScore = Math.max(0, Math.round(
    100 - (criticalCount * 15) - (warningCount * 5)
  ));
  const isolationScore = tables.length > 0
    ? Math.round((protectedTables.length / Math.max(tables.length, 1)) * 100)
    : 100;
  const policyScore = EXPECTED_PROTECTED.length > 0
    ? Math.round((EXPECTED_PROTECTED.filter(t => tables.find(r => r.table_name === t && r.rls_enabled && r.policy_count > 0)).length / EXPECTED_PROTECTED.length) * 100)
    : 0;
  const saasScore = Math.round((securityScore + isolationScore + policyScore) / 3);

  function ScoreGauge({ label, score }: { label: string; score: number }) {
    const isGood = score >= 90;
    const isMedium = score >= 70;
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-5 text-center">
        <div className={`text-4xl font-black mb-1 ${isGood ? 'text-emerald-600' : isMedium ? 'text-amber-500' : 'text-red-600'}`}>
          {score}
        </div>
        <div className="text-xs text-slate-500 font-medium">{label}</div>
        <div className="mt-3 h-2 bg-slate-100 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-700 ${isGood ? 'bg-emerald-500' : isMedium ? 'bg-amber-400' : 'bg-red-500'}`}
            style={{ width: `${score}%` }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-7 h-7 text-emerald-600" />
            لوحة مراقبة الأمان
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            {lastScanned ? `آخر فحص: ${lastScanned.toLocaleTimeString('ar-EG')}` : 'لم يتم الفحص بعد'}
          </p>
        </div>
        <button
          onClick={scan}
          disabled={loading}
          className="flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          فحص الآن
        </button>
      </div>

      {/* Score Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <ScoreGauge label="درجة الأمان" score={securityScore} />
        <ScoreGauge label="عزل المستأجرين" score={isolationScore} />
        <ScoreGauge label="تغطية السياسات" score={policyScore} />
        <ScoreGauge label="جاهزية SaaS" score={saasScore} />
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="flex items-center gap-2 text-slate-500 text-xs mb-1"><Database className="w-3.5 h-3.5" /> إجمالي الجداول</div>
          <div className="text-2xl font-bold text-slate-900">{tables.length}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="flex items-center gap-2 text-emerald-600 text-xs mb-1"><Lock className="w-3.5 h-3.5" /> جداول محمية</div>
          <div className="text-2xl font-bold text-emerald-700">{protectedTables.length}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="flex items-center gap-2 text-red-500 text-xs mb-1"><Unlock className="w-3.5 h-3.5" /> غير محمية</div>
          <div className="text-2xl font-bold text-red-600">{unprotectedTables.length}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="flex items-center gap-2 text-slate-500 text-xs mb-1"><FileText className="w-3.5 h-3.5" /> إجمالي السياسات</div>
          <div className="text-2xl font-bold text-slate-900">{totalPolicies}</div>
        </div>
      </div>

      {/* Issues */}
      {issues.length > 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl">
          <div className="p-4 border-b border-slate-100 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            <h2 className="font-bold text-slate-800">المشكلات المكتشفة ({issues.length})</h2>
            <div className="mr-auto flex gap-2">
              {criticalCount > 0 && <span className="text-xs font-bold bg-red-100 text-red-700 px-2 py-0.5 rounded-md">{criticalCount} حرج</span>}
              {warningCount > 0 && <span className="text-xs font-bold bg-amber-100 text-amber-700 px-2 py-0.5 rounded-md">{warningCount} تحذير</span>}
            </div>
          </div>
          <div className="divide-y divide-slate-100">
            {issues.map((issue, i) => (
              <div key={i} className="flex items-start gap-3 p-4">
                {issue.severity === 'critical'
                  ? <XCircle className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
                  : <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5 flex-shrink-0" />
                }
                <div>
                  <div className="font-semibold text-sm text-slate-800">{issue.title}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{issue.description}</div>
                </div>
                <span className={`mr-auto text-[10px] font-bold px-2 py-0.5 rounded-md flex-shrink-0 ${
                  issue.severity === 'critical' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                }`}>
                  {issue.severity === 'critical' ? 'حرج' : 'تحذير'}
                </span>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-6 flex items-center gap-4">
          <CheckCircle className="w-10 h-10 text-emerald-500 flex-shrink-0" />
          <div>
            <div className="font-bold text-emerald-800">لا توجد مشكلات أمنية مكتشفة</div>
            <div className="text-sm text-emerald-600">جميع الجداول محمية بسياسات RLS صحيحة.</div>
          </div>
        </div>
      )}

      {/* Table Coverage */}
      <div className="bg-white border border-slate-200 rounded-xl">
        <div className="p-4 border-b border-slate-100 flex items-center gap-2">
          <Shield className="w-5 h-5 text-slate-500" />
          <h2 className="font-bold text-slate-800">تغطية الجداول</h2>
        </div>
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <RefreshCw className="w-6 h-6 text-slate-300 animate-spin" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-slate-500 border-b border-slate-100">
                  <th className="text-right px-4 py-3 font-medium">اسم الجدول</th>
                  <th className="text-center px-4 py-3 font-medium">RLS</th>
                  <th className="text-center px-4 py-3 font-medium">عدد السياسات</th>
                  <th className="text-center px-4 py-3 font-medium">الحالة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {tables.map(t => {
                  const isOk = t.rls_enabled && t.policy_count >= 2;
                  const isWarning = t.rls_enabled && t.policy_count === 1;
                  const isCritical = !t.rls_enabled || (t.rls_enabled && t.policy_count === 0);
                  return (
                    <tr key={t.table_name} className="hover:bg-slate-50">
                      <td className="px-4 py-3 font-mono text-slate-700 text-xs">{t.table_name}</td>
                      <td className="px-4 py-3 text-center">
                        {t.rls_enabled
                          ? <span className="inline-flex items-center gap-1 text-xs text-emerald-600 font-semibold"><CheckCircle className="w-3.5 h-3.5" /> مفعّل</span>
                          : <span className="inline-flex items-center gap-1 text-xs text-red-600 font-semibold"><XCircle className="w-3.5 h-3.5" /> معطّل</span>
                        }
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`font-bold text-xs ${t.policy_count >= 4 ? 'text-emerald-600' : t.policy_count >= 2 ? 'text-amber-600' : 'text-red-600'}`}>
                          {t.policy_count}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        {isOk && <span className="text-[10px] bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-md font-bold">آمن</span>}
                        {isWarning && <span className="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-md font-bold">تحذير</span>}
                        {isCritical && <span className="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded-md font-bold">حرج</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Architecture Notes */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-3">
        <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
          <TrendingUp className="w-4 h-4" />
          ملخص البنية الأمنية
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-600">
          <div className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 flex-shrink-0" /><span>جميع الاستعلامات في الواجهة الأمامية تستخدم <code className="bg-slate-200 px-1 rounded">restaurant_id</code> الخاص بالمستأجر</span></div>
          <div className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 flex-shrink-0" /><span>سياسات RLS تستخدم <code className="bg-slate-200 px-1 rounded">auth.uid() = owner_id</code> لضمان العزل</span></div>
          <div className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 flex-shrink-0" /><span>Edge Functions تستخدم <code className="bg-slate-200 px-1 rounded">service_role</code> مع تحقق يدوي من الملكية</span></div>
          <div className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 flex-shrink-0" /><span>صلاحيات المدير المنصة تعتمد على جدول <code className="bg-slate-200 px-1 rounded">platform_admins</code> في قاعدة البيانات</span></div>
          <div className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 flex-shrink-0" /><span>Telegram sessions مقيّدة بـ service_role فقط</span></div>
          <div className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 flex-shrink-0" /><span>Realtime subscriptions تفلتر على <code className="bg-slate-200 px-1 rounded">restaurant_id=eq.{'{id}'}</code></span></div>
        </div>
      </div>
    </div>
  );
}
