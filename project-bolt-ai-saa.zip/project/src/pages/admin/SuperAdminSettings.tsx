import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Settings, Save, Loader2, CheckCircle, Globe, Mail,
  Zap
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import type { PlatformSetting } from '../../lib/database.types';

interface SettingForm {
  platform_name: string;
  support_email: string;
  support_whatsapp: string;
  trial_duration_days: string;
  trial_order_limit: string;
}

export default function SuperAdminSettings() {
  const { user } = useAuth();
  const [settings, setSettings] = useState<PlatformSetting[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const [form, setForm] = useState<SettingForm>({
    platform_name: 'RestroBot',
    support_email: '',
    support_whatsapp: '',
    trial_duration_days: '14',
    trial_order_limit: '50',
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  async function fetchSettings() {
    setLoading(true);
    const { data } = await supabase.from('platform_settings').select('*');
    if (data) {
      setSettings(data as PlatformSetting[]);
      const map: Record<string, string> = {};
      (data as PlatformSetting[]).forEach((s: PlatformSetting) => { map[s.key] = s.value; });
      setForm({
        platform_name: map.platform_name || 'RestroBot',
        support_email: map.support_email || '',
        support_whatsapp: map.support_whatsapp || '',
        trial_duration_days: map.trial_duration_days || '14',
        trial_order_limit: map.trial_order_limit || '50',
      });
    }
    setLoading(false);
  }

  async function handleSave() {
    setSaving(true);
    const entries = [
      { key: 'platform_name', value: form.platform_name, description: 'اسم المنصة' },
      { key: 'support_email', value: form.support_email, description: 'بريد الدعم' },
      { key: 'support_whatsapp', value: form.support_whatsapp, description: 'رقم واتساب الدعم' },
      { key: 'trial_duration_days', value: form.trial_duration_days, description: 'مدة التجربة بالأيام' },
      { key: 'trial_order_limit', value: form.trial_order_limit, description: 'حد الطلبات في التجربة' },
    ];

    for (const entry of entries) {
      const existing = settings.find(s => s.key === entry.key);
      if (existing) {
        await supabase.from('platform_settings').update({ value: entry.value }).eq('id', existing.id);
      } else {
        await supabase.from('platform_settings').insert(entry);
      }
    }

    await supabase.from('admin_audit_logs').insert({
      admin_id: user?.id,
      admin_email: user?.email,
      action: 'update_setting',
      target_type: 'platform_settings',
      target_id: 'global',
      target_name: 'Platform Settings',
      details: form,
    });

    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
    fetchSettings();
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96" dir="rtl">
        <div className="w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6" dir="rtl">
      <div className="flex items-center gap-2">
        <Settings className="w-5 h-5 text-primary-600" />
        <h2 className="text-lg font-bold text-slate-900">الإعدادات العامة</h2>
      </div>

      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card p-6 space-y-5">
        {/* Platform Identity */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
            <Globe className="w-4 h-4 text-primary-600" />
            هوية المنصة
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1.5">اسم المنصة</label>
            <input value={form.platform_name} onChange={e => setForm(p => ({ ...p, platform_name: e.target.value }))} className="input-field" />
          </div>
        </div>

        {/* Support */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
            <Mail className="w-4 h-4 text-primary-600" />
            معلومات الدعم
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">بريد الدعم</label>
              <input type="email" value={form.support_email} onChange={e => setForm(p => ({ ...p, support_email: e.target.value }))} className="input-field" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">واتساب الدعم</label>
              <input value={form.support_whatsapp} onChange={e => setForm(p => ({ ...p, support_whatsapp: e.target.value }))} placeholder="مثال: +20123456789" className="input-field" />
            </div>
          </div>
        </div>

        {/* Trial */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
            <Zap className="w-4 h-4 text-warning-600" />
            إعدادات التجربة
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">مدة التجربة (أيام)</label>
              <input type="number" min={1} value={form.trial_duration_days} onChange={e => setForm(p => ({ ...p, trial_duration_days: e.target.value }))} className="input-field" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">حد الطلبات في التجربة</label>
              <input type="number" min={1} value={form.trial_order_limit} onChange={e => setForm(p => ({ ...p, trial_order_limit: e.target.value }))} className="input-field" />
            </div>
          </div>
        </div>
      </motion.div>

      <div className="flex items-center gap-4 pb-4">
        <button onClick={handleSave} disabled={saving} className="btn-primary">
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {saving ? 'جارٍ الحفظ...' : 'حفظ الإعدادات'}
        </button>
        {saved && (
          <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} className="flex items-center gap-2 text-success-600 text-sm font-semibold">
            <CheckCircle className="w-4 h-4" /> تم الحفظ
          </motion.div>
        )}
      </div>
    </div>
  );
}
