import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Store, Clock, CheckCircle, Ban, Calendar, Search,
  RefreshCw, CreditCard, Eye, Loader2, XCircle, DollarSign, ArrowRight, MessageSquare,
  Trash2, FileText, X
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { deleteReceipt as deleteReceiptFromStorage } from '../../lib/receiptUpload';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import type { SystemPlan, RestaurantSubscription, SubscriptionRequest } from '../../lib/database.types';

interface RestaurantWithSub {
  id: string;
  name: string;
  email?: string;
  owner_id: string;
  created_at: string;
  subscription_plan: string;
  subscription_expires_at: string | null;
  is_suspended: boolean;
  is_active: boolean;
  has_used_trial: boolean;
  subscription?: RestaurantSubscription;
}

interface EnrichedRequest extends SubscriptionRequest {
  restaurant_name?: string;
  plan_name?: string;
}

interface SubStats {
  total: number;
  active: number;
  expired: number;
  pendingPayment: number;
  suspended: number;
  revenue: number;
}

export default function SuperAdminSubscriptions() {
  const { user } = useAdminAuth();
  const [restaurants, setRestaurants] = useState<RestaurantWithSub[]>([]);
  const [subRequests, setSubRequests] = useState<EnrichedRequest[]>([]);
  const [plans, setPlans] = useState<SystemPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'restaurants' | 'requests'>('overview');
  const [search, setSearch] = useState('');
  const [stats, setStats] = useState<SubStats>({ total: 0, active: 0, expired: 0, pendingPayment: 0, suspended: 0, revenue: 0 });
  const [selectedRestaurant, setSelectedRestaurant] = useState<RestaurantWithSub | null>(null);
  const [selectedRequest, setSelectedRequest] = useState<EnrichedRequest | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [renewPlanId, setRenewPlanId] = useState('');
  const [adminNotes, setAdminNotes] = useState('');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      // Batch all independent queries in parallel
      const [
        { data: plansData },
        { data: restaurantsData, error },
        { data: subs },
        { data: reqData },
      ] = await Promise.all([
        supabase.from('system_plans').select('*').order('sort_order', { ascending: true }),
        supabase.from('restaurants').select('id, name, email, created_at, subscription_plan, subscription_expires_at, is_suspended, is_active, has_used_trial, owner_id').order('created_at', { ascending: false }),
        supabase.from('restaurant_subscriptions').select('*').order('created_at', { ascending: false }),
        supabase.from('subscription_requests').select('*').order('created_at', { ascending: false }),
      ]);

      const plansList = (plansData ?? []) as SystemPlan[];
      setPlans(plansList);

      if (!error && restaurantsData) {
        const restaurantsWithSubs = restaurantsData.map(r => ({
          ...r,
          subscription: (subs ?? []).find((s: any) => s.restaurant_id === r.id),
        })) as RestaurantWithSub[];
        setRestaurants(restaurantsWithSubs);

        // Compute stats client-side from real data
        const now = new Date();
        let activeRevenue = 0;
        let activeCount = 0;
        let expiredCount = 0;
        let pendingCount = 0;
        const seenActive = new Set<string>();
        const seenExpired = new Set<string>();

        for (const r of restaurantsWithSubs) {
          const sub = r.subscription;
          if (!sub) continue;

          if (sub.status === 'active' && sub.payment_status === 'approved' && new Date(sub.expires_at) > now) {
            if (!seenActive.has(r.id)) {
              seenActive.add(r.id);
              activeCount++;
              const plan = plansList.find(p => p.id === sub.plan_id);
              if (plan && !plan.is_trial) activeRevenue += plan.price_monthly;
            }
          } else if (sub.payment_status === 'approved' && new Date(sub.expires_at) <= now && !plan_is_trial(sub.plan_id, plansList)) {
            if (!seenExpired.has(r.id)) {
              seenExpired.add(r.id);
              expiredCount++;
            }
          } else if (sub.status === 'pending_payment') {
            pendingCount++;
          }
        }

        setStats({
          total: restaurantsData.length,
          active: activeCount,
          expired: expiredCount,
          pendingPayment: pendingCount,
          suspended: restaurantsWithSubs.filter(r => r.is_suspended).length,
          revenue: activeRevenue,
        });
      }

      // Enrich requests with restaurant names — batch fetch instead of N+1
      if (reqData) {
        const reqs = reqData as SubscriptionRequest[];
        const restaurantIds = [...new Set(reqs.map(r => r.restaurant_id))];

        let nameMap = new Map<string, string>();
        if (restaurantIds.length > 0) {
          const { data: restNames } = await supabase
            .from('restaurants')
            .select('id, name')
            .in('id', restaurantIds);
          nameMap = new Map((restNames || []).map(r => [r.id, r.name]));
        }

        const enriched: EnrichedRequest[] = reqs.map(req => ({
          ...req,
          restaurant_name: nameMap.get(req.restaurant_id) || 'غير معروف',
          plan_name: plansList.find(p => p.id === req.plan_id)?.name_ar
            || plansList.find(p => p.id === req.plan_id)?.plan_name
            || 'غير معروف',
        }));
        setSubRequests(enriched);
      }
    } catch (err) {
      console.error('Subscriptions fetch error:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  // Helper: check if a plan is trial
  function plan_is_trial(planId: string, plansList: SystemPlan[]): boolean {
    return plansList.find(p => p.id === planId)?.is_trial ?? false;
  }

  async function handleApproveRequest(req: EnrichedRequest) {
    if (!confirm('تأكيد الموافقة على طلب الاشتراك؟')) return;
    setActionLoading(req.id);
    try {
      const plan = plans.find(p => p.id === req.plan_id);
      if (!plan) { alert('الباقة غير موجودة'); return; }

      // Prevent duplicate approval — check current status
      const { data: currentReq } = await supabase
        .from('subscription_requests')
        .select('status')
        .eq('id', req.id)
        .maybeSingle();

      if (currentReq?.status !== 'pending') {
        alert('هذا الطلب تمت معالجته بالفعل');
        return;
      }

      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + plan.duration_days);

      // Update request status
      const { error: reqError } = await supabase.from('subscription_requests').update({
        status: 'approved', reviewed_by: user?.id ?? null, reviewed_at: new Date().toISOString(),
      }).eq('id', req.id).eq('status', 'pending');

      if (reqError) {
        alert('فشل تحديث الطلب: ' + reqError.message);
        return;
      }

      // Update subscription
      await supabase.from('restaurant_subscriptions').update({
        status: 'active', payment_status: 'approved', expires_at: expiresAt.toISOString(),
        admin_notes: adminNotes || null,
      }).eq('restaurant_id', req.restaurant_id).eq('plan_id', req.plan_id).eq('status', 'pending_payment');

      // Update restaurant
      await supabase.from('restaurants').update({
        is_active: true, is_suspended: false,
        subscription_plan: plan.plan_name.toLowerCase(),
        subscription_expires_at: expiresAt.toISOString(),
      }).eq('id', req.restaurant_id);

      // Log to history
      await supabase.from('subscription_history').insert({
        restaurant_id: req.restaurant_id, plan_id: plan.id, action: 'approved',
        new_status: 'active', notes: adminNotes || null, performed_by: user?.id ?? null,
      });

      setAdminNotes('');
      setSelectedRequest(null);
      await fetchData();
    } catch (err: any) {
      alert('فشل الموافقة: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  }

  async function handleRejectRequest(req: EnrichedRequest) {
    if (!confirm('تأكيد رفض طلب الاشتراك؟')) return;
    setActionLoading(req.id);
    try {
      // Prevent duplicate rejection — check current status
      const { data: currentReq } = await supabase
        .from('subscription_requests')
        .select('status')
        .eq('id', req.id)
        .maybeSingle();

      if (currentReq?.status !== 'pending') {
        alert('هذا الطلب تمت معالجته بالفعل');
        return;
      }

      const { error: reqError } = await supabase.from('subscription_requests').update({
        status: 'rejected', reviewed_by: user?.id ?? null, reviewed_at: new Date().toISOString(),
        rejection_reason: adminNotes || null,
      }).eq('id', req.id).eq('status', 'pending');

      if (reqError) {
        alert('فشل رفض الطلب: ' + reqError.message);
        return;
      }

      await supabase.from('restaurant_subscriptions').update({
        payment_status: 'rejected', status: 'cancelled', admin_notes: adminNotes || null,
      }).eq('restaurant_id', req.restaurant_id).eq('plan_id', req.plan_id).eq('status', 'pending_payment');

      await supabase.from('subscription_history').insert({
        restaurant_id: req.restaurant_id, plan_id: req.plan_id, action: 'rejected',
        new_status: 'cancelled', notes: adminNotes || null, performed_by: user?.id ?? null,
      });

      setAdminNotes('');
      setSelectedRequest(null);
      await fetchData();
    } catch (err: any) {
      alert('فشل الرفض: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  }

  async function handleExtendSubscription() {
    if (!selectedRestaurant || !renewPlanId) return;
    setActionLoading(selectedRestaurant.id);
    try {
      const plan = plans.find(p => p.id === renewPlanId);
      if (!plan) { setActionLoading(null); return; }

      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + plan.duration_days);

      await supabase.from('restaurant_subscriptions').insert({
        restaurant_id: selectedRestaurant.id, plan_id: plan.id, billing_cycle: 'monthly',
        status: 'active', starts_at: new Date().toISOString(), expires_at: expiresAt.toISOString(),
        payment_status: 'approved', trial_used: selectedRestaurant.has_used_trial,
      });

      await supabase.from('restaurants').update({
        is_active: true, is_suspended: false,
        subscription_plan: plan.plan_name.toLowerCase(),
        subscription_expires_at: expiresAt.toISOString(),
      }).eq('id', selectedRestaurant.id);

      await supabase.from('subscription_history').insert({
        restaurant_id: selectedRestaurant.id, plan_id: plan.id, action: 'renewed',
        new_status: 'active', notes: adminNotes || null, performed_by: user?.id ?? null,
      });

      setSelectedRestaurant(null);
      setRenewPlanId('');
      setAdminNotes('');
      await fetchData();
    } catch (err: any) {
      alert('فشل التجديد: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  }

  async function handleToggleSuspension(restaurant: RestaurantWithSub) {
    setActionLoading(restaurant.id);
    try {
      await supabase.from('restaurants').update({ is_suspended: !restaurant.is_suspended }).eq('id', restaurant.id);
      await fetchData();
    } catch (err: any) {
      alert('فشل تغيير حالة الإيقاف: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  }

  async function handleDeleteReceipt(req: EnrichedRequest) {
    if (!confirm('هل أنت متأكد من حذف هذا الإيصال؟ سيتم حذف الملف نهائياً.')) return;
    setActionLoading(req.id);
    try {
      // Extract storage path from public URL
      const url = req.payment_proof_url;
      if (!url) { alert('لا يوجد إيصال'); return; }

      // Try to delete from storage — extract path after /payment-receipts/
      const pathMatch = url.match(/\/payment-receipts\/(.+)$/);
      if (pathMatch) {
        await supabase.storage.from('payment-receipts').remove([pathMatch[1]]);
      }

      // Also try receipts bucket (alternate name)
      const pathMatch2 = url.match(/\/receipts\/(.+)$/);
      if (pathMatch2) {
        await supabase.storage.from('receipts').remove([pathMatch2[1]]);
      }

      // Clear the database reference
      await supabase.from('subscription_requests')
        .update({ payment_proof_url: null })
        .eq('id', req.id);

      await fetchData();
    } catch (err: any) {
      alert('فشل حذف الإيصال: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  }

  const filteredRestaurants = restaurants.filter(r =>
    r.name.includes(search) || r.email?.includes(search) || r.owner_id?.includes(search)
  );

  function getSubscriptionStatus(restaurant: RestaurantWithSub) {
    const sub = restaurant.subscription;
    if (!sub) return { text: 'غير مشترك', color: 'badge-neutral' };
    if (sub.status === 'suspended') return { text: 'موقوف', color: 'badge-danger' };
    if (sub.status === 'pending_payment') return { text: 'بانتظار الدفع', color: 'badge-warning' };
    if (sub.status === 'cancelled') return { text: 'ملغي', color: 'badge-danger' };
    if (sub.status === 'active' && new Date(sub.expires_at) > new Date()) return { text: 'نشط', color: 'badge-success' };
    if (sub.status === 'expired' || new Date(sub.expires_at) <= new Date()) return { text: 'منتهي', color: 'badge-danger' };
    return { text: sub.status, color: 'badge-neutral' };
  }

  return (
    <div className="space-y-5" dir="rtl">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-bold text-slate-900">إدارة الاشتراكات</h1>
        <button onClick={fetchData} disabled={loading} className="btn-secondary text-sm">
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> تحديث
        </button>
      </div>

      <div className="flex bg-white rounded-xl p-1 border border-slate-200">
        {([['overview', 'نظرة عامة'], ['restaurants', 'المطاعم'], ['requests', 'طلبات الاشتراك']] as const).map(([key, label]) => (
          <button key={key} onClick={() => setActiveTab(key)}
            className={`px-5 py-2 rounded-lg text-sm font-semibold transition ${activeTab === key ? 'bg-primary-600 text-white' : 'text-slate-600 hover:bg-slate-50'}`}>
            {label}
            {key === 'requests' && subRequests.filter(r => r.status === 'pending').length > 0 && (
              <span className="mr-1 bg-danger-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                {subRequests.filter(r => r.status === 'pending').length}
              </span>
            )}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              { icon: Store, label: 'إجمالي المطاعم', value: stats.total, color: 'bg-slate-800' },
              { icon: CheckCircle, label: 'نشطة', value: stats.active, color: 'bg-success-500' },
              { icon: Clock, label: 'منتهية', value: stats.expired, color: 'bg-warning-500' },
              { icon: CreditCard, label: 'بانتظار الدفع', value: stats.pendingPayment, color: 'bg-primary-600' },
              { icon: Ban, label: 'موقوفة', value: stats.suspended, color: 'bg-danger-500' },
              { icon: DollarSign, label: 'الإيرادات الشهرية', value: `${stats.revenue} ج.م`, color: 'bg-amber-500' },
            ].map((s, i) => (
              <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="card p-4">
                <div className={`w-9 h-9 ${s.color} rounded-xl flex items-center justify-center mb-3`}>
                  <s.icon className="w-4.5 h-4.5 text-white" />
                </div>
                <p className="text-slate-500 text-xs font-medium">{s.label}</p>
                <p className="text-xl font-bold text-slate-900 mt-1">{s.value}</p>
              </motion.div>
            ))}
          </div>

          <div className="card overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900">آخر طلبات الاشتراك</h2>
              <button onClick={() => setActiveTab('requests')} className="text-sm text-primary-600 hover:text-primary-700 font-medium">
                عرض الكل <ArrowRight className="w-4 h-4 inline rotate-180" />
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">المطعم</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">الباقة</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">المبلغ</th>
                    <th className="px-4 py-3 text-center text-xs font-bold text-slate-700">الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {subRequests.slice(0, 5).map(req => (
                    <tr key={req.id} className="border-b border-slate-50 hover:bg-slate-50 cursor-pointer" onClick={() => setSelectedRequest(req)}>
                      <td className="px-4 py-3 font-medium text-slate-900">{req.restaurant_name}</td>
                      <td className="px-4 py-3 text-slate-600">{req.plan_name}</td>
                      <td className="px-4 py-3 text-slate-600">{req.amount} ج.م</td>
                      <td className="px-4 py-3 text-center">
                        {req.status === 'approved' && <span className="badge badge-success">تمت الموافقة</span>}
                        {req.status === 'rejected' && <span className="badge badge-danger">مرفوض</span>}
                        {req.status === 'pending' && <span className="badge badge-warning">قيد المراجعة</span>}
                      </td>
                    </tr>
                  ))}
                  {subRequests.length === 0 && <tr><td colSpan={4} className="px-4 py-8 text-center text-slate-400">لا توجد طلبات</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {activeTab === 'restaurants' && (
        <>
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="ابحث بالاسم أو البريد..." className="input-field pr-10" />
          </div>

          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 border-b border-slate-100">
                  <tr>
                    <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">المطعم</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">البريد</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">الباقة</th>
                    <th className="px-4 py-3 text-center text-xs font-bold text-slate-700">الحالة</th>
                    <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">الانتهاء</th>
                    <th className="px-4 py-3 text-center text-xs font-bold text-slate-700">إجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredRestaurants.map((r, idx) => {
                    const status = getSubscriptionStatus(r);
                    const plan = r.subscription ? plans.find(p => p.id === r.subscription?.plan_id) : null;
                    return (
                      <motion.tr key={r.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: idx * 0.02 }} className="border-b border-slate-50 hover:bg-slate-50">
                        <td className="px-4 py-3">
                          <div className="font-semibold text-slate-900">{r.name}</div>
                          <div className="text-xs text-slate-400">{r.owner_id?.slice(0, 8)}...</div>
                        </td>
                        <td className="px-4 py-3 text-xs text-slate-500">{r.email || '-'}</td>
                        <td className="px-4 py-3">
                          {plan ? <span className="badge badge-primary">{plan.name_ar || plan.plan_name}</span> : <span className="text-xs text-slate-400">غير مشترك</span>}
                        </td>
                        <td className="px-4 py-3 text-center"><span className={`badge ${status.color}`}>{status.text}</span></td>
                        <td className="px-4 py-3 text-xs text-slate-500">{r.subscription?.expires_at ? new Date(r.subscription.expires_at).toLocaleDateString('ar-EG') : '-'}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center justify-center gap-1.5">
                            <button onClick={() => setSelectedRestaurant(r)} className="p-2 bg-primary-50 hover:bg-primary-100 text-primary-600 rounded-lg transition-colors" title="تجديد/تغيير الباقة">
                              <Calendar className="w-4 h-4" />
                            </button>
                            <button onClick={() => handleToggleSuspension(r)} disabled={actionLoading === r.id}
                              className={`p-2 rounded-lg transition-colors disabled:opacity-50 ${r.is_suspended ? 'bg-success-50 hover:bg-success-100 text-success-600' : 'bg-danger-50 hover:bg-danger-100 text-danger-600'}`}
                              title={r.is_suspended ? 'إلغاء الإيقاف' : 'إيقاف'}>
                              {actionLoading === r.id ? <Loader2 className="w-4 h-4 animate-spin" /> : r.is_suspended ? <CheckCircle className="w-4 h-4" /> : <Ban className="w-4 h-4" />}
                            </button>
                          </div>
                        </td>
                      </motion.tr>
                    );
                  })}
                  {filteredRestaurants.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400">لا توجد نتائج</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {activeTab === 'requests' && (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">المطعم</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">الباقة</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">المبلغ</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">التاريخ</th>
                  <th className="px-4 py-3 text-center text-xs font-bold text-slate-700">الحالة</th>
                  <th className="px-4 py-3 text-center text-xs font-bold text-slate-700">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {subRequests.map((req, idx) => (
                  <motion.tr key={req.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: idx * 0.02 }} className="border-b border-slate-50 hover:bg-slate-50">
                    <td className="px-4 py-3 font-medium text-slate-900">{req.restaurant_name}</td>
                    <td className="px-4 py-3 text-slate-600">{req.plan_name}</td>
                    <td className="px-4 py-3 text-slate-600">{req.amount} {req.currency}</td>
                    <td className="px-4 py-3 text-xs text-slate-500">{new Date(req.created_at).toLocaleDateString('ar-EG')}</td>
                    <td className="px-4 py-3 text-center">
                      {req.status === 'approved' && <span className="badge badge-success"><CheckCircle className="w-3 h-3 mr-1" />تمت الموافقة</span>}
                      {req.status === 'rejected' && <span className="badge badge-danger"><XCircle className="w-3 h-3 mr-1" />مرفوض</span>}
                      {req.status === 'pending' && <span className="badge badge-warning"><Clock className="w-3 h-3 mr-1" />قيد المراجعة</span>}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1.5">
                        {/* View details button */}
                        <button onClick={() => setSelectedRequest(req)} className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-lg transition-colors" title="عرض التفاصيل">
                          <FileText className="w-4 h-4" />
                        </button>
                        {req.payment_proof_url && (
                          <>
                            <a href={req.payment_proof_url} target="_blank" rel="noopener noreferrer" className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-lg transition-colors" title="عرض الإيصال">
                              <Eye className="w-4 h-4" />
                            </a>
                            <button onClick={() => handleDeleteReceipt(req)} disabled={actionLoading === req.id} className="p-2 bg-danger-50 hover:bg-danger-100 text-danger-600 rounded-lg transition-colors disabled:opacity-50" title="حذف الإيصال">
                              {actionLoading === req.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                            </button>
                          </>
                        )}
                        {req.status === 'pending' && (
                          <>
                            <button onClick={() => handleApproveRequest(req)} disabled={actionLoading === req.id} className="p-2 bg-success-50 hover:bg-success-100 text-success-600 rounded-lg transition-colors disabled:opacity-50" title="موافقة">
                              {actionLoading === req.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                            </button>
                            <button onClick={() => handleRejectRequest(req)} disabled={actionLoading === req.id} className="p-2 bg-danger-50 hover:bg-danger-100 text-danger-600 rounded-lg transition-colors disabled:opacity-50" title="رفض">
                              {actionLoading === req.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />}
                            </button>
                          </>
                        )}
                        {req.notes && (
                          <div className="relative group">
                            <MessageSquare className="w-4 h-4 text-slate-400" />
                            <div className="absolute bottom-full right-0 mb-2 w-48 bg-slate-800 text-white text-xs p-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">{req.notes}</div>
                          </div>
                        )}
                      </div>
                    </td>
                  </motion.tr>
                ))}
                {subRequests.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400">لا توجد طلبات اشتراك</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Request Detail Modal */}
      <AnimatePresence>
        {selectedRequest && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedRequest(null)}
            dir="rtl"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-white rounded-2xl w-full max-w-lg shadow-modal max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between p-5 border-b border-slate-100">
                <h3 className="text-lg font-bold text-slate-900">تفاصيل طلب الاشتراك</h3>
                <button onClick={() => setSelectedRequest(null)} className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors">
                  <X className="w-5 h-5 text-slate-500" />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-slate-400 font-medium mb-1">المطعم</p>
                    <p className="text-sm font-semibold text-slate-900">{selectedRequest.restaurant_name}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 font-medium mb-1">الباقة</p>
                    <p className="text-sm font-semibold text-slate-900">{selectedRequest.plan_name}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 font-medium mb-1">المبلغ</p>
                    <p className="text-sm font-semibold text-slate-900">{selectedRequest.amount} {selectedRequest.currency}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 font-medium mb-1">التاريخ</p>
                    <p className="text-sm font-semibold text-slate-900">{new Date(selectedRequest.created_at).toLocaleDateString('ar-EG')}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 font-medium mb-1">الحالة</p>
                    {selectedRequest.status === 'approved' && <span className="badge badge-success">تمت الموافقة</span>}
                    {selectedRequest.status === 'rejected' && <span className="badge badge-danger">مرفوض</span>}
                    {selectedRequest.status === 'pending' && <span className="badge badge-warning">قيد المراجعة</span>}
                  </div>
                </div>

                {/* Receipt image */}
                {selectedRequest.payment_proof_url && (
                  <div>
                    <p className="text-xs text-slate-400 font-medium mb-2">إيصال الدفع</p>
                    <a href={selectedRequest.payment_proof_url} target="_blank" rel="noopener noreferrer" className="block">
                      <img
                        src={selectedRequest.payment_proof_url}
                        alt="إيصال الدفع"
                        className="w-full max-h-64 object-contain rounded-xl border border-slate-200 bg-slate-50"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = 'none';
                          const fallback = document.createElement('div');
                          fallback.className = 'flex items-center justify-center p-8 text-slate-400 text-sm';
                          fallback.textContent = 'ملف غير مدعوم — اضغط للفتح في نافذة جديدة';
                          (e.target as HTMLImageElement).parentElement?.appendChild(fallback);
                        }}
                      />
                    </a>
                  </div>
                )}

                {/* Notes */}
                {selectedRequest.notes && (
                  <div>
                    <p className="text-xs text-slate-400 font-medium mb-1">ملاحظات المطعم</p>
                    <p className="text-sm text-slate-600 bg-slate-50 rounded-xl p-3">{selectedRequest.notes}</p>
                  </div>
                )}

                {/* Admin notes input (only for pending) */}
                {selectedRequest.status === 'pending' && (
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">ملاحظات الأدمن (اختياري)</label>
                    <textarea
                      value={adminNotes}
                      onChange={e => setAdminNotes(e.target.value)}
                      placeholder="أي ملاحظات إدارية..."
                      className="input-field min-h-[60px]"
                    />
                  </div>
                )}

                {/* Actions */}
                {selectedRequest.status === 'pending' && (
                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={() => handleApproveRequest(selectedRequest)}
                      disabled={actionLoading === selectedRequest.id}
                      className="flex-1 py-2.5 bg-success-600 hover:bg-success-700 text-white rounded-xl text-sm font-semibold transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {actionLoading === selectedRequest.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                      موافقة
                    </button>
                    <button
                      onClick={() => handleRejectRequest(selectedRequest)}
                      disabled={actionLoading === selectedRequest.id}
                      className="flex-1 py-2.5 bg-danger-600 hover:bg-danger-700 text-white rounded-xl text-sm font-semibold transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {actionLoading === selectedRequest.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />}
                      رفض
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Renew Subscription Modal */}
      {selectedRestaurant && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setSelectedRestaurant(null)}>
          <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} onClick={e => e.stopPropagation()} className="bg-white rounded-2xl p-6 w-full max-w-md shadow-modal">
            <h3 className="text-lg font-bold text-slate-900 mb-4">تجديد/تغيير الاشتراك</h3>
            <p className="text-sm text-slate-500 mb-4">المطعم: <span className="font-semibold text-slate-900">{selectedRestaurant.name}</span></p>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-1">اختر الباقة</label>
                <select value={renewPlanId} onChange={e => setRenewPlanId(e.target.value)} className="input-field">
                  <option value="">-- اختر باقة --</option>
                  {plans.filter(p => !p.is_trial).map(p => <option key={p.id} value={p.id}>{p.name_ar || p.plan_name} - {p.price_monthly} ج.م/شهر</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-1">ملاحظات (اختياري)</label>
                <textarea value={adminNotes} onChange={e => setAdminNotes(e.target.value)} placeholder="أي ملاحظات..." className="input-field min-h-[60px]" />
              </div>
              <div className="flex gap-2 pt-2">
                <button onClick={() => setSelectedRestaurant(null)} className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-sm font-semibold transition-colors">إلغاء</button>
                <button onClick={handleExtendSubscription} disabled={actionLoading === selectedRestaurant.id || !renewPlanId} className="flex-1 py-2.5 btn-primary text-sm">
                  {actionLoading === selectedRestaurant.id ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'تأكيد'}
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
