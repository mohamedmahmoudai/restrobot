import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  MessageSquare, Search, CheckCircle, Clock,
  Send, Tag, Loader2, X, Reply
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import type { SupportTicket } from '../../lib/database.types';

export default function SuperAdminSupport() {
  const { user } = useAuth();
  const [tickets, setTickets] = useState<(SupportTicket & { restaurant_name?: string })[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'open' | 'in_progress' | 'closed'>('all');
  const [filterType, setFilterType] = useState<'all' | 'problem' | 'feature_request' | 'bug_report'>('all');
  const [selectedTicket, setSelectedTicket] = useState<(SupportTicket & { restaurant_name?: string }) | null>(null);
  const [replyText, setReplyText] = useState('');
  const [sending, setSending] = useState(false);

  useEffect(() => {
    fetchTickets();
  }, []);

  async function fetchTickets() {
    setLoading(true);
    const { data, error } = await supabase
      .from('support_tickets')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      const enriched = await Promise.all((data as SupportTicket[]).map(async (t) => {
        const { data: r } = await supabase.from('restaurants').select('name').eq('id', t.restaurant_id).maybeSingle();
        return { ...t, restaurant_name: r?.name || 'غير معروف' };
      }));
      setTickets(enriched);
    }
    setLoading(false);
  }

  async function handleReply() {
    if (!selectedTicket || !replyText.trim()) return;
    setSending(true);

    await supabase.from('support_tickets').update({
      admin_reply: replyText.trim(),
      status: 'in_progress',
      replied_at: new Date().toISOString(),
      replied_by: user?.id,
      updated_at: new Date().toISOString(),
    }).eq('id', selectedTicket.id);

    await logAction('reply_ticket', 'support_ticket', selectedTicket.id, selectedTicket.subject, { reply: replyText.trim() });

    setReplyText('');
    setSending(false);
    await fetchTickets();
    const updated = tickets.find(t => t.id === selectedTicket.id);
    if (updated) setSelectedTicket({ ...updated, admin_reply: replyText.trim(), status: 'in_progress' });
  }

  async function handleStatusChange(ticketId: string, newStatus: string) {
    await supabase.from('support_tickets').update({ status: newStatus, updated_at: new Date().toISOString() }).eq('id', ticketId);
    await logAction('change_ticket_status', 'support_ticket', ticketId, '', { status: newStatus });
    await fetchTickets();
  }

  async function logAction(action: string, targetType: string, targetId: string, targetName: string, details: object) {
    await supabase.from('admin_audit_logs').insert({
      admin_id: user?.id,
      admin_email: user?.email,
      action,
      target_type: targetType,
      target_id: targetId,
      target_name: targetName,
      details,
    });
  }

  const filtered = tickets.filter(t => {
    const matchSearch = t.subject.includes(search) || t.body.includes(search) || (t.restaurant_name?.includes(search) ?? false);
    const matchStatus = filterStatus === 'all' || t.status === filterStatus;
    const matchType = filterType === 'all' || t.type === filterType;
    return matchSearch && matchStatus && matchType;
  });

  const typeLabels: Record<string, string> = { problem: 'مشكلة', feature_request: 'طلب ميزة', bug_report: 'بلاغ خطأ' };
  const typeColors: Record<string, string> = { problem: 'bg-danger-50 text-danger-700', feature_request: 'bg-primary-50 text-primary-700', bug_report: 'bg-warning-50 text-warning-700' };
  const statusLabels: Record<string, string> = { open: 'مفتوح', in_progress: 'قيد المعالجة', closed: 'مغلق' };
  const statusColors: Record<string, string> = { open: 'badge-danger', in_progress: 'badge-warning', closed: 'badge-success' };
  const priorityColors: Record<string, string> = { low: 'text-slate-500', normal: 'text-primary-600', high: 'text-danger-600', urgent: 'text-danger-700' };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96" dir="rtl">
        <div className="w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-5" dir="rtl">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="ابحث في التذاكر..." className="input-field pr-10" />
        </div>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value as any)} className="input-field w-auto">
          <option value="all">كل الحالات</option>
          <option value="open">مفتوح</option>
          <option value="in_progress">قيد المعالجة</option>
          <option value="closed">مغلق</option>
        </select>
        <select value={filterType} onChange={e => setFilterType(e.target.value as any)} className="input-field w-auto">
          <option value="all">كل الأنواع</option>
          <option value="problem">مشكلة</option>
          <option value="feature_request">طلب ميزة</option>
          <option value="bug_report">بلاغ خطأ</option>
        </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Ticket List */}
        <div className="lg:col-span-1 space-y-3 max-h-[70vh] overflow-y-auto">
          {filtered.map(ticket => (
            <motion.div
              key={ticket.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              onClick={() => setSelectedTicket(ticket)}
              className={`card p-4 cursor-pointer transition-all ${selectedTicket?.id === ticket.id ? 'ring-2 ring-primary-500 bg-primary-50/30' : 'hover:bg-slate-50'}`}
            >
              <div className="flex items-start justify-between mb-2">
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${typeColors[ticket.type] || 'bg-slate-100 text-slate-600'}`}>{typeLabels[ticket.type] || ticket.type}</span>
                <span className={`badge ${statusColors[ticket.status] || 'badge-neutral'}`}>{statusLabels[ticket.status] || ticket.status}</span>
              </div>
              <p className="font-semibold text-slate-900 text-sm mb-1 line-clamp-1">{ticket.subject}</p>
              <p className="text-xs text-slate-500 line-clamp-2 mb-2">{ticket.body}</p>
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>{ticket.restaurant_name}</span>
                <span>{new Date(ticket.created_at).toLocaleDateString('ar-EG')}</span>
              </div>
            </motion.div>
          ))}
          {filtered.length === 0 && (
            <div className="card p-8 text-center">
              <MessageSquare className="w-10 h-10 text-slate-200 mx-auto mb-3" />
              <p className="text-slate-400 text-sm">لا توجد تذاكر</p>
            </div>
          )}
        </div>

        {/* Ticket Detail */}
        <div className="lg:col-span-2">
          {selectedTicket ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="card p-6 space-y-5">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${typeColors[selectedTicket.type] || ''}`}>{typeLabels[selectedTicket.type] || selectedTicket.type}</span>
                    <span className={`badge ${statusColors[selectedTicket.status] || ''}`}>{statusLabels[selectedTicket.status] || selectedTicket.status}</span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">{selectedTicket.subject}</h3>
                  <p className="text-xs text-slate-500 mt-1">{selectedTicket.restaurant_name} — {new Date(selectedTicket.created_at).toLocaleDateString('ar-EG')}</p>
                </div>
                <div className="flex gap-1.5">
                  {selectedTicket.status !== 'closed' && (
                    <button onClick={() => handleStatusChange(selectedTicket.id, 'closed')} className="p-2 bg-success-50 hover:bg-success-100 text-success-600 rounded-lg transition-colors" title="إغلاق"><CheckCircle className="w-4 h-4" /></button>
                  )}
                  {selectedTicket.status === 'closed' && (
                    <button onClick={() => handleStatusChange(selectedTicket.id, 'open')} className="p-2 bg-primary-50 hover:bg-primary-100 text-primary-600 rounded-lg transition-colors" title="إعادة فتح"><Clock className="w-4 h-4" /></button>
                  )}
                </div>
              </div>

              <div className="bg-slate-50 rounded-xl p-4">
                <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap">{selectedTicket.body}</p>
              </div>

              {selectedTicket.admin_reply && (
                <div className="bg-primary-50 rounded-xl p-4 border border-primary-100">
                  <div className="flex items-center gap-2 mb-2">
                    <Reply className="w-4 h-4 text-primary-600" />
                    <span className="text-sm font-bold text-primary-700">رد الإدارة</span>
                    <span className="text-xs text-slate-400 mr-auto">{selectedTicket.replied_at ? new Date(selectedTicket.replied_at).toLocaleDateString('ar-EG') : ''}</span>
                  </div>
                  <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap">{selectedTicket.admin_reply}</p>
                </div>
              )}

              {selectedTicket.status !== 'closed' && (
                <div className="space-y-3">
                  <textarea
                    value={replyText}
                    onChange={e => setReplyText(e.target.value)}
                    placeholder="اكتب ردك هنا..."
                    rows={4}
                    className="input-field resize-none"
                  />
                  <button onClick={handleReply} disabled={sending || !replyText.trim()} className="btn-primary text-sm">
                    {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    إرسال رد
                  </button>
                </div>
              )}
            </motion.div>
          ) : (
            <div className="card p-12 text-center">
              <MessageSquare className="w-12 h-12 text-slate-200 mx-auto mb-3" />
              <p className="text-slate-400 text-sm">اختر تذكرة لعرض التفاصيل</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
