import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Activity, Filter, RefreshCw, Package, ShoppingBag,
  Users, Star, CreditCard, Settings
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { SkeletonTable, EmptyState, RetryError } from '../../components/Skeletons';

interface ActivityLog {
  id: string;
  action: string;
  entity_type: string;
  entity_id: string | null;
  entity_name: string | null;
  user_email: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
}

const entityIcons: Record<string, React.FC<{ className?: string }>> = {
  product: Package,
  menu_item: Package,
  order: ShoppingBag,
  customer: Users,
  loyalty: Star,
  subscription: CreditCard,
  settings: Settings,
};

const actionColor: Record<string, string> = {
  create: 'bg-emerald-100 text-emerald-700',
  update: 'bg-blue-100 text-blue-700',
  delete: 'bg-red-100 text-red-700',
  redeem: 'bg-amber-100 text-amber-700',
  status_change: 'bg-slate-100 text-slate-700',
};

const ACTION_LABELS: Record<string, string> = {
  create: 'إنشاء',
  update: 'تحديث',
  delete: 'حذف',
  redeem: 'استرداد',
  status_change: 'تغيير حالة',
};

const ENTITY_LABELS: Record<string, string> = {
  product: 'منتج',
  menu_item: 'منتج',
  order: 'طلب',
  customer: 'عميل',
  loyalty: 'ولاء',
  subscription: 'اشتراك',
  settings: 'إعدادات',
};

export default function ActivityLogs() {
  const { restaurant } = useAuth();
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [filterType, setFilterType] = useState('all');
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 20;

  useEffect(() => {
    if (restaurant) fetchLogs();
  }, [restaurant, filterType, page]);

  async function fetchLogs() {
    if (!restaurant) return;
    setLoading(true);
    setError(false);
    try {
      let q = supabase
        .from('activity_logs')
        .select('*')
        .eq('restaurant_id', restaurant.id)
        .order('created_at', { ascending: false })
        .range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);

      if (filterType !== 'all') q = q.eq('entity_type', filterType);

      const { data, error: err } = await q;
      if (err) throw err;
      setLogs(data as ActivityLog[]);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }

  function timeAgo(d: string) {
    const diff = Date.now() - new Date(d).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'الآن';
    if (mins < 60) return `منذ ${mins} دقيقة`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `منذ ${hrs} ساعة`;
    return new Date(d).toLocaleDateString('ar-EG', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  }

  const FILTERS = [
    { value: 'all', label: 'الكل' },
    { value: 'order', label: 'الطلبات' },
    { value: 'menu_item', label: 'المنتجات' },
    { value: 'customer', label: 'العملاء' },
    { value: 'loyalty', label: 'الولاء' },
    { value: 'subscription', label: 'الاشتراك' },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-5" dir="rtl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Activity className="w-6 h-6 text-primary-600" />
            سجل النشاطات
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">جميع الإجراءات المسجلة على حسابك</p>
        </div>
        <button onClick={fetch} disabled={loading} className="btn-secondary text-sm px-3 py-2">
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          تحديث
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-2 flex-wrap">
        <Filter className="w-4 h-4 text-slate-400 self-center" />
        {FILTERS.map(f => (
          <button
            key={f.value}
            onClick={() => { setFilterType(f.value); setPage(0); }}
            className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors ${
              filterType === f.value
                ? 'bg-primary-600 text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:border-primary-300'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        {loading ? (
          <div className="p-5"><SkeletonTable rows={8} /></div>
        ) : error ? (
          <RetryError onRetry={fetch} />
        ) : logs.length === 0 ? (
          <EmptyState
            icon={Activity}
            title="لا توجد نشاطات"
            description="ستظهر هنا جميع الإجراءات التي تقوم بها على المنصة"
          />
        ) : (
          <>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-slate-500 border-b border-slate-100">
                  <th className="text-right px-4 py-3 font-medium">النشاط</th>
                  <th className="text-right px-4 py-3 font-medium hidden md:table-cell">العنصر</th>
                  <th className="text-right px-4 py-3 font-medium hidden lg:table-cell">المستخدم</th>
                  <th className="text-right px-4 py-3 font-medium">الوقت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {logs.map((log, i) => {
                  const Icon = entityIcons[log.entity_type] ?? Activity;
                  const actionKey = log.action.toLowerCase().replace(/ /g, '_');
                  const colorClass = actionColor[actionKey] ?? actionColor.update;
                  return (
                    <motion.tr
                      key={log.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: i * 0.02 }}
                      className="hover:bg-slate-50"
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 bg-slate-100 rounded-lg flex items-center justify-center flex-shrink-0">
                            <Icon className="w-3.5 h-3.5 text-slate-500" />
                          </div>
                          <div>
                            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${colorClass}`}>
                              {ACTION_LABELS[actionKey] ?? log.action}
                            </span>
                            <span className="text-xs text-slate-500 mr-1">
                              {ENTITY_LABELS[log.entity_type] ?? log.entity_type}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 hidden md:table-cell">
                        <span className="text-xs text-slate-700 font-medium">{log.entity_name ?? log.entity_id ?? '—'}</span>
                      </td>
                      <td className="px-4 py-3 hidden lg:table-cell">
                        <span className="text-xs text-slate-400">{log.user_email ?? '—'}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-xs text-slate-400">{timeAgo(log.created_at)}</span>
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>

            {/* Pagination */}
            <div className="flex items-center justify-between px-4 py-3 border-t border-slate-100">
              <button
                onClick={() => setPage(p => Math.max(0, p - 1))}
                disabled={page === 0}
                className="text-xs btn-secondary px-3 py-1.5 disabled:opacity-40"
              >السابق</button>
              <span className="text-xs text-slate-400">الصفحة {page + 1}</span>
              <button
                onClick={() => setPage(p => p + 1)}
                disabled={logs.length < PAGE_SIZE}
                className="text-xs btn-secondary px-3 py-1.5 disabled:opacity-40"
              >التالي</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
