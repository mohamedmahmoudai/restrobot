import { useEffect, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp, TrendingDown, ShoppingBag, Users, DollarSign,
  BarChart3, Package, Clock, Download, RefreshCw, Star,
  ArrowUpRight, ArrowDownRight, Minus, Target, Zap, Copy, Check
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { SkeletonGrid, RetryError } from '../../components/Skeletons';
import { exportOrders, exportCustomers, exportProducts, exportLoyalty } from '../../lib/exportCsv';
import { useToast } from '../../components/Toast';
import type { Order } from '../../lib/database.types';

type DateRange = '7d' | '30d' | '90d';

interface KPIs {
  revenue: number;
  prevRevenue: number;
  orders: number;
  prevOrders: number;
  newCustomers: number;
  prevNewCustomers: number;
  avgOrderValue: number;
  prevAvgOrderValue: number;
  completionRate: number;
  cancellationRate: number;
  loyaltyParticipants: number;
  returningCustomers: number;
  totalCustomers: number;
}

interface HourBucket { hour: number; count: number }
interface DayBucket { day: number; count: number; label: string }
interface ProductStat { name: string; name_ar: string; qty: number; revenue: number }
interface DailyBucket { date: string; revenue: number; orders: number }
interface Insight { icon: string; title: string; body: string; color: string }

const DAY_LABELS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

function trendIcon(curr: number, prev: number) {
  if (prev === 0) return <Minus className="w-3.5 h-3.5 text-slate-400" />;
  if (curr > prev) return <ArrowUpRight className="w-3.5 h-3.5 text-emerald-500" />;
  return <ArrowDownRight className="w-3.5 h-3.5 text-red-400" />;
}

function trendPct(curr: number, prev: number) {
  if (prev === 0) return '—';
  const pct = ((curr - prev) / prev) * 100;
  return `${pct >= 0 ? '+' : ''}${pct.toFixed(1)}%`;
}

function trendColor(curr: number, prev: number) {
  if (prev === 0) return 'text-slate-400';
  return curr >= prev ? 'text-emerald-600' : 'text-red-500';
}

function BarMini({ value, max, color = 'bg-primary-500' }: { value: number; max: number; color?: string }) {
  const pct = max > 0 ? Math.round((value / max) * 100) : 0;
  return (
    <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
      <div className={`h-full rounded-full ${color}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export default function Analytics() {
  const { restaurant } = useAuth();
  const { error: toastError, success } = useToast();
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(false);
  const [range, setRange] = useState<DateRange>('30d');
  const [kpis, setKpis] = useState<KPIs | null>(null);
  const [hourBuckets, setHourBuckets] = useState<HourBucket[]>([]);
  const [dayBuckets, setDayBuckets] = useState<DayBucket[]>([]);
  const [topProducts, setTopProducts] = useState<ProductStat[]>([]);
  const [worstProducts, setWorstProducts] = useState<ProductStat[]>([]);
  const [dailyTrend, setDailyTrend] = useState<DailyBucket[]>([]);
  const [insights, setInsights] = useState<Insight[]>([]);
  const [exporting, setExporting] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const currencySymbol = restaurant?.currency === 'SAR' ? 'ر.س' : restaurant?.currency === 'AED' ? 'د.إ' : 'ج.م';

  const getDays = () => range === '7d' ? 7 : range === '30d' ? 30 : 90;

  const fetchData = useCallback(async () => {
    if (!restaurant) return;
    setLoading(true);
    setErr(false);
    try {
      const days = getDays();
      const now = new Date();
      const fromDate = new Date(now);
      fromDate.setDate(fromDate.getDate() - days);
      const prevFromDate = new Date(fromDate);
      prevFromDate.setDate(prevFromDate.getDate() - days);

      const [ordersRes, prevOrdersRes, customersRes, prevCustomersRes, loyaltyRes] = await Promise.all([
        supabase.from('orders').select('id,total,status,channel,created_at,customer_id')
          .eq('restaurant_id', restaurant.id)
          .gte('created_at', fromDate.toISOString()),
        supabase.from('orders').select('id,total,status,customer_id')
          .eq('restaurant_id', restaurant.id)
          .gte('created_at', prevFromDate.toISOString())
          .lt('created_at', fromDate.toISOString()),
        supabase.from('customers').select('id,created_at')
          .eq('restaurant_id', restaurant.id)
          .gte('created_at', fromDate.toISOString()),
        supabase.from('customers').select('id')
          .eq('restaurant_id', restaurant.id)
          .gte('created_at', prevFromDate.toISOString())
          .lt('created_at', fromDate.toISOString()),
        supabase.from('customer_points_wallet').select('customer_id')
          .eq('restaurant_id', restaurant.id)
          .gt('lifetime_points', 0),
      ]);

      // Fetch order items filtered by this restaurant's order IDs (safe cross-tenant)
      const orderIds = (ordersRes.data ?? []).map((o: {id: string}) => o.id);
      const orderItemsRes = orderIds.length > 0
        ? await supabase.from('order_items').select('menu_item_id,quantity,unit_price,order_id,menu_items(name,name_ar)').in('order_id', orderIds)
        : { data: [] };

      const orders = (ordersRes.data ?? []) as (Order & { customer_id: string | null })[];
      const prevOrders = (prevOrdersRes.data ?? []) as (Order & { customer_id: string | null })[];
      const newCustomers = customersRes.data?.length ?? 0;
      const prevNewCustomers = prevCustomersRes.data?.length ?? 0;

      const completed = orders.filter(o => o.status === 'delivered' || o.status === 'ready');
      const cancelled = orders.filter(o => o.status === 'cancelled');
      const revenue = completed.reduce((s, o) => s + Number(o.total), 0);
      const prevRevenue = prevOrders.filter(o => o.status === 'delivered' || o.status === 'ready').reduce((s, o) => s + Number(o.total), 0);
      const avgOrderValue = completed.length > 0 ? revenue / completed.length : 0;
      const prevCompleted = prevOrders.filter(o => o.status === 'delivered' || o.status === 'ready');
      const prevAvgOrderValue = prevCompleted.length > 0 ? prevCompleted.reduce((s, o) => s + Number(o.total), 0) / prevCompleted.length : 0;

      // Returning customers: customer_id appears in both periods
      const prevCustIds = new Set(prevOrders.map(o => o.customer_id).filter(Boolean));
      const returningCustomers = new Set(orders.filter(o => o.customer_id && prevCustIds.has(o.customer_id)).map(o => o.customer_id)).size;
      const totalCustomers = (await supabase.from('customers').select('id', { count: 'exact', head: true }).eq('restaurant_id', restaurant.id)).count ?? 0;

      setKpis({
        revenue, prevRevenue,
        orders: orders.length,
        prevOrders: prevOrders.length,
        newCustomers, prevNewCustomers,
        avgOrderValue, prevAvgOrderValue,
        completionRate: orders.length > 0 ? (completed.length / orders.length) * 100 : 0,
        cancellationRate: orders.length > 0 ? (cancelled.length / orders.length) * 100 : 0,
        loyaltyParticipants: loyaltyRes.data?.length ?? 0,
        returningCustomers,
        totalCustomers,
      });

      // Hour distribution
      const hourMap: Record<number, number> = {};
      orders.forEach(o => {
        const h = new Date(o.created_at).getHours();
        hourMap[h] = (hourMap[h] ?? 0) + 1;
      });
      setHourBuckets(Array.from({ length: 24 }, (_, h) => ({ hour: h, count: hourMap[h] ?? 0 })));

      // Day of week distribution
      const dayMap: Record<number, number> = {};
      orders.forEach(o => {
        const d = new Date(o.created_at).getDay();
        dayMap[d] = (dayMap[d] ?? 0) + 1;
      });
      setDayBuckets(Array.from({ length: 7 }, (_, d) => ({ day: d, count: dayMap[d] ?? 0, label: DAY_LABELS[d] })));

      // Daily trend
      const trendMap: Record<string, { revenue: number; orders: number }> = {};
      orders.forEach(o => {
        const k = o.created_at.split('T')[0];
        if (!trendMap[k]) trendMap[k] = { revenue: 0, orders: 0 };
        trendMap[k].orders++;
        if (o.status === 'delivered' || o.status === 'ready') trendMap[k].revenue += Number(o.total);
      });
      const trend = Object.entries(trendMap).sort((a, b) => a[0].localeCompare(b[0])).map(([date, v]) => ({ date, ...v }));
      setDailyTrend(trend);

      // Product stats from order_items (filter client-side due to nested filter limitation)
      const productMap: Record<string, ProductStat> = {};
      ((orderItemsRes.data ?? []) as any[]).forEach(item => {
        if (!item.menu_item_id || !item.menu_items) return;
        const id = item.menu_item_id;
        if (!productMap[id]) productMap[id] = { name: item.menu_items.name ?? '', name_ar: item.menu_items.name_ar ?? '', qty: 0, revenue: 0 };
        productMap[id].qty += item.quantity;
        productMap[id].revenue += item.quantity * Number(item.unit_price);
      });
      const sorted = Object.values(productMap).sort((a, b) => b.qty - a.qty);
      setTopProducts(sorted.slice(0, 5));
      setWorstProducts(sorted.slice(-5).reverse());

      // Insights engine
      const ins: Insight[] = [];
      if (sorted.length > 0) ins.push({ icon: '🏆', title: 'الأكثر مبيعاً', body: `${sorted[0].name_ar || sorted[0].name} — ${sorted[0].qty} وحدة`, color: 'bg-amber-50 border-amber-200' });
      if (sorted.length > 1) ins.push({ icon: '⚠️', title: 'منتجات بطيئة', body: `${sorted[sorted.length - 1]?.name_ar || sorted[sorted.length - 1]?.name} — ${sorted[sorted.length - 1]?.qty} فقط`, color: 'bg-red-50 border-red-200' });
      const growthPct = prevRevenue > 0 ? ((revenue - prevRevenue) / prevRevenue) * 100 : 0;
      if (growthPct > 10) ins.push({ icon: '📈', title: 'نمو قوي في الإيرادات', body: `+${growthPct.toFixed(1)}% مقارنة بالفترة السابقة`, color: 'bg-emerald-50 border-emerald-200' });
      if (growthPct < -10) ins.push({ icon: '📉', title: 'تراجع في الإيرادات', body: `${growthPct.toFixed(1)}% مقارنة بالفترة السابقة`, color: 'bg-red-50 border-red-200' });
      const loyaltyRate = totalCustomers > 0 ? ((loyaltyRes.data?.length ?? 0) / Number(totalCustomers)) * 100 : 0;
      if (loyaltyRate > 50) ins.push({ icon: '⭐', title: 'مشاركة عالية في الولاء', body: `${loyaltyRate.toFixed(0)}% من عملائك يجمعون النقاط`, color: 'bg-blue-50 border-blue-200' });
      setInsights(ins);
    } catch {
      setErr(true);
    } finally {
      setLoading(false);
    }
  }, [restaurant, range]);

  useEffect(() => { fetchData(); }, [fetchData]);

  async function handleExport(type: string) {
    if (!restaurant) return;
    setExporting(type);
    try {
      if (type === 'orders') await exportOrders(restaurant.id, currencySymbol);
      else if (type === 'customers') await exportCustomers(restaurant.id);
      else if (type === 'products') await exportProducts(restaurant.id, currencySymbol);
      else if (type === 'loyalty') await exportLoyalty(restaurant.id);
      success('تم تصدير البيانات بنجاح');
    } catch {
      toastError('فشل تصدير البيانات');
    } finally {
      setExporting(null);
    }
  }

  function copyReport() {
    if (!kpis) return;
    const lines = [
      `### تقرير RestroBot — ${restaurant?.name}`,
      `الفترة: ${getDays()} يوم`,
      ``,
      `الإيرادات: ${kpis.revenue.toFixed(0)} ${currencySymbol}`,
      `الطلبات: ${kpis.orders}`,
      `متوسط قيمة الطلب: ${kpis.avgOrderValue.toFixed(0)} ${currencySymbol}`,
      `عملاء جدد: ${kpis.newCustomers}`,
      `معدل الاكتمال: ${kpis.completionRate.toFixed(1)}%`,
      `معدل الإلغاء: ${kpis.cancellationRate.toFixed(1)}%`,
    ];
    navigator.clipboard.writeText(lines.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  }

  const maxHour = Math.max(...hourBuckets.map(h => h.count), 1);
  const maxDay = Math.max(...dayBuckets.map(d => d.count), 1);
  const maxTrend = Math.max(...dailyTrend.map(d => d.revenue), 1);

  if (loading) return <div className="max-w-6xl mx-auto" dir="rtl"><SkeletonGrid cols={4} /><div className="mt-4"><SkeletonGrid cols={2} /></div></div>;
  if (err) return <RetryError onRetry={fetchData} />;

  return (
    <div className="max-w-6xl mx-auto space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-primary-600" />
            التحليلات المتقدمة
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">ذكاء أعمال شامل لمطعمك</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Date range */}
          <div className="flex bg-white border border-slate-200 rounded-xl p-0.5">
            {([['7d','7 أيام'],['30d','30 يوم'],['90d','90 يوم']] as [DateRange,string][]).map(([v,l]) => (
              <button
                key={v}
                onClick={() => setRange(v)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${range === v ? 'bg-primary-600 text-white' : 'text-slate-500 hover:text-slate-800'}`}
              >
                {l}
              </button>
            ))}
          </div>
          <button onClick={fetchData} className="p-2 text-slate-500 hover:bg-slate-100 rounded-xl">
            <RefreshCw className="w-4 h-4" />
          </button>
          <button onClick={copyReport} className="btn-secondary text-xs px-3 py-2">
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'تم النسخ' : 'نسخ تقرير'}
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      {kpis && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'الإيرادات', value: `${kpis.revenue.toFixed(0)} ${currencySymbol}`, curr: kpis.revenue, prev: kpis.prevRevenue, icon: DollarSign, color: 'text-emerald-600', bg: 'bg-emerald-50' },
            { label: 'الطلبات', value: String(kpis.orders), curr: kpis.orders, prev: kpis.prevOrders, icon: ShoppingBag, color: 'text-blue-600', bg: 'bg-blue-50' },
            { label: 'عملاء جدد', value: String(kpis.newCustomers), curr: kpis.newCustomers, prev: kpis.prevNewCustomers, icon: Users, color: 'text-violet-600', bg: 'bg-violet-50' },
            { label: 'متوسط الطلب', value: `${kpis.avgOrderValue.toFixed(0)} ${currencySymbol}`, curr: kpis.avgOrderValue, prev: kpis.prevAvgOrderValue, icon: Target, color: 'text-amber-600', bg: 'bg-amber-50' },
          ].map((kpi, i) => (
            <motion.div key={kpi.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="bg-white rounded-2xl border border-slate-200 p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-slate-500 font-medium">{kpi.label}</span>
                <div className={`w-8 h-8 ${kpi.bg} rounded-xl flex items-center justify-center`}>
                  <kpi.icon className={`w-4 h-4 ${kpi.color}`} />
                </div>
              </div>
              <div className="text-2xl font-bold text-slate-900 mb-1">{kpi.value}</div>
              <div className={`flex items-center gap-1 text-xs font-medium ${trendColor(kpi.curr, kpi.prev)}`}>
                {trendIcon(kpi.curr, kpi.prev)}
                {trendPct(kpi.curr, kpi.prev)} من الفترة السابقة
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Operational KPIs */}
      {kpis && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'معدل الاكتمال', value: `${kpis.completionRate.toFixed(1)}%`, icon: '✅', good: kpis.completionRate >= 70 },
            { label: 'معدل الإلغاء', value: `${kpis.cancellationRate.toFixed(1)}%`, icon: '❌', good: kpis.cancellationRate <= 10 },
            { label: 'مشاركة الولاء', value: String(kpis.loyaltyParticipants), icon: '⭐', good: true },
            { label: 'عملاء عائدون', value: String(kpis.returningCustomers), icon: '🔄', good: true },
          ].map(stat => (
            <div key={stat.label} className={`bg-white rounded-2xl border p-4 text-center ${stat.good ? 'border-emerald-200' : 'border-red-200'}`}>
              <div className="text-2xl mb-1">{stat.icon}</div>
              <div className="text-xl font-bold text-slate-900">{stat.value}</div>
              <div className="text-xs text-slate-500 mt-0.5">{stat.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Revenue Trend */}
      {dailyTrend.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><TrendingUp className="w-4 h-4 text-primary-500" />اتجاه الإيرادات اليومي</h3>
          <div className="flex items-end gap-1 h-24 overflow-x-auto">
            {dailyTrend.map((d, i) => {
              const h = Math.max(4, Math.round((d.revenue / maxTrend) * 96));
              return (
                <div key={d.date} className="flex flex-col items-center gap-1 flex-shrink-0" style={{ minWidth: '12px' }}>
                  <div
                    className="w-full bg-primary-500 rounded-t-sm hover:bg-primary-600 transition-colors cursor-default"
                    style={{ height: `${h}px` }}
                    title={`${d.date}: ${d.revenue.toFixed(0)} ${currencySymbol}`}
                  />
                </div>
              );
            })}
          </div>
          <div className="flex justify-between text-[10px] text-slate-400 mt-2">
            <span>{dailyTrend[0]?.date}</span>
            <span>{dailyTrend[dailyTrend.length - 1]?.date}</span>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Top Products */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Package className="w-4 h-4 text-amber-500" />الأكثر مبيعاً</h3>
          {topProducts.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-6">لا توجد بيانات</p>
          ) : (
            <div className="space-y-3">
              {topProducts.map((p, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-700 font-medium truncate">{p.name_ar || p.name}</span>
                    <span className="text-slate-500 text-xs flex-shrink-0 mr-2">{p.qty} وحدة</span>
                  </div>
                  <BarMini value={p.qty} max={topProducts[0]?.qty ?? 1} color="bg-amber-400" />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Worst Products */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><TrendingDown className="w-4 h-4 text-red-400" />الأقل مبيعاً</h3>
          {worstProducts.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-6">لا توجد بيانات</p>
          ) : (
            <div className="space-y-3">
              {worstProducts.map((p, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-700 font-medium truncate">{p.name_ar || p.name}</span>
                    <span className="text-slate-500 text-xs flex-shrink-0 mr-2">{p.qty} وحدة</span>
                  </div>
                  <BarMini value={p.qty} max={worstProducts[0]?.qty ?? 1} color="bg-red-300" />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Peak Hours */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Clock className="w-4 h-4 text-blue-500" />أوقات الذروة</h3>
          <div className="flex items-end gap-0.5 h-16">
            {hourBuckets.map(h => {
              const ht = Math.max(2, Math.round((h.count / maxHour) * 64));
              const isPeak = h.count === Math.max(...hourBuckets.map(b => b.count));
              return (
                <div key={h.hour} className="flex-1 flex flex-col items-center gap-0.5" title={`${h.hour}:00 — ${h.count} طلب`}>
                  <div className={`w-full rounded-t-sm ${isPeak ? 'bg-blue-500' : 'bg-slate-200'}`} style={{ height: `${ht}px` }} />
                </div>
              );
            })}
          </div>
          <div className="flex justify-between text-[9px] text-slate-400 mt-1">
            {[0,6,12,18,23].map(h => <span key={h}>{h}:00</span>)}
          </div>
        </div>

        {/* Peak Days */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Zap className="w-4 h-4 text-violet-500" />أنشط أيام الأسبوع</h3>
          <div className="space-y-2">
            {[...dayBuckets].sort((a, b) => b.count - a.count).map(d => (
              <div key={d.day} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-600">{d.label}</span>
                  <span className="text-slate-400">{d.count} طلب</span>
                </div>
                <BarMini value={d.count} max={maxDay} color="bg-violet-400" />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Insights */}
      {insights.length > 0 && (
        <div>
          <h3 className="font-bold text-slate-800 mb-3 flex items-center gap-2"><Star className="w-4 h-4 text-amber-500" />رؤى الأعمال</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {insights.map((ins, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }} className={`rounded-2xl border p-4 ${ins.color}`}>
                <div className="text-2xl mb-2">{ins.icon}</div>
                <div className="font-bold text-slate-800 text-sm">{ins.title}</div>
                <div className="text-xs text-slate-600 mt-1">{ins.body}</div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Export */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Download className="w-4 h-4 text-slate-500" />تصدير البيانات</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { key: 'orders', label: 'الطلبات CSV' },
            { key: 'customers', label: 'العملاء CSV' },
            { key: 'products', label: 'المنتجات CSV' },
            { key: 'loyalty', label: 'الولاء CSV' },
          ].map(btn => (
            <button
              key={btn.key}
              onClick={() => handleExport(btn.key)}
              disabled={exporting === btn.key}
              className="btn-secondary text-xs py-2.5 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {exporting === btn.key
                ? <RefreshCw className="w-3 h-3 animate-spin" />
                : <Download className="w-3 h-3" />
              }
              {btn.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
