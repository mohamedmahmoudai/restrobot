import { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  RefreshCw, Printer, Search, AlertCircle, Clock, CheckCircle,
  XCircle, ChefHat, Package, Truck, Phone, MapPin, User,
  ChevronLeft, Filter, Volume2, VolumeX,
  TrendingUp, CheckCheck, Timer, Calendar, Receipt
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import type { Order, OrderItem, OrderEvent, Customer } from '../../lib/database.types';

interface EnrichedOrder extends Order {
  customer?: Customer | null;
  items?: OrderItem[];
  events?: OrderEvent[];
  delivery_zone_name?: string;
}

const STATUS_FLOW = ['pending', 'confirmed', 'preparing', 'ready', 'out_for_delivery', 'delivered', 'cancelled'] as const;
type OrderStatus = typeof STATUS_FLOW[number];

const STATUS_LABELS: Record<string, string> = {
  pending: 'قيد الانتظار',
  confirmed: 'تم التأكيد',
  preparing: 'قيد التحضير',
  ready: 'جاهز',
  out_for_delivery: 'في الطريق',
  delivered: 'تم التوصيل',
  cancelled: 'ملغي',
};

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-amber-100 text-amber-700 border-amber-200',
  confirmed: 'bg-blue-100 text-blue-700 border-blue-200',
  preparing: 'bg-orange-100 text-orange-700 border-orange-200',
  ready: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  out_for_delivery: 'bg-indigo-100 text-indigo-700 border-indigo-200',
  delivered: 'bg-slate-100 text-slate-600 border-slate-200',
  cancelled: 'bg-red-100 text-red-700 border-red-200',
};

const STATUS_ICONS: Record<string, React.ReactNode> = {
  pending: <Clock className="w-3.5 h-3.5" />,
  confirmed: <CheckCircle className="w-3.5 h-3.5" />,
  preparing: <ChefHat className="w-3.5 h-3.5" />,
  ready: <Package className="w-3.5 h-3.5" />,
  out_for_delivery: <Truck className="w-3.5 h-3.5" />,
  delivered: <CheckCheck className="w-3.5 h-3.5" />,
  cancelled: <XCircle className="w-3.5 h-3.5" />,
};

function formatCurrency(amount: number, currency: string = 'ج.م'): string {
  return `${Number(amount).toFixed(0)} ${currency}`;
}



function playNotificationSound() {
  try {
    // Resume AudioContext if suspended (browser autoplay policy)
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    // Create a more pleasant notification sound
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    // First tone
    osc.frequency.value = 880;
    osc.type = 'sine';
    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.15);

    // Second tone (higher pitch)
    setTimeout(() => {
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.frequency.value = 1200;
      osc2.type = 'sine';
      gain2.gain.setValueAtTime(0.3, ctx.currentTime);
      gain2.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
      osc2.start(ctx.currentTime);
      osc2.stop(ctx.currentTime + 0.2);
    }, 150);

    console.log('[CASHIER] Notification sound played');
  } catch (e) {
    console.error('[CASHIER] Sound playback error:', e);
  }
}

export default function Cashier() {
  const { restaurant } = useAuth();
  const [orders, setOrders] = useState<EnrichedOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('today');
  const [selectedOrder, setSelectedOrder] = useState<EnrichedOrder | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const soundEnabledRef = useRef(true);
  const [toast, setToast] = useState<string | null>(null);
  const [realtimeStatus, setRealtimeStatus] = useState<'connected' | 'disconnected'>('connected');
  const [printingOrderId, setPrintingOrderId] = useState<string | null>(null);

  const prevOrdersRef = useRef<EnrichedOrder[]>([]);
  const channelRef = useRef<any>(null);
  const selfUpdateRef = useRef<Set<string>>(new Set());

  // Keep soundEnabledRef in sync
  useEffect(() => {
    soundEnabledRef.current = soundEnabled;
  }, [soundEnabled]);

  const currency = restaurant?.currency === 'SAR' ? 'ر.س' : restaurant?.currency === 'AED' ? 'د.إ' : restaurant?.currency === 'USD' ? '$' : 'ج.م';

  const fetchOrders = useCallback(async () => {
    if (!restaurant?.id) return;
    setLoading(true);
    try {
      const { data: ordersData, error: ordersError } = await supabase
        .from('orders')
        .select('*, customers(*)')
        .eq('restaurant_id', restaurant.id)
        .order('created_at', { ascending: false })
        .limit(200);
      if (ordersError) throw ordersError;

      const orderIds = (ordersData || []).map(o => o.id);
      let itemsData: OrderItem[] = [];
      let eventsData: OrderEvent[] = [];

      if (orderIds.length > 0) {
        const { data: items } = await supabase
          .from('order_items')
          .select('*')
          .in('order_id', orderIds);
        itemsData = items || [];

        const { data: events } = await supabase
          .from('order_events')
          .select('*')
          .in('order_id', orderIds)
          .order('created_at', { ascending: true });
        eventsData = events || [];
      }

      const enriched: EnrichedOrder[] = (ordersData || []).map(o => {
        const raw = o as any;
        const payload = raw.raw_payload || {};
        const zoneName = payload.checkout_data?.zone_name || '';
        const zonePrice = payload.checkout_data?.zone_price || 0;
        return {
          ...o,
          customer: raw.customers || null,
          items: itemsData.filter(i => i.order_id === o.id),
          events: eventsData.filter(e => e.order_id === o.id),
          delivery_zone_name: zoneName,
          delivery_fee: zonePrice,
        };
      });

      setOrders(enriched);
    } catch (err) {
      console.error('fetchOrders error:', err);
    } finally {
      setLoading(false);
    }
  }, [restaurant?.id]);

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  // Track processed order IDs to prevent duplicates
  const processedOrdersRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!restaurant?.id) return;

    console.log('[CASHIER] Setting up realtime subscription for restaurant:', restaurant.id);

    const channel = supabase
      .channel(`orders-realtime-${restaurant.id}`, {
        config: {
          broadcast: { self: false },
          presence: { key: restaurant.id },
        }
      })
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'orders', filter: `restaurant_id=eq.${restaurant.id}` },
        async (payload: any) => {
          const newOrder = payload.new;
          console.log('[CASHIER] New order received:', newOrder.id, newOrder.order_number);

          // Prevent duplicate processing
          if (processedOrdersRef.current.has(newOrder.id)) {
            console.log('[CASHIER] Order already processed, skipping');
            return;
          }
          processedOrdersRef.current.add(newOrder.id);

          // Fetch full order data including items
          const { data: fullOrder } = await supabase
            .from('orders')
            .select('*, customers(*)')
            .eq('id', newOrder.id)
            .maybeSingle();

          const { data: items } = await supabase
            .from('order_items')
            .select('*')
            .eq('order_id', newOrder.id);

          const raw = fullOrder as any;
          const payload2 = raw?.raw_payload || {};
          const zoneName = payload2.checkout_data?.zone_name || '';
          const zonePrice = payload2.delivery_fee || payload2.checkout_data?.zone_price || 0;

          const enriched: EnrichedOrder = {
            ...newOrder,
            customer: raw?.customers || null,
            items: items || [],
            events: [],
            delivery_zone_name: zoneName,
            delivery_fee: zonePrice,
          };

          setOrders(prev => {
            // Double-check we don't already have this order
            if (prev.some(o => o.id === newOrder.id)) return prev;
            return [enriched, ...prev];
          });

          // Play sound and show toast (use ref for soundEnabled)
          console.log('[CASHIER] Sound enabled:', soundEnabledRef.current);
          if (soundEnabledRef.current) {
            playNotificationSound();
          }
          setToast(`🔔 طلب جديد #${newOrder.order_number}`);
          setTimeout(() => setToast(null), 4000);
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'orders', filter: `restaurant_id=eq.${restaurant.id}` },
        async (payload: any) => {
          const updated = payload.new;
          console.log('[CASHIER] Order updated:', updated.id, 'status:', updated.status);

          // Fetch customer data if not present
          const { data: orderWithCustomer } = await supabase
            .from('orders')
            .select('*, customers(*)')
            .eq('id', updated.id)
            .maybeSingle();

          setOrders(prev => prev.map(o => {
            if (o.id !== updated.id) return o;
            return {
              ...o,
              ...updated,
              customer: (orderWithCustomer as any)?.customers || o.customer,
            };
          }));

          // Show toast for status change (suppress if this was the cashier's own update)
          if (!selfUpdateRef.current.has(updated.id)) {
            setToast(`تم تحديث الحالة إلى: ${STATUS_LABELS[updated.status] || updated.status}`);
            setTimeout(() => setToast(null), 3000);
          } else {
            selfUpdateRef.current.delete(updated.id);
          }
        }
      )
      .subscribe((status: string) => {
        console.log('[CASHIER] Realtime status:', status);
        setRealtimeStatus(status === 'SUBSCRIBED' ? 'connected' : 'disconnected');
      });

    channelRef.current = channel;

    return () => {
      console.log('[CASHIER] Cleaning up realtime subscription');
      channel.unsubscribe();
    };
  }, [restaurant?.id]);

  // Keep ref to soundEnabled to avoid re-subscribing
  useEffect(() => {
    const ref = { soundEnabled };
    return () => { ref.soundEnabled = soundEnabled; };
  }, [soundEnabled]);

  useEffect(() => {
    prevOrdersRef.current = orders;
  }, [orders]);

  async function updateOrderStatus(orderId: string, newStatus: string) {
    if (!restaurant?.id) return;

    // Optimistic update
    const previousStatus = orders.find(o => o.id === orderId)?.status;
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));

    const { error } = await supabase
      .from('orders')
      .update({ status: newStatus, updated_at: new Date().toISOString() })
      .eq('id', orderId)
      .eq('restaurant_id', restaurant.id);

    if (error) {
      console.error('updateOrderStatus error:', error);
      // Revert optimistic update
      setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: previousStatus } as typeof o : o));
      setToast('فشل تحديث الحالة');
      setTimeout(() => setToast(null), 3000);
      return;
    }

    // Mark this as a self-update so the realtime handler doesn't show a duplicate toast
    selfUpdateRef.current.add(orderId);

    // order_events are populated by the DB trigger `trg_record_order_event`.
    // The telegram-notify edge function is the single notification path to the customer.

    setToast(`تم تحديث الحالة إلى: ${STATUS_LABELS[newStatus] || newStatus}`);
    setTimeout(() => setToast(null), 3000);

    // Notify customer — awaited to preserve notification ordering.
    // The edge function has a stale-status guard that skips notifications
    // if the order's actual DB status doesn't match the requested status.
    notifyCustomer(orderId, newStatus).catch(err => console.error('Telegram notify error:', err));
  }

  // Separate function for Telegram notification
  async function notifyCustomer(orderId: string, status: string) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token || import.meta.env.VITE_SUPABASE_ANON_KEY;
      const resp = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/telegram-notify`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ order_id: orderId, status }),
      });
      if (!resp.ok) {
        console.error('[CASHIER] Telegram notify HTTP error:', resp.status, await resp.text().catch(() => ''));
      }
    } catch (err) {
      console.error('[CASHIER] Telegram notify error:', err);
    }
  }


  const filteredOrders = useMemo(() => {
    let result = [...orders];
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      result = result.filter(o =>
        o.order_number.toLowerCase().includes(q) ||
        (o.customer?.name || '').toLowerCase().includes(q) ||
        (o.customer?.phone || '').includes(q)
      );
    }
    if (statusFilter !== 'all') {
      result = result.filter(o => o.status === statusFilter);
    }
    if (dateFilter === 'today') {
      const today = new Date().toISOString().slice(0, 10);
      result = result.filter(o => o.created_at.slice(0, 10) === today);
    } else if (dateFilter === 'week') {
      const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
      result = result.filter(o => o.created_at >= weekAgo);
    }
    return result;
  }, [orders, search, statusFilter, dateFilter]);

  const ordersByStatus = useMemo(() => {
    const map: Record<string, EnrichedOrder[]> = {};
    STATUS_FLOW.forEach(s => { map[s] = []; });
    filteredOrders.forEach(o => {
      if (!map[o.status]) map[o.status] = [];
      map[o.status].push(o);
    });
    return map;
  }, [filteredOrders]);

  const metrics = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const todayOrders = orders.filter(o => o.created_at.slice(0, 10) === today);
    const pending = todayOrders.filter(o => o.status === 'pending').length;
    const completed = todayOrders.filter(o => o.status === 'delivered').length;
    const cancelled = todayOrders.filter(o => o.status === 'cancelled').length;

    const prepTimes: number[] = [];
    const deliveryTimes: number[] = [];
    orders.forEach(o => {
      const evs = o.events || [];
      const created = new Date(o.created_at).getTime();
      const readyEv = evs.find(e => e.new_status === 'ready');
      const deliveredEv = evs.find(e => e.new_status === 'delivered');
      if (readyEv) {
        const prep = new Date(readyEv.created_at).getTime() - created;
        if (prep > 0) prepTimes.push(prep);
      }
      if (deliveredEv && readyEv) {
        const del = new Date(deliveredEv.created_at).getTime() - new Date(readyEv.created_at).getTime();
        if (del > 0) deliveryTimes.push(del);
      }
    });

    const avgPrep = prepTimes.length > 0 ? Math.round(prepTimes.reduce((a, b) => a + b, 0) / prepTimes.length / 60000) : 0;
    const avgDel = deliveryTimes.length > 0 ? Math.round(deliveryTimes.reduce((a, b) => a + b, 0) / deliveryTimes.length / 60000) : 0;

    return { todayTotal: todayOrders.length, pending, completed, cancelled, avgPrep, avgDel };
  }, [orders]);

  function printReceipt(order: EnrichedOrder) {
    setPrintingOrderId(order.id);
    setTimeout(() => {
      const win = window.open('', '_blank', 'width=400,height=700');
      if (!win) { setPrintingOrderId(null); return; }
      const itemsHtml = (order.items || []).map(item =>
        `<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px dashed #e5e7eb;font-size:13px;">
          <span>${item.quantity}x ${item.name}</span><span>${formatCurrency(item.total_price, currency)}</span>
        </div>`
      ).join('');
      const subtotal = order.subtotal || (order.items || []).reduce((s, i) => s + i.total_price, 0);
      const deliveryFee = order.delivery_fee || 0;
      win.document.write(`<!DOCTYPE html><html dir="rtl"><head><meta charset="UTF-8"><title>فاتورة #${order.order_number}</title>
        <style>body{font-family:'Segoe UI',Tahoma,sans-serif;direction:rtl;padding:16px;font-size:13px;background:#fff;color:#111;}
        .receipt{max-width:340px;margin:0 auto;}
        .header{text-align:center;margin-bottom:12px;padding-bottom:12px;border-bottom:2px solid #111;}
        .logo{font-size:16px;font-weight:700;margin-bottom:4px;}
        .meta{color:#666;font-size:12px;margin-bottom:2px;}
        .items{margin:12px 0;}
        .total-row{display:flex;justify-content:space-between;padding:6px 0;font-weight:600;border-top:1px solid #111;margin-top:8px;font-size:14px;}
        .footer{text-align:center;margin-top:16px;padding-top:12px;border-top:1px dashed #ccc;color:#888;font-size:11px;}
        .info-row{display:flex;justify-content:space-between;padding:3px 0;font-size:12px;color:#444;}
        </style></head>
        <body><div class="receipt">
        <div class="header">
          <div class="logo">${restaurant?.name || 'المطعم'}</div>
          <div class="meta">رقم الطلب: #${order.order_number}</div>
          <div class="meta">${new Date(order.created_at).toLocaleString('ar-EG')}</div>
        </div>
        <div class="info-row"><span>العميل</span><span>${order.customer?.name || '-'}</span></div>
        <div class="info-row"><span>الهاتف</span><span>${order.customer?.phone || '-'}</span></div>
        <div class="info-row"><span>العنوان</span><span>${order.delivery_address || '-'}</span></div>
        <div class="info-row"><span>المنطقة</span><span>${order.delivery_zone_name || '-'}</span></div>
        <div class="items">${itemsHtml}</div>
        <div class="total-row"><span>المجموع الفرعي</span><span>${formatCurrency(subtotal, currency)}</span></div>
        ${deliveryFee > 0 ? `<div class="info-row" style="justify-content:space-between;padding:3px 0;"><span>التوصيل</span><span>${formatCurrency(deliveryFee, currency)}</span></div>` : ''}
        <div class="total-row" style="font-size:16px;"><span>الإجمالي</span><span>${formatCurrency(order.total, currency)}</span></div>
        <div class="footer"><p>شكراً لزيارتكم</p><p>RestroBot</p></div>
        </div></body></html>`);
      win.document.close();
      setPrintingOrderId(null);
      setTimeout(() => win.print(), 400);
    }, 300);
  }

  function OrderCard({ order }: { order: EnrichedOrder }) {
    const isPrinting = printingOrderId === order.id;

    return (
      <motion.div layout initial={{ opacity: 0, scale: 0.97, y: 8 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.97, y: -8 }}
        className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
        onClick={() => setSelectedOrder(order)}
      >
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono font-bold text-slate-900 text-sm">#{order.order_number}</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <User className="w-3 h-3 text-slate-400" />
              <span className="font-semibold">{order.customer?.name || 'عميل'}</span>
            </div>
          </div>
          <span className="font-mono font-bold text-primary-600 text-sm flex-shrink-0">{formatCurrency(order.total, currency)}</span>
        </div>

        <div className="space-y-1 mb-3">
          {(order.items || []).slice(0, 3).map((item, idx) => (
            <div key={idx} className="text-xs text-slate-600 flex items-center gap-1.5">
              <span className="w-1 h-1 rounded-full bg-slate-300" />
              <span>{item.quantity}x {item.name}</span>
            </div>
          ))}
          {(order.items || []).length > 3 && (
            <div className="text-[10px] text-slate-400">+{(order.items || []).length - 3} منتج آخر</div>
          )}
        </div>

        <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mb-2">
          <Phone className="w-3 h-3" />
          <span>{order.customer?.phone || '-'}</span>
          {order.delivery_zone_name && (
            <>
              <span className="mx-1">·</span>
              <MapPin className="w-3 h-3" />
              <span>{order.delivery_zone_name}</span>
            </>
          )}
        </div>

        <div className="flex gap-2">
          <button
            onClick={(e) => { e.stopPropagation(); printReceipt(order); }}
            disabled={isPrinting}
            className="w-8 h-8 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-lg flex items-center justify-center transition-colors disabled:opacity-50"
          >
            {isPrinting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Receipt className="w-3.5 h-3.5" />}
          </button>
          <StatusActions order={order} onChange={(s) => updateOrderStatus(order.id, s)} />
        </div>
      </motion.div>
    );
  }

  function StatusActions({ order, onChange }: { order: EnrichedOrder; onChange: (s: string) => void }) {
    const currentIdx = STATUS_FLOW.indexOf(order.status as OrderStatus);
    const nextStatus = currentIdx >= 0 && currentIdx < STATUS_FLOW.length - 2 ? STATUS_FLOW[currentIdx + 1] : null;
    const cancelAvailable = order.status !== 'delivered' && order.status !== 'cancelled';

    return (
      <div className="flex gap-1.5 flex-1">
        {nextStatus && (
          <button
            onClick={(e) => { e.stopPropagation(); onChange(nextStatus); }}
            className="flex-1 flex items-center justify-center gap-1 bg-primary-50 hover:bg-primary-100 text-primary-700 font-medium rounded-lg py-1.5 text-[11px] transition-colors"
          >
            {STATUS_ICONS[nextStatus]} {STATUS_LABELS[nextStatus]}
          </button>
        )}
        {cancelAvailable && (
          <button
            onClick={(e) => { e.stopPropagation(); onChange('cancelled'); }}
            className="px-2 bg-red-50 hover:bg-red-100 text-red-700 rounded-lg text-[11px] font-medium transition-colors"
          >
            إلغاء
          </button>
        )}
      </div>
    );
  }

  function OrderDetailDrawer({ order, onClose }: { order: EnrichedOrder; onClose: () => void }) {
    const evs = order.events || [];
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex justify-end">
        <div className="absolute inset-0 bg-black/30" onClick={onClose} />
        <motion.div initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="relative w-full max-w-md bg-white h-full shadow-2xl overflow-y-auto"
          dir="rtl"
        >
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900">تفاصيل الطلب #{order.order_number}</h2>
              <p className="text-xs text-slate-500">{new Date(order.created_at).toLocaleString('ar-EG')}</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
              <ChevronLeft className="w-5 h-5 text-slate-500" />
            </button>
          </div>

          <div className="p-5 space-y-5">
            <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold border ${STATUS_COLORS[order.status] || 'bg-slate-100 text-slate-600'}`}>
              {STATUS_ICONS[order.status]} {STATUS_LABELS[order.status] || order.status}
            </div>

            <div className="bg-slate-50 rounded-xl p-4 space-y-2">
              <h3 className="text-sm font-bold text-slate-800 mb-2">بيانات العميل</h3>
              <div className="flex items-center gap-2 text-sm text-slate-700"><User className="w-4 h-4 text-slate-400" /> {order.customer?.name || '-'}</div>
              <div className="flex items-center gap-2 text-sm text-slate-700"><Phone className="w-4 h-4 text-slate-400" /> {order.customer?.phone || '-'}</div>
              <div className="flex items-center gap-2 text-sm text-slate-700"><MapPin className="w-4 h-4 text-slate-400" /> {order.delivery_address || '-'}</div>
              {order.delivery_zone_name && (
                <div className="flex items-center gap-2 text-sm text-slate-700"><Truck className="w-4 h-4 text-slate-400" /> {order.delivery_zone_name} — {formatCurrency(order.delivery_fee || 0, currency)}</div>
              )}
            </div>

            <div>
              <h3 className="text-sm font-bold text-slate-800 mb-2">المنتجات</h3>
              <div className="space-y-2">
                {(order.items || []).map((item, idx) => (
                  <div key={idx} className="flex justify-between items-center py-2 border-b border-slate-100">
                    <div>
                      <div className="text-sm font-medium text-slate-800">{item.name}</div>
                      <div className="text-xs text-slate-500">{item.quantity} × {formatCurrency(item.unit_price, currency)}</div>
                    </div>
                    <div className="text-sm font-bold text-slate-900">{formatCurrency(item.total_price, currency)}</div>
                  </div>
                ))}
              </div>
              <div className="flex justify-between items-center pt-3 mt-2 border-t border-slate-200">
                <span className="text-sm font-bold text-slate-800">الإجمالي</span>
                <span className="text-lg font-bold text-primary-600">{formatCurrency(order.total, currency)}</span>
              </div>
            </div>

            {order.notes && (
              <div className="bg-amber-50 rounded-xl p-3 text-sm text-amber-800">
                <span className="font-bold">ملاحظات:</span> {order.notes}
              </div>
            )}

            <div>
              <h3 className="text-sm font-bold text-slate-800 mb-2">سجل الحالة</h3>
              <div className="space-y-3">
                {evs.length === 0 && <p className="text-xs text-slate-400">لا يوجد سجل</p>}
                {evs.map((ev, idx) => (
                  <div key={idx} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className="w-2 h-2 rounded-full bg-primary-500" />
                      {idx < evs.length - 1 && <div className="w-0.5 flex-1 bg-slate-200 my-1" />}
                    </div>
                    <div className="pb-3">
                      <div className="text-xs font-semibold text-slate-700">
                        {ev.event_type === 'order_created' ? 'تم إنشاء الطلب' :
                          ev.old_status && ev.new_status ? `${STATUS_LABELS[ev.old_status] || ev.old_status} → ${STATUS_LABELS[ev.new_status] || ev.new_status}` :
                            ev.event_type}
                      </div>
                      <div className="text-[10px] text-slate-400">{new Date(ev.created_at).toLocaleString('ar-EG')}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button onClick={() => printReceipt(order)} className="flex-1 flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl py-2.5 text-sm font-medium transition-colors">
                <Printer className="w-4 h-4" /> طباعة الفاتورة
              </button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    );
  }

  function KanbanColumn({ status, orders: colOrders }: { status: string; orders: EnrichedOrder[] }) {
    return (
      <div className="flex flex-col gap-3 flex-1 min-w-[280px] max-w-[340px]">
        <div className={`rounded-xl p-3 flex items-center justify-between ${STATUS_COLORS[status].replace('text-', 'bg-').replace('border-', '').split(' ')[0]} bg-opacity-40`}>
          <div className="flex items-center gap-2">
            {STATUS_ICONS[status]}
            <h3 className="font-bold text-sm text-slate-800">{STATUS_LABELS[status]}</h3>
          </div>
          <span className="text-xs font-semibold text-slate-500 bg-white/70 px-2 py-0.5 rounded-md">{colOrders.length}</span>
        </div>
        <div className="flex flex-col gap-3 overflow-y-auto max-h-[calc(100vh-320px)] pr-1">
          <AnimatePresence mode="popLayout">
            {colOrders.length === 0 ? (
              <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-8">
                <AlertCircle className="w-8 h-8 text-slate-200 mx-auto mb-2" />
                <p className="text-slate-400 text-xs">لا توجد طلبات</p>
              </motion.div>
            ) : (
              colOrders.map(order => <OrderCard key={order.id} order={order} />)
            )}
          </AnimatePresence>
        </div>
      </div>
    );
  }

  const activeStatuses = STATUS_FLOW.filter(s => s !== 'cancelled' && s !== 'delivered');

  return (
    <div className="max-w-[1600px] mx-auto space-y-4" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">الكاشير</h1>
          <p className="text-sm text-slate-500 mt-0.5">إدارة الطلبات والعملاء</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setSoundEnabled(v => !v)} className={`p-2.5 rounded-xl border transition-all ${soundEnabled ? 'bg-primary-50 border-primary-200 text-primary-600' : 'bg-white border-slate-200 text-s-slate-400'}`}>
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <button onClick={fetchOrders} className="p-2.5 rounded-xl bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 transition-all">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Realtime status */}
      {realtimeStatus === 'disconnected' && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-center gap-2 text-amber-700 text-sm">
          <AlertCircle className="w-4 h-4" />
          <span>انقطع الاتصال بالخادم. جاري إعادة الاتصال...</span>
        </div>
      )}

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-center gap-2 text-slate-500 text-xs mb-1"><Calendar className="w-3.5 h-3.5" /> طلبات اليوم</div>
          <div className="text-xl font-bold text-slate-900">{metrics.todayTotal}</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-center gap-2 text-amber-600 text-xs mb-1"><Clock className="w-3.5 h-3.5" /> قيد الانتظار</div>
          <div className="text-xl font-bold text-amber-700">{metrics.pending}</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-center gap-2 text-emerald-600 text-xs mb-1"><CheckCheck className="w-3.5 h-3.5" /> مكتملة</div>
          <div className="text-xl font-bold text-emerald-700">{metrics.completed}</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-center gap-2 text-slate-500 text-xs mb-1"><Timer className="w-3.5 h-3.5" /> متوسط التحضير</div>
          <div className="text-xl font-bold text-slate-900">{metrics.avgPrep}د</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-center gap-2 text-red-500 text-xs mb-1"><XCircle className="w-3.5 h-3.5" /> ملغية</div>
          <div className="text-xl font-bold text-red-600">{metrics.cancelled}</div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-wrap items-center gap-2 bg-white rounded-xl border border-slate-200 p-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="بحث برقم الطلب أو اسم العميل أو الهاتف..."
            className="w-full pr-9 pl-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-primary-500"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-primary-500">
            <option value="all">كل الحالات</option>
            {STATUS_FLOW.map(s => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
          </select>
          <select value={dateFilter} onChange={e => setDateFilter(e.target.value)} className="text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-primary-500">
            <option value="today">اليوم</option>
            <option value="week">آخر أسبوع</option>
            <option value="all">الكل</option>
          </select>
        </div>
      </div>

      {/* Kanban Board */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <RefreshCw className="w-8 h-8 text-slate-300 animate-spin" />
        </div>
      ) : (
        <div className="flex gap-4 overflow-x-auto pb-4">
          {activeStatuses.map(status => (
            <KanbanColumn key={status} status={status} orders={ordersByStatus[status] || []} />
          ))}
          <KanbanColumn status="delivered" orders={ordersByStatus['delivered'] || []} />
          <KanbanColumn status="cancelled" orders={ordersByStatus['cancelled'] || []} />
        </div>
      )}

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-5 py-2.5 rounded-xl shadow-lg text-sm font-medium flex items-center gap-2"
          >
            <TrendingUp className="w-4 h-4" /> {toast}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Order Detail Drawer */}
      <AnimatePresence>
        {selectedOrder && <OrderDetailDrawer order={selectedOrder} onClose={() => setSelectedOrder(null)} />}
      </AnimatePresence>

    </div>
  );
}
