import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, History, Lock, Unlock, Star, Crown, Medal, Gem, ChevronLeft } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
type Customer = { id: string; name: string; phone?: string; address?: string; telegram_id?: string; channel?: string; total_orders: number; total_spent: number; status?: string; created_at: string; [key: string]: any };
type CustomerPointsWallet = { id: string; current_points: number; lifetime_points: number; redeemed_points: number; current_tier?: string; [key: string]: any };
type CustomerTier = { id: string; tier_name: string; tier_label_ar: string; min_points: number; color_hex?: string; [key: string]: any };
type PointsTransaction = { id: string; type: string; points: number; balance_after: number; notes?: string; created_at: string; [key: string]: any };

interface CustomerWithWallet {
  customer: Customer;
  wallet: CustomerPointsWallet | null;
  tier: CustomerTier | null;
}

export default function Customers() {
  const { restaurant } = useAuth();
  const [customers, setCustomers] = useState<CustomerWithWallet[]>([]);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'verified' | 'blocked'>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [tiers, setTiers] = useState<CustomerTier[]>([]);
  const [transactions, setTransactions] = useState<PointsTransaction[]>([]);

  useEffect(() => {
    if (restaurant) fetchData();
  }, [restaurant]);

  async function fetchData() {
    if (!restaurant) return;
    setLoading(true);

    const [customersRes, tiersRes] = await Promise.all([
      supabase.from('customers').select('*').eq('restaurant_id', restaurant.id).order('created_at', { ascending: false }).limit(100),
      supabase.from('customer_tiers').select('*').eq('restaurant_id', restaurant.id).order('sort_order', { ascending: true }),
    ]);

    const customerList = (customersRes.data ?? []) as Customer[];
    const tierList = (tiersRes.data ?? []) as CustomerTier[];
    setTiers(tierList);

    if (customerList.length > 0) {
      const customerIds = customerList.map(c => c.id);
      const { data: wallets } = await supabase
        .from('customer_points_wallet')
        .select('*')
        .in('customer_id', customerIds)
        .eq('restaurant_id', restaurant.id);

      const walletMap = new Map((wallets ?? []).map((w: any) => [w.customer_id, w]));

      const mapped: CustomerWithWallet[] = customerList.map(c => {
        const w = walletMap.get(c.id) as CustomerPointsWallet | undefined;
        const tier = w ? tierList.find(t => t.tier_name === w.current_tier) ?? null : null;
        return { customer: c, wallet: w ?? null, tier };
      });
      setCustomers(mapped);
    } else {
      setCustomers([]);
    }
    setLoading(false);
  }

  async function fetchCustomerDetails(customerId: string) {
    if (!restaurant) return;
    const { data } = await supabase
      .from('points_transactions')
      .select('*')
      .eq('restaurant_id', restaurant.id)
      .eq('customer_id', customerId)
      .order('created_at', { ascending: false })
      .limit(10);
    setTransactions((data ?? []) as PointsTransaction[]);
  }

  async function toggleStatus(customerId: string, currentStatus: string) {
    const newStatus = currentStatus === 'blocked' ? 'verified' : 'blocked';
    await supabase.from('customers').update({ status: newStatus }).eq('id', customerId);
    setCustomers(prev => prev.map(c =>
      c.customer.id === customerId ? { ...c, customer: { ...c.customer, status: newStatus as any } } : c
    ));
  }

  const filtered = customers.filter(c => {
    const matchSearch = c.customer.name.includes(search) || c.customer.phone.includes(search);
    const matchFilter = filterStatus === 'all' || c.customer.status === filterStatus;
    return matchSearch && matchFilter;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'verified': return <span className="badge badge-success">موثق</span>;
      case 'new': return <span className="badge badge-neutral">جديد</span>;
      case 'blocked': return <span className="badge badge-danger">محظور</span>;
      default: return null;
    }
  };

  const tierIcons: Record<string, React.FC<{ className?: string }>> = {
    bronze: Medal, silver: Star, gold: Crown, platinum: Gem,
  };

  const getTierColor = (tierName: string | null) => {
    if (!tierName) return '#94a3b8';
    const tier = tiers.find(t => t.tier_name === tierName);
    return tier?.color_hex ?? '#94a3b8';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64" dir="rtl">
        <div className="w-6 h-6 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-4" dir="rtl">
      <div className="space-y-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">العملاء</h1>
          <p className="text-sm text-slate-500 mt-0.5">إدارة وتتبع عملائك</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input type="text" placeholder="ابحث بالاسم أو رقم الهاتف..." value={search} onChange={(e) => setSearch(e.target.value)} className="input-field pr-10" />
          </div>
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value as 'all' | 'verified' | 'blocked')} className="input-field w-auto">
            <option value="all">كل العملاء</option>
            <option value="verified">الموثقين</option>
            <option value="blocked">المحظورين</option>
          </select>
        </div>
      </div>

      <div className="text-sm text-slate-500 font-medium">
        عرض <span className="text-slate-900 font-bold">{filtered.length}</span> عميل من أصل <span className="text-slate-900 font-bold">{customers.length}</span>
      </div>

      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-12 text-center">
            <Search className="w-10 h-10 text-slate-200 mx-auto mb-3" />
            <p className="text-slate-400 text-sm">لم يتم العثور على عملاء</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50">
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">العميل</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">المستوى</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">الطلبات</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">النقاط</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">المدفوعات</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">الحالة</th>
                  <th className="px-4 py-3 text-center text-xs font-bold text-slate-700">إجراء</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((item, idx) => {
                  const c = item.customer;
                  return (
                    <motion.tr key={c.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.04 }} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                      <td className="px-4 py-3.5">
                        <div>
                          <p className="font-semibold text-slate-900 text-sm">{c.name}</p>
                          <p className="text-slate-400 text-xs font-mono mt-0.5">{c.phone}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        {item.wallet ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold" style={{ backgroundColor: getTierColor(item.wallet.current_tier) + '20', color: getTierColor(item.wallet.current_tier) }}>
                            {(() => {
                              const Icon = tierIcons[item.wallet!.current_tier] ?? Star;
                              return <Icon className="w-3 h-3" />;
                            })()}
                            {item.tier?.tier_label_ar ?? item.wallet.current_tier}
                          </span>
                        ) : (
                          <span className="text-xs text-slate-400">-</span>
                        )}
                      </td>
                      <td className="px-4 py-3.5"><p className="font-mono font-bold text-slate-900 text-sm">{c.total_orders}</p></td>
                      <td className="px-4 py-3.5"><span className="font-mono font-bold text-primary-600 text-sm">{item.wallet?.current_points ?? 0}</span></td>
                      <td className="px-4 py-3.5"><p className="font-mono font-bold text-slate-900 text-sm">{Number(c.total_spent || 0).toFixed(0)} ج.م</p></td>
                      <td className="px-4 py-3.5">{getStatusBadge(c.status)}</td>
                      <td className="px-4 py-3.5">
                        <div className="flex items-center justify-center gap-1.5">
                          <button onClick={() => { setExpandedId(expandedId === c.id ? null : c.id); if (expandedId !== c.id) fetchCustomerDetails(c.id); }} className="p-2 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-600 transition-all" title="عرض التفاصيل">
                            <History className="w-4 h-4" />
                          </button>
                          <button onClick={() => toggleStatus(c.id, c.status)} className={`p-2 rounded-lg transition-all ${c.status === 'blocked' ? 'bg-danger-50 hover:bg-danger-100 text-danger-600' : 'bg-success-50 hover:bg-success-100 text-success-600'}`} title={c.status === 'blocked' ? 'إلغاء الحظر' : 'حظر'}>
                            {c.status === 'blocked' ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>

      {/* Expanded Customer Details */}
      {expandedId && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
          {(() => {
            const item = customers.find(c => c.customer.id === expandedId);
            if (!item) return null;
            const c = item.customer;
            return (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-slate-900">ملف العميل: {c.name}</h3>
                  <button onClick={() => setExpandedId(null)} className="text-slate-400 hover:text-slate-600 p-1">✕</button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-primary-50 rounded-xl p-4 border border-primary-100">
                    <div className="text-primary-700 text-2xl font-bold">{c.total_orders}</div>
                    <div className="text-primary-600 text-sm font-semibold mt-1">إجمالي الطلبات</div>
                  </div>
                  <div className="bg-success-50 rounded-xl p-4 border border-success-100">
                    <div className="text-success-700 text-2xl font-bold">{Number(c.total_spent || 0).toFixed(0)} ج.م</div>
                    <div className="text-success-600 text-sm font-semibold mt-1">إجمالي المدفوعات</div>
                  </div>
                  <div className="bg-amber-50 rounded-xl p-4 border border-amber-100">
                    <div className="text-amber-700 text-2xl font-bold">{item.wallet?.current_points ?? 0}</div>
                    <div className="text-amber-600 text-sm font-semibold mt-1">النقاط الحالية</div>
                  </div>
                  <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
                    <div className="text-slate-700 text-2xl font-bold">{item.wallet?.lifetime_points ?? 0}</div>
                    <div className="text-slate-600 text-sm font-semibold mt-1">إجمالي النقاط</div>
                  </div>
                </div>

                {item.wallet && item.tier && (
                  <div className="flex items-center gap-3 p-4 rounded-xl" style={{ backgroundColor: item.tier.color_hex + '10', border: `1px solid ${item.tier.color_hex}30` }}>
                    {(() => {
                      const Icon = tierIcons[item.wallet.current_tier] ?? Star;
                      return <span style={{ color: item.tier.color_hex }}><Icon className="w-6 h-6" /></span>;
                    })()}
                    <div>
                      <p className="font-bold text-sm" style={{ color: item.tier.color_hex }}>المستوى: {item.tier.tier_label_ar}</p>
                      <p className="text-xs text-slate-500">{item.tier.benefits}</p>
                    </div>
                  </div>
                )}

                {transactions.length > 0 && (
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm mb-2">آخر حركات النقاط</h4>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {transactions.map(tx => (
                        <div key={tx.id} className={`flex items-center justify-between p-2.5 rounded-lg text-xs ${tx.type === 'earned' ? 'bg-success-50' : tx.type === 'redeemed' ? 'bg-primary-50' : 'bg-slate-50'}`}>
                          <span className={`font-bold ${tx.type === 'earned' ? 'text-success-700' : tx.type === 'redeemed' ? 'text-primary-700' : 'text-slate-700'}`}>
                            {tx.type === 'earned' ? '+' : tx.type === 'redeemed' ? '-' : ''}{tx.points} نقطة
                          </span>
                          <span className="text-slate-400">{new Date(tx.created_at).toLocaleDateString('ar-EG')}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })()}
        </motion.div>
      )}
    </div>
  );
}
