import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Users, Coins, Gift, TrendingUp, Star, Crown, Medal, Gem, ChevronLeft, Settings, Tag, Award } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
type CustomerPointsWallet = { id: string; customer_id: string; current_points: number; lifetime_points: number; redeemed_points: number; current_tier: string; [key: string]: any };
type CustomerTier = { id: string; tier_name: string; tier_label_ar: string; min_points: number; max_points?: number; color_hex?: string; benefits?: string; sort_order?: number; [key: string]: any };
type PointsTransaction = { id: string; type: string; points: number; balance_after: number; notes?: string; created_at: string; [key: string]: any };
type RewardRedemption = { id: string; reward_id: string; points_used: number; redemption_code?: string; status: string; created_at: string; reward_catalog?: any; [key: string]: any };

interface LoyaltyMember {
  wallet: CustomerPointsWallet;
  customer: { id: string; name: string; phone: string; total_orders: number; total_spent: number };
  tier: CustomerTier | null;
}

interface LoyaltyStats {
  totalMembers: number;
  totalPointsIssued: number;
  totalPointsRedeemed: number;
  totalRedemptions: number;
  avgPointsPerMember: number;
  topTierCount: number;
}

export default function Loyalty() {
  const { restaurant } = useAuth();
  const [members, setMembers] = useState<LoyaltyMember[]>([]);
  const [stats, setStats] = useState<LoyaltyStats>({
    totalMembers: 0, totalPointsIssued: 0, totalPointsRedeemed: 0,
    totalRedemptions: 0, avgPointsPerMember: 0, topTierCount: 0,
  });
  const [loading, setLoading] = useState(true);
  const [selectedMember, setSelectedMember] = useState<LoyaltyMember | null>(null);
  const [transactions, setTransactions] = useState<PointsTransaction[]>([]);
  const [redemptions, setRedemptions] = useState<RewardRedemption[]>([]);
  const [tiers, setTiers] = useState<CustomerTier[]>([]);

  useEffect(() => {
    if (restaurant) {
      fetchData();
      const sub = supabase
        .channel('loyalty-dashboard')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'customer_points_wallet', filter: `restaurant_id=eq.${restaurant.id}` }, () => fetchData())
        .on('postgres_changes', { event: '*', schema: 'public', table: 'points_transactions', filter: `restaurant_id=eq.${restaurant.id}` }, () => fetchData())
        .subscribe();
      return () => { sub.unsubscribe(); };
    }
  }, [restaurant]);

  async function fetchData() {
    if (!restaurant) return;
    setLoading(true);

    const [walletsRes, tiersRes, redemptionsRes] = await Promise.all([
      supabase.from('customer_points_wallet').select('*, customers(id, name, phone, total_orders, total_spent)').eq('restaurant_id', restaurant.id).order('lifetime_points', { ascending: false }).limit(50),
      supabase.from('customer_tiers').select('*').eq('restaurant_id', restaurant.id).order('sort_order', { ascending: true }),
      supabase.from('reward_redemptions').select('*').eq('restaurant_id', restaurant.id).eq('status', 'approved'),
    ]);

    const wallets = (walletsRes.data ?? []) as any[];
    const tierList = (tiersRes.data ?? []) as CustomerTier[];
    const redemptionList = (redemptionsRes.data ?? []) as RewardRedemption[];

    const mappedMembers: LoyaltyMember[] = wallets.map(w => {
      const c = w.customers;
      const tier = tierList.find(t => t.tier_name === w.current_tier) ?? null;
      return { wallet: w, customer: c, tier };
    });

    const totalPointsIssued = wallets.reduce((s, w) => s + w.lifetime_points, 0);
    const totalPointsRedeemed = wallets.reduce((s, w) => s + w.redeemed_points, 0);
    const topTierCount = wallets.filter(w => w.current_tier === 'platinum' || w.current_tier === 'gold').length;

    setMembers(mappedMembers);
    setTiers(tierList);
    setRedemptions(redemptionList);
    setStats({
      totalMembers: wallets.length,
      totalPointsIssued,
      totalPointsRedeemed,
      totalRedemptions: redemptionList.length,
      avgPointsPerMember: wallets.length > 0 ? Math.round(totalPointsIssued / wallets.length) : 0,
      topTierCount,
    });
    setLoading(false);
  }

  async function fetchMemberDetails(member: LoyaltyMember) {
    if (!restaurant) return;
    setSelectedMember(member);

    const [txRes, redRes] = await Promise.all([
      supabase.from('points_transactions').select('*').eq('restaurant_id', restaurant.id).eq('customer_id', member.customer.id).order('created_at', { ascending: false }).limit(20),
      supabase.from('reward_redemptions').select('*, reward_catalog(name)').eq('restaurant_id', restaurant.id).eq('customer_id', member.customer.id).order('created_at', { ascending: false }).limit(10),
    ]);

    setTransactions((txRes.data ?? []) as PointsTransaction[]);
    setRedemptions((redRes.data ?? []) as any[]);
  }

  const tierIcons: Record<string, React.FC<{ className?: string }>> = {
    bronze: Medal, silver: Star, gold: Crown, platinum: Gem,
  };

  const getTierColor = (tierName: string) => {
    const tier = tiers.find(t => t.tier_name === tierName);
    return tier?.color_hex ?? '#94a3b8';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64" dir="rtl">
        <div className="w-6 h-6 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (selectedMember) {
    return (
      <div className="max-w-4xl mx-auto space-y-5" dir="rtl">
        <button onClick={() => setSelectedMember(null)} className="flex items-center gap-1 text-sm text-primary-600 hover:text-primary-700 font-medium">
          <ChevronLeft className="w-4 h-4" /> العودة للقائمة
        </button>

        <div className="card p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{ backgroundColor: getTierColor(selectedMember.wallet.current_tier) + '20' }}>
              {(() => {
                const Icon = tierIcons[selectedMember.wallet.current_tier] ?? Star;
                return <span style={{ color: getTierColor(selectedMember.wallet.current_tier) }}><Icon className="w-7 h-7" /></span>;
              })()}
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">{selectedMember.customer.name}</h2>
              <p className="text-sm text-slate-500">{selectedMember.customer.phone}</p>
            </div>
            <div className="mr-auto">
              <span className="px-3 py-1 rounded-full text-sm font-bold" style={{ backgroundColor: getTierColor(selectedMember.wallet.current_tier) + '20', color: getTierColor(selectedMember.wallet.current_tier) }}>
                {selectedMember.tier?.tier_label_ar ?? selectedMember.wallet.current_tier}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-primary-50 rounded-xl p-4 border border-primary-100">
              <p className="text-xs text-primary-600 font-medium">النقاط الحالية</p>
              <p className="text-2xl font-bold text-primary-700">{selectedMember.wallet.current_points}</p>
            </div>
            <div className="bg-success-50 rounded-xl p-4 border border-success-100">
              <p className="text-xs text-success-600 font-medium">إجمالي النقاط</p>
              <p className="text-2xl font-bold text-success-700">{selectedMember.wallet.lifetime_points}</p>
            </div>
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
              <p className="text-xs text-slate-600 font-medium">النقاط المستبدلة</p>
              <p className="text-2xl font-bold text-slate-700">{selectedMember.wallet.redeemed_points}</p>
            </div>
            <div className="bg-warning-50 rounded-xl p-4 border border-warning-100">
              <p className="text-xs text-warning-600 font-medium">إجمالي الطلبات</p>
              <p className="text-2xl font-bold text-warning-700">{selectedMember.customer.total_orders}</p>
            </div>
          </div>

          {/* Transactions */}
          <div className="space-y-3">
            <h3 className="font-bold text-slate-900 text-sm">سجل النقاط</h3>
            {transactions.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-4">لا يوجد سجل نقاط</p>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {transactions.map(tx => (
                  <div key={tx.id} className={`flex items-center justify-between p-3 rounded-lg text-xs ${tx.type === 'earned' ? 'bg-success-50 border border-success-100' : tx.type === 'redeemed' ? 'bg-primary-50 border border-primary-100' : 'bg-slate-50 border border-slate-100'}`}>
                    <div>
                      <span className={`font-bold ${tx.type === 'earned' ? 'text-success-700' : tx.type === 'redeemed' ? 'text-primary-700' : 'text-slate-700'}`}>
                        {tx.type === 'earned' ? '+' : tx.type === 'redeemed' ? '-' : ''}{tx.points} نقطة
                      </span>
                      {tx.notes && <p className="text-slate-500 mt-0.5">{tx.notes}</p>}
                    </div>
                    <div className="text-left">
                      <span className="text-slate-400">{new Date(tx.created_at).toLocaleDateString('ar-EG')}</span>
                      <p className="text-slate-500 font-mono">{tx.balance_after}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-5" dir="rtl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">نظام الولاء</h1>
          <p className="text-sm text-slate-500 mt-0.5">تتبع نقاط العملاء والمكافآت</p>
        </div>
        <div className="flex gap-2">
          <Link to="/dashboard/loyalty/settings" className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-sm font-medium text-slate-700 transition-all">
            <Settings className="w-3.5 h-3.5" /> الإعدادات
          </Link>
          <Link to="/dashboard/loyalty/rewards" className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-sm font-medium text-slate-700 transition-all">
            <Tag className="w-3.5 h-3.5" /> المكافآت
          </Link>
          <Link to="/dashboard/loyalty/tiers" className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-sm font-medium text-slate-700 transition-all">
            <Award className="w-3.5 h-3.5" /> المستويات
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'الأعضاء', value: stats.totalMembers, icon: Users, color: 'bg-blue-50 text-blue-600' },
          { label: 'النقاط المصدرة', value: stats.totalPointsIssued, icon: Coins, color: 'bg-success-50 text-success-600' },
          { label: 'النقاط المستبدلة', value: stats.totalPointsRedeemed, icon: Gift, color: 'bg-primary-50 text-primary-600' },
          { label: 'عمليات الاستبدال', value: stats.totalRedemptions, icon: TrendingUp, color: 'bg-amber-50 text-amber-600' },
          { label: 'متوسط النقاط', value: stats.avgPointsPerMember, icon: Star, color: 'bg-purple-50 text-purple-600' },
          { label: 'VIP', value: stats.topTierCount, icon: Crown, color: 'bg-sky-50 text-sky-600' },
        ].map((s) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-7 h-7 ${s.color} rounded-lg flex items-center justify-center`}>
                <s.icon className="w-3.5 h-3.5" />
              </div>
              <span className="text-xs text-slate-500 font-medium">{s.label}</span>
            </div>
            <p className="text-xl font-bold text-slate-900">{s.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Members Table */}
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h2 className="font-bold text-slate-900 text-sm">أعضاء الولاء</h2>
          <span className="text-xs text-slate-400">{members.length} عضو</span>
        </div>

        {members.length === 0 ? (
          <div className="p-12 text-center">
            <Users className="w-10 h-10 text-slate-200 mx-auto mb-3" />
            <p className="text-slate-400 text-sm">لا يوجد أعضاء في نظام الولاء بعد</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50">
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">العميل</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">المستوى</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">النقاط</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">إجمالي الطلبات</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">الإنفاق</th>
                </tr>
              </thead>
              <tbody>
                {members.map((m, idx) => (
                  <motion.tr
                    key={m.wallet.id}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.03 }}
                    className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors cursor-pointer"
                    onClick={() => fetchMemberDetails(m)}
                  >
                    <td className="px-4 py-3.5">
                      <div>
                        <p className="font-semibold text-slate-900 text-sm">{m.customer.name}</p>
                        <p className="text-slate-400 text-xs font-mono">{m.customer.phone}</p>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold" style={{ backgroundColor: getTierColor(m.wallet.current_tier) + '20', color: getTierColor(m.wallet.current_tier) }}>
                        {(() => {
                          const Icon = tierIcons[m.wallet.current_tier] ?? Star;
                          return <Icon className="w-3 h-3" />;
                        })()}
                        {m.tier?.tier_label_ar ?? m.wallet.current_tier}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="font-mono font-bold text-primary-600">{m.wallet.current_points}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="font-mono text-slate-700">{m.customer.total_orders}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="font-mono font-bold text-slate-900">{m.customer.total_spent.toFixed(0)}</span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>
    </div>
  );
}
