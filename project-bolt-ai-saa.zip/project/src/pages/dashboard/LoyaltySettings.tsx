import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Save, Loader2, CheckCircle, ToggleLeft, ToggleRight, Coins, Clock, Gift, Sliders } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
type LoyaltySettings = { id: string; [key: string]: any };

export default function LoyaltySettingsPage() {
  const { restaurant } = useAuth();
  const [settings, setSettings] = useState<LoyaltySettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const [form, setForm] = useState({
    points_per_currency_unit: 1,
    currency_unit: 10,
    points_expiration_days: 365,
    min_redemption_points: 100,
    max_redemption_per_order: 1,
    is_active: true,
  });

  useEffect(() => {
    if (restaurant) fetchSettings();
  }, [restaurant]);

  async function fetchSettings() {
    if (!restaurant) return;
    setLoading(true);
    const { data } = await supabase
      .from('loyalty_settings')
      .select('*')
      .eq('restaurant_id', restaurant.id)
      .maybeSingle();

    if (data) {
      setSettings(data);
      setForm({
        points_per_currency_unit: data.points_per_currency_unit ?? 1,
        currency_unit: data.currency_unit ?? 10,
        points_expiration_days: data.points_expiration_days ?? 365,
        min_redemption_points: data.min_redemption_points ?? 100,
        max_redemption_per_order: data.max_redemption_per_order ?? 1,
        is_active: data.is_active ?? true,
      });
    }
    setLoading(false);
  }

  async function handleSave() {
    if (!restaurant) return;
    setSaving(true);
    setSaved(false);

    const payload = {
      restaurant_id: restaurant.id,
      points_per_currency_unit: form.points_per_currency_unit,
      currency_unit: form.currency_unit,
      points_expiration_days: form.points_expiration_days,
      min_redemption_points: form.min_redemption_points,
      max_redemption_per_order: form.max_redemption_per_order,
      is_active: form.is_active,
      rule_type: 'points_per_spend',
      orders_threshold: 0,
      orders_points: 0,
      amount_threshold: 0,
      amount_points: 0,
    };

    if (settings) {
      const { error } = await supabase.from('loyalty_settings').update(payload).eq('id', settings.id);
      if (error) { console.error('loyalty update error', error); setSaving(false); return; }
    } else {
      const { data: inserted, error } = await supabase.from('loyalty_settings').insert(payload).select('*').maybeSingle();
      if (error) { console.error('loyalty insert error', error); setSaving(false); return; }
      if (inserted) setSettings(inserted);
    }

    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64" dir="rtl">
        <div className="w-6 h-6 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">إعدادات نظام الولاء</h1>
        <p className="text-sm text-slate-500 mt-0.5">تخصيص كيفية كسب واستبدال النقاط</p>
      </div>

      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card p-6 space-y-6">
        {/* Active Toggle */}
        <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
          <div>
            <p className="text-sm font-semibold text-slate-900">تفعيل نظام الولاء</p>
            <p className="text-xs text-slate-500 mt-0.5">عند التعطيل، لن يكسب العملاء نقاطاً جديدة</p>
          </div>
          <button
            onClick={() => setForm(p => ({ ...p, is_active: !p.is_active }))}
            className={`relative w-12 h-7 rounded-full transition-colors ${form.is_active ? 'bg-primary-600' : 'bg-slate-300'}`}
          >
            <motion.div
              layout
              className="absolute top-1 w-5 h-5 bg-white rounded-full shadow"
              animate={{ left: form.is_active ? '1.5rem' : '0.25rem' }}
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
            />
          </button>
        </div>

        {/* Points Calculation */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
            <Coins className="w-4 h-4 text-primary-600" />
            حساب النقاط
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">نقاط لكل وحدة عملة</label>
              <input
                type="number"
                min={0}
                step={0.1}
                value={form.points_per_currency_unit}
                onChange={e => setForm(p => ({ ...p, points_per_currency_unit: parseFloat(e.target.value) || 0 }))}
                className="input-field"
              />
              <p className="text-xs text-slate-400 mt-1">كم نقطة يحصل عليها العميل</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">قيمة الوحدة (ج.م)</label>
              <input
                type="number"
                min={1}
                step={1}
                value={form.currency_unit}
                onChange={e => setForm(p => ({ ...p, currency_unit: parseInt(e.target.value) || 1 }))}
                className="input-field"
              />
              <p className="text-xs text-slate-400 mt-1">كل كم جنيه = نقطة واحدة</p>
            </div>
          </div>
          <div className="bg-primary-50 rounded-xl p-3 border border-primary-100">
            <p className="text-xs text-primary-700">
              مثال: طلب بـ 300 ج.م = {Math.floor(300 / (form.currency_unit || 1) * (form.points_per_currency_unit || 1))} نقطة
            </p>
          </div>
        </div>

        {/* Expiration */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
            <Clock className="w-4 h-4 text-warning-600" />
            صلاحية النقاط
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">مدة صلاحية النقاط (يوم)</label>
            <input
              type="number"
              min={1}
              value={form.points_expiration_days}
              onChange={e => setForm(p => ({ ...p, points_expiration_days: parseInt(e.target.value) || 365 }))}
              className="input-field"
            />
          </div>
        </div>

        {/* Redemption Limits */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
            <Gift className="w-4 h-4 text-success-600" />
            حدود الاستبدال
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">الحد الأدنى للاستبدال</label>
              <input
                type="number"
                min={0}
                value={form.min_redemption_points}
                onChange={e => setForm(p => ({ ...p, min_redemption_points: parseInt(e.target.value) || 0 }))}
                className="input-field"
              />
              <p className="text-xs text-slate-400 mt-1">أقل عدد نقاط لاستبدال مكافأة</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">الحد الأقصى للاستبدال/طلب</label>
              <input
                type="number"
                min={1}
                value={form.max_redemption_per_order}
                onChange={e => setForm(p => ({ ...p, max_redemption_per_order: parseInt(e.target.value) || 1 }))}
                className="input-field"
              />
              <p className="text-xs text-slate-400 mt-1">عدد المكافآت المسموح بها في طلب واحد</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Save */}
      <div className="flex items-center gap-4 pb-4">
        <button onClick={handleSave} disabled={saving} className="btn-primary">
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {saving ? 'جارٍ الحفظ...' : 'حفظ الإعدادات'}
        </button>
        {saved && (
          <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} className="flex items-center gap-2 text-success-600 text-sm font-semibold">
            <CheckCircle className="w-4 h-4" /> تم الحفظ بنجاح
          </motion.div>
        )}
      </div>
    </div>
  );
}
