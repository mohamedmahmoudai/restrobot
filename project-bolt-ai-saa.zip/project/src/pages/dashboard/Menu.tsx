import { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Minus, Printer, Loader2, AlertCircle, Trash2, Pencil, X, Check, Truck, Package, Upload, ChefHat, CheckCircle, Clock } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import type { DeliveryZone } from '../../lib/database.types';

interface Category {
  id: string;
  name: string;
  name_ar?: string;
}

interface Product {
  id: string;
  name: string;
  name_ar?: string;
  price: number;
  category_id: string;
  image_url?: string;
  is_available?: boolean;
}

interface CartItem extends Product {
  quantity: number;
}

interface PosOrder {
  id: string;
  order_number: string;
  items: { name: string; quantity: number; unit_price: number }[];
  subtotal: number;
  delivery_fee: number;
  total: number;
  type: 'dine-in' | 'takeaway' | 'delivery';
  table_number?: string;
  delivery_address?: string;
  delivery_zone_name?: string;
  delivery_customer_name?: string;
  delivery_customer_phone?: string;
  takeaway_customer_name?: string;
  status: string;
  created_at: string;
}

const ALL_CAT: Category = { id: '__all__', name: 'الكل', name_ar: 'الكل' };

const TYPE_BADGE: Record<string, string> = {
  'dine-in': 'badge-success',
  'delivery': 'badge-primary',
  'takeaway': 'badge-warning',
};
const TYPE_LABEL: Record<string, string> = {
  'dine-in': 'صالة',
  'delivery': 'توصيل',
  'takeaway': 'تيك أووي',
};

export default function Menu() {
  const { restaurant } = useAuth();
  const restaurantName = restaurant?.name ?? 'RestroBot';
  const currencySymbol = restaurant?.currency === 'SAR' ? 'ر.س' : restaurant?.currency === 'AED' ? 'د.إ' : restaurant?.currency === 'KWD' ? 'د.ك' : restaurant?.currency === 'USD' ? '$' : 'ج.م';

  const [categories, setCategories] = useState<Category[]>([ALL_CAT]);
  const [products, setProducts] = useState<Product[]>([]);
  const [, setLoadingData] = useState(true);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('__all__');
  const [orderType, setOrderType] = useState<'dine-in' | 'takeaway' | 'delivery'>('dine-in');
  const [tableNumber, setTableNumber] = useState<string>('1');
  const [takeawayName, setTakeawayName] = useState<string>('');
  const [deliveryZones, setDeliveryZones] = useState<DeliveryZone[]>([]);
  const [selectedZoneId, setSelectedZoneId] = useState<string>('');
  const [deliveryAddress, setDeliveryAddress] = useState<string>('');
  const [deliveryCustomerName, setDeliveryCustomerName] = useState<string>('');
  const [deliveryCustomerPhone, setDeliveryCustomerPhone] = useState<string>('');
  const [printingOrderId, setPrintingOrderId] = useState<string | null>(null);
  const [draftOrderId, setDraftOrderId] = useState<string | null>(null);
  const [draftSaving, setDraftSaving] = useState(false);
  const [orderMessage, setOrderMessage] = useState<string | null>(null);
  const [telegramMenuImages, setTelegramMenuImages] = useState<string[]>([]);
  const [uploadingMenuImage, setUploadingMenuImage] = useState(false);
  const menuImageInputRef = useRef<HTMLInputElement>(null);
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [editingCategoryName, setEditingCategoryName] = useState('');
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productForm, setProductForm] = useState({ name: '', price: '', category_id: '', image_data: '' });
  const productImageRef = useRef<HTMLInputElement>(null);
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);
  const productsRef = useRef<Product[]>([]);

  // POS order board state
  const [waitingOrders, setWaitingOrders] = useState<PosOrder[]>([]);
  const [readyOrders, setReadyOrders] = useState<PosOrder[]>([]);
  const [completedOrders, setCompletedOrders] = useState<PosOrder[]>([]);
  const [completedFilter, setCompletedFilter] = useState<'today' | 'week' | 'month' | 'all'>('today');

  useEffect(() => { if (restaurant) { loadZones(); loadMenuData(); } }, [restaurant]);
  useEffect(() => { productsRef.current = products; }, [products]);

  const loadMenuData = useCallback(async () => {
    if (!restaurant) return;
    setLoadingData(true);
    const [{ data: cats }, { data: items }] = await Promise.all([
      supabase.from('menu_categories').select('id, name, name_ar').eq('restaurant_id', restaurant.id).eq('is_active', true).order('sort_order'),
      supabase.from('menu_items').select('id, name, name_ar, price, category_id, image_url').eq('restaurant_id', restaurant.id).eq('is_available', true).order('sort_order'),
    ]);
    setCategories([ALL_CAT, ...(cats ?? [])]);
    setProducts((items ?? []).map(p => ({ ...p, price: Number(p.price) })));
    setLoadingData(false);
    await loadDraft();
    await loadPosOrders();
  }, [restaurant]);

  async function loadZones() {
    if (!restaurant) return;
    const { data } = await supabase.from('delivery_zones').select('*').eq('restaurant_id', restaurant.id).order('created_at');
    setDeliveryZones(data ?? []);
  }

  // ── POS Order helpers ──────────────────────────────────────────────────────

  async function fetchOrderItems(orderId: string) {
    const { data } = await supabase.from('order_items').select('name, quantity, unit_price').eq('order_id', orderId);
    return (data ?? []).map((item: any) => ({ name: item.name, quantity: item.quantity, unit_price: Number(item.unit_price) }));
  }

  function mapOrder(row: any, items: { name: string; quantity: number; unit_price: number }[]): PosOrder {
    const payload = row.raw_payload as any;
    return {
      id: row.id,
      order_number: row.order_number ?? row.id,
      items,
      subtotal: Number(row.subtotal),
      delivery_fee: Number(row.delivery_fee ?? 0),
      total: Number(row.total),
      type: payload?.order_type ?? payload?.type ?? 'takeaway',
      table_number: payload?.table_number,
      delivery_address: row.delivery_address ?? undefined,
      delivery_zone_name: payload?.zone_name,
      delivery_customer_name: payload?.delivery_customer_name,
      delivery_customer_phone: payload?.delivery_customer_phone,
      takeaway_customer_name: payload?.takeaway_customer_name,
      status: row.status,
      created_at: row.created_at,
    };
  }

  async function loadPosOrders() {
    if (!restaurant) return;
    const { data } = await supabase
      .from('orders')
      .select('id, order_number, raw_payload, subtotal, delivery_fee, total, delivery_address, status, created_at')
      .eq('restaurant_id', restaurant.id)
      .eq('channel', 'pos')
      .in('status', ['waiting', 'ready', 'delivered', 'cancelled'])
      .order('created_at', { ascending: false })
      .limit(100);

    if (!data) return;

    const waiting: PosOrder[] = [];
    const ready: PosOrder[] = [];
    const completed: PosOrder[] = [];

    for (const row of data as any[]) {
      const items = await fetchOrderItems(row.id);
      const order = mapOrder(row, items);
      if (row.status === 'waiting') waiting.push(order);
      else if (row.status === 'ready') ready.push(order);
      else if (row.status === 'delivered' || row.status === 'cancelled') completed.push(order);
    }

    setWaitingOrders(waiting);
    setReadyOrders(ready);
    setCompletedOrders(completed);
  }

  // Realtime subscription for POS orders only
  useEffect(() => {
    if (!restaurant) return;
    const channel = supabase
      .channel('pos-orders-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders', filter: `restaurant_id=eq.${restaurant.id}` },
        (payload: any) => {
          if (payload.new?.channel === 'pos') loadPosOrders();
        }
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [restaurant]);

  async function loadDraft() {
    if (!restaurant) return;
    const { data } = await supabase
      .from('orders')
      .select('id, raw_payload, subtotal, delivery_fee, total, notes, delivery_address')
      .eq('restaurant_id', restaurant.id)
      .eq('channel', 'pos')
      .eq('status', 'draft')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (data) {
      setDraftOrderId(data.id);
      const payload = data.raw_payload as any;
      if (payload?.order_type) setOrderType(payload.order_type);
      if (payload?.table_number) setTableNumber(payload.table_number);
      if (payload?.takeaway_customer_name) setTakeawayName(payload.takeaway_customer_name);
      if (payload?.delivery_address) setDeliveryAddress(payload.delivery_address);
      if (payload?.selected_zone_id) setSelectedZoneId(payload.selected_zone_id);
      if (payload?.delivery_customer_name) setDeliveryCustomerName(payload.delivery_customer_name);
      if (payload?.delivery_customer_phone) setDeliveryCustomerPhone(payload.delivery_customer_phone);

      const { data: items } = await supabase
        .from('order_items')
        .select('menu_item_id, name, quantity, unit_price')
        .eq('order_id', data.id);

      if (items && items.length > 0) {
        const cartItems: CartItem[] = items.map((item: any) => {
          const product = productsRef.current.find(p => p.id === item.menu_item_id);
          return {
            id: item.menu_item_id,
            name: product?.name ?? item.name,
            name_ar: product?.name_ar ?? item.name,
            price: Number(item.unit_price),
            category_id: product?.category_id ?? '',
            image_url: product?.image_url,
            is_available: true,
            quantity: item.quantity,
          };
        });
        setCart(cartItems);
      }
    }
  }

  // ── Telegram Menu Images ───────────────────────────────────────────────────
  useEffect(() => {
    if (restaurant) loadTelegramMenuImages();
  }, [restaurant]);

  function loadTelegramMenuImages() {
    const imgs = (restaurant as any)?.telegram_menu_images;
    if (Array.isArray(imgs)) setTelegramMenuImages(imgs);
  }

  async function handleMenuImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !restaurant) return;
    if (telegramMenuImages.length >= 4) {
      setOrderMessage('الحد الأقصى 4 صور للقائمة');
      setTimeout(() => setOrderMessage(null), 2500);
      return;
    }
    setUploadingMenuImage(true);
    try {
      const ext = file.name.split('.').pop() ?? 'jpg';
      const path = `${restaurant.id}/${Date.now()}.${ext}`;
      const { error: uploadError } = await supabase.storage
        .from('telegram-menu-images')
        .upload(path, file, { upsert: false });
      if (uploadError) throw uploadError;
      const { data: urlData } = supabase.storage.from('telegram-menu-images').getPublicUrl(path);
      const newImages = [...telegramMenuImages, urlData.publicUrl];
      const { error: updateError } = await supabase.from('restaurants')
        .update({ telegram_menu_images: newImages })
        .eq('id', restaurant.id);
      if (updateError) throw updateError;
      setTelegramMenuImages(newImages);
    } catch {
      setOrderMessage('فشل رفع الصورة');
      setTimeout(() => setOrderMessage(null), 2500);
    } finally {
      setUploadingMenuImage(false);
      if (menuImageInputRef.current) menuImageInputRef.current.value = '';
    }
  }

  async function handleMenuImageRemove(index: number) {
    if (!restaurant) return;
    const newImages = telegramMenuImages.filter((_, i) => i !== index);
    const { error } = await supabase.from('restaurants')
      .update({ telegram_menu_images: newImages })
      .eq('id', restaurant.id);
    if (!error) setTelegramMenuImages(newImages);
  }

  async function addCategory() {
    if (!newCategoryName.trim() || !restaurant) return;
    const { data } = await supabase.from('menu_categories').insert({
      restaurant_id: restaurant.id,
      name: newCategoryName.trim(),
      name_ar: newCategoryName.trim(),
      is_active: true,
      sort_order: categories.length,
    }).select('id, name, name_ar').maybeSingle();
    if (data) setCategories(prev => [...prev, data]);
    setNewCategoryName('');
    setShowCategoryModal(false);
  }

  async function deleteCategory(id: string) {
    if (id === '__all__' || !restaurant) return;
    await supabase.from('menu_categories').delete().eq('id', id).eq('restaurant_id', restaurant.id);
    setCategories(prev => prev.filter(c => c.id !== id));
    setProducts(prev => prev.filter(p => p.category_id !== id));
    if (activeCategory === id) setActiveCategory('__all__');
  }

  function startRenameCategory(cat: Category) {
    setEditingCategoryId(cat.id);
    setEditingCategoryName(cat.name_ar || cat.name);
  }

  async function commitRenameCategory() {
    if (!editingCategoryName.trim() || !editingCategoryId || !restaurant) return;
    await supabase.from('menu_categories').update({ name: editingCategoryName.trim(), name_ar: editingCategoryName.trim() })
      .eq('id', editingCategoryId).eq('restaurant_id', restaurant.id);
    setCategories(prev => prev.map(c => c.id === editingCategoryId ? { ...c, name: editingCategoryName.trim(), name_ar: editingCategoryName.trim() } : c));
    setEditingCategoryId(null);
    setEditingCategoryName('');
  }

  function openProductModal(product?: Product) {
    setEditingProduct(product ?? null);
    const firstCat = categories.find(c => c.id !== '__all__');
    setProductForm(
      product
        ? { name: product.name_ar || product.name, price: String(product.price), category_id: product.category_id, image_data: '' }
        : { name: '', price: '', category_id: firstCat?.id ?? '', image_data: '' }
    );
    setShowProductModal(true);
  }

  function handleProductImageChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setProductForm(prev => ({ ...prev, image_data: reader.result as string }));
    reader.readAsDataURL(file);
  }

  async function saveProduct() {
    if (!productForm.name.trim() || !productForm.price || !restaurant) return;
    const payload = {
      name: productForm.name.trim(),
      name_ar: productForm.name.trim(),
      price: parseFloat(productForm.price),
      category_id: productForm.category_id,
      is_available: true,
    };
    if (editingProduct) {
      const { data } = await supabase.from('menu_items').update(payload).eq('id', editingProduct.id).eq('restaurant_id', restaurant.id).select('id, name, name_ar, price, category_id, image_url').maybeSingle();
      if (data) {
        const updated: Product = { ...data, price: Number(data.price) };
        setProducts(prev => prev.map(p => p.id === editingProduct.id ? updated : p));
        setCart(prev => prev.map(ci => ci.id === editingProduct.id ? { ...updated, quantity: ci.quantity } : ci));
      }
    } else {
      const { data } = await supabase.from('menu_items').insert({ ...payload, restaurant_id: restaurant.id, sort_order: products.length }).select('id, name, name_ar, price, category_id, image_url').maybeSingle();
      if (data) setProducts(prev => [...prev, { ...data, price: Number(data.price) }]);
    }
    setShowProductModal(false);
  }

  function requestDeleteProduct(id: string) { setDeleteTargetId(id); }

  async function confirmDeleteProduct() {
    if (!deleteTargetId || !restaurant) return;
    await supabase.from('menu_items').delete().eq('id', deleteTargetId).eq('restaurant_id', restaurant.id);
    setProducts(prev => prev.filter(p => p.id !== deleteTargetId));
    setCart(prev => prev.filter(ci => ci.id !== deleteTargetId));
    setDeleteTargetId(null);
  }

  // ── Draft persistence ──────────────────────────────────────────────────────

  function resolveDeliveryFee(): { fee: number; zoneName: string } {
    if (!selectedZoneId) {
      const addr = deliveryAddress.trim().toLowerCase();
      const match = deliveryZones.find(z => addr.includes(z.name.toLowerCase()) || z.name.toLowerCase().includes(addr.split(' ')[0]));
      if (match) return { fee: Number(match.price), zoneName: match.name };
      return { fee: 0, zoneName: '' };
    }
    const zone = deliveryZones.find(z => z.id === selectedZoneId);
    return zone ? { fee: Number(zone.price), zoneName: zone.name } : { fee: 0, zoneName: '' };
  }

  function buildPayload() {
    const zoneName = orderType === 'delivery' ? resolveDeliveryFee().zoneName : '';
    return {
      type: orderType,
      order_type: orderType,
      table_number: tableNumber,
      takeaway_customer_name: takeawayName,
      zone_name: zoneName,
      selected_zone_id: selectedZoneId,
      delivery_customer_name: deliveryCustomerName,
      delivery_customer_phone: deliveryCustomerPhone,
    };
  }

  async function saveDraft(cartItems: CartItem[]) {
    if (!restaurant) return;
    if (cartItems.length === 0) {
      if (draftOrderId) {
        await supabase.from('order_items').delete().eq('order_id', draftOrderId);
        await supabase.from('orders').delete().eq('id', draftOrderId);
        setDraftOrderId(null);
      }
      return;
    }

    setDraftSaving(true);
    const subtotal = cartItems.reduce((s, i) => s + i.price * i.quantity, 0);
    const fee = orderType === 'delivery' ? resolveDeliveryFee().fee : 0;
    const total = subtotal + fee;
    const notes = orderType === 'dine-in' ? `طاولة: ${tableNumber}` : orderType === 'delivery' ? `توصيل: ${deliveryAddress}` : takeawayName ? `تيك أووي: ${takeawayName}` : 'تيك أووي';
    const payload = buildPayload();

    if (draftOrderId) {
      await supabase.from('orders').update({
        subtotal, discount: 0, total, delivery_fee: fee,
        delivery_address: deliveryAddress || '',
        notes, raw_payload: payload,
      }).eq('id', draftOrderId);
      await supabase.from('order_items').delete().eq('order_id', draftOrderId);
      await supabase.from('order_items').insert(
        cartItems.map(item => ({
          order_id: draftOrderId,
          menu_item_id: item.id,
          name: item.name_ar || item.name,
          quantity: item.quantity,
          unit_price: item.price,
          total_price: item.price * item.quantity,
        }))
      );
    } else {
      const orderNumber = `POS-${Date.now().toString(36).toUpperCase()}`;
      const { data: order } = await supabase.from('orders').insert({
        restaurant_id: restaurant.id,
        order_number: orderNumber,
        status: 'draft',
        channel: 'pos',
        subtotal, discount: 0, total, delivery_fee: fee,
        delivery_address: deliveryAddress || '',
        notes, payment_method: 'cash',
        raw_payload: payload,
      }).select('id').maybeSingle();

      if (order) {
        setDraftOrderId(order.id);
        await supabase.from('order_items').insert(
          cartItems.map(item => ({
            order_id: order.id,
            menu_item_id: item.id,
            name: item.name_ar || item.name,
            quantity: item.quantity,
            unit_price: item.price,
            total_price: item.price * item.quantity,
          }))
        );
      }
    }
    setDraftSaving(false);
  }

  async function deleteDraft() {
    if (!draftOrderId) return;
    await supabase.from('order_items').delete().eq('order_id', draftOrderId);
    await supabase.from('orders').delete().eq('id', draftOrderId);
    setDraftOrderId(null);
    setCart([]);
    setTakeawayName('');
    setOrderMessage('تم حذف الطلب');
    setTimeout(() => setOrderMessage(null), 2500);
  }

  function addToCart(product: Product) {
    const newCart = (() => {
      const existing = cart.find(ci => ci.id === product.id);
      if (existing) return cart.map(ci => ci.id === product.id ? { ...ci, quantity: ci.quantity + 1 } : ci);
      return [...cart, { ...product, quantity: 1 }];
    })();
    setCart(newCart);
    saveDraft(newCart);
  }

  function updateQuantity(itemId: string, quantity: number) {
    const newCart = quantity <= 0
      ? cart.filter(ci => ci.id !== itemId)
      : cart.map(ci => ci.id === itemId ? { ...ci, quantity } : ci);
    setCart(newCart);
    saveDraft(newCart);
  }

  async function confirmOrder() {
    if (cart.length === 0) { setOrderMessage('الرجاء إضافة منتجات أولاً'); setTimeout(() => setOrderMessage(null), 2500); return; }
    if (orderType === 'dine-in' && !tableNumber.trim()) { setOrderMessage('الرجاء إدخال رقم الطاولة'); setTimeout(() => setOrderMessage(null), 2500); return; }
    if (orderType === 'delivery' && !deliveryAddress.trim()) { setOrderMessage('الرجاء إدخال عنوان التوصيل'); setTimeout(() => setOrderMessage(null), 2500); return; }
    if (!restaurant) return;

    const subtotal = cart.reduce((s, i) => s + i.price * i.quantity, 0);
    const fee = orderType === 'delivery' ? resolveDeliveryFee().fee : 0;
    const total = subtotal + fee;
    const payload = buildPayload();

    if (draftOrderId) {
      await supabase.from('orders').update({
        status: 'waiting',
        subtotal, discount: 0, total, delivery_fee: fee,
        delivery_address: deliveryAddress || '',
        raw_payload: payload,
      }).eq('id', draftOrderId);
      await supabase.from('order_items').delete().eq('order_id', draftOrderId);
      await supabase.from('order_items').insert(
        cart.map(item => ({
          order_id: draftOrderId,
          menu_item_id: item.id,
          name: item.name_ar || item.name,
          quantity: item.quantity,
          unit_price: item.price,
          total_price: item.price * item.quantity,
        }))
      );
    } else {
      const orderNumber = `POS-${Date.now().toString(36).toUpperCase()}`;
      const { data: order } = await supabase.from('orders').insert({
        restaurant_id: restaurant.id,
        order_number: orderNumber,
        status: 'waiting',
        channel: 'pos',
        subtotal, discount: 0, total, delivery_fee: fee,
        delivery_address: deliveryAddress || '',
        payment_method: 'cash',
        raw_payload: payload,
      }).select('id').maybeSingle();
      if (order) {
        await supabase.from('order_items').insert(
          cart.map(item => ({
            order_id: order.id,
            menu_item_id: item.id,
            name: item.name_ar || item.name,
            quantity: item.quantity,
            unit_price: item.price,
            total_price: item.price * item.quantity,
          }))
        );
      }
    }

    setCart([]);
    setDraftOrderId(null);
    setTakeawayName('');
    if (orderType === 'dine-in') setTableNumber(t => String((parseInt(t) || 0) + 1));
    if (orderType === 'delivery') { setDeliveryAddress(''); setSelectedZoneId(''); setDeliveryCustomerName(''); setDeliveryCustomerPhone(''); }
    setOrderMessage('تم تأكيد الطلب!');
    setTimeout(() => setOrderMessage(null), 2500);
    loadPosOrders();
  }

  // ── Status transitions ─────────────────────────────────────────────────────

  async function markReady(orderId: string) {
    await supabase.from('orders').update({ status: 'ready' }).eq('id', orderId);
    loadPosOrders();
  }

  async function markDelivered(orderId: string) {
    await supabase.from('orders').update({ status: 'delivered' }).eq('id', orderId);
    loadPosOrders();
  }

  async function cancelPosOrder(orderId: string) {
    await supabase.from('orders').update({ status: 'cancelled' }).eq('id', orderId);
    loadPosOrders();
  }

  async function clearCompletedHistory() {
    if (!restaurant) return;
    const ids = filteredCompleted.map(o => o.id);
    if (ids.length === 0) return;
    await supabase.from('order_items').delete().in('order_id', ids);
    await supabase.from('orders').delete().in('id', ids).eq('channel', 'pos').in('status', ['delivered', 'cancelled']);
    setOrderMessage('تم مسح السجل');
    setTimeout(() => setOrderMessage(null), 2500);
    loadPosOrders();
  }

  // ── Printing ───────────────────────────────────────────────────────────────

  function printReceipt(order: PosOrder) {
    setPrintingOrderId(order.id);
    setTimeout(() => {
      const win = window.open('', '_blank', 'width=520,height=780');
      if (!win) { setPrintingOrderId(null); return; }

      const itemsHtml = order.items
        .map(item => `<div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f1f5f9;font-size:13px;"><span>${item.quantity}x ${item.name}</span><span style="font-weight:600;">${(item.unit_price * item.quantity).toFixed(2)} ${currencySymbol}</span></div>`)
        .join('');

      const deliveryHtml = order.type === 'delivery' ? `
        <div style="margin:10px 0;padding:10px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;">
          <div style="font-weight:700;color:#065f46;font-size:12px;margin-bottom:4px;">توصيل</div>
          ${order.delivery_customer_name ? `<div style="font-size:12px;color:#333;font-weight:700;">${order.delivery_customer_name}</div>` : ''}
          ${order.delivery_customer_phone ? `<div style="font-size:12px;color:#555;margin-top:2px;">${order.delivery_customer_phone}</div>` : ''}
          <div style="font-size:12px;color:#333;margin-top:4px;">عنوان: <strong>${order.delivery_address ?? '-'}</strong></div>
          ${order.delivery_zone_name ? `<div style="font-size:12px;color:#555;margin-top:2px;">المنطقة: ${order.delivery_zone_name}</div>` : ''}
          <div style="display:flex;justify-content:space-between;margin-top:6px;padding-top:6px;border-top:1px solid #dcfce7;font-size:12px;">
            <span>خدمة التوصيل</span><span style="font-weight:700;">${order.delivery_fee.toFixed(2)} ${currencySymbol}</span>
          </div>
        </div>` : '';

      const takeawayHtml = order.type === 'takeaway' && order.takeaway_customer_name ? `
        <div style="margin:10px 0;padding:8px;background:#fef3c7;border:1px solid #fde68a;border-radius:8px;">
          <div style="font-weight:700;color:#92400e;font-size:12px;">تيك أووي — ${order.takeaway_customer_name}</div>
        </div>` : '';

      const subtotalLine = order.delivery_fee > 0
        ? `<div style="display:flex;justify-content:space-between;padding:4px 0;font-size:12px;color:#64748b;"><span>المجموع الفرعي:</span><span style="font-family:monospace;">${order.subtotal.toFixed(2)} ${currencySymbol}</span></div>
           <div style="display:flex;justify-content:space-between;padding:4px 0;font-size:12px;color:#64748b;"><span>خدمة التوصيل:</span><span style="font-family:monospace;">${order.delivery_fee.toFixed(2)} ${currencySymbol}</span></div>`
        : '';

      const typeBadge = order.type === 'dine-in'
        ? '<span style="display:inline-block;background:#d1fae5;color:#065f46;padding:2px 8px;border-radius:20px;font-size:10px;font-weight:600;">صالة</span>'
        : order.type === 'delivery'
        ? '<span style="display:inline-block;background:#fef3c7;color:#92400e;padding:2px 8px;border-radius:20px;font-size:10px;font-weight:600;">توصيل</span>'
        : '<span style="display:inline-block;background:#fef3c7;color:#92400e;padding:2px 8px;border-radius:20px;font-size:10px;font-weight:600;">تيك أووي</span>';

      win.document.write(`<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <title>فاتورة #${order.order_number.slice(-6)}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;600;700&display=swap');
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'IBM Plex Sans Arabic', Arial, sans-serif; direction: rtl; background: #f8fafc; padding: 24px; font-size: 13px; color: #0f172a; }
    .receipt { background: white; padding: 24px; border-radius: 12px; max-width: 400px; margin: 0 auto; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
    .logo-row { text-align: center; margin-bottom: 14px; }
    .restaurant-name { font-size: 18px; font-weight: 700; color: #2563eb; }
    .divider { border: none; border-top: 1px solid #e5e7eb; margin: 12px 0; }
    .meta-row { display: flex; justify-content: space-between; padding: 3px 0; color: #64748b; font-size: 11px; }
    .total-row { display: flex; justify-content: space-between; padding: 10px 0; font-weight: 700; font-size: 15px; color: #0f172a; border-top: 2px solid #e5e7eb; margin-top: 8px; }
    .footer { text-align: center; color: #94a3b8; font-size: 11px; margin-top: 16px; padding-top: 12px; border-top: 1px dashed #e5e7eb; }
  </style>
</head>
<body>
  <div class="receipt">
    <div class="logo-row">
      <div class="restaurant-name">${restaurantName}</div>
      <div style="color:#94a3b8;font-size:11px;margin-top:2px;">نقطة بيع</div>
    </div>
    <div class="divider"></div>
    <div class="meta-row"><span>رقم الفاتورة:</span><span><strong>#${order.order_number.slice(-6)}</strong></span></div>
    <div class="meta-row"><span>التاريخ:</span><span>${new Date(order.created_at).toLocaleString('ar-EG')}</span></div>
    ${order.type === 'dine-in' ? `<div class="meta-row"><span>الطاولة:</span><span><strong>${order.table_number ?? '-'}</strong></span></div>` : ''}
    <div class="meta-row"><span>نوع الطلب:</span><span>${typeBadge}</span></div>
    <div class="divider"></div>
    <div style="font-weight:700;font-size:11px;color:#94a3b8;margin-bottom:6px;">المنتجات</div>
    <div>${itemsHtml}</div>
    ${takeawayHtml}
    ${deliveryHtml}
    <div class="divider"></div>
    ${subtotalLine}
    <div class="total-row"><span>الإجمالي:</span><span>${order.total.toFixed(2)} ${currencySymbol}</span></div>
    <div class="footer">
      <p>شكراً لزيارتكم <strong>${restaurantName}</strong></p>
      <p>RestroBot</p>
    </div>
  </div>
  <script>window.onload = function(){ window.print(); }</script>
</body>
</html>`);
      win.document.close();
      setPrintingOrderId(null);
    }, 350);
  }

  // ── Derived ─────────────────────────────────────────────────────────────────

  const filtered = activeCategory === '__all__' ? products : products.filter(p => p.category_id === activeCategory);
  const cartSubtotal = cart.reduce((s, i) => s + i.price * i.quantity, 0);
  const currentDeliveryFee = orderType === 'delivery' ? resolveDeliveryFee().fee : 0;
  const cartTotal = cartSubtotal + currentDeliveryFee;

  const filteredCompleted = (() => {
    const now = new Date();
    const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startWeek = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6);
    const startMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    return completedOrders.filter(o => {
      const d = new Date(o.created_at);
      if (completedFilter === 'today') return d >= startToday;
      if (completedFilter === 'week') return d >= startWeek;
      if (completedFilter === 'month') return d >= startMonth;
      return true;
    });
  })();

  // ── Order card sub-component ────────────────────────────────────────────────

  function OrderCard({ order, section }: { order: PosOrder; section: 'waiting' | 'ready' | 'completed' }) {
    return (
      <div className="flex-shrink-0 w-64 card p-3 space-y-2.5">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="font-mono text-xs text-slate-500">{order.order_number.slice(-8)}</p>
            <span className={`inline-block mt-1 px-2 py-0.5 rounded-lg text-xs font-semibold ${TYPE_BADGE[order.type] ?? 'badge-warning'}`}>
              {TYPE_LABEL[order.type] ?? order.type}
            </span>
          </div>
          {section === 'completed' && order.status === 'cancelled' && (
            <span className="badge-danger text-xs">ملغي</span>
          )}
        </div>

        {order.table_number && (
          <div className="text-xs text-slate-600 bg-slate-50 rounded-lg px-2 py-1">طاولة: <strong>{order.table_number}</strong></div>
        )}
        {order.takeaway_customer_name && (
          <div className="text-xs text-slate-600 bg-slate-50 rounded-lg px-2 py-1">العميل: <strong>{order.takeaway_customer_name}</strong></div>
        )}
        {order.delivery_customer_name && (
          <div className="text-xs text-slate-600 bg-primary-50 rounded-lg px-2 py-1">{order.delivery_customer_name} {order.delivery_customer_phone && `— ${order.delivery_customer_phone}`}</div>
        )}
        {order.delivery_address && (
          <div className="text-xs text-slate-500 bg-slate-50 border border-slate-100 rounded-lg px-2 py-1 truncate">{order.delivery_address}</div>
        )}

        <div className="bg-slate-50 rounded-xl p-2 space-y-0.5 max-h-28 overflow-y-auto border border-slate-100">
          {order.items.map((item, idx) => (
            <div key={idx} className="flex justify-between text-xs text-slate-700">
              <span>{item.quantity}× {item.name}</span>
              <span className="font-mono text-slate-500">{(item.unit_price * item.quantity).toFixed(0)}</span>
            </div>
          ))}
          {order.delivery_fee > 0 && (
            <div className="flex justify-between text-xs text-primary-600 border-t border-primary-100 pt-1 mt-1">
              <span>خدمة التوصيل</span>
              <span className="font-mono">{order.delivery_fee.toFixed(0)}</span>
            </div>
          )}
        </div>

        <div className="flex justify-between items-center border-t border-slate-100 pt-2">
          <span className="text-xs text-slate-500">الإجمالي</span>
          <span className="font-mono font-bold text-sm text-primary-700">{order.total.toFixed(0)} {currencySymbol}</span>
        </div>

        <div className="flex gap-1.5">
          <button onClick={() => printReceipt(order)} disabled={printingOrderId === order.id} className="flex-1 py-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 font-bold rounded-xl text-xs flex items-center justify-center gap-1 transition-colors disabled:opacity-50">
            {printingOrderId === order.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Printer className="w-3 h-3" />}
            طباعة
          </button>
          {section === 'waiting' && (
            <>
              <button onClick={() => markReady(order.id)} className="flex-1 py-1.5 bg-success-50 text-success-700 hover:bg-success-100 font-bold rounded-xl text-xs flex items-center justify-center gap-1 transition-colors">
                <CheckCircle className="w-3 h-3" /> جاهز
              </button>
              <button onClick={() => cancelPosOrder(order.id)} className="px-2 py-1.5 bg-danger-50 text-danger-600 hover:bg-danger-100 font-bold rounded-xl text-xs transition-colors">
                <X className="w-3 h-3" />
              </button>
            </>
          )}
          {section === 'ready' && (
            <>
              <button onClick={() => markDelivered(order.id)} className="flex-1 py-1.5 bg-success-600 text-white hover:bg-success-700 font-bold rounded-xl text-xs flex items-center justify-center gap-1 transition-colors">
                <CheckCircle className="w-3 h-3" /> تسليم
              </button>
              <button onClick={() => cancelPosOrder(order.id)} className="px-2 py-1.5 bg-danger-50 text-danger-600 hover:bg-danger-100 font-bold rounded-xl text-xs transition-colors">
                <X className="w-3 h-3" />
              </button>
            </>
          )}
        </div>

      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-4" dir="rtl">
      {/* Header row: title + Telegram images (compact, top-left) */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">نقطة البيع</h1>
          <p className="text-sm text-slate-500 mt-0.5">إدارة الطلبات والقوائم</p>
        </div>

        {/* Telegram Menu Images — compact, ~25% smaller */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between gap-3">
            <h2 className="font-bold text-slate-900 text-xs">صور قائمة تيليجرام</h2>
            <span className="text-xs text-slate-400">{telegramMenuImages.length}/4</span>
          </div>
          <div className="flex gap-2 flex-wrap">
            {telegramMenuImages.map((url, idx) => (
              <div key={idx} className="relative w-16 h-16 rounded-lg overflow-hidden border border-slate-200 flex-shrink-0">
                <img src={url} alt={`menu-${idx}`} className="w-full h-full object-cover" />
                <button
                  onClick={() => handleMenuImageRemove(idx)}
                  className="absolute top-0.5 right-0.5 w-4 h-4 bg-danger-500 text-white rounded-full flex items-center justify-center hover:bg-danger-600 transition-colors"
                >
                  <X className="w-2.5 h-2.5" />
                </button>
              </div>
            ))}
            {telegramMenuImages.length < 4 && (
              <button
                onClick={() => menuImageInputRef.current?.click()}
                disabled={uploadingMenuImage}
                className="w-16 h-16 rounded-lg border-2 border-dashed border-slate-300 hover:border-primary-400 hover:bg-primary-50 flex flex-col items-center justify-center gap-0.5 text-slate-400 hover:text-primary-600 transition-all disabled:opacity-50 flex-shrink-0"
              >
                {uploadingMenuImage ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                <span className="text-xs">{uploadingMenuImage ? '...' : 'إضافة'}</span>
              </button>
            )}
          </div>
          <input ref={menuImageInputRef} type="file" accept="image/*" className="hidden" onChange={handleMenuImageUpload} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-10 gap-4">
        {/* LEFT: Catalog */}
        <div className="lg:col-span-7 space-y-4">
          {/* Categories */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-slate-900 text-sm">الفئات</h2>
              <button onClick={() => setShowCategoryModal(true)} className="p-1.5 rounded-lg bg-primary-50 hover:bg-primary-100 text-primary-600 transition-colors" title="إضافة فئة">
                <Plus className="w-4 h-4" />
              </button>
            </div>
            <div className="flex gap-2 flex-wrap">
              <AnimatePresence mode="popLayout">
                {categories.map(cat => (
                  <motion.div key={cat.id} layout initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} className="relative group">
                    {editingCategoryId === cat.id ? (
                      <div className="flex items-center gap-1 bg-white border-2 border-primary-500 rounded-xl px-2 py-1 shadow-sm">
                        <input autoFocus value={editingCategoryName} onChange={e => setEditingCategoryName(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') commitRenameCategory(); if (e.key === 'Escape') setEditingCategoryId(null); }} className="text-sm font-semibold text-slate-900 bg-transparent outline-none w-24" />
                        <button onClick={commitRenameCategory} className="text-success-600 hover:text-success-700"><Check className="w-3.5 h-3.5" /></button>
                        <button onClick={() => setEditingCategoryId(null)} className="text-slate-400 hover:text-slate-600"><X className="w-3.5 h-3.5" /></button>
                      </div>
                    ) : (
                      <button onClick={() => setActiveCategory(cat.id)} onDoubleClick={() => cat.id !== '__all__' && startRenameCategory(cat)} className={`px-4 py-2 rounded-xl font-semibold text-sm whitespace-nowrap transition-all ${activeCategory === cat.id ? 'bg-primary-600 text-white shadow-md shadow-primary-500/20' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'}`}>
                        {cat.name_ar || cat.name}
                      </button>
                    )}
                    {cat.id !== '__all__' && editingCategoryId !== cat.id && (
                      <div className="absolute -top-8 right-0 bg-white border border-slate-200 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity flex gap-1 p-1 z-10 pointer-events-none group-hover:pointer-events-auto">
                        <button onClick={() => startRenameCategory(cat)} className="p-1 hover:bg-slate-50 rounded" title="تعديل"><Pencil className="w-3 h-3 text-slate-600" /></button>
                        <button onClick={() => deleteCategory(cat.id)} className="p-1 hover:bg-danger-50 rounded" title="حذف"><Trash2 className="w-3 h-3 text-danger-500" /></button>
                      </div>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          {/* Products Grid */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-slate-900 text-sm">المنتجات</h2>
              <button onClick={() => openProductModal()} className="px-3 py-1.5 text-sm bg-primary-50 hover:bg-primary-100 text-primary-700 rounded-xl font-semibold transition-all flex items-center gap-1.5">
                <Plus className="w-3.5 h-3.5" /> منتج جديد
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <AnimatePresence mode="popLayout">
                {filtered.map((item, idx) => (
                  <motion.div key={item.id} layout initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} transition={{ delay: idx * 0.03 }} className="group relative">
                    <div onClick={() => addToCart(item)} className="card p-3 cursor-pointer card-hover h-full flex flex-col">
                      <div className="h-16 bg-slate-50 rounded-xl overflow-hidden flex items-center justify-center mb-3">
                        {item.image_url ? <img src={item.image_url} alt={item.name_ar || item.name} className="w-full h-full object-cover" /> : <Package className="w-6 h-6 text-slate-300" />}
                      </div>
                      <p className="font-bold text-sm text-slate-900 line-clamp-2 flex-1">{item.name_ar || item.name}</p>
                      <div className="flex items-center justify-between pt-2 mt-2 border-t border-slate-100">
                        <span className="font-mono font-bold text-primary-600 text-sm">{item.price.toFixed(0)} {currencySymbol}</span>
                        <Plus className="w-4 h-4 text-primary-500" />
                      </div>
                    </div>
                    <div className="absolute top-2 left-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 backdrop-blur-sm rounded-lg shadow p-0.5 pointer-events-none group-hover:pointer-events-auto">
                      <button onClick={e => { e.stopPropagation(); openProductModal(item); }} className="p-1 hover:bg-slate-50 rounded" title="تعديل"><Pencil className="w-3.5 h-3.5 text-slate-600" /></button>
                      <button onClick={e => { e.stopPropagation(); requestDeleteProduct(item.id); }} className="p-1 hover:bg-danger-50 rounded" title="حذف"><Trash2 className="w-3.5 h-3.5 text-danger-500" /></button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          {/* ── Waiting For Preparation ── */}
          <AnimatePresence>
            {waitingOrders.length > 0 && (
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }} className="space-y-3 pt-2">
                <div className="flex items-center gap-2">
                  <ChefHat className="w-4 h-4 text-warning-600" />
                  <h2 className="font-bold text-slate-900 text-sm">طلبات التجهيز</h2>
                  <span className="text-xs text-slate-400">({waitingOrders.length})</span>
                </div>
                <div className="flex gap-3 overflow-x-auto pb-2">
                  <AnimatePresence mode="popLayout">
                    {waitingOrders.map(order => (
                      <motion.div key={order.id} layout initial={{ opacity: 0, scale: 0.95, x: 20 }} animate={{ opacity: 1, scale: 1, x: 0 }} exit={{ opacity: 0, scale: 0.95, x: -20 }}>
                        <OrderCard order={order} section="waiting" />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* ── Ready To Deliver ── */}
          <AnimatePresence>
            {readyOrders.length > 0 && (
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }} className="space-y-3 pt-2">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-success-600" />
                  <h2 className="font-bold text-slate-900 text-sm">جاهزة للتسليم</h2>
                  <span className="text-xs text-slate-400">({readyOrders.length})</span>
                </div>
                <div className="flex gap-3 overflow-x-auto pb-2">
                  <AnimatePresence mode="popLayout">
                    {readyOrders.map(order => (
                      <motion.div key={order.id} layout initial={{ opacity: 0, scale: 0.95, x: 20 }} animate={{ opacity: 1, scale: 1, x: 0 }} exit={{ opacity: 0, scale: 0.95, x: -20 }}>
                        <OrderCard order={order} section="ready" />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* ── Completed Orders (compact table, bottom) ── */}
          <AnimatePresence>
            {completedOrders.length > 0 && (
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }} className="space-y-3 pt-2">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-slate-500" />
                    <h2 className="font-bold text-slate-900 text-sm">الطلبات المكتملة</h2>
                    <span className="text-xs text-slate-400">({filteredCompleted.length})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1 bg-slate-100 rounded-lg p-0.5">
                      {([
                        { key: 'today' as const, label: 'اليوم' },
                        { key: 'week' as const, label: 'الأسبوع' },
                        { key: 'month' as const, label: 'الشهر' },
                        { key: 'all' as const, label: 'الكل' },
                      ]).map(f => (
                        <button key={f.key} onClick={() => setCompletedFilter(f.key)} className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-all ${completedFilter === f.key ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
                          {f.label}
                        </button>
                      ))}
                    </div>
                    <button onClick={clearCompletedHistory} title="مسح السجل" className="p-1.5 bg-danger-50 text-danger-600 hover:bg-danger-100 rounded-lg transition-colors">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <div className="card overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-slate-50">
                        <tr>
                          <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">رقم الطلب</th>
                          <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">النوع</th>
                          <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">اسم العميل</th>
                          <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">عدد الأصناف</th>
                          <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">الإجمالي</th>
                          <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">التاريخ</th>
                          <th className="px-4 py-3 text-center text-xs font-bold text-slate-700">طباعة</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredCompleted.map(order => (
                          <tr key={order.id} className="border-b border-slate-50 hover:bg-slate-50">
                            <td className="px-4 py-3 font-mono text-xs text-slate-700">#{order.order_number.slice(-8)}</td>
                            <td className="px-4 py-3">
                              <span className={`inline-block px-2 py-0.5 rounded-lg text-xs font-semibold ${TYPE_BADGE[order.type] ?? 'badge-warning'}`}>
                                {TYPE_LABEL[order.type] ?? order.type}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-xs text-slate-700">
                              {order.type === 'dine-in'
                                ? `طاولة رقم ${order.table_number ?? '-'}`
                                : order.type === 'delivery'
                                ? (order.delivery_customer_name || 'عميل')
                                : (order.takeaway_customer_name || 'عميل')}
                            </td>
                            <td className="px-4 py-3 text-xs text-slate-600">{order.items.length} أصناف</td>
                            <td className="px-4 py-3 font-semibold text-slate-900">{order.total.toFixed(0)} {currencySymbol}</td>
                            <td className="px-4 py-3 text-xs text-slate-500">{new Date(order.created_at).toLocaleDateString('ar-EG')}</td>
                            <td className="px-4 py-3 text-center">
                              <button onClick={() => printReceipt(order)} disabled={printingOrderId === order.id} className="p-1.5 bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200 transition-colors disabled:opacity-50">
                                {printingOrderId === order.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* RIGHT: Checkout (Current Order) */}
        <div className="lg:col-span-3">
          <div className="sticky top-4 space-y-3">
            <div className="card p-4 space-y-3">
              {/* Order type */}
              <div className="space-y-1.5">
                <p className="text-xs font-semibold text-slate-600">نوع الطلب:</p>
                <div className="grid grid-cols-3 gap-1.5">
                  {([
                    { key: 'dine-in' as const, label: 'في الصالة', activeCls: 'bg-success-50 text-success-700 border-success-200' },
                    { key: 'takeaway' as const, label: 'تيك أووي', activeCls: 'bg-warning-50 text-warning-700 border-warning-200' },
                    { key: 'delivery' as const, label: 'توصيل', activeCls: 'bg-primary-50 text-primary-700 border-primary-200' },
                  ]).map(t => (
                    <button key={t.key} onClick={() => setOrderType(t.key)} className={`py-1.5 rounded-lg text-xs font-semibold transition-all border ${orderType === t.key ? t.activeCls : 'bg-slate-50 text-slate-600 border-slate-200'}`}>
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <AnimatePresence initial={false}>
                {orderType === 'dine-in' && (
                  <motion.div key="table" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                    <p className="text-xs font-semibold text-slate-600 mb-1">رقم الطاولة:</p>
                    <input type="text" value={tableNumber} onChange={e => setTableNumber(e.target.value)} placeholder="مثال: 5" className="input-field" />
                  </motion.div>
                )}
                {orderType === 'takeaway' && (
                  <motion.div key="takeaway" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                    <p className="text-xs font-semibold text-slate-600 mb-1">اسم العميل (اختياري):</p>
                    <input type="text" value={takeawayName} onChange={e => setTakeawayName(e.target.value)} placeholder="اسم العميل" className="input-field" />
                  </motion.div>
                )}
                {orderType === 'delivery' && (
                  <motion.div key="delivery" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden space-y-2">
                    <div>
                      <p className="text-xs font-semibold text-slate-600 mb-1">عنوان التوصيل:</p>
                      <input type="text" value={deliveryAddress} onChange={e => setDeliveryAddress(e.target.value)} placeholder="مثال: ١٥ شارع المعادي" className="input-field" />
                    </div>
                    {deliveryZones.length > 0 && (
                      <div>
                        <p className="text-xs font-semibold text-slate-600 mb-1">المنطقة:</p>
                        <select value={selectedZoneId} onChange={e => setSelectedZoneId(e.target.value)} className="input-field">
                          <option value="">كشف تلقائي حسب العنوان</option>
                          {deliveryZones.map(z => (
                            <option key={z.id} value={z.id}>{z.name} — {Number(z.price)} {currencySymbol}</option>
                          ))}
                        </select>
                      </div>
                    )}
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <p className="text-xs font-semibold text-slate-600 mb-1">اسم العميل:</p>
                        <input type="text" value={deliveryCustomerName} onChange={e => setDeliveryCustomerName(e.target.value)} placeholder="اسم العميل" className="input-field" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-slate-600 mb-1">رقم الموبايل:</p>
                        <input type="tel" value={deliveryCustomerPhone} onChange={e => setDeliveryCustomerPhone(e.target.value)} placeholder="01xxxxxxxxx" className="input-field" />
                      </div>
                    </div>
                    {currentDeliveryFee > 0 && (
                      <div className="flex items-center justify-between bg-primary-50 border border-primary-100 rounded-xl px-3 py-1.5">
                        <span className="text-xs font-semibold text-primary-700 flex items-center gap-1"><Truck className="w-3 h-3" />خدمة التوصيل</span>
                        <span className="font-mono font-bold text-sm text-primary-700">{currentDeliveryFee.toFixed(0)} {currencySymbol}</span>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Cart */}
              <div className="pb-1.5 border-b border-slate-100">
                <h2 className="text-sm font-bold text-slate-900">الطلب الحالي</h2>
                <p className="text-xs text-slate-400 mt-0.5">{cart.length} منتج</p>
              </div>

              <div className="space-y-2 max-h-52 overflow-y-auto">
                <AnimatePresence mode="popLayout">
                  {cart.length === 0 ? (
                    <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center py-5 text-slate-300 text-xs">
                      <AlertCircle className="w-5 h-5 mx-auto mb-1 opacity-40" />الطلب فارغ
                    </motion.div>
                  ) : (
                    cart.map((item) => (
                      <motion.div key={item.id} layout initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} className="bg-slate-50 rounded-xl p-2 flex items-start justify-between gap-2 border border-slate-100">
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-xs text-slate-900 truncate">{item.name_ar || item.name}</p>
                          <p className="text-xs text-slate-500 font-mono mt-0.5">{(item.price * item.quantity).toFixed(0)} {currencySymbol}</p>
                        </div>
                        <div className="flex items-center gap-0.5 bg-white rounded-lg border border-slate-200 p-0.5 flex-shrink-0">
                          <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="w-5 h-5 flex items-center justify-center hover:bg-danger-50 rounded transition-colors"><Minus className="w-2.5 h-2.5 text-slate-600" /></button>
                          <span className="w-5 text-center text-xs font-bold text-slate-900">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="w-5 h-5 flex items-center justify-center hover:bg-success-50 rounded transition-colors"><Plus className="w-2.5 h-2.5 text-slate-600" /></button>
                        </div>
                      </motion.div>
                    ))
                  )}
                </AnimatePresence>
              </div>

              {cart.length > 0 && (
                <div className="border-t border-slate-100 pt-2 space-y-2">
                  <div className="flex justify-between text-xs text-slate-600">
                    <span>المجموع الفرعي:</span>
                    <span className="font-mono">{cartSubtotal.toFixed(0)} {currencySymbol}</span>
                  </div>
                  {currentDeliveryFee > 0 && (
                    <div className="flex justify-between text-xs text-primary-600">
                      <span className="flex items-center gap-1"><Truck className="w-3 h-3" />خدمة التوصيل:</span>
                      <span className="font-mono">{currentDeliveryFee.toFixed(0)} {currencySymbol}</span>
                    </div>
                  )}
                  <div className="bg-primary-50 rounded-xl p-2.5 border border-primary-100 flex justify-between items-center">
                    <span className="font-semibold text-xs text-primary-700">الإجمالي:</span>
                    <span className="font-mono font-bold text-sm text-primary-700">{cartTotal.toFixed(0)} {currencySymbol}</span>
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                <button onClick={confirmOrder} disabled={cart.length === 0 || draftSaving} className="flex-1 btn-primary py-2.5 text-xs">
                  <Printer className="w-3.5 h-3.5" /> تأكيد الطلب
                </button>
                {cart.length > 0 && (
                  <button onClick={deleteDraft} disabled={draftSaving} className="px-3 py-2.5 bg-danger-50 hover:bg-danger-100 text-danger-700 font-semibold rounded-xl transition-all text-xs">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              {draftSaving && <p className="text-xs text-slate-400 text-center">جاري الحفظ...</p>}
            </div>
          </div>
        </div>
      </div>

      {/* Category Modal */}
      <AnimatePresence>
        {showCategoryModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 modal-overlay flex items-center justify-center p-4 z-50" onClick={() => setShowCategoryModal(false)}>
            <motion.div initial={{ scale: 0.95, y: 12 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 12 }} onClick={e => e.stopPropagation()} className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-modal space-y-4">
              <h2 className="text-lg font-bold text-slate-900">فئة جديدة</h2>
              <input type="text" placeholder="اسم الفئة" value={newCategoryName} onChange={e => setNewCategoryName(e.target.value)} onKeyDown={e => e.key === 'Enter' && addCategory()} autoFocus className="input-field" />
              <div className="flex gap-2">
                <button onClick={() => setShowCategoryModal(false)} className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-sm transition-all">إلغاء</button>
                <button onClick={addCategory} className="flex-1 py-2.5 btn-primary text-sm">إضافة</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Product Modal */}
      <AnimatePresence>
        {showProductModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 modal-overlay flex items-center justify-center p-4 z-50" onClick={() => setShowProductModal(false)}>
            <motion.div initial={{ scale: 0.95, y: 12 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 12 }} onClick={e => e.stopPropagation()} className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-modal space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-slate-900">{editingProduct ? 'تعديل منتج' : 'منتج جديد'}</h2>
                <button onClick={() => setShowProductModal(false)} className="p-1 hover:bg-slate-100 rounded-lg"><X className="w-4 h-4 text-slate-400" /></button>
              </div>
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600 block mb-1">الاسم <span className="text-danger-500">*</span></label>
                  <input type="text" placeholder="اسم المنتج" value={productForm.name} onChange={e => setProductForm(p => ({ ...p, name: e.target.value }))} className="input-field" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 block mb-1">السعر ({currencySymbol}) <span className="text-danger-500">*</span></label>
                  <input type="number" min="0" step="0.5" placeholder="0.00" value={productForm.price} onChange={e => setProductForm(p => ({ ...p, price: e.target.value }))} className="input-field" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 block mb-1">الفئة</label>
                  <select value={productForm.category_id} onChange={e => setProductForm(p => ({ ...p, category_id: e.target.value }))} className="input-field">
                    {categories.filter(c => c.id !== '__all__').map(cat => <option key={cat.id} value={cat.id}>{cat.name_ar || cat.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 block mb-1">صورة المنتج</label>
                  <label className="flex flex-col items-center justify-center w-full h-28 border-2 border-dashed border-slate-200 hover:border-primary-400 rounded-xl cursor-pointer bg-slate-50 hover:bg-primary-50/50 transition-all overflow-hidden">
                    {productForm.image_data ? <img src={productForm.image_data} alt="preview" className="h-full w-full object-cover rounded-xl" /> : (
                      <div className="flex flex-col items-center gap-1 text-slate-400">
                        <Plus className="w-5 h-5" /><span className="text-xs font-medium">اختر صورة</span>
                      </div>
                    )}
                    <input ref={productImageRef} type="file" accept="image/*" className="hidden" onChange={handleProductImageChange} />
                  </label>
                  {productForm.image_data && (
                    <button onClick={() => { setProductForm(p => ({ ...p, image_data: '' })); if (productImageRef.current) productImageRef.current.value = ''; }} className="mt-1 text-xs text-danger-500 hover:text-danger-700">إزالة الصورة</button>
                  )}
                </div>
              </div>
              <div className="flex gap-2 pt-1">
                <button onClick={() => setShowProductModal(false)} className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-sm transition-all">إلغاء</button>
                <button onClick={saveProduct} className="flex-1 py-2.5 btn-primary text-sm">{editingProduct ? 'تحديث' : 'إضافة'}</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation */}
      <AnimatePresence>
        {deleteTargetId && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 modal-overlay flex items-center justify-center p-4 z-50">
            <motion.div initial={{ scale: 0.95, y: 12 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 12 }} className="bg-white rounded-2xl p-6 max-w-xs w-full shadow-modal space-y-4 text-center">
              <div className="w-10 h-10 bg-danger-50 rounded-full flex items-center justify-center mx-auto"><Trash2 className="w-5 h-5 text-danger-500" /></div>
              <h2 className="text-base font-bold text-slate-900">هل أنت متأكد؟</h2>
              <p className="text-sm text-slate-500">لا يمكن التراجع عن هذه العملية.</p>
              <div className="flex gap-2">
                <button onClick={() => setDeleteTargetId(null)} className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-sm transition-all">تراجع</button>
                <button onClick={confirmDeleteProduct} className="flex-1 py-2.5 btn-danger text-sm">تأكيد</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toast */}
      <AnimatePresence>
        {orderMessage && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }} className="fixed bottom-6 right-6 bg-success-500 text-white px-4 py-3 rounded-xl shadow-lg font-semibold text-sm z-50">
            {orderMessage}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
