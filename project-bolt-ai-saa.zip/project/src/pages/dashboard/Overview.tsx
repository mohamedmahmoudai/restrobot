import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ShoppingBag, TrendingUp, Users, Star,
  Clock, ArrowRight, UtensilsCrossed, CreditCard, Zap
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { useSubscription } from '../../contexts/SubscriptionContext';
import type { Order } from '../../lib/database.types';

interface Stats {
  todayOrders: number;
  todayRevenue: number;
  totalCustomers: number;
  pendingOrders: number;
}

interface TopProduct {
  id: string;
  name: string;
  name_ar: string;
  category: string;
  totalOrders: number;
  growth: number;
}

const fadeIn = { initial: { opacity: 0, y: 12 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.4, ease: [0.25, 0.1, 0.25, 1] as const } };

export default function Overview() {
  const { restaurant } = useAuth();
  const { subscriptionStatus } = useSubscription();
  const [stats, setStats] = useState<Stats>({ todayOrders: 0, todayRevenue: 0, totalCustomers: 0, pendingOrders: 0 });
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [topProducts, setTopProducts] = useState<TopProduct[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!restaurant) return;
    fetchData();
    const sub = supabase
      .channel('orders-overview')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders', filter: `restaurant_id=eq.${restaurant.id}` }, () => fetchData())
      .subscribe();
    return () => { sub.unsubscribe(); };
  }, [restaurant]);

  async function fetchData() {
    if (!restaurant) return;
    const today = new Date().toISOString().split('T')[0];

    const [ordersRes, customersRes, pendingRes, recentRes, topProductsRes] = await Promise.all([
      supabase.from('orders').select('total').eq('restaurant_id', restaurant.id).gte('created_at', today),
      supabase.from('customers').select('id', { count: 'exact', head: true }).eq('restaurant_id', restaurant.id),
      supabase.from('orders').select('id', { count: 'exact', head: true }).eq('restaurant_id', restaurant.id).eq('status', 'pending'),
      supabase.from('orders').select('*').eq('restaurant_id', restaurant.id).order('created_at', { ascending: false }).limit(8),
      supabase.from('orders').select('id').eq('restaurant_id', restaurant.id).order('created_at', { ascending: false }).limit(100),
    ]);

    const todayRevenue = (ordersRes.data ?? []).reduce((s, o) => s + Number(o.total), 0);


    setStats({
      todayOrders: ordersRes.data?.length ?? 0,
      todayRevenue,
      totalCustomers: customersRes.count ?? 0,
      pendingOrders: pendingRes.count ?? 0,
    });
    setRecentOrders(recentRes.data ?? []);

    // Fetch order items scoped to this restaurant's orders
    const orderIds = (topProductsRes.data ?? []).map((o: any) => o.id);
    const productCounts: Record<string, { count: number; name: string; name_ar: string; category: string }> = {};
    if (orderIds.length > 0) {
      const { data: itemsData } = await supabase
        .from('order_items')
        .select('menu_item_id, quantity, menu_items(name, name_ar, menu_categories(name))')
        .in('order_id', orderIds);
      (itemsData ?? []).forEach((item: any) => {
        if (item.menu_items) {
          const id = item.menu_item_id;
          if (!productCounts[id]) {
            productCounts[id] = {
              count: 0,
              name: item.menu_items.name || 'Unknown',
              name_ar: item.menu_items.name_ar || 'غير معروف',
              category: item.menu_items.menu_categories?.name || 'عام',
            };
          }
          productCounts[id].count += item.quantity;
        }
      });
    }

    const sortedProducts = Object.entries(productCounts)
      .map(([id, data]) => ({
        id, name: data.name, name_ar: data.name_ar, category: data.category,
        totalOrders: data.count, growth: 0,
      }))
      .sort((a, b) => b.totalOrders - a.totalOrders)
      .slice(0, 3);

    setTopProducts(sortedProducts);
    setLoading(false);
  }

  const statusConfig: Record<string, { label: string; color: string }> = {
    pending: { label: 'جديد', color: 'badge-warning' },
    preparing: { label: 'قيد التحضير', color: 'badge-primary' },
    ready: { label: 'جاهز', color: 'badge-success' },
    delivered: { label: 'مُسلَّم', color: 'badge-neutral' },
    cancelled: { label: 'ملغي', color: 'badge-danger' },
  };

  if (loading) return <LoadingSkeleton />;

  return (
    <div className="max-w-6xl mx-auto space-y-6" dir="rtl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900">نظرة عامة</h1>
        <p className="text-sm text-slate-500 mt-0.5">ملخص أداء مطعمك اليوم</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'طلبات اليوم', value: stats.todayOrders, icon: ShoppingBag, change: '+12%', accent: 'bg-primary-50 text-primary-600' },
          { label: 'إيرادات اليوم', value: `${stats.todayRevenue.toFixed(0)} ج.م`, icon: TrendingUp, change: '+8%', accent: 'bg-success-50 text-success-600' },
          { label: 'إجمالي العملاء', value: stats.totalCustomers, icon: Users, change: '+5', accent: 'bg-blue-50 text-blue-600' },
          { label: 'طلبات معلقة', value: stats.pendingOrders, icon: Clock, change: null, accent: 'bg-amber-50 text-amber-600' },
        ].map((s) => (
          <motion.div key={s.label} {...fadeIn} className="card p-5 card-hover">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-slate-500 mb-1">{s.label}</p>
                <p className="text-2xl font-bold text-slate-900">{s.value}</p>
                {s.change && <p className="text-xs text-success-600 font-medium mt-1">{s.change}</p>}
              </div>
              <div className={`w-9 h-9 ${s.accent} rounded-xl flex items-center justify-center`}>
                <s.icon className="w-4 h-4" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Subscription Widget */}
      {subscriptionStatus && (
        <motion.div {...fadeIn} className={`card p-5 ${subscriptionStatus.status !== 'active' ? 'border-l-4 border-l-danger-500' : subscriptionStatus.daysRemaining <= 7 ? 'border-l-4 border-l-warning-500' : 'border-l-4 border-l-success-500'}`}>
          <div className="flex items-start gap-4">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${subscriptionStatus.status !== 'active' ? 'bg-danger-50 text-danger-600' : subscriptionStatus.daysRemaining <= 7 ? 'bg-warning-50 text-warning-600' : 'bg-success-50 text-success-600'}`}>
              {subscriptionStatus.isTrialPlan ? <Zap className="w-5 h-5" /> : <CreditCard className="w-5 h-5" />}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">{subscriptionStatus.planNameAr || 'الباقة الحالية'}</h3>
                  <p className="text-sm text-slate-500 mt-0.5">
                    {subscriptionStatus.status === 'active' ? (
                      subscriptionStatus.daysRemaining > 0
                        ? `${subscriptionStatus.daysRemaining} يوم متبقي`
                        : 'ينتهي اليوم'
                    ) : subscriptionStatus.status === 'pending_payment'
                      ? 'بانتظار تأكيد الدفع'
                      : subscriptionStatus.status === 'suspended'
                        ? 'اشتراك موقوف'
                        : 'اشتراك منتهي'}
                  </p>
                </div>
                <Link to="/dashboard/subscription" className="text-sm font-semibold text-primary-600 hover:text-primary-700 transition-colors flex items-center gap-1">
                  إدارة الاشتراك
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
              {subscriptionStatus.maxOrders && (
                <div className="mt-3">
                  <div className="flex justify-between text-xs text-slate-500 mb-1">
                    <span>الطلبات المستخدمة</span>
                    <span>{subscriptionStatus.ordersUsed} / {subscriptionStatus.maxOrders}</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-1.5">
                    <div className={`h-1.5 rounded-full transition-all ${(subscriptionStatus.ordersUsed / subscriptionStatus.maxOrders) > 0.9 ? 'bg-danger-500' : (subscriptionStatus.ordersUsed / subscriptionStatus.maxOrders) > 0.7 ? 'bg-warning-500' : 'bg-primary-500'}`} style={{ width: `${Math.min(100, (subscriptionStatus.ordersUsed / subscriptionStatus.maxOrders) * 100)}%` }} />
                  </div>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      )}

      {/* Setup Banner */}
      {restaurant && !restaurant.telegram_bot_token && (
        <motion.div {...fadeIn} className="card p-5 border-l-4 border-l-primary-500 card-hover">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 bg-primary-50 rounded-xl flex items-center justify-center flex-shrink-0">
              <Star className="w-5 h-5 text-primary-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-slate-900 text-sm mb-1">أكمل إعداد مطعمك</h3>
              <p className="text-sm text-slate-500">أضف بيانات بوت تيليجرام لبدء استقبال الطلبات تلقائياً</p>
              <Link to="/dashboard/settings" className="inline-flex items-center gap-1.5 mt-3 text-sm font-semibold text-primary-600 hover:text-primary-700 transition-colors">
                الذهاب للإعدادات
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </motion.div>
      )}

      {/* Top Products + Recent Orders */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Products */}
        <div className="lg:col-span-1 space-y-4">
          <h2 className="font-bold text-slate-900 text-sm">أكثر المنتجات طلباً</h2>
          {topProducts.length > 0 ? (
            <div className="space-y-3">
              {topProducts.map((product, i) => (
                <motion.div key={product.id} {...fadeIn} className="card p-4 card-hover">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-primary-50 rounded-lg flex items-center justify-center text-xs font-bold text-primary-600">
                      #{i + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-slate-900 text-sm truncate">{product.name_ar}</p>
                      <p className="text-xs text-slate-400">{product.category}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-slate-900">{product.totalOrders}</p>
                      <p className="text-xs text-success-600">+{product.growth}%</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="card p-8 text-center">
              <UtensilsCrossed className="w-10 h-10 text-slate-200 mx-auto mb-3" />
              <p className="text-slate-400 text-sm">لا توجد بيانات منتجات بعد</p>
            </div>
          )}
        </div>

        {/* Recent Orders */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-slate-900 text-sm">آخر الطلبات</h2>
            <Link to="/dashboard/cashier" className="text-sm font-medium text-primary-600 hover:text-primary-700 flex items-center gap-1 transition-colors">
              عرض الكل
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {recentOrders.length === 0 ? (
            <div className="card p-8 text-center">
              <ShoppingBag className="w-10 h-10 text-slate-200 mx-auto mb-3" />
              <p className="text-slate-400 text-sm">لا توجد طلبات بعد</p>
            </div>
          ) : (
            <div className="card overflow-hidden">
              <div className="divide-y divide-slate-100">
                {recentOrders.slice(0, 6).map((order) => {
                  const sc = statusConfig[order.status] ?? statusConfig.pending;
                  return (
                    <div key={order.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-slate-50 transition-colors">
                      <span className="font-mono text-xs bg-slate-100 px-2 py-1 rounded-lg text-slate-700 flex-shrink-0">{order.order_number}</span>
                      <span className="text-xs text-slate-500 capitalize hidden sm:block flex-shrink-0 w-20">{order.channel}</span>
                      <span className={`badge ${sc.color} flex-shrink-0`}>{sc.label}</span>
                      <span className="text-sm font-semibold text-slate-900 mr-auto">{Number(order.total).toFixed(2)} ج.م</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="max-w-6xl mx-auto space-y-6 animate-pulse" dir="rtl">
      <div className="h-6 w-32 bg-slate-200 rounded-lg" />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="card p-5">
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <div className="h-3 w-20 bg-slate-200 rounded" />
                <div className="h-6 w-16 bg-slate-200 rounded" />
              </div>
              <div className="w-9 h-9 bg-slate-200 rounded-xl" />
            </div>
          </div>
        ))}
      </div>
      <div className="card h-48" />
    </div>
  );
}
