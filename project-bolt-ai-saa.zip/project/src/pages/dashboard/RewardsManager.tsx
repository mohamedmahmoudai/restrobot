import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, CreditCard as Edit3, CheckCircle, Loader2, Gift, Tag, Percent, Coffee, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import type { RewardCatalog } from '../../lib/database.types';

type RewardType = 'free_item' | 'discount_percentage' | 'discount_fixed';

const REWARD_TYPES: { value: RewardType; label: string; icon: React.FC<{ className?: string }> }[] = [
  { value: 'free_item', label: 'منتج مجاني', icon: Coffee },
  { value: 'discount_percentage', label: 'خصم نسبة', icon: Percent },
  { value: 'discount_fixed', label: 'خصم ثابت', icon: Tag },
];

export default function RewardsManager() {
  const { restaurant } = useAuth();
  const [rewards, setRewards] = useState<RewardCatalog[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    name: '',
    description: '',
    points_required: 100,
    reward_type: 'free_item' as RewardType,
    reward_value: 0,
    reward_item_name: '',
    is_active: true,
  });

  const [editingId, setEditingId] = useState<string | null>(null);

  useEffect(() => {
    if (restaurant) fetchRewards();
  }, [restaurant]);

  async function fetchRewards() {
    if (!restaurant) return;
    setLoading(true);
    const { data } = await supabase
      .from('reward_catalog')
      .select('*')
      .eq('restaurant_id', restaurant.id)
      .order('sort_order', { ascending: true });
    setRewards(data ?? []);
    setLoading(false);
  }

  function resetForm() {
    setForm({
      name: '',
      description: '',
      points_required: 100,
      reward_type: 'free_item',
      reward_value: 0,
      reward_item_name: '',
      is_active: true,
    });
    setEditingId(null);
  }

  async function handleSave() {
    if (!restaurant || !form.name.trim()) return;
    setSaving(true);

    const payload = {
      restaurant_id: restaurant.id,
      name: form.name.trim(),
      description: form.description.trim() || null,
      points_required: form.points_required,
      reward_type: form.reward_type,
      reward_value: form.reward_value,
      reward_item_name: form.reward_item_name.trim() || null,
      is_active: form.is_active,
      sort_order: editingId ? undefined : rewards.length + 1,
    };

    if (editingId) {
      await supabase.from('reward_catalog').update(payload).eq('id', editingId);
    } else {
      await supabase.from('reward_catalog').insert(payload);
    }

    setSaving(false);
    setShowForm(false);
    resetForm();
    fetchRewards();
  }

  async function handleDelete(id: string) {
    if (!confirm('هل أنت متأكد من حذف هذه المكافأة؟')) return;
    await supabase.from('reward_catalog').delete().eq('id', id);
    fetchRewards();
  }

  function startEdit(reward: RewardCatalog) {
    setForm({
      name: reward.name,
      description: reward.description ?? '',
      points_required: reward.points_required,
      reward_type: reward.reward_type as RewardType,
      reward_value: reward.reward_value,
      reward_item_name: reward.reward_item_name ?? '',
      is_active: reward.is_active,
    });
    setEditingId(reward.id);
    setShowForm(true);
  }

  const getTypeLabel = (type: string) => REWARD_TYPES.find(t => t.value === type)?.label ?? type;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64" dir="rtl">
        <div className="w-6 h-6 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-5" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">إدارة المكافآت</h1>
          <p className="text-sm text-slate-500 mt-0.5">أنشئ وعدّل مكافآت الولاء</p>
        </div>
        <button onClick={() => { resetForm(); setShowForm(true); }} className="btn-primary text-sm">
          <Plus className="w-4 h-4" />
          مكافأة جديدة
        </button>
      </div>

      {/* Rewards Grid */}
      {rewards.length === 0 ? (
        <div className="card p-12 text-center">
          <Gift className="w-12 h-12 text-slate-200 mx-auto mb-3" />
          <p className="text-slate-400 text-sm">لم تُضف مكافآت بعد</p>
          <button onClick={() => { resetForm(); setShowForm(true); }} className="btn-primary text-xs mt-4">
            <Plus className="w-3.5 h-3.5" /> إضافة أول مكافأة
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence mode="popLayout">
            {rewards.map((reward) => (
              <motion.div
                key={reward.id}
                layout
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className={`card p-5 relative ${!reward.is_active ? 'opacity-60' : ''}`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 bg-primary-50 rounded-lg flex items-center justify-center">
                      <Gift className="w-4 h-4 text-primary-600" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 text-sm">{reward.name}</p>
                      <span className="text-[10px] text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">{getTypeLabel(reward.reward_type)}</span>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => startEdit(reward)} className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-all">
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => handleDelete(reward.id)} className="p-1.5 text-slate-400 hover:text-danger-600 hover:bg-danger-50 rounded-lg transition-all">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {reward.description && (
                  <p className="text-xs text-slate-500 mb-3 line-clamp-2">{reward.description}</p>
                )}

                <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                  <div className="flex items-center gap-1.5">
                    <span className="text-lg font-bold text-primary-600">{reward.points_required}</span>
                    <span className="text-xs text-slate-400">نقطة</span>
                  </div>
                  {reward.reward_type === 'free_item' && reward.reward_item_name && (
                    <span className="text-xs text-slate-500">{reward.reward_item_name}</span>
                  )}
                  {(reward.reward_type === 'discount_percentage' || reward.reward_type === 'discount_fixed') && (
                    <span className="text-xs text-slate-500">
                      {reward.reward_type === 'discount_percentage' ? `${reward.reward_value}%` : `${reward.reward_value} ج.م`}
                    </span>
                  )}
                </div>

                {!reward.is_active && (
                  <div className="absolute top-2 left-2">
                    <span className="text-[10px] bg-slate-200 text-slate-500 px-1.5 py-0.5 rounded">معطل</span>
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Form Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6 space-y-5">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-slate-900">
                    {editingId ? 'تعديل مكافأة' : 'مكافأة جديدة'}
                  </h2>
                  <button onClick={() => setShowForm(false)} className="p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-50">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1.5">اسم المكافأة</label>
                    <input
                      value={form.name}
                      onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                      placeholder="مثال: مشروب مجاني"
                      className="input-field"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1.5">الوصف</label>
                    <textarea
                      value={form.description}
                      onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
                      placeholder="وصف قصير للمكافأة..."
                      rows={2}
                      className="input-field resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1.5">النقاط المطلوبة</label>
                      <input
                        type="number"
                        min={1}
                        value={form.points_required}
                        onChange={e => setForm(p => ({ ...p, points_required: parseInt(e.target.value) || 1 }))}
                        className="input-field"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1.5">نوع المكافأة</label>
                      <select
                        value={form.reward_type}
                        onChange={e => setForm(p => ({ ...p, reward_type: e.target.value as RewardType }))}
                        className="input-field"
                      >
                        {REWARD_TYPES.map(t => (
                          <option key={t.value} value={t.value}>{t.label}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {form.reward_type === 'free_item' && (
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1.5">اسم المنتج المجاني</label>
                      <input
                        value={form.reward_item_name}
                        onChange={e => setForm(p => ({ ...p, reward_item_name: e.target.value }))}
                        placeholder="مثال: كولا"
                        className="input-field"
                      />
                    </div>
                  )}

                  {(form.reward_type === 'discount_percentage' || form.reward_type === 'discount_fixed') && (
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1.5">
                        {form.reward_type === 'discount_percentage' ? 'نسبة الخصم (%)' : 'قيمة الخصم (ج.م)'}
                      </label>
                      <input
                        type="number"
                        min={0}
                        value={form.reward_value}
                        onChange={e => setForm(p => ({ ...p, reward_value: parseFloat(e.target.value) || 0 }))}
                        className="input-field"
                      />
                    </div>
                  )}

                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                    <span className="text-sm font-medium text-slate-700">مكافأة نشطة</span>
                    <button
                      onClick={() => setForm(p => ({ ...p, is_active: !p.is_active }))}
                      className={`relative w-12 h-7 rounded-full transition-colors ${form.is_active ? 'bg-primary-600' : 'bg-slate-300'}`}
                    >
                      <motion.div
                        layout
                        className="absolute top-1 w-5 h-5 bg-white rounded-full shadow"
                        animate={{ left: form.is_active ? '1.5rem' : '0.25rem' }}
                        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                      />
                    </button>
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button onClick={handleSave} disabled={saving || !form.name.trim()} className="btn-primary flex-1">
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                    {saving ? 'جارٍ الحفظ...' : (editingId ? 'تحديث' : 'إنشاء')}
                  </button>
                  <button onClick={() => setShowForm(false)} className="btn-secondary flex-1">إلغاء</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
