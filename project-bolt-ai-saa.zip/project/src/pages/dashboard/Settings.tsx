import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Save, Bot, Phone, MapPin, MessageCircle, Webhook,
  AlertCircle, CheckCircle, Copy, Eye, EyeOff, Link2,
  Loader2, Wifi, WifiOff, Store, Trash2, Plus, Truck, Gift,
  ChevronLeft, RefreshCw, FolderOpen, UtensilsCrossed, Clock, History
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import type { DeliveryZone } from '../../lib/database.types';
import TelegramSettingsPanel from '../../components/TelegramSettingsPanel';

type ConnectionState = 'idle' | 'checking' | 'success' | 'error';
type SettingsTab = 'general' | 'telegram' | 'whatsapp' | 'n8n' | 'delivery';

export default function Settings() {
  const { restaurant, refreshRestaurant } = useAuth();
  const [activeTab, setActiveTab] = useState<SettingsTab>('general');

  const [form, setForm] = useState({
    name: '', phone: '', address: '',
    whatsapp_webhook_url: '', n8n_webhook_url: '', currency: 'EGP', min_order: '', loyalty_enabled: true,
    is_closed: false, closed_message: '',
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showToken, setShowToken] = useState(false);
  const [copied, setCopied] = useState('');
  const [telegramSetupStatus, setTelegramSetupStatus] = useState<'idle' | 'loading' | 'done' | 'error'>('idle');
  const [telegramError, setTelegramError] = useState('');
  const [telegramMsg, setTelegramMsg] = useState('');

  const [zones, setZones] = useState<DeliveryZone[]>([]);
  const [zonesLoading, setZonesLoading] = useState(true);
  const [newZoneName, setNewZoneName] = useState('');
  const [newZonePrice, setNewZonePrice] = useState('');
  const [addingZone, setAddingZone] = useState(false);

  useEffect(() => {
    if (restaurant) {
      setForm({
        name: restaurant.name ?? '', phone: restaurant.phone ?? '', address: restaurant.address ?? '',
        whatsapp_webhook_url: restaurant.whatsapp_webhook_url ?? '', n8n_webhook_url: restaurant.n8n_webhook_url ?? '',
        currency: restaurant.currency ?? 'EGP', min_order: '', loyalty_enabled: restaurant.loyalty_enabled ?? true,
        is_closed: (restaurant as any)?.is_suspended ? true : (restaurant.is_closed ?? false), closed_message: restaurant.closed_message ?? '',
      });
      fetchZones();
    }
  }, [restaurant]);

  async function fetchZones() {
    if (!restaurant) return;
    const { data } = await supabase.from('delivery_zones').select('*').eq('restaurant_id', restaurant.id).order('created_at');
    setZones(data ?? []);
    setZonesLoading(false);
  }

  function setField<K extends keyof typeof form>(key: K, val: (typeof form)[K]) {
    setForm(p => ({ ...p, [key]: val }));
  }

  async function handleSave() {
    if (!restaurant) return;
    setSaving(true);
    setSaved(false);
    const { min_order, ...dbFields } = form;
    if ((restaurant as any)?.is_suspended) {
      dbFields.is_closed = true;
    }
    await supabase.from('restaurants').update(dbFields).eq('id', restaurant.id);
    await refreshRestaurant();
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3500);
  }

  function copyToClipboard(text: string, key: string) {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(''), 2500);
  }

  async function checkN8nConnection() {
    if (!form.n8n_webhook_url) { setN8nStatus('error'); setTimeout(() => setN8nStatus('idle'), 3000); return; }
    setN8nStatus('checking');
    try {
      await fetch(form.n8n_webhook_url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ping: true, source: 'restrobot-settings-check' }) });
      setN8nStatus('success');
    } catch { setN8nStatus('error'); }
    setTimeout(() => setN8nStatus('idle'), 4000);
  }

  async function addZone() {
    if (!restaurant || !newZoneName.trim()) return;
    setAddingZone(true);
    const { data } = await supabase.from('delivery_zones').insert({ restaurant_id: restaurant.id, name: newZoneName.trim(), price: parseFloat(newZonePrice) || 0 }).select('*').maybeSingle();
    if (data) setZones(prev => [...prev, data]);
    setNewZoneName(''); setNewZonePrice('');
    setAddingZone(false);
  }

  async function updateZonePrice(id: string, price: string) {
    if (!restaurant) return;
    const num = parseFloat(price);
    if (isNaN(num)) return;
    await supabase.from('delivery_zones').update({ price: num }).eq('id', id).eq('restaurant_id', restaurant.id);
    setZones(prev => prev.map(z => z.id === id ? { ...z, price: num } : z));
  }

  async function updateZoneName(id: string, name: string) {
    if (!restaurant || !name.trim()) return;
    await supabase.from('delivery_zones').update({ name: name.trim() }).eq('id', id).eq('restaurant_id', restaurant.id);
    setZones(prev => prev.map(z => z.id === id ? { ...z, name: name.trim() } : z));
  }

  async function deleteZone(id: string) {
    if (!restaurant) return;
    await supabase.from('delivery_zones').delete().eq('id', id).eq('restaurant_id', restaurant.id);
    setZones(prev => prev.filter(z => z.id !== id));
  }

  const webhookUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/order-intake`;

  const currencyOptions = [
    { value: 'EGP', label: 'جنيه مصري (ج.م)' },
    { value: 'SAR', label: 'ريال سعودي (ر.س)' },
    { value: 'AED', label: 'درهم إماراتي (د.إ)' },
    { value: 'KWD', label: 'دينار كويتي (د.ك)' },
    { value: 'USD', label: 'دولار أمريكي ($)' },
  ];

  const currencySymbol = form.currency === 'EGP' ? 'ج.م' : form.currency === 'SAR' ? 'ر.س' : form.currency === 'AED' ? 'د.إ' : form.currency === 'KWD' ? 'د.ك' : '$';

  const tabs: { key: SettingsTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { key: 'general', label: 'عام', icon: Store },
    { key: 'delivery', label: 'التوصيل', icon: Truck },
    { key: 'telegram', label: 'تيليجرام', icon: Bot },
    { key: 'whatsapp', label: 'واتساب', icon: MessageCircle },
    { key: 'n8n', label: 'n8n', icon: Webhook },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-5" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">الإعدادات</h1>
        <p className="text-sm text-slate-500 mt-0.5">ضبط وتخصيص إعدادات مطعمك</p>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-1 bg-slate-100 rounded-xl p-1 overflow-x-auto">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                activeTab === tab.key ? 'bg-white text-primary-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* General Tab */}
      {activeTab === 'general' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card p-6 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">اسم المطعم</label>
              <input value={form.name} onChange={e => setField('name', e.target.value)} placeholder="مثال: مطعم الشاورما الذهبية" className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">رقم الهاتف</label>
              <input value={form.phone} onChange={e => setField('phone', e.target.value)} placeholder="+20 100 000 0000" dir="ltr" className="input-field" />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">العملة</label>
              <select value={form.currency} onChange={e => setField('currency', e.target.value)} className="input-field">
                {currencyOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">العنوان</label>
              <input value={form.address} onChange={e => setField('address', e.target.value)} placeholder="المدينة، الحي، الشارع..." className="input-field" />
            </div>
          </div>

          {/* Loyalty Toggle */}
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
            <div>
              <p className="text-sm font-semibold text-slate-900">نظام المكافآت والولاء</p>
              <p className="text-xs text-slate-500 mt-0.5">تفعيل برنامج نقاط الولاء للعملاء</p>
            </div>
            <button
              onClick={() => setField('loyalty_enabled', !form.loyalty_enabled)}
              className={`relative w-12 h-7 rounded-full transition-colors ${form.loyalty_enabled ? 'bg-primary-600' : 'bg-slate-300'}`}
            >
              <motion.div
                layout
                className="absolute top-1 w-5 h-5 bg-white rounded-full shadow"
                animate={{ left: form.loyalty_enabled ? '1.5rem' : '0.25rem' }}
                transition={{ type: 'spring', stiffness: 500, damping: 30 }}
              />
            </button>
          </div>

          {/* Closed Mode Toggle */}
          <div className={`flex items-center justify-between p-4 rounded-xl border transition-colors ${form.is_closed ? 'bg-danger-50 border-danger-200' : 'bg-slate-50 border-slate-100'}`}>
            <div>
              <p className={`text-sm font-semibold ${form.is_closed ? 'text-danger-800' : 'text-slate-900'}`}>وضع الإغلاق</p>
              <p className={`text-xs mt-0.5 ${form.is_closed ? 'text-danger-600' : 'text-slate-500'}`}>
                {form.is_closed ? 'المطعم مغلق — لا يمكن استقبال طلبات جديدة' : 'المطعم مفتوح ويستقبل الطلبات'}
              </p>
              {(restaurant as any)?.is_suspended && (
                <p className="text-xs text-danger-600 mt-1 font-medium">⚠️ المطعم موقوف من الإدارة — وضع الإغلاق مُفعّل إجبارياً</p>
              )}
            </div>
            <button
              onClick={() => {
                if ((restaurant as any)?.is_suspended) return;
                setField('is_closed', !form.is_closed);
              }}
              disabled={(restaurant as any)?.is_suspended}
              className={`relative w-12 h-7 rounded-full transition-colors ${form.is_closed ? 'bg-danger-500' : 'bg-slate-300'} ${(restaurant as any)?.is_suspended ? 'opacity-60 cursor-not-allowed' : ''}`}
            >
              <motion.div
                layout
                className="absolute top-1 w-5 h-5 bg-white rounded-full shadow"
                animate={{ left: form.is_closed ? '1.5rem' : '0.25rem' }}
                transition={{ type: 'spring', stiffness: 500, damping: 30 }}
              />
            </button>
          </div>

          {/* Closed Message (shown when is_closed) */}
          <AnimatePresence>
            {form.is_closed && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <label className="block text-sm font-medium text-slate-700 mb-1.5">رسالة إغلاق المطعم</label>
                <textarea
                  value={form.closed_message}
                  onChange={e => setField('closed_message', e.target.value)}
                  placeholder="عذراً، المطعم مغلق حالياً. سنعود قريباً!"
                  rows={3}
                  className="input-field resize-none"
                />
                <p className="text-xs text-slate-400 mt-1">تُرسَل هذه الرسالة للعملاء عبر تيليجرام عند محاولة الطلب</p>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}

      {/* Delivery Tab */}
      {activeTab === 'delivery' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card p-6 space-y-5">
          <div>
            <h3 className="font-bold text-slate-900 text-sm mb-1">مناطق التوصيل والرسوم</h3>
            <p className="text-xs text-slate-500">حدد مناطق التوصيل ورسوم كل منطقة</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">الحد الأدنى للطلب</label>
              <div className="relative">
                <input type="number" min="0" step="1" value={form.min_order} onChange={e => setField('min_order', e.target.value)} placeholder="0" className="input-field pl-10" />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-mono">{currencySymbol}</span>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-4">
            <p className="text-xs font-bold text-slate-600 mb-3">المناطق المضافة ({zones.length})</p>
            {zonesLoading ? (
              <div className="flex justify-center py-4"><div className="w-5 h-5 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" /></div>
            ) : zones.length === 0 ? (
              <div className="text-center py-6 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <Truck className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                <p className="text-sm text-slate-400">لم تُضف مناطق توصيل بعد</p>
              </div>
            ) : (
              <div className="space-y-2">
                <AnimatePresence mode="popLayout">
                  {zones.map(zone => (
                    <motion.div key={zone.id} layout initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -20, height: 0 }} className="flex items-center gap-2 bg-slate-50 border border-slate-100 rounded-xl p-2.5 group">
                      <input value={zone.name} onChange={e => setZones(prev => prev.map(z => z.id === zone.id ? { ...z, name: e.target.value } : z))} onBlur={e => updateZoneName(zone.id, e.target.value)} className="flex-1 bg-transparent border-0 text-sm font-semibold text-slate-800 focus:outline-none placeholder-slate-400 min-w-0" placeholder="اسم المنطقة" />
                      <span className="text-xs text-slate-400 font-mono flex-shrink-0">{currencySymbol}</span>
                      <input type="number" min="0" step="0.5" value={zone.price} onChange={e => { const v = e.target.value; setZones(prev => prev.map(z => z.id === zone.id ? { ...z, price: parseFloat(v) || 0 } : z)); }} onBlur={e => updateZonePrice(zone.id, e.target.value)} className="w-20 bg-white border border-slate-200 rounded-lg px-2 py-1 text-sm font-mono text-slate-800 focus:outline-none focus:border-primary-500 text-center" />
                      <button onClick={() => deleteZone(zone.id)} className="p-1.5 text-slate-400 hover:text-danger-500 hover:bg-danger-50 rounded-lg transition-all flex-shrink-0" title="حذف المنطقة"><Trash2 className="w-3.5 h-3.5" /></button>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>

          <div className="bg-primary-50 border border-primary-100 rounded-xl p-4 space-y-3">
            <p className="text-xs font-bold text-primary-700 flex items-center gap-1.5"><Plus className="w-3.5 h-3.5" />إضافة منطقة توصيل جديدة</p>
            <div className="flex gap-2">
              <input value={newZoneName} onChange={e => setNewZoneName(e.target.value)} placeholder="اسم المنطقة" className="input-field flex-1" onKeyDown={e => e.key === 'Enter' && addZone()} />
              <div className="relative">
                <input type="number" min="0" step="0.5" value={newZonePrice} onChange={e => setNewZonePrice(e.target.value)} placeholder="0" className="input-field w-24 text-center" onKeyDown={e => e.key === 'Enter' && addZone()} />
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-mono">{currencySymbol}</span>
              </div>
              <button onClick={addZone} disabled={addingZone || !newZoneName.trim()} className="px-4 py-2 bg-primary-600 hover:bg-primary-700 disabled:opacity-40 text-white font-semibold rounded-xl text-sm transition-all flex items-center gap-1.5 flex-shrink-0">
                {addingZone ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}إضافة
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Telegram Tab */}
      {activeTab === 'telegram' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
          <TelegramSettingsPanel restaurant={restaurant} onRefresh={refreshRestaurant} />
        </motion.div>
      )}

      {/* WhatsApp Tab */}
      {activeTab === 'whatsapp' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card p-6 space-y-5">
          <div>
            <h3 className="font-bold text-slate-900 text-sm mb-1">تكامل واتساب بيزنس</h3>
            <p className="text-xs text-slate-500">استقبال الطلبات عبر واتساب</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">WhatsApp Business Webhook URL</label>
            <input value={form.whatsapp_webhook_url} onChange={e => setField('whatsapp_webhook_url', e.target.value)} placeholder="https://graph.facebook.com/v18.0/..." dir="ltr" className="input-field font-mono text-xs" />
          </div>
          <div className="flex items-start gap-2 bg-warning-50 border border-warning-100 rounded-xl p-3">
            <AlertCircle className="w-4 h-4 text-warning-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-warning-700">ميزة واتساب Business قيد التطوير وستكون متاحة في التحديث القادم.</p>
          </div>
        </motion.div>
      )}

      {/* n8n Tab */}
      {activeTab === 'n8n' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card p-6 space-y-5">
          <div>
            <h3 className="font-bold text-slate-900 text-sm mb-1">ربط الأتمتة مع n8n</h3>
            <p className="text-xs text-slate-500">فحص الاتصال وربط سير عمل n8n</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">n8n Webhook URL</label>
            <input value={form.n8n_webhook_url} onChange={e => setField('n8n_webhook_url', e.target.value)} placeholder="https://your-n8n.com/webhook/..." dir="ltr" className="input-field font-mono text-xs" />
          </div>
          <div className="flex items-center gap-3">
            <button onClick={checkN8nConnection} disabled={n8nStatus === 'checking'} className="btn-primary text-xs">
              {n8nStatus === 'checking' ? <><Loader2 className="w-4 h-4 animate-spin" /> جاري الفحص...</> : <><Wifi className="w-4 h-4" /> فحص الاتصال</>}
            </button>
            <AnimatePresence mode="wait">
              {n8nStatus === 'success' && (
                <motion.span key="ok" initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} className="flex items-center gap-1.5 text-success-600 text-sm font-semibold"><CheckCircle className="w-4 h-4" /> الاتصال ناجح</motion.span>
              )}
              {n8nStatus === 'error' && (
                <motion.span key="err" initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} className="flex items-center gap-1.5 text-danger-600 text-sm font-semibold"><WifiOff className="w-4 h-4" /> فشل الاتصال</motion.span>
              )}
            </AnimatePresence>
          </div>
          <details className="group">
            <summary className="flex items-center gap-2 cursor-pointer text-xs text-slate-500 hover:text-slate-800 font-semibold select-none py-1"><Link2 className="w-3.5 h-3.5" />عرض قالب n8n Payload</summary>
            <div className="mt-3 relative">
              <button onClick={() => copyToClipboard(JSON.stringify({ restaurant_id: restaurant?.id ?? 'YOUR_ID', order_number: 'ORD-{{ $json.message_id }}', channel: 'telegram', total: '{{ $json.total }}', notes: '{{ $json.text }}', customer: { name: '{{ $json.first_name }}', telegram_id: '{{ $json.from.id }}' }, items: [{ name: '{{ item.name }}', quantity: 1, unit_price: 0, total_price: 0 }] }, null, 2), 'template')} className="absolute top-2 left-2 flex items-center gap-1 text-xs text-slate-400 hover:text-slate-700 bg-white/80 px-2 py-1 rounded-lg border border-slate-200 z-10">{copied === 'template' ? <CheckCircle className="w-3 h-3 text-success-500" /> : <Copy className="w-3 h-3" />}{copied === 'template' ? 'تم' : 'نسخ'}</button>
              <pre className="bg-slate-900 text-slate-200 rounded-xl p-4 text-xs overflow-x-auto font-mono leading-relaxed pt-9">{JSON.stringify({ restaurant_id: restaurant?.id ?? 'YOUR_ID', order_number: 'ORD-{{ $json.message_id }}', channel: 'telegram', total: '{{ $json.total }}', notes: '{{ $json.text }}', customer: { name: '{{ $json.first_name }}', telegram_id: '{{ $json.from.id }}' }, items: [{ name: '{{ item.name }}', quantity: 1, unit_price: 0, total_price: 0 }] }, null, 2)}</pre>
            </div>
          </details>
        </motion.div>
      )}

      {/* Save Button */}
      <div className="flex items-center gap-4 pb-4">
        <button onClick={handleSave} disabled={saving} className="btn-primary">
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {saving ? 'جارٍ الحفظ...' : 'حفظ الإعدادات'}
        </button>
        <AnimatePresence>
          {saved && (
            <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} className="flex items-center gap-2 text-success-600 text-sm font-semibold"><CheckCircle className="w-4 h-4" /> تم الحفظ بنجاح</motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
