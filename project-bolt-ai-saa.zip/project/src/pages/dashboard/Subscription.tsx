import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  CreditCard, Calendar, Check, AlertCircle, TrendingUp, Zap,
  FileText, Loader2, RefreshCw, Info, CheckCircle, XCircle, Hourglass,
  Upload, X, Image as ImageIcon
} from 'lucide-react';
import { useSubscription } from '../../contexts/SubscriptionContext';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import { uploadReceipt } from '../../lib/receiptUpload';
import type { SystemPlan } from '../../lib/database.types';

export default function Subscription() {
  const { restaurant } = useAuth();
  const {
    plans,
    subscriptionStatus,
    subscriptionRequests,
    loading,
    hasUsedFreePlan,
    requestSubscription,
    refreshSubscription,
  } = useSubscription();

  const [selectedPlan, setSelectedPlan] = useState<SystemPlan | null>(null);
  const [paymentProofUrl, setPaymentProofUrl] = useState('');
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function handleFileUpload(file: File | null) {
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      setError('حجم الملف يجب ألا يتجاوز 10 ميجابايت');
      return;
    }
    setUploading(true);
    setError('');
    try {
      const publicUrl = await uploadReceipt(file, restaurant?.id || 'unknown');
      setPaymentProofUrl(publicUrl);
      setReceiptFile(file);
    } catch (err: any) {
      setError('فشل رفع الملف: ' + err.message);
    } finally {
      setUploading(false);
    }
  }

  async function handleSubmitPayment() {
    if (!selectedPlan) return;

    if (selectedPlan.plan_type === 'free') {
      if (hasUsedFreePlan) {
        setError('لقد استخدمت الباقة المجانية من قبل. يرجى اختيار أحد الباقات المدفوعة.');
        return;
      }
    } else if (!paymentProofUrl.trim()) {
      setError('يرجى رفع إيصال الدفع');
      return;
    }

    setSubmitting(true);
    setError('');
    setSuccess('');

    const result = await requestSubscription(selectedPlan.id, paymentProofUrl, notes);

    if (result.error) {
      setError(result.error);
      setSubmitting(false);
      return;
    }

    if (selectedPlan.plan_type === 'free') {
      setSuccess('تم تفعيل الخطة المجانية بنجاح!');
    } else {
      setSuccess('تم إرسال طلب الاشتراك بنجاح! سيتم مراجعته خلال 24 ساعة.');
    }
    setSelectedPlan(null);
    setPaymentProofUrl('');
    setReceiptFile(null);
    setNotes('');
    setSubmitting(false);
    await refreshSubscription();
  }

  function getStatusBadge(status: string) {
    switch (status) {
      case 'active': return <span className="badge badge-success">نشط</span>;
      case 'expired': return <span className="badge badge-danger">منتهي</span>;
      case 'pending_payment': return <span className="badge badge-warning">بانتظار الدفع</span>;
      case 'suspended': return <span className="badge badge-danger">موقوف</span>;
      case 'cancelled': return <span className="badge badge-danger">ملغي</span>;
      default: return <span className="badge badge-neutral">{status}</span>;
    }
  }

  function getPaymentStatusBadge(status: string) {
    switch (status) {
      case 'approved': return <span className="badge badge-success"><CheckCircle className="w-3 h-3 mr-1" />تمت الموافقة</span>;
      case 'rejected': return <span className="badge badge-danger"><XCircle className="w-3 h-3 mr-1" />مرفوض</span>;
      case 'pending': default: return <span className="badge badge-warning"><Hourglass className="w-3 h-3 mr-1" />قيد المراجعة</span>;
    }
  }

  const subscribablePlans = plans.filter(p => p.can_subscribe && p.is_active && !p.is_trial);

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900">الاشتراك والفواتير</h1>
          <p className="text-sm text-slate-500 mt-1">إدارة باقتك — اشتراك شهري</p>
        </div>
        <button onClick={refreshSubscription} disabled={loading} className="btn-secondary text-sm">
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> تحديث
        </button>
      </div>

      {subscriptionStatus && subscriptionStatus.daysRemaining <= 7 && subscriptionStatus.status === 'active' && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="bg-warning-50 border border-warning-200 rounded-xl p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-warning-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-warning-800">{subscriptionStatus.daysRemaining === 0 ? 'ينتهي اشتراكك اليوم!' : `ينتهي اشتراكك خلال ${subscriptionStatus.daysRemaining} أيام`}</p>
            <p className="text-sm text-warning-700 mt-1">قم بتجديد الاشتراك لضمان استمرارية الخدمة</p>
          </div>
        </motion.div>
      )}

      {subscriptionStatus && subscriptionStatus.status !== 'active' && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="bg-danger-50 border border-danger-200 rounded-xl p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-danger-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-danger-800">انتهى اشتراكك</p>
            <p className="text-sm text-danger-700 mt-1">يرجى التجديد لمتابعة استخدام النظام</p>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-primary-100 rounded-xl flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-primary-600" />
            </div>
            <div>
              <p className="text-xs text-slate-500">الباقة الحالية</p>
              <p className="font-bold text-slate-900">{subscriptionStatus?.planNameAr || 'غير مشترك'}</p>
            </div>
          </div>
          {subscriptionStatus && (
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-slate-500">الحالة</span>{getStatusBadge(subscriptionStatus.status)}</div>
              <div className="flex justify-between"><span className="text-slate-500">دورة الفوترة</span><span className="font-semibold text-slate-900">شهري</span></div>
              <div className="flex justify-between"><span className="text-slate-500">الأيام المتبقية</span><span className="font-semibold text-slate-900">{subscriptionStatus.daysRemaining} يوم</span></div>
            </div>
          )}
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="card p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-slate-600" />
            </div>
            <div>
              <p className="text-xs text-slate-500">الطلبات</p>
              <p className="font-bold text-slate-900">{subscriptionStatus?.ordersUsed || 0}{subscriptionStatus?.maxOrders && ` / ${subscriptionStatus.maxOrders}`}</p>
            </div>
          </div>
          <div className="space-y-2">
            {subscriptionStatus?.maxOrders && (
              <div className="w-full bg-slate-100 rounded-full h-2">
                <div className={`h-2 rounded-full transition-all ${(subscriptionStatus.ordersUsed / subscriptionStatus.maxOrders) > 0.9 ? 'bg-danger-500' : (subscriptionStatus.ordersUsed / subscriptionStatus.maxOrders) > 0.7 ? 'bg-warning-500' : 'bg-primary-500'}`} style={{ width: `${Math.min(100, (subscriptionStatus.ordersUsed / subscriptionStatus.maxOrders) * 100)}%` }} />
              </div>
            )}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="card p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center">
              <Calendar className="w-5 h-5 text-slate-600" />
            </div>
            <div>
              <p className="text-xs text-slate-500">تاريخ الانتهاء</p>
              <p className="font-bold text-slate-900">{subscriptionStatus?.expiresAt ? new Date(subscriptionStatus.expiresAt).toLocaleDateString('ar-EG') : 'غير محدد'}</p>
            </div>
          </div>
          {subscriptionStatus?.isTrialPlan && (
            <span className="text-primary-600 flex items-center gap-1 text-sm"><Zap className="w-3 h-3" /> باقة تجريبية</span>
          )}
        </motion.div>
      </div>

      {subscriptionStatus && (
        <div className="card p-4">
          <h3 className="text-sm font-bold text-slate-800 mb-3">حدود الباقة</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-slate-50 rounded-lg p-3 text-center"><p className="text-xs text-slate-500">الطلبات</p><p className="font-bold text-slate-900">{subscriptionStatus.maxOrders ?? '∞'}</p></div>
            <div className="bg-slate-50 rounded-lg p-3 text-center"><p className="text-xs text-slate-500">المستخدمين</p><p className="font-bold text-slate-900">{subscriptionStatus.maxUsers ?? '∞'}</p></div>
            <div className="bg-slate-50 rounded-lg p-3 text-center"><p className="text-xs text-slate-500">الفروع</p><p className="font-bold text-slate-900">{subscriptionStatus.maxBranches ?? '∞'}</p></div>
            <div className="bg-slate-50 rounded-lg p-3 text-center"><p className="text-xs text-slate-500">المميزات</p><p className="font-bold text-slate-900">{subscriptionStatus.features.length}</p></div>
          </div>
        </div>
      )}

      <div className="card p-6">
        <h2 className="text-base font-bold text-slate-900 mb-4">ترقية الاشتراك</h2>
        <p className="text-sm text-slate-500 mb-6">اشتراك شهري فقط — اختر الباقة المناسبة</p>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {subscribablePlans.map(plan => (
            <div key={plan.id} onClick={() => setSelectedPlan(plan)} className={`border rounded-xl p-4 cursor-pointer transition-all ${selectedPlan?.id === plan.id ? 'border-primary-500 bg-primary-50 ring-2 ring-primary-200' : 'border-slate-200 hover:border-slate-300'}`}>
              <h3 className="font-bold text-slate-900 mb-1">{plan.name_ar || plan.plan_name}</h3>
              <div className="flex items-baseline gap-1 mb-2">
                {plan.plan_type === 'enterprise' ? (
                  <span className="text-lg font-bold text-slate-900">تواصل معنا</span>
                ) : plan.plan_type === 'free' || plan.price_monthly === 0 ? (
                  <span className="text-lg font-bold text-success-600">مجاني</span>
                ) : (
                  <>
                    <span className="text-2xl font-bold text-slate-900">{plan.price_monthly}</span>
                    <span className="text-sm text-slate-400">ج.م/شهر</span>
                  </>
                )}
              </div>
              <div className="space-y-1 text-xs text-slate-500 mb-2">
                {plan.max_orders != null && <p>{plan.max_orders} طلب / شهر</p>}
                {plan.max_branches != null && <p>{plan.max_branches} فرع</p>}
                {plan.max_users != null && <p>{plan.max_users} مستخدم</p>}
              </div>
              {((plan.features as string[]) || []).length > 0 && (
                <ul className="space-y-1 text-xs text-slate-600">
                  {((plan.features as string[]) || []).slice(0, 4).map((f, i) => (
                    <li key={i} className="flex items-center gap-1"><Check className="w-3 h-3 text-success-500 flex-shrink-0" />{f}</li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>

        {selectedPlan && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="mt-6 pt-6 border-t border-slate-200">
            <h3 className="font-semibold text-slate-900 mb-4">تفاصيل الاشتراك</h3>

            {error && <div className="bg-danger-50 border border-danger-200 text-danger-600 text-sm px-4 py-3 rounded-xl mb-4">{error}</div>}
            {success && <div className="bg-success-50 border border-success-200 text-success-600 text-sm px-4 py-3 rounded-xl mb-4">{success}</div>}

            {selectedPlan.plan_type === 'free' && hasUsedFreePlan && (
              <div className="bg-warning-50 border border-warning-200 rounded-xl p-4 mb-4 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-warning-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-warning-800">لقد استخدمت الباقة المجانية من قبل</p>
                  <p className="text-sm text-warning-700 mt-1">يرجى اختيار أحد الباقات المدفوعة.</p>
                </div>
              </div>
            )}

            {selectedPlan.plan_type !== 'free' && (
              <div className="space-y-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">رفع إيصال الدفع (إلزامي)</label>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,application/pdf"
                    onChange={e => handleFileUpload(e.target.files?.[0] || null)}
                    className="hidden"
                    disabled={submitting || uploading}
                  />
                  {!paymentProofUrl ? (
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={submitting || uploading}
                      className="w-full border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-primary-400 hover:bg-primary-50 transition-all"
                    >
                      {uploading ? (
                        <><Loader2 className="w-6 h-6 mx-auto mb-2 text-primary-500 animate-spin" /><p className="text-sm text-slate-500">جارٍ الرفع...</p></>
                      ) : (
                        <><Upload className="w-6 h-6 mx-auto mb-2 text-slate-400" /><p className="text-sm text-slate-500">اضغط لرفع صورة الإيصال</p><p className="text-xs text-slate-400 mt-1">PNG, JPG, PDF — حتى 10MB</p></>
                      )}
                    </button>
                  ) : (
                    <div className="flex items-center gap-3 bg-success-50 border border-success-200 rounded-xl p-3">
                      <ImageIcon className="w-5 h-5 text-success-600 flex-shrink-0" />
                      <span className="text-sm text-success-700 flex-1 truncate">{receiptFile?.name || 'تم رفع الإيصال'}</span>
                      <button onClick={() => { setPaymentProofUrl(''); setReceiptFile(null); }} className="text-slate-400 hover:text-danger-500">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">ملاحظات (اختياري)</label>
                  <textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="أي ملاحظات تريد إرسالها للإدارة..." className="input-field min-h-[80px]" disabled={submitting} />
                </div>
              </div>
            )}

            <div className="mt-4 flex items-center justify-between">
              <div className="text-sm text-slate-500">
                <Info className="w-4 h-4 inline mr-1" />
                {selectedPlan.plan_type === 'free' ? (
                  <span className="font-semibold text-slate-900">تفعيل خطة مجانية</span>
                ) : selectedPlan.plan_type === 'enterprise' ? (
                  <span className="font-semibold text-slate-900">سيتم التواصل معك</span>
                ) : (
                  <>المبلغ: <span className="font-semibold text-slate-900">{selectedPlan.price_monthly} ج.م</span> <span className="text-xs text-slate-400 mr-1">(شهري — 30 يوم)</span></>
                )}
              </div>
              <button onClick={handleSubmitPayment} disabled={submitting || uploading || (selectedPlan.plan_type === 'free' && hasUsedFreePlan) || (selectedPlan.plan_type !== 'free' && !paymentProofUrl.trim())} className="btn-primary">
                {submitting ? <><Loader2 className="w-4 h-4 animate-spin" /> جارٍ الإرسال...</> : <>{selectedPlan.plan_type === 'free' ? 'تفعيل' : 'إرسال طلب الاشتراك'} <CreditCard className="w-4 h-4 mr-2" /></>}
              </button>
            </div>
          </motion.div>
        )}
      </div>

      <div className="card overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100">
          <h2 className="text-base font-bold text-slate-900">سجل طلبات الاشتراك</h2>
        </div>
        {subscriptionRequests.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <FileText className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p>لا توجد طلبات سابقة</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">الباقة</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">المبلغ</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-slate-700">التاريخ</th>
                  <th className="px-4 py-3 text-center text-xs font-bold text-slate-700">الحالة</th>
                </tr>
              </thead>
              <tbody>
                {subscriptionRequests.map(req => {
                  const plan = plans.find(p => p.id === req.plan_id);
                  return (
                    <tr key={req.id} className="border-b border-slate-50 hover:bg-slate-50">
                      <td className="px-4 py-3 font-medium text-slate-900">{plan?.name_ar || plan?.plan_name || 'غير معروف'}</td>
                      <td className="px-4 py-3 text-slate-600">{req.amount} {req.currency}</td>
                      <td className="px-4 py-3 text-slate-500">{new Date(req.created_at).toLocaleDateString('ar-EG')}</td>
                      <td className="px-4 py-3 text-center">{getPaymentStatusBadge(req.status)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
