import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Save, Loader2, CheckCircle, Crown, Medal, Gem, Star } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import type { CustomerTier } from '../../lib/database.types';

const TIER_ICONS: Record<string, React.FC<any>> = {
  bronze: Medal,
  silver: Star,
  gold: Crown,
  platinum: Gem,
};

const DEFAULT_TIERS: Omit<CustomerTier, 'id' | 'restaurant_id' | 'created_at' | 'updated_at'>[] = [
  { tier_name: 'bronze', tier_label_ar: 'برونزي', min_points: 0, max_points: 500, color_hex: '#a16207', benefits: 'بدء البرنامج', sort_order: 1 },
  { tier_name: 'silver', tier_label_ar: 'فضي', min_points: 501, max_points: 1500, color_hex: '#64748b', benefits: 'خصم 5% على كل طلب', sort_order: 2 },
  { tier_name: 'gold', tier_label_ar: 'ذهبي', min_points: 1501, max_points: 5000, color_hex: '#d97706', benefits: 'خصم 10% + توصيل مجاني', sort_order: 3 },
  { tier_name: 'platinum', tier_label_ar: 'بلاتيني', min_points: 5001, max_points: null, color_hex: '#0ea5e9', benefits: 'خصم 15% + توصيل مجاني + أولوية', sort_order: 4 },
];

export default function TiersManager() {
  const { restaurant } = useAuth();
  const [tiers, setTiers] = useState<CustomerTier[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (restaurant) fetchTiers();
  }, [restaurant]);

  async function fetchTiers() {
    if (!restaurant) return;
    setLoading(true);
    const { data } = await supabase
      .from('customer_tiers')
      .select('*')
      .eq('restaurant_id', restaurant.id)
      .order('sort_order', { ascending: true });

    if (data && data.length > 0) {
      setTiers(data);
    } else if (restaurant) {
      // Seed defaults
      const seed = DEFAULT_TIERS.map(t => ({ ...t, restaurant_id: restaurant.id }));
      await supabase.from('customer_tiers').insert(seed);
      const { data: seeded } = await supabase
        .from('customer_tiers')
        .select('*')
        .eq('restaurant_id', restaurant.id)
        .order('sort_order', { ascending: true });
      setTiers(seeded ?? []);
    }
    setLoading(false);
  }

  function updateTier(id: string, field: keyof CustomerTier, value: string | number | null) {
    setTiers(prev => prev.map(t => t.id === id ? { ...t, [field]: value } : t));
  }

  async function handleSave() {
    if (!restaurant) return;
    setSaving(true);

    for (const tier of tiers) {
      await supabase.from('customer_tiers').update({
        tier_label_ar: tier.tier_label_ar,
        min_points: tier.min_points,
        max_points: tier.max_points,
        color_hex: tier.color_hex,
        benefits: tier.benefits,
      }).eq('id', tier.id);
    }

    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64" dir="rtl">
        <div className="w-6 h-6 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">مستويات العملاء</h1>
        <p className="text-sm text-slate-500 mt-0.5">تخصيص حدود النقاط والمميزات لكل مستوى</p>
      </div>

      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
        {tiers.map((tier) => {
          const Icon = TIER_ICONS[tier.tier_name] ?? Star;
          return (
            <div key={tier.id} className="card p-5 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: tier.color_hex + '20' }}>
                  <Icon className="w-5 h-5" style={{ color: tier.color_hex }} />
                </div>
                <div>
                  <p className="font-bold text-slate-900">{tier.tier_label_ar}</p>
                  <p className="text-xs text-slate-400 capitalize">{tier.tier_name}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">الحد الأدنى للنقاط</label>
                  <input
                    type="number"
                    min={0}
                    value={tier.min_points}
                    onChange={e => updateTier(tier.id, 'min_points', parseInt(e.target.value) || 0)}
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">الحد الأقصى للنقاط</label>
                  <input
                    type="number"
                    min={0}
                    value={tier.max_points ?? ''}
                    onChange={e => {
                      const val = e.target.value;
                      updateTier(tier.id, 'max_points', val === '' ? null : parseInt(val));
                    }}
                    placeholder="بدون حد"
                    className="input-field"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">لون المستوى</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={tier.color_hex}
                      onChange={e => updateTier(tier.id, 'color_hex', e.target.value)}
                      className="w-10 h-10 rounded-lg border border-slate-200 cursor-pointer"
                    />
                    <input
                      value={tier.color_hex}
                      onChange={e => updateTier(tier.id, 'color_hex', e.target.value)}
                      className="input-field flex-1 font-mono text-xs"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">المميزات</label>
                  <input
                    value={tier.benefits ?? ''}
                    onChange={e => updateTier(tier.id, 'benefits', e.target.value)}
                    placeholder="مثال: خصم 10%"
                    className="input-field"
                  />
                </div>
              </div>
            </div>
          );
        })}
      </motion.div>

      <div className="flex items-center gap-4 pb-4">
        <button onClick={handleSave} disabled={saving} className="btn-primary">
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {saving ? 'جارٍ الحفظ...' : 'حفظ التغييرات'}
        </button>
        {saved && (
          <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} className="flex items-center gap-2 text-success-600 text-sm font-semibold">
            <CheckCircle className="w-4 h-4" /> تم الحفظ
          </motion.div>
        )}
      </div>
    </div>
  );
}
