export interface DeliveryZone {
  id: string;
  name: string;
  price: number;
}

export function resolveDeliveryFee(
  zoneId: string | null,
  zones: DeliveryZone[],
  defaultFee: number
): { zone: DeliveryZone | null; fee: number } {
  if (!zoneId) return { zone: null, fee: defaultFee };
  const matched = zones.find(z => z.id === zoneId) ?? null;
  return { zone: matched, fee: matched ? matched.price : defaultFee };
}

export function resolveDeliveryZoneByAddress(
  address: string,
  zones: DeliveryZone[]
): { zone: DeliveryZone | null; fee: number } {
  const addr = (address || '').trim().toLowerCase();
  if (!addr || zones.length === 0) return { zone: null, fee: 0 };
  const match = zones.find(
    z => addr.includes(z.name.toLowerCase()) || z.name.toLowerCase().includes(addr.split(' ')[0])
  );
  return match ? { zone: match, fee: match.price } : { zone: null, fee: 0 };
}
