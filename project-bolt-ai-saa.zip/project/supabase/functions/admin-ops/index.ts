import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return jsonError(401, "Missing auth header");
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: authError } = await supabase.auth.getUser(token);
    if (authError || !userData.user) {
      return jsonError(401, "Invalid token");
    }

    const { data: adminRecord } = await supabase
      .from("platform_admins")
      .select("id, role, is_active")
      .eq("user_id", userData.user.id)
      .eq("is_active", true)
      .maybeSingle();

    if (!adminRecord) {
      return jsonError(403, "Not an admin");
    }

    const body = await req.json();
    const { action } = body;

    switch (action) {
      case "get_stats":
        return await getStats(supabase);
      case "delete_restaurant":
        return await deleteRestaurant(supabase, body.restaurant_id, adminRecord, userData.user);
      case "delete_receipt":
        return await deleteReceipt(supabase, body.request_id);
      case "check_free_plan_used":
        return await checkFreePlanUsed(supabase, body.restaurant_id);
      case "get_subscription_stats":
        return await getSubscriptionStats(supabase);
      default:
        return jsonError(400, "Unknown action");
    }
  } catch (err) {
    return jsonError(500, err.message);
  }
});

function jsonError(code: number, msg: string) {
  return new Response(JSON.stringify({ error: msg }), {
    status: code,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function jsonOk(data: unknown) {
  return new Response(JSON.stringify(data), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function getStats(supabase: ReturnType<typeof createClient>) {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();

  const [{ count: totalRestaurants }, { count: totalCustomers }, { count: totalOrders }] = await Promise.all([
    supabase.from("restaurants").select("*", { count: "exact", head: true }),
    supabase.from("customers").select("*", { count: "exact", head: true }),
    supabase.from("orders").select("*", { count: "exact", head: true }),
  ]);

  const { count: dailyOrders } = await supabase
    .from("orders").select("*", { count: "exact", head: true })
    .gte("created_at", todayStart);

  const { data: deliveredRevenue } = await supabase
    .from("orders").select("total")
    .eq("status", "delivered");
  const totalRevenue = (deliveredRevenue || []).reduce((s: number, r: any) => s + Number(r.total || 0), 0);

  const { data: dailyRevData } = await supabase
    .from("orders").select("total")
    .eq("status", "delivered")
    .gte("created_at", todayStart);
  const dailyRevenue = (dailyRevData || []).reduce((s: number, r: any) => s + Number(r.total || 0), 0);

  const { count: newRestaurantsThisMonth } = await supabase
    .from("restaurants").select("*", { count: "exact", head: true })
    .gte("created_at", monthStart);

  const { count: newCustomersThisMonth } = await supabase
    .from("customers").select("*", { count: "exact", head: true })
    .gte("created_at", monthStart);

  // Active: has active subscription, not suspended
  const { data: activeSubs } = await supabase
    .from("restaurant_subscriptions").select("restaurant_id, plan_id, expires_at, status")
    .eq("status", "active").gt("expires_at", now.toISOString());
  const activeRestaurantIds = new Set((activeSubs || []).map((s: any) => s.restaurant_id));

  const { data: allRestaurants } = await supabase
    .from("restaurants").select("id, name, is_active, is_suspended, subscription_plan, subscription_expires_at, created_at");

  const active = (allRestaurants || []).filter(r => activeRestaurantIds.has(r.id) && !r.is_suspended);
  const expired = (allRestaurants || []).filter(r =>
    !activeRestaurantIds.has(r.id) && !r.is_suspended && r.subscription_expires_at && new Date(r.subscription_expires_at) < now
  );

  // Trial: active sub with free/trial plan
  const { data: planData } = await supabase.from("system_plans").select("id, plan_type, is_trial");
  const freePlanIds = new Set((planData || []).filter((p: any) => p.plan_type === "free" || p.is_trial).map((p: any) => p.id));
  const trial = (activeSubs || []).filter((s: any) => freePlanIds.has(s.plan_id));

  // Pending: subscription_requests with status pending
  const { count: pendingActivations } = await supabase
    .from("subscription_requests").select("*", { count: "exact", head: true })
    .eq("status", "pending");

  // MRR / ARR
  const { data: activePaidSubs } = await supabase
    .from("restaurant_subscriptions").select("plan_id, expires_at, status")
    .eq("status", "active").gt("expires_at", now.toISOString());
  const paidPlanPrices = new Map((planData || []).filter((p: any) => p.plan_type !== "free" && !p.is_trial).map((p: any) => [p.id, Number(p.price_monthly || 0)]));
  const mrr = (activePaidSubs || []).reduce((s: number, sub: any) => s + (paidPlanPrices.get(sub.plan_id) || 0), 0);
  const arr = mrr * 12;

  // Top restaurants
  const { data: topData } = await supabase
    .from("restaurants").select("id, name").order("created_at", { ascending: false }).limit(50);
  const topRestaurants = [];
  for (const r of (topData || [])) {
    const [{ count: orders }, { data: revRows }] = await Promise.all([
      supabase.from("orders").select("*", { count: "exact", head: true }).eq("restaurant_id", r.id),
      supabase.from("orders").select("total").eq("restaurant_id", r.id).eq("status", "delivered"),
    ]);
    const revenue = (revRows || []).reduce((s: number, row: any) => s + Number(row.total || 0), 0);
    topRestaurants.push({ id: r.id, name: r.name, orders: orders || 0, revenue });
  }
  topRestaurants.sort((a, b) => b.revenue - a.revenue || b.orders - a.orders);
  const top10 = topRestaurants.slice(0, 10);

  return jsonOk({
    total_restaurants: totalRestaurants || 0,
    active_restaurants: active.length,
    expired_restaurants: expired.length,
    trial_restaurants: trial.length,
    pending_activations: pendingActivations || 0,
    total_customers: totalCustomers || 0,
    total_orders: totalOrders || 0,
    daily_orders: dailyOrders || 0,
    total_revenue: totalRevenue,
    daily_revenue: dailyRevenue,
    mrr,
    arr,
    new_restaurants_this_month: newRestaurantsThisMonth || 0,
    new_customers_this_month: newCustomersThisMonth || 0,
    top_restaurants: top10,
  });
}

async function deleteRestaurant(supabase: ReturnType<typeof createClient>, restaurantId: string, admin: any, user: any) {
  if (!restaurantId) return jsonError(400, "restaurant_id required");

  const tables = [
    "order_items", "order_events", "orders", "points_transactions",
    "reward_redemptions", "reward_catalog", "customer_points_wallet",
    "customer_tiers", "loyalty_transactions", "loyalty_rewards",
    "loyalty_settings", "customers", "menu_items", "menu_categories",
    "delivery_zones", "notifications", "analytics_snapshots",
    "telegram_sessions", "telegram_menu_cache", "telegram_sync_logs",
    "telegram_bots", "subscription_history", "subscription_requests",
    "restaurant_subscriptions", "onboarding_progress", "support_tickets",
    "activity_logs", "order_status_history",
  ];

  // Delete order_items through orders
  const { data: orderIds } = await supabase.from("orders").select("id").eq("restaurant_id", restaurantId);
  if (orderIds && orderIds.length > 0) {
    const ids = orderIds.map((o: any) => o.id);
    await supabase.from("order_items").delete().in("order_id", ids);
  }

  for (const table of tables) {
    if (table === "order_items") continue;
    try {
      await supabase.from(table).delete().eq("restaurant_id", restaurantId);
    } catch { /* table may not have restaurant_id column */ }
  }

  // Delete storage files for this restaurant
  try {
    await supabase.storage.from("restaurant-logos").remove([`logos/${restaurantId}`]);
    await supabase.storage.from("menu-images").remove([`menu/${restaurantId}`]);
    await supabase.storage.from("payment-receipts").remove([`receipts/${restaurantId}`]);
  } catch { /* ignore storage errors */ }

  await supabase.from("restaurants").delete().eq("id", restaurantId);

  await supabase.from("admin_audit_logs").insert({
    admin_id: user.id,
    admin_email: user.email,
    action: "delete_restaurant",
    target_type: "restaurant",
    target_id: restaurantId,
    target_name: restaurantId,
    details: { permanent: true },
  });

  return jsonOk({ success: true });
}

async function deleteReceipt(supabase: ReturnType<typeof createClient>, requestId: string) {
  if (!requestId) return jsonError(400, "request_id required");

  const { data: req } = await supabase
    .from("subscription_requests").select("payment_proof_url, restaurant_id, plan_id")
    .eq("id", requestId).maybeSingle();

  if (!req) return jsonError(404, "Request not found");

  // Delete from storage if it's a storage path
  if (req.payment_proof_url) {
    try {
      const url = req.payment_proof_url;
      if (url.includes("/storage/")) {
        const path = url.split("/payment-receipts/")[1];
        if (path) await supabase.storage.from("payment-receipts").remove([path]);
      }
    } catch { /* ignore */ }
  }

  await supabase.from("subscription_requests").update({ payment_proof_url: null, updated_at: new Date().toISOString() }).eq("id", requestId);
  await supabase.from("restaurant_subscriptions").update({ payment_proof_url: null, updated_at: new Date().toISOString() })
    .eq("restaurant_id", req.restaurant_id).eq("plan_id", req.plan_id);

  return jsonOk({ success: true, message: "Receipt deleted" });
}

async function checkFreePlanUsed(supabase: ReturnType<typeof createClient>, restaurantId: string) {
  if (!restaurantId) return jsonError(400, "restaurant_id required");

  // Check if restaurant has has_used_free_plan column
  const { data: restaurant } = await supabase
    .from("restaurants").select("has_used_trial, has_used_free_plan")
    .eq("id", restaurantId).maybeSingle();

  const hasUsedFreePlan = (restaurant as any)?.has_used_free_plan || false;
  const hasUsedTrial = (restaurant as any)?.has_used_trial || false;

  // Also check subscription history for any free plan activation
  const { data: freePlanSubs } = await supabase
    .from("restaurant_subscriptions").select("id, plan_id")
    .eq("restaurant_id", restaurantId)
    .eq("trial_used", true);

  return jsonOk({
    has_used_free_plan: hasUsedFreePlan || (freePlanSubs && freePlanSubs.length > 0),
    has_used_trial: hasUsedTrial,
  });
}

async function getSubscriptionStats(supabase: ReturnType<typeof createClient>) {
  const now = new Date().toISOString();

  const { count: totalRestaurants } = await supabase
    .from("restaurants").select("*", { count: "exact", head: true });

  // Active subscriptions
  const { data: activeSubs } = await supabase
    .from("restaurant_subscriptions").select("restaurant_id, plan_id, status, expires_at")
    .eq("status", "active").gt("expires_at", now);
  const activeIds = new Set((activeSubs || []).map((s: any) => s.restaurant_id));

  const { data: allRestaurants } = await supabase
    .from("restaurants").select("id, is_suspended, subscription_expires_at");

  const active = (allRestaurants || []).filter(r => activeIds.has(r.id) && !r.is_suspended);
  const suspended = (allRestaurants || []).filter(r => r.is_suspended);
  const expired = (allRestaurants || []).filter(r =>
    !activeIds.has(r.id) && !r.is_suspended && r.subscription_expires_at && new Date(r.subscription_expires_at) < new Date()
  );

  const { count: pendingPayment } = await supabase
    .from("subscription_requests").select("*", { count: "exact", head: true })
    .eq("status", "pending");

  return jsonOk({
    total_restaurants: totalRestaurants || 0,
    active: active.length,
    expired: expired.length,
    suspended: suspended.length,
    pending_payment: pendingPayment || 0,
  });
}
