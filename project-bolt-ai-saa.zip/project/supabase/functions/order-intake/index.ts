import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const body = await req.json();
    const {
      restaurant_id,
      order_number,
      channel = "telegram",
      total = 0,
      subtotal = 0,
      discount = 0,
      tax = 0,
      notes = "",
      delivery_address = "",
      payment_method = "cash",
      items = [],
      customer,
    } = body;

    if (!restaurant_id) {
      return new Response(JSON.stringify({ error: "restaurant_id is required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: restaurant } = await supabase
      .from("restaurants")
      .select("id, name, telegram_bot_token, telegram_chat_id")
      .eq("id", restaurant_id)
      .maybeSingle();

    if (!restaurant) {
      return new Response(JSON.stringify({ error: "Restaurant not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Validate bot token if supplied
    const suppliedToken = (body.bot_token ?? body.channel_token) as string | undefined;
    if (suppliedToken && restaurant.telegram_bot_token && suppliedToken !== restaurant.telegram_bot_token) {
      return new Response(JSON.stringify({ error: "Unauthorized: bot token mismatch" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Upsert customer — lookup by telegram_id or whatsapp_id
    let customerId: string | null = null;
    if (customer?.name || customer?.telegram_id) {
      const lookupField = customer.telegram_id ? "telegram_id" : customer.whatsapp_id ? "whatsapp_id" : null;
      let existingCustomer: { id: string } | null = null;

      if (lookupField) {
        const { data } = await supabase
          .from("customers")
          .select("id")
          .eq("restaurant_id", restaurant_id)
          .eq(lookupField, customer[lookupField])
          .maybeSingle();
        existingCustomer = data;
      }

      if (existingCustomer) {
        customerId = existingCustomer.id;
        // Only update if something changed
        await supabase.from("customers").update({
          name:    customer.name ?? undefined,
          address: customer.address ?? delivery_address ?? undefined,
        }).eq("id", customerId);
      } else {
        const { data: newCustomer } = await supabase.from("customers").insert({
          restaurant_id,
          name:        customer.name ?? "عميل",
          telegram_id: customer.telegram_id ?? "",
          whatsapp_id: customer.whatsapp_id ?? "",
          phone:       customer.phone ?? "",
          channel,
          address:     customer.address ?? delivery_address ?? "",
          total_orders: 0,
          total_spent:  0,
        }).select("id").maybeSingle();
        customerId = newCustomer?.id ?? null;
      }
    }

    const finalOrderNumber = order_number ?? `ORD-${Date.now().toString(36).toUpperCase()}`;
    const orderTotal       = parseFloat(String(total)) || 0;
    const orderSubtotal    = parseFloat(String(subtotal)) || orderTotal;
    const orderDiscount    = parseFloat(String(discount)) || 0;
    const orderTax         = parseFloat(String(tax)) || 0;

    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert({
        restaurant_id,
        customer_id:      customerId,
        order_number:     finalOrderNumber,
        status:           "pending",
        channel,
        subtotal:         orderSubtotal,
        discount:         orderDiscount,
        tax:              orderTax,
        total:            orderTotal,
        notes,
        delivery_address,
        payment_method,
        raw_payload:      body,
      })
      .select("id")
      .maybeSingle();

    if (orderError || !order) {
      return new Response(JSON.stringify({ error: orderError?.message ?? "Failed to create order" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Insert order items WITH menu_item_id
    if (Array.isArray(items) && items.length > 0) {
      await supabase.from("order_items").insert(
        items.map((item: {
          name?: string; quantity?: number; unit_price?: number;
          total_price?: number; notes?: string; menu_item_id?: string
        }) => ({
          order_id:     order.id,
          menu_item_id: item.menu_item_id ?? null,
          name:         item.name ?? "صنف",
          quantity:     item.quantity ?? 1,
          unit_price:   item.unit_price ?? 0,
          total_price:  item.total_price ?? (item.unit_price ?? 0) * (item.quantity ?? 1),
          notes:        item.notes ?? "",
        }))
      );
    }

    // NOTE: customer stats (total_orders, total_spent) are now handled by DB trigger
    // trg_customer_stats_on_order — no manual update needed here.

    // In-app notification
    await supabase.from("notifications").insert({
      restaurant_id,
      type:  "order",
      title: `طلب جديد #${finalOrderNumber}`,
      body:  notes || `طلب من ${channel} بقيمة ${orderTotal}`,
      data:  { order_id: order.id },
    });

    // Cashier Telegram notification (non-blocking)
    if (restaurant.telegram_bot_token && restaurant.telegram_chat_id) {
      const cur = "ج.م";
      const msg = `🍽 *طلب جديد — ${restaurant.name}*\n\n` +
        `📋 رقم: \`${finalOrderNumber}\`\n` +
        `📱 القناة: ${channel}\n` +
        `💰 الإجمالي: *${orderTotal} ${cur}*\n` +
        (notes ? `📝 ملاحظة: ${notes}\n` : "") +
        (customer?.name ? `👤 العميل: ${customer.name}\n` : "") +
        (customer?.phone ? `📞 الهاتف: ${customer.phone}\n` : "");

      EdgeRuntime.waitUntil(
        fetch(`https://api.telegram.org/bot${restaurant.telegram_bot_token}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chat_id: restaurant.telegram_chat_id, text: msg, parse_mode: "Markdown" }),
        }).catch(() => null)
      );
    }

    return new Response(
      JSON.stringify({ success: true, order_id: order.id, order_number: finalOrderNumber }),
      { status: 201, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
