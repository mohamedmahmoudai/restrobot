import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

// Order status messages - friendly and professional
const STATUS_MESSAGES: Record<string, { emoji: string; title: string; body: string }> = {
  pending: {
    emoji: "🟡",
    title: "تم استلام طلبك",
    body: "سنبدأ التحضير قريباً.\nسنتواصل معك بمجرد تأكيد الطلب."
  },
  confirmed: {
    emoji: "✅",
    title: "تم تأكيد الطلب",
    body: "طلبك مؤكد الآن!\nسيبدأ التحضير في ближай وقت."
  },
  preparing: {
    emoji: "👨‍🍳",
    title: "جاري التحضير",
    body: "طلبك الآن قيد التحضير.\nسنخبرك بمجرد أن يصبح جاهزاً."
  },
  ready: {
    emoji: "📦",
    title: "الطلب جاهز",
    body: "طلبك جاهز الآن!\nسيتم التوصيل قريباً."
  },
  out_for_delivery: {
    emoji: "🛵",
    title: "الطلب في الطريق",
    body: "المندوب في طريقه إليك!\nاستعد لاستلام طلبك."
  },
  delivered: {
    emoji: "✅",
    title: "تم تسليم طلبك",
    body: "نتمنى أن تنال الخدمة إعجابك ❤️\n\nشكراً لاختيارنا!"
  },
  cancelled: {
    emoji: "❌",
    title: "تم إلغاء الطلب",
    body: "نعتذر عن أي إزعاج.\n\nيمكنك تقديم طلب جديد في أي وقت."
  }
};

// Keyboard for delivery confirmation (optional)
function kbDeliveredConfirmation() {
  return {
    inline_keyboard: [
      [{ text: "✅ تم الاستلام", callback_data: "confirm_delivery" }],
      [{ text: "🚀 اطلب مرة أخرى", callback_data: "start_order" }],
    ],
  };
}

// Keyboard for new order after completion
function kbNewOrder() {
  return {
    inline_keyboard: [
      [{ text: "🚀 ابدأ طلب جديد", callback_data: "start_order" }],
    ],
  };
}

// Send Telegram message
async function sendTelegramMessage(botToken: string, chatId: string, text: string, markup?: object) {
  try {
    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "Markdown",
        ...(markup ? { reply_markup: markup } : {})
      }),
    });
    const result = await response.json();
    console.log(`[TG_SEND] ok=${result?.ok} chat=${chatId}`);
    return result;
  } catch (e) {
    console.error(`[TG_SEND_ERROR] ${e}`);
    return null;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  try {
    const { order_id, status: providedStatus } = await req.json();
    if (!order_id) {
      return new Response(JSON.stringify({ error: "order_id is required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`[NOTIFY] order_id=${order_id} status=${providedStatus}`);

    // Fetch order with related data
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .select(`
        id, order_number, status, total, subtotal, notes, raw_payload,
        customers(id, name, phone, telegram_id),
        restaurants(id, telegram_bot_token, name, currency)
      `)
      .eq("id", order_id)
      .maybeSingle();

    if (orderError) {
      console.error(`[NOTIFY_ERROR] Failed to fetch order: ${orderError.message}`);
      return new Response(JSON.stringify({ error: "Failed to fetch order" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!order) {
      console.error(`[NOTIFY_ERROR] Order not found: ${order_id}`);
      return new Response(JSON.stringify({ error: "Order not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const botToken = (order.restaurants as any)?.telegram_bot_token;
    // Primary: telegram_chat_id stored permanently on the order at creation time
    // Fallback: customer's telegram_id (for backward compatibility with older orders)
    const rawPayload = (order as any)?.raw_payload as any;
    const storedChatId = rawPayload?.telegram_chat_id ?? rawPayload?.checkout_data?.telegram_chat_id;
    const telegramId = storedChatId || (order.customers as any)?.telegram_id;
    const restaurantName = (order.restaurants as any)?.name ?? "المطعم";
    const currencyCode = (order.restaurants as any)?.currency ?? "EGP";
    const curMap: Record<string, string> = { SAR: "ر.س", AED: "د.إ", EGP: "ج.م", KWD: "د.ك", USD: "$" };
    const cur = curMap[currencyCode] ?? "ج.م";

    // Use provided status or order status
    const status = providedStatus || order.status;

    console.log(`[NOTIFY] telegramId=${telegramId} hasToken=${!!botToken} status=${status}`);

    // Guard: skip notification if the order's current DB status doesn't match the requested status.
    // This prevents stale notifications from arriving after a newer status change.
    // e.g., if cashier clicks "Delivered" then "Preparing", the "Preparing" notification is skipped
    // because the order's actual status is already "delivered".
    if (providedStatus && order.status !== providedStatus) {
      console.log(`[NOTIFY_SKIP] Stale notification: requested=${providedStatus} but actual=${order.status}`);
      return new Response(JSON.stringify({ ok: true, skipped: "stale_status", requested: providedStatus, actual: order.status }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // If no Telegram data, just return success
    if (!telegramId || !botToken) {
      console.log(`[NOTIFY_SKIP] No Telegram configuration for customer`);
      return new Response(JSON.stringify({ ok: true, skipped: "no_telegram" }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get status message
    const statusInfo = STATUS_MESSAGES[status];
    if (!statusInfo) {
      console.log(`[NOTIFY_SKIP] Unknown status: ${status}`);
      return new Response(JSON.stringify({ ok: true, skipped: "unknown_status" }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Build message
    const total = Number(order.total ?? 0);
    let text = `${statusInfo.emoji} *${statusInfo.title}*\n\n`;
    text += `${statusInfo.body}\n\n`;
    text += `━━━━━━━━━━━━\n`;
    text += `🏪 *${restaurantName}*\n`;
    text += `📋 رقم الطلب: \`${order.order_number}\`\n`;
    text += `💰 الإجمالي: *${total.toFixed(0)} ${cur}*\n`;

    // Add order notes if present
    if (order.notes) {
      text += `\n📝 ملاحظات: ${order.notes}`;
    }

    // If delivered, show loyalty points
    if (status === "delivered" && (order.customers as any)?.id) {
      const customerId = (order.customers as any).id;
      const { data: wallet } = await supabase
        .from("customer_points_wallet")
        .select("current_points")
        .eq("customer_id", customerId)
        .maybeSingle();

      if (wallet) {
        text += `\n\n⭐ رصيد نقاطك: *${wallet.current_points} نقطة*`;
      }
    }

    // Choose keyboard based on status
    let keyboard = undefined;
    if (status === "delivered") {
      keyboard = kbDeliveredConfirmation();
    } else if (status === "cancelled") {
      keyboard = kbNewOrder();
    }
    // NOTE: telegram-notify must NEVER update telegram_sessions.
    // Session state is the single source of truth owned by telegram-webhook only.
    // The session resets when the user clicks "Start Order" (start_order callback).

    // Send message
    const result = await sendTelegramMessage(botToken, telegramId, text, keyboard);

    console.log(`[NOTIFY_SUCCESS] order=${order.order_number} status=${status}`);

    return new Response(JSON.stringify({ ok: result?.ok ?? false, tg: result }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (err) {
    console.error(`[NOTIFY_ERROR] ${err}`);
    return new Response(JSON.stringify({ error: "Internal error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
