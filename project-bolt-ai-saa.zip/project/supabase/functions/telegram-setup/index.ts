import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

async function tgGet(token: string, method: string) {
  const r = await fetch(`https://api.telegram.org/bot${token}/${method}`);
  return await r.json();
}

async function tgPost(token: string, method: string, body: object) {
  const r = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return await r.json();
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Verify the calling user owns this restaurant
  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: authHeader } } }
  );

  const { data: { user }, error: authError } = await userClient.auth.getUser();
  if (authError || !user) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  try {
    const body = await req.json();
    const { action, bot_token, restaurant_id } = body as {
      action: "setup" | "test" | "remove";
      bot_token?: string;
      restaurant_id: string;
    };

    // Verify ownership
    const { data: restaurant, error: restError } = await supabase
      .from("restaurants")
      .select("id, owner_id, telegram_bot_token, telegram_bot_username, telegram_webhook_status, telegram_owner_chat_id")
      .eq("id", restaurant_id)
      .eq("owner_id", user.id)
      .maybeSingle();

    if (restError || !restaurant) {
      return new Response(JSON.stringify({ error: "Restaurant not found or access denied" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const webhookUrl = `${Deno.env.get("SUPABASE_URL")}/functions/v1/telegram-webhook?restaurant_id=${restaurant_id}`;

    // ── SETUP: validate token + register webhook ─────────────────────────────
    if (action === "setup") {
      const token = (bot_token ?? "").trim();
      if (!token) {
        return new Response(JSON.stringify({ error: "bot_token is required" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // 1. Validate token via getMe
      const getMeRes = await tgGet(token, "getMe");
      if (!getMeRes.ok) {
        // Save invalid state
        await supabase.from("restaurants").update({
          telegram_bot_token:    token,
          telegram_webhook_status: "token_invalid",
          telegram_bot_username:   null,
          updated_at:              new Date().toISOString(),
        }).eq("id", restaurant_id);

        return new Response(JSON.stringify({
          ok: false,
          step: "validate_token",
          error: getMeRes.description ?? "Invalid bot token",
        }), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const botUsername = getMeRes.result?.username ?? null;
      const botFirstName = getMeRes.result?.first_name ?? null;

      // 2. Delete any existing webhook for this token (clean slate)
      await tgPost(token, "deleteWebhook", { drop_pending_updates: false });

      // 3. Register webhook
      const setWebhookRes = await tgPost(token, "setWebhook", {
        url: webhookUrl,
        allowed_updates: ["message", "callback_query"],
        drop_pending_updates: false,
      });

      if (!setWebhookRes.ok) {
        await supabase.from("restaurants").update({
          telegram_bot_token:      token,
          telegram_bot_username:   botUsername,
          telegram_webhook_status: "error",
          updated_at:              new Date().toISOString(),
        }).eq("id", restaurant_id);

        return new Response(JSON.stringify({
          ok: false,
          step: "register_webhook",
          error: setWebhookRes.description ?? "Failed to register webhook",
          bot_username: botUsername,
        }), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // 4. Persist everything
      await supabase.from("restaurants").update({
        telegram_bot_token:      token,
        telegram_bot_username:   botUsername,
        telegram_webhook_status: "active",
        telegram_webhook_set_at: new Date().toISOString(),
        updated_at:              new Date().toISOString(),
      }).eq("id", restaurant_id);

      return new Response(JSON.stringify({
        ok: true,
        bot_username: botUsername,
        bot_first_name: botFirstName,
        webhook_url: webhookUrl,
        owner_start_url: `https://t.me/${botUsername}?start=owner_${restaurant_id}`,
        message: `تم ربط البوت @${botUsername} بنجاح وتسجيل الويب هوك`,
      }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── TEST: send a test message to the owner's chat_id ────────────────────
    if (action === "test") {
      const token = restaurant.telegram_bot_token;
      if (!token) {
        return new Response(JSON.stringify({ ok: false, error: "لم يتم ضبط توكن البوت بعد" }), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const ownerChatId = restaurant.telegram_owner_chat_id;
      if (!ownerChatId) {
        return new Response(JSON.stringify({
          ok: false,
          error: "لم يتم تسجيل chat_id بعد. أرسل /start للبوت أولاً ثم اضغط اختبار مجدداً.",
        }), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const testRes = await tgPost(token, "sendMessage", {
        chat_id: ownerChatId,
        text: `✅ *اختبار الاتصال ناجح!*\n\nمرحباً! هذا تأكيد أن البوت يعمل بشكل صحيح.\n\n🤖 البوت: @${restaurant.telegram_bot_username ?? "unknown"}\n🔗 الويب هوك: مسجّل ونشط\n\nستصل إشعارات الطلبات الجديدة هنا.`,
        parse_mode: "Markdown",
      });

      if (!testRes.ok) {
        return new Response(JSON.stringify({
          ok: false,
          error: testRes.description ?? "فشل إرسال الرسالة التجريبية",
        }), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Also verify webhook is still registered
      const webhookInfo = await tgGet(token, "getWebhookInfo");
      const webhookActive = webhookInfo.result?.url === webhookUrl;

      return new Response(JSON.stringify({
        ok: true,
        message_sent: true,
        webhook_active: webhookActive,
        webhook_url: webhookInfo.result?.url ?? null,
        pending_updates: webhookInfo.result?.pending_update_count ?? 0,
      }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── REMOVE: delete webhook + clear bot config ────────────────────────────
    if (action === "remove") {
      const token = restaurant.telegram_bot_token;
      if (token) {
        await tgPost(token, "deleteWebhook", { drop_pending_updates: false });
      }

      await supabase.from("restaurants").update({
        telegram_bot_token:      null,
        telegram_bot_username:   null,
        telegram_webhook_status: "not_configured",
        telegram_owner_chat_id:  null,
        telegram_webhook_set_at: null,
        updated_at:              new Date().toISOString(),
      }).eq("id", restaurant_id);

      return new Response(JSON.stringify({ ok: true, message: "تم إزالة ربط البوت" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Unknown action" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (err) {
    console.error("telegram-setup error:", err);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
