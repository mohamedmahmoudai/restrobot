import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

// ── Types ────────────────────────────────────────────────────────────────────

type CartItem = {
  id: string;
  name: string;
  name_ar: string;
  price: number;
  quantity: number;
};

type CheckoutData = {
  address?: string;
  notes?: string;
  zone_id?: string;
  zone_name?: string;
  zone_price?: number;
  _reg_name?: string;
};

type Session = {
  id: string;
  restaurant_id: string;
  telegram_user_id: string;
  customer_id: string | null;
  state: string;
  current_category_id: string | null;
  cart: CartItem[];
  checkout_data: CheckoutData;
  message_id: string;
  updated_at?: string;
  restaurants?: {
    telegram_bot_token?: string;
    currency?: string;
    loyalty_enabled?: boolean;
    logo_url?: string;
    name?: string;
    is_closed?: boolean;
    closed_message?: string;
    telegram_menu_images?: string[];
  };
};

// ── State machine ────────────────────────────────────────────────────────────

const S = {
  IDLE:             "idle",
  MAIN_MENU:        "main_menu",
  BROWSING_MENU:    "browsing_menu",
  VIEWING_CATEGORY: "viewing_category",
  SELECTING_ZONE:   "selecting_zone",
  CART:             "cart",
  REG_NAME:         "reg_name",
  REG_PHONE:        "reg_phone",
  CHECKOUT_ADDRESS: "checkout_address",
  CHECKOUT_NOTES:   "checkout_notes",
  CONFIRM:          "confirm",
  VIEWING_REWARDS:  "viewing_rewards",
  POST_ORDER:       "post_order",  // After order completion
} as const;

// ── Supabase client ──────────────────────────────────────────────────────────

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

// ── Logging helper ──────────────────────────────────────────────────────────

function log(context: string, data: Record<string, unknown>) {
  console.log(JSON.stringify({ timestamp: new Date().toISOString(), context, ...data }));
}

// ── Performance tracker ─────────────────────────────────────────────────────

type PerfStep = { label: string; ms: number; ts: number };

class Perf {
  private steps: PerfStep[] = [];
  private t0 = performance.now();

  mark(label: string): void {
    const now = performance.now();
    const last = this.steps.length > 0 ? this.steps[this.steps.length - 1].ts : this.t0;
    this.steps.push({ label, ms: Math.round((now - last) * 100) / 100, ts: now });
  }

  total(): number {
    return Math.round((performance.now() - this.t0) * 100) / 100;
  }

  timeline(): { total_ms: number; steps: PerfStep[]; slow: boolean; bottleneck: string | null } {
    const total = this.total();
    let bottleneck: string | null = null;
    let maxMs = 0;
    for (const s of this.steps) {
      if (s.ms > maxMs) { maxMs = s.ms; bottleneck = s.label; }
    }
    return { total_ms: total, steps: this.steps, slow: total > 2000, bottleneck };
  }
}

let _perf: Perf | null = null;

function perf(): Perf {
  if (!_perf) _perf = new Perf();
  return _perf;
}

async function timed<T>(label: string, fn: () => Promise<T>): Promise<T> {
  const p = perf();
  const result = await fn();
  p.mark(label);
  return result;
}

// ── Telegram helpers ─────────────────────────────────────────────────────────

async function tg(token: string, method: string, body: object): Promise<{ ok: boolean; result?: any; description?: string } | null> {
  try {
    log(`tg_request`, { method, body });
    const r = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await r.json();
    perf().mark(`tg:${method}`);
    log(`tg_response`, { method, ok: data?.ok, description: data?.description });
    return data;
  } catch (e) {
    perf().mark(`tg:${method}:error`);
    log(`tg_error`, { method, error: e instanceof Error ? e.message : String(e) });
    return null;
  }
}

async function send(token: string, chatId: number | string, text: string, markup?: object): Promise<{ ok: boolean; result?: any } | null> {
  const result = await tg(token, "sendMessage", {
    chat_id: chatId, text, parse_mode: "Markdown",
    ...(markup ? { reply_markup: markup } : {}),
  });
  if (!result?.ok) {
    log(`send_failed_markdown`, { chatId, text: text.slice(0, 50), error: result?.description });
    // Retry without parse_mode — Markdown parse errors should never block the message
    const fallback = await tg(token, "sendMessage", {
      chat_id: chatId, text: text.replace(/[*_`[\]]/g, ""),
      ...(markup ? { reply_markup: markup } : {}),
    });
    if (!fallback?.ok) {
      log(`send_failed_plain`, { chatId, text: text.slice(0, 50), error: fallback?.description });
    }
    return fallback;
  }
  return result;
}

async function edit(token: string, chatId: number | string, msgId: string | number, text: string, markup?: object): Promise<{ ok: boolean; result?: any } | null> {
  const result = await tg(token, "editMessageText", {
    chat_id: chatId, message_id: msgId, text, parse_mode: "Markdown",
    ...(markup ? { reply_markup: markup } : {}),
  });
  if (!result?.ok && result?.description !== "Bad Request: message is not modified") {
    log(`edit_failed`, { chatId, msgId, text: text.slice(0, 50) });
  }
  return result;
}

// Fire-and-forget ack — Telegram answerCallbackQuery is non-critical and takes 600-900ms
// We don't need to wait for it before continuing
function ack(token: string, callbackId: string, text = ""): void {
  tg(token, "answerCallbackQuery", { callback_query_id: callbackId, text, show_alert: false })
    .then(result => { if (!result?.ok) log(`ack_failed`, { callbackId }); })
    .catch(() => {});
}

// ── Currency formatter ───────────────────────────────────────────────────────

function currencyLabel(code?: string | null): string {
  const map: Record<string, string> = { SAR: "ر.س", AED: "د.إ", KWD: "د.ك", USD: "$", EGP: "ج.م" };
  return (code && map[code]) ? map[code] : "ج.م";
}

function fmt(amount: number, cur: string) {
  return `${amount.toFixed(0)} ${cur}`;
}

// ── Keyboard builders ────────────────────────────────────────────────────────

// Permanent Start Button - shown after order completion
function kbStartOrder() {
  return {
    inline_keyboard: [
      [{ text: "🚀 ابدأ الطلب", callback_data: "start_order" }],
    ],
  };
}

// Post-order keyboard with confirmation button (optional)
function kbPostOrder(hasConfirmation: boolean = false) {
  const rows: object[][] = [
    [{ text: "🚀 ابدأ طلب جديد", callback_data: "start_order" }],
  ];
  if (hasConfirmation) {
    rows.unshift([{ text: "✅ تم الاستلام", callback_data: "confirm_delivery" }]);
  }
  return { inline_keyboard: rows };
}

function kbMain(loyaltyEnabled: boolean) {
  const rows: object[][] = [
    [{ text: "📋 تصفح المنيو", callback_data: "show_menu" }],
    [{ text: "🚗 منطقة التوصيل", callback_data: "select_zone" }, { text: "🛒 السلة", callback_data: "cart" }],
  ];
  if (loyaltyEnabled) rows.splice(1, 0, [{ text: "🎁 نقاطي ومكافآتي", callback_data: "loyalty_menu" }]);
  return { inline_keyboard: rows };
}

function kbCategories(
  cats: { id: string; name: string; name_ar: string }[],
  hasCart: boolean
) {
  const rows = cats.map(c => [{ text: c.name_ar || c.name, callback_data: `cat:${c.id}` }]);
  if (hasCart) rows.push([{ text: "🛒 عرض السلة", callback_data: "cart" }]);
  rows.push([{ text: "◀ القائمة الرئيسية", callback_data: "main_menu" }]);
  return { inline_keyboard: rows };
}

function kbProducts(prods: { id: string; name: string; name_ar: string; price: number }[], cur: string) {
  const rows = prods.map(p => [{
    text: `${p.name_ar || p.name}  •  ${fmt(Number(p.price), cur)}`,
    callback_data: `product:${p.id}`,
  }]);
  rows.push([{ text: "◀ الأقسام", callback_data: "show_menu" }, { text: "🛒 السلة", callback_data: "cart" }]);
  return { inline_keyboard: rows };
}

function kbQty(itemId: string, qty: number) {
  return {
    inline_keyboard: [
      [
        { text: "➖", callback_data: `qty_minus:${itemId}` },
        { text: `${qty}`, callback_data: "noop" },
        { text: "➕", callback_data: `qty_plus:${itemId}` },
      ],
      [
        { text: "🗑 حذف", callback_data: `remove:${itemId}` },
        { text: "✓ تم", callback_data: "cart" },
      ],
    ],
  };
}

function kbCart() {
  return {
    inline_keyboard: [
      [{ text: "📋 إضافة المزيد", callback_data: "show_menu" }],
      [{ text: "🚗 منطقة التوصيل", callback_data: "select_zone" }],
      [{ text: "✅ إتمام الطلب", callback_data: "checkout" }],
      [{ text: "🗑 إفراغ السلة", callback_data: "clear_cart" }],
    ],
  };
}

function kbZones(zones: { id: string; name: string; price: number }[], cur: string) {
  const rows = zones.map(z => [{
    text: `${z.name}  •  ${fmt(Number(z.price), cur)}`,
    callback_data: `zone:${z.id}:${z.price}`,
  }]);
  rows.push([{ text: "◀ القائمة الرئيسية", callback_data: "main_menu" }]);
  return { inline_keyboard: rows };
}

function kbSkipNotes() {
  return { inline_keyboard: [[{ text: "⏭ تخطي الملاحظات", callback_data: "skip_notes" }, { text: "◀ السلة", callback_data: "cart" }]] };
}

function kbConfirm() {
  return { inline_keyboard: [[{ text: "✅ تأكيد الطلب", callback_data: "confirm_order" }, { text: "◀ تعديل", callback_data: "cart" }]] };
}

function kbLoyalty() {
  return {
    inline_keyboard: [
      [{ text: "🎁 نقاطي", callback_data: "my_points" }, { text: "🏆 مستواي", callback_data: "my_tier" }],
      [{ text: "🎉 المكافآت", callback_data: "view_rewards" }, { text: "📈 السجل", callback_data: "points_history" }],
      [{ text: "◀ القائمة الرئيسية", callback_data: "main_menu" }],
    ],
  };
}

// ── Cart formatter ───────────────────────────────────────────────────────────

function fmtCart(cart: CartItem[], cur: string, zonePrice = 0, zoneName = "") {
  if (!cart.length) return "السلة فارغة 🛒";
  let sub = 0;
  const lines = cart.map((i, n) => {
    const lt = i.price * i.quantity;
    sub += lt;
    return `${n + 1}. *${i.name_ar || i.name}*\n   ${i.quantity} × ${fmt(i.price, cur)} = ${fmt(lt, cur)}`;
  });
  let t = lines.join("\n\n") + `\n\n━━━━━━━━━━━━\nالمجموع الفرعي: ${fmt(sub, cur)}`;
  if (zonePrice > 0) t += `\n🚗 التوصيل (${zoneName}): ${fmt(zonePrice, cur)}`;
  t += `\n\n*الإجمالي: ${fmt(sub + zonePrice, cur)}*`;
  return t;
}

// ── Session helpers ──────────────────────────────────────────────────────────

async function getSession(telegramUserId: string, restaurantId?: string): Promise<Session | null> {
  try {
    let query = supabase
      .from("telegram_sessions")
      .select("*, restaurants(telegram_bot_token, currency, loyalty_enabled, logo_url, name, is_closed, closed_message, is_suspended, telegram_menu_images)")
      .eq("telegram_user_id", String(telegramUserId));

    if (restaurantId) {
      query = query.eq("restaurant_id", restaurantId);
    }

    const { data, error } = await query.maybeSingle();
    perf().mark("getSession");

    if (error) {
      log(`session_query_error`, { telegramUserId, restaurantId, error: error.message });
      return null;
    }

    log(`session_lookup`, { telegramUserId, restaurantId, found: !!data, state: data?.state });
    return data as Session | null;
  } catch (e) {
    log(`session_exception`, { telegramUserId, restaurantId, error: e instanceof Error ? e.message : String(e) });
    return null;
  }
}

async function saveSession(
  restaurantId: string,
  telegramUserId: string,
  patch: Partial<Omit<Session, "id" | "restaurant_id" | "telegram_user_id">>,
  expectedUpdatedAt?: string
): Promise<boolean> {
  try {
    const now = new Date().toISOString();
    let query = supabase
      .from("telegram_sessions")
      .update({ ...patch, updated_at: now })
      .eq("restaurant_id", restaurantId)
      .eq("telegram_user_id", String(telegramUserId));

    // Optimistic concurrency: only update if session hasn't been modified since we read it
    if (expectedUpdatedAt) {
      query = query.eq("updated_at", expectedUpdatedAt);
    }

    const { data, error } = await query.select("id").maybeSingle();
    perf().mark("saveSession");

    if (error) {
      log(`session_save_error`, { telegramUserId, error: error.message });
      return false;
    }

    if (!data && expectedUpdatedAt) {
      // Session was modified by another request — don't overwrite
      log(`session_save_stale`, { telegramUserId, expectedUpdatedAt });
      return false;
    }

    // If session doesn't exist at all, create it via upsert fallback
    if (!data) {
      const { error: upsertError } = await supabase
        .from("telegram_sessions")
        .upsert(
          { restaurant_id: restaurantId, telegram_user_id: String(telegramUserId), ...patch, updated_at: new Date().toISOString() },
          { onConflict: "restaurant_id,telegram_user_id" }
        );
      if (upsertError) {
        log(`session_save_upsert_error`, { telegramUserId, error: upsertError.message });
        return false;
      }
    }

    log(`session_saved`, { telegramUserId, state: patch.state });
    return true;
  } catch (e) {
    log(`session_save_exception`, { telegramUserId, error: e instanceof Error ? e.message : String(e) });
    return false;
  }
}

async function resetSessionForNewOrder(restaurantId: string, telegramUserId: string, customerId: string | null): Promise<void> {
  try {
    // Reset session for new order but keep customer_id
    const { error } = await supabase
      .from("telegram_sessions")
      .update({
        state: S.MAIN_MENU,
        cart: [],
        checkout_data: {},
        current_category_id: null,
        customer_id: customerId,
        updated_at: new Date().toISOString()
      })
      .eq("restaurant_id", restaurantId)
      .eq("telegram_user_id", String(telegramUserId));
    perf().mark("resetSession");

    if (error) {
      log(`session_reset_error`, { telegramUserId, error: error.message });
    } else {
      log(`session_reset_for_new_order`, { telegramUserId, customerId });
    }
  } catch (e) {
    log(`session_reset_exception`, { telegramUserId, error: e instanceof Error ? e.message : String(e) });
  }
}

// ── DB loaders ──────────────────────────────────────────────────────────────

async function loadCategories(restaurantId: string) {
  try {
    const { data, error } = await supabase
      .from("menu_categories")
      .select("id, name, name_ar")
      .eq("restaurant_id", restaurantId)
      .eq("is_active", true)
      .order("sort_order");
    perf().mark("loadCategories");

    if (error) {
      log(`load_categories_error`, { restaurantId, error: error.message });
      return [];
    }

    log(`load_categories`, { restaurantId, count: data?.length ?? 0 });
    return data ?? [];
  } catch (e) {
    log(`load_categories_exception`, { restaurantId, error: e instanceof Error ? e.message : String(e) });
    return [];
  }
}

async function loadProducts(restaurantId: string, categoryId: string) {
  try {
    const { data, error } = await supabase
      .from("menu_items")
      .select("id, name, name_ar, price, description")
      .eq("restaurant_id", restaurantId)
      .eq("category_id", categoryId)
      .eq("is_available", true)
      .order("sort_order");
    perf().mark("loadProducts");

    if (error) {
      log(`load_products_error`, { restaurantId, categoryId, error: error.message });
      return [];
    }

    log(`load_products`, { restaurantId, categoryId, count: data?.length ?? 0 });
    return data ?? [];
  } catch (e) {
    log(`load_products_exception`, { restaurantId, categoryId, error: e instanceof Error ? e.message : String(e) });
    return [];
  }
}

async function loadProduct(productId: string) {
  try {
    const { data, error } = await supabase
      .from("menu_items")
      .select("id, name, name_ar, price, description")
      .eq("id", productId)
      .maybeSingle();
    perf().mark("loadProduct");

    if (error) {
      log(`load_product_error`, { productId, error: error.message });
      return null;
    }

    log(`load_product`, { productId, found: !!data });
    return data;
  } catch (e) {
    log(`load_product_exception`, { productId, error: e instanceof Error ? e.message : String(e) });
    return null;
  }
}

async function loadZones(restaurantId: string) {
  try {
    const { data, error } = await supabase
      .from("delivery_zones")
      .select("id, name, price")
      .eq("restaurant_id", restaurantId)
      .order("created_at");
    perf().mark("loadZones");

    if (error) {
      log(`load_zones_error`, { restaurantId, error: error.message });
      return [];
    }

    return (data ?? []) as { id: string; name: string; price: number }[];
  } catch (e) {
    log(`load_zones_exception`, { restaurantId, error: e instanceof Error ? e.message : String(e) });
    return [];
  }
}

async function loadLoyaltySettings(restaurantId: string) {
  try {
    const { data, error } = await supabase
      .from("loyalty_settings")
      .select("*")
      .eq("restaurant_id", restaurantId)
      .maybeSingle();
    perf().mark("loadLoyaltySettings");

    if (error) {
      log(`load_loyalty_settings_error`, { restaurantId, error: error.message });
      return null;
    }
    return data;
  } catch (e) {
    log(`load_loyalty_settings_exception`, { restaurantId, error: e instanceof Error ? e.message : String(e) });
    return null;
  }
}

async function loadRewards(restaurantId: string) {
  try {
    const { data, error } = await supabase
      .from("reward_catalog")
      .select("id, name, points_required, reward_type, reward_value, reward_item_name")
      .eq("restaurant_id", restaurantId)
      .eq("is_active", true)
      .order("points_required");
    perf().mark("loadRewards");

    if (error) {
      log(`load_rewards_error`, { restaurantId, error: error.message });
      return [];
    }
    return (data ?? []) as any[];
  } catch (e) {
    log(`load_rewards_exception`, { restaurantId, error: e instanceof Error ? e.message : String(e) });
    return [];
  }
}

async function loadCustomerByTelegramId(restaurantId: string, telegramId: string) {
  try {
    const { data, error } = await supabase
      .from("customers")
      .select("id, name, phone, telegram_id, total_orders")
      .eq("restaurant_id", restaurantId)
      .eq("telegram_id", telegramId)
      .maybeSingle();
    perf().mark("loadCustomer");

    if (error) {
      log(`load_customer_error`, { telegramId, error: error.message });
      return null;
    }
    return data;
  } catch (e) {
    log(`load_customer_exception`, { telegramId, error: e instanceof Error ? e.message : String(e) });
    return null;
  }
}

async function loadWallet(restaurantId: string, customerId: string) {
  try {
    const { data, error } = await supabase
      .from("customer_points_wallet")
      .select("*")
      .eq("restaurant_id", restaurantId)
      .eq("customer_id", customerId)
      .maybeSingle();
    perf().mark("loadWallet");

    if (error) {
      log(`load_wallet_error`, { customerId, error: error.message });
      return null;
    }
    return data;
  } catch (e) {
    log(`load_wallet_exception`, { customerId, error: e instanceof Error ? e.message : String(e) });
    return null;
  }
}

// Find restaurant by telegram bot to support users without deep link
async function findRestaurantByBotToken(telegramUserId: string): Promise<{ restaurantId: string; token: string; rest: any } | null> {
  try {
    // Check if user has an existing session — use .limit(1) + .single() to avoid
    // multi-row errors when user has sessions for multiple restaurants
    const { data: sessionData } = await supabase
      .from("telegram_sessions")
      .select("restaurant_id, restaurants(telegram_bot_token, currency, loyalty_enabled, logo_url, name, is_closed, closed_message, is_suspended, telegram_menu_images)")
      .eq("telegram_user_id", String(telegramUserId))
      .limit(1);
    perf().mark("findRestaurant:session");

    if (sessionData && sessionData.length > 0) {
      const s = sessionData[0] as any;
      if (s.restaurants?.telegram_bot_token) {
        return {
          restaurantId: s.restaurant_id,
          token: s.restaurants.telegram_bot_token,
          rest: s.restaurants
        };
      }
    }

    // Fallback: Find any restaurant with a bot token (multi-tenant fallback)
    const { data: restaurants } = await supabase
      .from("restaurants")
      .select("id, name, telegram_bot_token, currency, loyalty_enabled, logo_url, is_closed, closed_message, is_suspended, telegram_menu_images")
      .not("telegram_bot_token", "is", null)
      .neq("telegram_bot_token", "")
      .limit(1);
    perf().mark("findRestaurant:fallback");

    if (restaurants && restaurants.length > 0) {
      const r = restaurants[0];
      return {
        restaurantId: r.id,
        token: r.telegram_bot_token,
        rest: r
      };
    }

    return null;
  } catch (e) {
    log(`find_restaurant_error`, { error: e instanceof Error ? e.message : String(e) });
    return null;
  }
}

// ── Entry point ──────────────────────────────────────────────────────────────

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  // Reset perf tracker for this request
  _perf = new Perf();

  // Extract restaurant_id from query parameter (set during webhook registration)
  const url = new URL(req.url);
  const restaurantIdFromQuery = url.searchParams.get("restaurant_id");

  perf().mark("request_start");

  let debugInfo: any = { ok: true };
  try {
    const body = await req.json();
    perf().mark("parse_body");

    log(`webhook_received`, {
      hasCallback: !!body.callback_query,
      hasMessage: !!body.message,
      messageText: body.message?.text?.slice(0, 100),
      callbackData: body.callback_query?.data,
      restaurantIdFromQuery,
    });

    if (body.callback_query) {
      await handleCallback(body.callback_query, restaurantIdFromQuery);
      perf().mark("handle_callback");
    } else if (body.message) {
      const result = await handleMessage(body.message, restaurantIdFromQuery);
      perf().mark("handle_message");
      if (result) debugInfo.msg = result;
    } else {
      log(`webhook_unknown`, { body });
    }
  } catch (e) {
    perf().mark("error");
    log(`webhook_error`, { error: e instanceof Error ? e.message : String(e), stack: e instanceof Error ? e.stack : undefined });
    debugInfo.error = e instanceof Error ? e.message : String(e);
  }

  const tl = perf().timeline();
  if (tl.slow) {
    log(`perf_slow`, { total_ms: tl.total_ms, bottleneck: tl.bottleneck, steps: tl.steps });
  } else {
    log(`perf_timeline`, { total_ms: tl.total_ms, steps: tl.steps });
  }
  debugInfo.perf = tl;

  return new Response(JSON.stringify(debugInfo), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
});

// ── /start handler ───────────────────────────────────────────────────────────

async function handleStart(msg: any, restaurantId: string | undefined) {
  const chatId = msg.chat?.id;
  const userId = msg.from?.id;

  log(`handleStart_entry`, { restaurantId, chatId, userId });

  if (!restaurantId) {
    log(`handleStart_no_restaurant_id`, { chatId, userId });
    // Try to find restaurant from existing session or fallback
    const found = await findRestaurantByBotToken(String(userId));
    if (!found) {
      log(`handleStart_no_restaurant_found`, { userId });
      return;
    }
    restaurantId = found.restaurantId;
  }

  // Lookup restaurant
  let rest: any = null;
  try {
    const { data, error } = await supabase
      .from("restaurants")
      .select("id, name, logo_url, telegram_bot_token, currency, loyalty_enabled, is_closed, closed_message, is_suspended, telegram_menu_images")
      .eq("id", restaurantId)
      .maybeSingle();

    if (error) {
      log(`restaurant_query_error`, { restaurantId, error: error.message });
      return;
    }

    rest = data;
    log(`restaurant_lookup`, { restaurantId, found: !!rest, hasToken: !!rest?.telegram_bot_token });
  } catch (e) {
    log(`restaurant_query_exception`, { restaurantId, error: e instanceof Error ? e.message : String(e) });
    return;
  }

  if (!rest) {
    log(`handleStart_restaurant_not_found`, { restaurantId });
    return;
  }

  if (!rest.telegram_bot_token) {
    log(`handleStart_no_bot_token`, { restaurantId, restaurantName: rest.name });
    return;
  }

  // Suspension or closed mode — same message
  if (rest.is_suspended || rest.is_closed) {
    const closedMsg = rest.closed_message?.trim() || "المطعم مغلق حالياً. سنعود قريباً! 🔒";
    await tg(rest.telegram_bot_token, "sendMessage", { chat_id: chatId, text: closedMsg });
    return;
  }

  const token = rest.telegram_bot_token;
  const cur   = currencyLabel(rest.currency);
  const uid   = String(userId);

  // Get or create session — pass restaurantId to avoid multi-row ambiguity
  const existing = await getSession(uid, restaurantId);
  const customerId = existing?.customer_id ?? null;

  // Check if customer exists in DB
  const customer = await loadCustomerByTelegramId(restaurantId, uid);
  const resolvedCustomerId = customer?.id ?? customerId ?? null;

  log(`handleStart_customer_check`, {
    uid,
    existingSession: !!existing,
    existingCustomerId: customerId,
    dbCustomerId: customer?.id,
    resolvedCustomerId
  });

  // Save session
  await saveSession(restaurantId, uid, {
    state: S.MAIN_MENU,
    cart: [],
    checkout_data: {},
    current_category_id: null,
    customer_id: resolvedCustomerId,
  });

  // First-visit registration gate
  if (!resolvedCustomerId) {
    log(`handleStart_new_customer`, { uid });

    const regMsg = await send(token, chatId,
      `*مرحباً بك في ${rest.name}!* 👋\n\nيبدو أنك تزورنا للمرة الأولى.\nنحتاج إلى بعض معلوماتك لإتمام الطلب.\n\n👤 *أدخل اسمك الكامل:*`
    );

    if (!regMsg?.ok) {
      log(`handleStart_send_failed`, { uid });
      return;
    }

    await saveSession(restaurantId, uid, {
      state: S.REG_NAME,
      cart: [],
      checkout_data: {},
      current_category_id: null,
      customer_id: null,
      message_id: String(regMsg?.result?.message_id ?? ""),
    });

    log(`handleStart_registration_started`, { uid, messageId: regMsg?.result?.message_id });
    return;
  }

  // Returning customer — show welcome + menu with start button
  log(`handleStart_returning_customer`, { uid, customerId: resolvedCustomerId });

  const welcomeText = `*${rest.name}* 🎉\n\nأهلاً بعودتك *${customer?.name ?? ""}*!\nإجمالي طلباتك: ${customer?.total_orders ?? 0} طلب\n\nاختر من القائمة أو اضغط للبدء:`;
  const sentMsg = await send(token, chatId, welcomeText, kbMain(rest.loyalty_enabled ?? true));

  if (!sentMsg?.ok) {
    log(`handleStart_welcome_send_failed`, { uid });
    return;
  }

  await saveSession(restaurantId, uid, {
    state: S.MAIN_MENU,
    message_id: String(sentMsg?.result?.message_id ?? ""),
  });

  // Send menu image if configured
  if (rest.logo_url) {
    log(`handleStart_sending_logo`, { uid, logoUrl: rest.logo_url });
    EdgeRuntime.waitUntil(
      tg(token, "sendPhoto", { chat_id: chatId, photo: rest.logo_url, caption: `*${rest.name}*`, parse_mode: "Markdown" })
        .catch(e => log(`logo_send_error`, { error: e instanceof Error ? e.message : String(e) }))
    );
  }

  log(`handleStart_complete`, { uid, state: S.MAIN_MENU });
}

// ── Callback handler ─────────────────────────────────────────────────────────

async function handleCallback(cb: any, restaurantIdFromWebhook?: string | null) {
  const chatId  = cb.message?.chat?.id;
  const userId  = cb.from?.id;
  const msgId   = cb.message?.message_id;
  const data    = cb.data;

  log(`callback_received`, { chatId, userId, msgId, data, restaurantIdFromWebhook });

  if (!chatId || !userId || !data) {
    log(`callback_missing_fields`, { chatId, userId, data });
    return;
  }

  // Always filter by restaurant when we have it — a user may have sessions
  // for multiple restaurants, and .maybeSingle() fails if more than one row matches
  const session = await getSession(String(userId), restaurantIdFromWebhook || undefined);

  if (!session) {
    log(`callback_no_session`, { userId, restaurantIdFromWebhook });

    // Use restaurant ID from webhook URL if available
    let targetRestaurantId = restaurantIdFromWebhook;

    if (!targetRestaurantId) {
      // Fallback: try to find restaurant from existing session or fallback
      const found = await findRestaurantByBotToken(String(userId));
      if (!found) {
        log(`callback_no_restaurant`, { userId });
        return;
      }
      targetRestaurantId = found.restaurantId;
    }

    // Get restaurant data
    const { data: restaurant } = await supabase
      .from("restaurants")
      .select("id, telegram_bot_token, currency, loyalty_enabled, name, is_closed, closed_message, is_suspended, telegram_menu_images")
      .eq("id", targetRestaurantId)
      .maybeSingle();

    if (!restaurant?.telegram_bot_token) {
      log(`callback_no_restaurant_data`, { targetRestaurantId });
      return;
    }

    // Suspension or closed mode — no-session fallback
    if (restaurant.is_suspended || restaurant.is_closed) {
      const closedMsg = restaurant.closed_message?.trim() || "المطعم مغلق حالياً. سنعود قريباً! 🔒";
      await tg(restaurant.telegram_bot_token, "sendMessage", { chat_id: chatId, text: closedMsg });
      return;
    }

    // Check if customer exists
    const existingCustomer = await loadCustomerByTelegramId(targetRestaurantId, String(userId));

    // Create a new session
    await saveSession(targetRestaurantId, String(userId), {
      state: S.IDLE,
      cart: [],
      checkout_data: {},
      current_category_id: null,
      customer_id: existingCustomer?.id ?? null,
    });

    // Re-fetch session — pass restaurantId to avoid multi-row ambiguity
    const newSession = await getSession(String(userId), targetRestaurantId);
    if (!newSession) return;

    // Continue with new session
    await handleCallbackWithSession(cb, newSession);
    return;
  }

  await handleCallbackWithSession(cb, session);
}

async function handleCallbackWithSession(cb: any, session: Session) {
  const chatId  = cb.message?.chat?.id;
  const userId  = cb.from?.id;
  const msgId   = cb.message?.message_id;
  const data    = cb.data;

  let token = session.restaurants?.telegram_bot_token;
  let cur   = currencyLabel(session.restaurants?.currency);
  let loyaltyEnabled = session.restaurants?.loyalty_enabled ?? true;

  // Wrapper that automatically passes the session's updated_at for optimistic concurrency
  const saveSess = (patch: Parameters<typeof saveSession>[2]) =>
    saveSession(session.restaurant_id, String(userId), patch, session.updated_at);

  if (!token) {
    log(`callback_token_missing_in_session`, { userId, restaurantId: session.restaurant_id });
    const { data: rest } = await supabase
      .from("restaurants")
      .select("telegram_bot_token, currency, loyalty_enabled, name, is_closed, closed_message, is_suspended, telegram_menu_images")
      .eq("id", session.restaurant_id)
      .maybeSingle();
    if (rest?.telegram_bot_token) {
      token = rest.telegram_bot_token;
      cur = currencyLabel(rest.currency);
      loyaltyEnabled = rest.loyalty_enabled ?? true;
      log(`callback_token_recovered`, { userId, restaurantId: session.restaurant_id });
    }
  }

  if (!token) {
    log(`callback_no_token`, { userId, restaurantId: session.restaurant_id });
    return;
  }

  const [action, ...params] = data.split(":");

  ack(token, cb.id);

  switch (action) {

    // ── Start Order (NEW) ────────────────────────────────────────────────────
    case "start_order": {
      log(`start_order_callback`, { userId, customerId: session.customer_id });

      // Suspension or closed mode — start_order callback
      if (session.restaurants?.is_suspended || session.restaurants?.is_closed) {
        const closedMsg = session.restaurants?.closed_message?.trim() || "المطعم مغلق حالياً. سنعود قريباً! 🔒";
        await send(token, chatId, closedMsg);
        break;
      }

      // Check if customer exists for this Telegram user
      const existingCustomer = await loadCustomerByTelegramId(session.restaurant_id, String(userId));

      if (!existingCustomer && !session.customer_id) {
        // NEW CUSTOMER - Start registration flow
        log(`start_order_new_customer_registration`, { userId });

        const regMsg = await send(token, chatId,
          `*مرحباً بك!* 👋\n\nيبدو أنك تزورنا للمرة الأولى.\nنحتاج إلى بعض معلوماتك لإتمام الطلب.\n\n👤 *أدخل اسمك الكامل:*`
        );

        // Always save session state, even if Telegram send failed
        await saveSess({
          state: S.REG_NAME,
          cart: [],
          checkout_data: {},
          current_category_id: null,
          message_id: String(regMsg?.result?.message_id ?? ""),
        });
        break;
      }

      // EXISTING CUSTOMER - Start ordering directly
      const customerIdToUse = existingCustomer?.id ?? session.customer_id;
      await resetSessionForNewOrder(session.restaurant_id, String(userId), customerIdToUse);

      const rest = session.restaurants;
      const customerData = existingCustomer || session.customer_id ? await supabase
        .from("customers")
        .select("name, total_orders")
        .eq("id", customerIdToUse)
        .maybeSingle() : null;

      const welcomeText = `*${rest?.name ?? "المطعم"}* 🎉\n\n` +
        (customerData?.data ? `أهلاً *${customerData.data.name}*!\n` : '') +
        `اختر من القائمة:`;
      await send(token, chatId, welcomeText, kbMain(loyaltyEnabled));

      // resetSessionForNewOrder already set customer_id, so no extra save needed
      log(`start_order_complete`, { userId, customerId: customerIdToUse });
      break;
    }

    // ── Delivery Confirmation (OPTIONAL) ─────────────────────────────────────
    case "confirm_delivery": {
      // Log confirmation and transition to idle state for new orders
      log(`delivery_confirmed_by_customer`, { userId, customerId: session.customer_id });
      await saveSess({
        state: S.IDLE,
        cart: [],
        checkout_data: {},
        current_category_id: null,
      });
      await send(token, chatId,
        `✅ *شكراً للتأكيد!*\n\nنتمنى أن تنال الخدمة إعجابك ❤️\n\nيمكنك طلب المزيد في أي وقت!`,
        kbStartOrder()
      );
      break;
    }

    case "main_menu": {
      await edit(token, chatId, msgId, "*القائمة الرئيسية*\nاختر ما تريد:", kbMain(loyaltyEnabled));
      await saveSess({ state: S.MAIN_MENU });
      break;
    }

    case "show_menu": {
      // Suspension or closed mode — show_menu callback
      if (session.restaurants?.is_suspended || session.restaurants?.is_closed) {
        const closedMsg = session.restaurants?.closed_message?.trim() || "المطعم مغلق حالياً. سنعود قريباً! 🔒";
        await edit(token, chatId, msgId, closedMsg, { inline_keyboard: [[{ text: "◀ القائمة الرئيسية", callback_data: "main_menu" }]] });
        break;
      }
      const cats = await loadCategories(session.restaurant_id);
      if (!cats.length) {
        await edit(token, chatId, msgId, "⚠️ لا توجد أقسام متاحة حالياً.", { inline_keyboard: [[{ text: "◀ القائمة الرئيسية", callback_data: "main_menu" }]] });
        break;
      }
      const cart = (session.cart ?? []) as CartItem[];
      // Menu image sending — Feature 6: send up to 4 images BEFORE showing categories
      const menuImages = (session.restaurants?.telegram_menu_images ?? []) as string[];
      if (menuImages.length > 0) {
        // Remove the keyboard from the old message first
        await edit(token, chatId, msgId, "📋 *المنيو*", { inline_keyboard: [] });
        // Send images as new messages so they appear chronologically before categories
        for (const imgUrl of menuImages.slice(0, 4)) {
          if (imgUrl) {
            try {
              await tg(token, "sendPhoto", { chat_id: chatId, photo: imgUrl });
            } catch (e: unknown) {
              log(`menu_image_send_error`, { error: e instanceof Error ? e.message : String(e) });
            }
          }
        }
        // Send categories as a NEW message (below images in chat)
        await send(token, chatId, "*📋 الأقسام*\n\nاختر القسم:", kbCategories(cats, cart.length > 0));
      } else {
        // No images — edit existing message to show categories
        await edit(token, chatId, msgId, "*📋 الأقسام*\n\nاختر القسم:", kbCategories(cats, cart.length > 0));
      }
      await saveSess({ state: S.BROWSING_MENU });
      break;
    }

    case "cat": {
      const catId = params[0];
      const prods = await loadProducts(session.restaurant_id, catId);
      const { data: cat } = await supabase.from("menu_categories").select("name, name_ar").eq("id", catId).maybeSingle();
      const catName = cat?.name_ar || cat?.name || "الأصناف";
      if (!prods.length) {
        await edit(token, chatId, msgId, `*${catName}*\n\nلا توجد منتجات متاحة في هذا القسم.`, { inline_keyboard: [[{ text: "◀ الأقسام", callback_data: "show_menu" }]] });
        break;
      }
      await edit(token, chatId, msgId, `*${catName}*\n\nاضغط على المنتج لإضافته:`, kbProducts(prods as any, cur));
      await saveSess({ state: S.VIEWING_CATEGORY, current_category_id: catId });
      break;
    }

    case "product": {
      const productId = params[0];
      const product = await loadProduct(productId);
      if (!product) {
        log(`callback_product_not_found`, { productId });
        ack(token, cb.id, "المنتج غير متاح");
        break;
      }
      const cart = [...(session.cart ?? [])] as CartItem[];
      const existing = cart.find(i => i.id === productId);
      if (existing) existing.quantity += 1;
      else cart.push({ id: product.id, name: product.name, name_ar: product.name_ar ?? product.name, price: Number(product.price), quantity: 1 });
      const item = cart.find(i => i.id === productId)!;
      const desc = (product as any).description ? `\n_${(product as any).description}_` : "";
      const itemText = `*${item.name_ar || item.name}*${desc}\n\nالكمية: *${item.quantity}*\n${fmt(item.price, cur)} × ${item.quantity} = *${fmt(item.price * item.quantity, cur)}*`;
      await send(token, chatId, itemText, kbQty(productId, item.quantity));
      await saveSess({ cart });
      break;
    }

    case "qty_plus": {
      const itemId = params[0];
      const cart = [...(session.cart ?? [])] as CartItem[];
      const item = cart.find(i => i.id === itemId);
      if (item) {
        item.quantity += 1;
        await edit(token, chatId, msgId, `*${item.name_ar || item.name}*\n\nالكمية: *${item.quantity}*\n${fmt(item.price, cur)} × ${item.quantity} = *${fmt(item.price * item.quantity, cur)}*`, kbQty(itemId, item.quantity));
        await saveSess({ cart });
      }
      break;
    }

    case "qty_minus": {
      const itemId = params[0];
      const cart = [...(session.cart ?? [])] as CartItem[];
      const idx = cart.findIndex(i => i.id === itemId);
      if (idx >= 0) {
        cart[idx].quantity -= 1;
        if (cart[idx].quantity <= 0) cart.splice(idx, 1);
      }
      if (cart.length === 0) {
        await edit(token, chatId, msgId, "🗑 السلة فارغة الآن.", kbMain(loyaltyEnabled));
      } else {
        const item = cart.find(i => i.id === itemId);
        if (item) await edit(token, chatId, msgId, `*${item.name_ar || item.name}*\n\nالكمية: *${item.quantity}*\n${fmt(item.price, cur)} × ${item.quantity} = *${fmt(item.price * item.quantity, cur)}*`, kbQty(itemId, item.quantity));
      }
      await saveSess({ cart });
      break;
    }

    case "remove": {
      const itemId = params[0];
      const cart = (session.cart ?? []).filter((i: CartItem) => i.id !== itemId);
      await edit(token, chatId, msgId, "🗑 تم حذف المنتج.", cart.length > 0 ? kbCart() : kbMain(loyaltyEnabled));
      await saveSess({ cart });
      break;
    }

    case "cart": {
      const cart = (session.cart ?? []) as CartItem[];
      const cd   = (session.checkout_data ?? {}) as CheckoutData;
      await edit(token, chatId, msgId, `*🛒 سلة التسوق*\n\n${fmtCart(cart, cur, cd.zone_price, cd.zone_name)}`, kbCart());
      await saveSess({ state: S.CART });
      break;
    }

    case "clear_cart": {
      await saveSess({ cart: [], checkout_data: {} });
      await edit(token, chatId, msgId, "🗑 تم إفراغ السلة.", kbMain(loyaltyEnabled));
      break;
    }

    case "select_zone": {
      const zones = await loadZones(session.restaurant_id);
      if (!zones.length) {
        ack(token, cb.id, "لا توجد مناطق توصيل");
        break;
      }
      await edit(token, chatId, msgId, "*🚗 مناطق التوصيل*\n\nاختر منطقتك:", kbZones(zones, cur));
      await saveSess({ state: S.SELECTING_ZONE });
      break;
    }

    case "zone": {
      const zoneId    = params[0];
      const zonePrice = parseFloat(params[1]) || 0;
      const zones     = await loadZones(session.restaurant_id);
      const zone      = zones.find(z => z.id === zoneId);
      if (!zone) break;
      const cd = { ...(session.checkout_data ?? {}), zone_id: zoneId, zone_name: zone.name, zone_price: zonePrice } as CheckoutData;
      await saveSess({ checkout_data: cd });
      const cart = (session.cart ?? []) as CartItem[];
      await edit(token, chatId, msgId, `*🛒 السلة*\n\n${fmtCart(cart, cur, zonePrice, zone.name)}`, kbCart());
      break;
    }

    case "checkout": {
      const cart = (session.cart ?? []) as CartItem[];
      if (!cart.length) {
        ack(token, cb.id, "السلة فارغة!");
        break;
      }

      // MANDATORY: Check delivery zone is selected
      const cd = (session.checkout_data ?? {}) as CheckoutData;
      if (!cd.zone_id || !cd.zone_name) {
        ack(token, cb.id, "يجب اختيار منطقة التوصيل أولاً");
        // Redirect to zone selection
        const zones = await loadZones(session.restaurant_id);
        if (zones.length) {
          await send(token, chatId, "🚗 *يجب اختيار منطقة التوصيل أولاً*\n\nاختر منطقتك:", kbZones(zones, cur));
          await saveSess({ state: S.SELECTING_ZONE });
        }
        break;
      }

      await saveSess({ state: S.CHECKOUT_ADDRESS, checkout_data: session.checkout_data ?? {} });
      await send(token, chatId, "📍 *أدخل عنوان التوصيل التفصيلي:*\n_(اسم الشارع، رقم المبنى، أي علامة مميزة)_");
      break;
    }

    case "skip_notes": {
      const cd = (session.checkout_data ?? {}) as CheckoutData;
      // Validate required fields before showing confirmation
      if (!cd.zone_id || !cd.zone_name) {
        await send(token, chatId, "⚠️ يجب اختيار منطقة التوصيل أولاً");
        const zones = await loadZones(session.restaurant_id);
        if (zones.length) {
          await send(token, chatId, "🚗 *اختر منطقة التوصيل:*", kbZones(zones, cur));
          await saveSess({ state: S.SELECTING_ZONE });
        }
        break;
      }
      if (!cd.address || cd.address.length < 5) {
        await send(token, chatId, "⚠️ يجب إدخال عنوان التوصيل أولاً");
        await saveSess({ state: S.CHECKOUT_ADDRESS });
        await send(token, chatId, "📍 *أدخل عنوان التوصيل التفصيلي:*");
        break;
      }
      await showConfirmation(token, chatId, session, cur);
      await saveSess({ state: S.CONFIRM, checkout_data: { ...cd, notes: "" } });
      break;
    }

    case "confirm_order": {
      await processOrder(token, chatId, session, cur, String(userId));
      break;
    }

    // ── Loyalty ──────────────────────────────────────────────────────────────

    case "loyalty_menu": {
      await edit(token, chatId, msgId, "*🎁 نظام الولاء*\n\nاختر:", kbLoyalty());
      break;
    }

    case "my_points": {
      if (!session.customer_id) {
        await edit(token, chatId, msgId, "لم تقم بطلب بعد. اطلب أولاً لكسب النقاط!", kbLoyalty());
        break;
      }
      const wallet   = await loadWallet(session.restaurant_id, session.customer_id);
      const settings = await loadLoyaltySettings(session.restaurant_id);
      const text = `*🎁 نقاطك*\n\n` +
        `النقاط الحالية: *${wallet?.current_points ?? 0}*\n` +
        `إجمالي النقاط المكتسبة: *${wallet?.lifetime_points ?? 0}*\n` +
        `النقاط المستبدلة: *${wallet?.redeemed_points ?? 0}*\n\n` +
        (settings?.is_active
          ? `💡 كل ${settings.currency_unit ?? 10} ج.م = ${settings.points_per_currency_unit ?? 1} نقطة`
          : "نظام الولاء معطل حالياً");
      await edit(token, chatId, msgId, text, kbLoyalty());
      break;
    }

    case "my_tier": {
      if (!session.customer_id) {
        await edit(token, chatId, msgId, "لم تقم بطلب بعد!", kbLoyalty());
        break;
      }
      const wallet = await loadWallet(session.restaurant_id, session.customer_id);
      const { data: tiers } = await supabase.from("customer_tiers").select("*").eq("restaurant_id", session.restaurant_id).order("min_points");
      const tierArr = tiers ?? [];
      const currentTier = tierArr.find((t: any) => t.tier_name === wallet?.current_tier);
      const nextTier    = tierArr.find((t: any) => t.min_points > (wallet?.lifetime_points ?? 0));
      let text = `*🏆 مستواك: ${currentTier?.tier_label_ar ?? wallet?.current_tier ?? "مبتدئ"}*\n\n`;
      if (currentTier?.benefits) text += `🎁 ${currentTier.benefits}\n\n`;
      if (nextTier) text += `📈 تحتاج ${nextTier.min_points - (wallet?.lifetime_points ?? 0)} نقطة للوصول إلى ${nextTier.tier_label_ar}`;
      else text += `🌟 أنت في أعلى مستوى!`;
      await edit(token, chatId, msgId, text, kbLoyalty());
      break;
    }

    case "view_rewards": {
      const rewards = await loadRewards(session.restaurant_id);
      const wallet  = session.customer_id ? await loadWallet(session.restaurant_id, session.customer_id) : null;
      const points  = wallet?.current_points ?? 0;
      const rows = rewards.map((r: any) => [{
        text: `${r.name}  •  ${r.points_required} نقطة ${points >= r.points_required ? "✅" : "🔒"}`,
        callback_data: `claim_reward:${r.id}`,
      }]);
      if (!rows.length) rows.push([{ text: "لا توجد مكافآت حالياً", callback_data: "noop" }]);
      rows.push([{ text: "◀ رجوع", callback_data: "loyalty_menu" }]);
      await edit(token, chatId, msgId, `*🎉 المكافآت المتاحة*\n\nرصيد نقاطك: *${points} نقطة*`, { inline_keyboard: rows });
      break;
    }

    case "points_history": {
      if (!session.customer_id) {
        await edit(token, chatId, msgId, "لا يوجد سجل بعد.", kbLoyalty());
        break;
      }
      const { data: txs } = await supabase.from("points_transactions")
        .select("type, points, balance_after, notes, created_at")
        .eq("restaurant_id", session.restaurant_id)
        .eq("customer_id", session.customer_id)
        .order("created_at", { ascending: false })
        .limit(10);
      if (!txs?.length) {
        await edit(token, chatId, msgId, "لا يوجد سجل نقاط بعد.", kbLoyalty());
        break;
      }
      const lines = (txs as any[]).map(tx => {
        const sign  = tx.type === "earned" ? "+" : "-";
        const emoji = tx.type === "earned" ? "🎁" : "🎉";
        return `${emoji} ${sign}${tx.points} نقطة  |  رصيد: ${tx.balance_after}\n_${tx.notes ?? ""}  •  ${new Date(tx.created_at).toLocaleDateString("ar-EG")}_`;
      });
      await edit(token, chatId, msgId, `*📈 تاريخ النقاط*\n\n${lines.join("\n\n")}`, kbLoyalty());
      break;
    }

    case "claim_reward": {
      const rewardId = params[0];
      if (!session.customer_id) {
        ack(token, cb.id, "يجب الطلب أولاً");
        break;
      }
      const rewards  = await loadRewards(session.restaurant_id);
      const reward   = rewards.find((r: any) => r.id === rewardId);
      const wallet   = await loadWallet(session.restaurant_id, session.customer_id);
      const settings = await loadLoyaltySettings(session.restaurant_id);

      if (!reward)           { ack(token, cb.id, "المكافأة غير موجودة"); break; }
      if (!settings?.is_active) { ack(token, cb.id, "نظام الولاء معطل"); break; }
      if ((wallet?.current_points ?? 0) < reward.points_required) {
        await ack(token, cb.id, `نقاط غير كافية — تحتاج ${reward.points_required}`);
        break;
      }

      const code     = `RWD-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      const newBal   = (wallet?.current_points ?? 0) - reward.points_required;

      await supabase.from("customer_points_wallet").update({
        current_points:  newBal,
        redeemed_points: (wallet?.redeemed_points ?? 0) + reward.points_required,
        updated_at:      new Date().toISOString(),
      }).eq("id", wallet?.id);

      await supabase.from("reward_redemptions").insert({
        restaurant_id:   session.restaurant_id,
        customer_id:     session.customer_id,
        reward_id:       reward.id,
        points_used:     reward.points_required,
        redemption_code: code,
        status:          "pending",
        expires_at:      new Date(Date.now() + 7 * 86400000).toISOString(),
      });

      await supabase.from("points_transactions").insert({
        restaurant_id: session.restaurant_id,
        customer_id:   session.customer_id,
        reward_id:     reward.id,
        type:          "redeemed",
        points:        reward.points_required,
        balance_after: newBal,
        notes:         `استبدال: ${reward.name}`,
      });

      await supabase.from("notifications").insert({
        restaurant_id: session.restaurant_id,
        type:  "loyalty",
        title: "استبدال مكافأة",
        body:  `عميل استبدل: ${reward.name}`,
        data:  { reward_id: reward.id, customer_id: session.customer_id },
      });

      await send(token, chatId,
        `✅ *تم استبدال المكافأة بنجاح!*\n\n🎁 ${reward.name}\n🔑 كود الاستلام: \`${code}\`\n⏰ صالح 7 أيام\n\n📍 أظهر الكود للكاشير`
      );
      break;
    }

    case "noop": break;
  }
}

// ── Confirmation screen ──────────────────────────────────────────────────────

async function showConfirmation(token: string, chatId: number, session: Session, cur: string) {
  const cart = (session.cart ?? []) as CartItem[];
  const cd   = (session.checkout_data ?? {}) as CheckoutData;

  // Validate required fields
  if (!cd.zone_id || !cd.zone_name) {
    await send(token, chatId, "⚠️ يجب اختيار منطقة التوصيل أولاً");
    return;
  }
  if (!cd.address || cd.address.length < 5) {
    await send(token, chatId, "⚠️ يجب إدخال عنوان التوصيل أولاً");
    return;
  }

  const text = `*✅ تأكيد الطلب*\n\n` +
    `📍 العنوان: ${cd.address}\n` +
    `🚗 المنطقة: ${cd.zone_name}\n` +
    (cd.notes    ? `📝 ملاحظات: ${cd.notes}\n`    : "") +
    `\n${fmtCart(cart, cur, cd.zone_price ?? 0, cd.zone_name)}`;
  await send(token, chatId, text, kbConfirm());
}

// ── Order placement ──────────────────────────────────────────────────────────

async function processOrder(token: string, chatId: number, session: Session, cur: string, telegramUserId: string) {
  const cart = (session.cart ?? []) as CartItem[];
  const cd   = (session.checkout_data ?? {}) as CheckoutData;

  log(`processOrder_start`, { telegramUserId, cartItems: cart.length });

  // Suspension or closed mode — processOrder (defensive)
  if (session.restaurants?.is_suspended || session.restaurants?.is_closed) {
    const closedMsg = session.restaurants?.closed_message?.trim() || "المطعم مغلق حالياً. سنعود قريباً! 🔒";
    await send(token, chatId, closedMsg);
    return;
  }

  if (!cart.length) {
    await send(token, chatId, "السلة فارغة!");
    return;
  }

  // MANDATORY: Validate delivery zone
  if (!cd.zone_id || !cd.zone_name) {
    await send(token, chatId, "⚠️ يجب اختيار منطقة التوصيل قبل إتمام الطلب");
    return;
  }

  // MANDATORY: Validate delivery address
  if (!cd.address || cd.address.length < 5) {
    await send(token, chatId, "⚠️ يجب إدخال عنوان التوصيل قبل إتمام الطلب");
    return;
  }

  const subtotal    = cart.reduce((s, i) => s + i.price * i.quantity, 0);
  const deliveryFee = cd.zone_price ?? 0;
  const total       = subtotal + deliveryFee;
  const orderNumber = `ORD-${Date.now().toString(36).toUpperCase()}`;

  const customerId = session.customer_id!;

  if (!customerId) {
    log(`processOrder_no_customer`, { telegramUserId });
    await send(token, chatId, "❌ خطأ في بيانات العميل. حاول مرة أخرى.");
    return;
  }

  log(`processOrder_creating`, { orderNumber, subtotal, deliveryFee, total });

  const { data: order, error: orderError } = await supabase.from("orders").insert({
    restaurant_id: session.restaurant_id,
    customer_id:   customerId,
    order_number:  orderNumber,
    status:        "pending",
    channel:       "telegram",
    subtotal,
    discount:      0,
    tax:          0,
    total,
    delivery_address: cd.address ?? "",
    notes:         cd.notes ?? "",
    payment_method: "cash",
    raw_payload:   { cart, checkout_data: cd, delivery_fee: deliveryFee, telegram_chat_id: String(chatId) },
  }).select("id").maybeSingle();
  perf().mark("insertOrder");

  if (orderError || !order) {
    log(`processOrder_insert_failed`, { error: orderError?.message });
    await send(token, chatId, "❌ فشل إنشاء الطلب. حاول مرة أخرى.");
    return;
  }

  log(`processOrder_created`, { orderId: order.id, orderNumber });

  // Insert order items WITH menu_item_id
  const { error: itemsError } = await supabase.from("order_items").insert(
    cart.map(item => ({
      order_id:    order.id,
      menu_item_id: item.id,
      name:        item.name_ar || item.name,
      quantity:    item.quantity,
      unit_price:  item.price,
      total_price: item.price * item.quantity,
    }))
  );
  perf().mark("insertOrderItems");

  if (itemsError) {
    log(`processOrder_items_failed`, { error: itemsError.message });
  }

  // In-app notification
  await supabase.from("notifications").insert({
    restaurant_id: session.restaurant_id,
    type:  "order",
    title: `طلب جديد #${orderNumber}`,
    body:  `طلب من Telegram بقيمة ${fmt(total, cur)}`,
    data:  { order_id: order.id },
  });
  perf().mark("insertNotification");

  // Notify cashier channel
  const { data: restData } = await supabase
    .from("restaurants")
    .select("telegram_chat_id, name")
    .eq("id", session.restaurant_id)
    .maybeSingle();
  perf().mark("loadRestaurantForCashier");

  if (restData?.telegram_chat_id) {
    const { data: custData } = await supabase
      .from("customers")
      .select("name, phone")
      .eq("id", customerId)
      .maybeSingle();
    perf().mark("loadCustomerForCashier");

    const adminMsg = `🍽 *طلب جديد — ${restData.name}*\n\n` +
      `📋 رقم: \`${orderNumber}\`\n` +
      `👤 العميل: ${custData?.name ?? "—"}\n` +
      (custData?.phone ? `📱 الهاتف: ${custData.phone}\n` : "") +
      (cd.address      ? `📍 العنوان: ${cd.address}\n`    : "") +
      (cd.zone_name    ? `🚗 المنطقة: ${cd.zone_name}\n`  : "") +
      (cd.notes        ? `📝 ملاحظات: ${cd.notes}\n`      : "") +
      `\n${fmtCart(cart, cur, deliveryFee, cd.zone_name)}\n\n` +
      `💰 *الإجمالي: ${fmt(total, cur)}*`;

    log(`processOrder_sending_cashier_notification`, { chatId: restData.telegram_chat_id });

    EdgeRuntime.waitUntil(
      tg(token, "sendMessage", { chat_id: restData.telegram_chat_id, text: adminMsg, parse_mode: "Markdown" })
        .catch(e => log(`cashier_notification_failed`, { error: e instanceof Error ? e.message : String(e) }))
    );
  }

  // Send confirmation WITHOUT start button - order is still in progress
  await send(token, chatId,
    `✅ *شكراً لطلبك!*\n\nرقم الطلب: \`${orderNumber}\`\n🟡 تم استلام طلبك\n\nسيتم التواصل معك قريباً. 🙏\n\n📋 يمكنك متابعة حالة طلبك من خلال الإشعارات.`
  );

  // Set state to POST_ORDER but DON'T show start button until delivered/cancelled
  await saveSession(session.restaurant_id, telegramUserId, {
    state: S.POST_ORDER,
    cart: [],
    checkout_data: {},
    current_category_id: null,
    customer_id: customerId,
  }, session.updated_at);
  perf().mark("processOrder_saveSession");

  log(`processOrder_complete`, { orderNumber });
}

// ── Message handler (text input) ─────────────────────────────────────────────

async function handleMessage(msg: any, restaurantIdFromWebhook?: string | null) {
  const chatId  = msg.chat?.id;
  const userId  = msg.from?.id;
  const text    = msg.text?.trim() ?? "";

  log(`message_received`, { chatId, userId, text: text.slice(0, 100), restaurantIdFromWebhook });

  if (!chatId || !userId) {
    log(`message_missing_fields`, { chatId, userId });
    return;
  }

  // /start owner_<restaurantId>  — owner registers their chat_id for notifications
  if (text.startsWith("/start owner_")) {
    const restaurantId = text.split("owner_")[1]?.trim();
    log(`owner_start`, { restaurantId, chatId });

    if (!restaurantId) {
      log(`owner_start_no_restaurant_id`);
      return;
    }

    const { data: rest, error } = await supabase
      .from("restaurants")
      .select("id, name, telegram_bot_token, telegram_owner_chat_id")
      .eq("id", restaurantId)
      .maybeSingle();

    if (error) {
      log(`owner_start_query_error`, { error: error.message });
      return;
    }

    if (!rest?.telegram_bot_token) {
      log(`owner_start_no_token`, { restaurantId });
      return;
    }

    // Store owner chat_id
    const { error: updateError } = await supabase.from("restaurants").update({
      telegram_owner_chat_id: String(chatId),
      updated_at: new Date().toISOString(),
    }).eq("id", restaurantId);

    if (updateError) {
      log(`owner_start_update_failed`, { error: updateError.message });
    }

    await tg(rest.telegram_bot_token, "sendMessage", {
      chat_id: chatId,
      text: `✅ *تم ربط حسابك كمالك المطعم!*\n\n🏪 المطعم: *${rest.name}*\n\nستصل إليك إشعارات الطلبات الجديدة على هذا الحساب مباشرةً.`,
      parse_mode: "Markdown",
    });

    log(`owner_start_complete`, { restaurantId, chatId });
    return;
  }

  // /start <restaurantId>  — customer starts order flow
  if (text.startsWith("/start ")) {
    const restaurantId = text.split(" ")[1]?.trim();
    log(`customer_start`, { restaurantId });
    return handleStart(msg, restaurantId);
  }

  // Bare /start — show welcome message with start button
  if (text === "/start") {
    log(`bare_start`, { userId, restaurantIdFromWebhook });

    // Use restaurant ID from webhook if available
    let targetRestaurantId = restaurantIdFromWebhook;

    if (!targetRestaurantId) {
      // Check for existing session — use .limit(1) to avoid multi-row errors
      const { data: sessionRows } = await supabase
        .from("telegram_sessions")
        .select("restaurant_id")
        .eq("telegram_user_id", String(userId))
        .limit(1);
      if (sessionRows && sessionRows.length > 0) {
        targetRestaurantId = sessionRows[0].restaurant_id;
      } else {
        // Fallback: find any restaurant with bot token
        const { data: restaurants } = await supabase
          .from("restaurants")
          .select("id, name, telegram_bot_token, currency, loyalty_enabled")
          .not("telegram_bot_token", "is", null)
          .neq("telegram_bot_token", "")
          .limit(1);

        if (restaurants && restaurants.length > 0) {
          targetRestaurantId = restaurants[0].id;
        }
      }
    }

    if (!targetRestaurantId) {
      log(`bare_start_no_restaurant`, { userId });
      return;
    }

    // Get restaurant data
    const { data: restaurant } = await supabase
      .from("restaurants")
      .select("id, name, telegram_bot_token, currency, loyalty_enabled, is_closed, closed_message, is_suspended, telegram_menu_images")
      .eq("id", targetRestaurantId)
      .maybeSingle();

    if (!restaurant?.telegram_bot_token) {
      log(`bare_start_no_token`, { userId, targetRestaurantId });
      return;
    }

    // Suspension or closed mode — bare /start handler
    if (restaurant.is_suspended || restaurant.is_closed) {
      const closedMsg = restaurant.closed_message?.trim() || "المطعم مغلق حالياً. سنعود قريباً! 🔒";
      await tg(restaurant.telegram_bot_token, "sendMessage", { chat_id: chatId, text: closedMsg });
      return;
    }

    // Check for existing customer
    const existingCustomer = await loadCustomerByTelegramId(targetRestaurantId, String(userId));

    // Create/update session
    await saveSession(targetRestaurantId, String(userId), {
      state: S.IDLE,
      cart: [],
      checkout_data: {},
      current_category_id: null,
      customer_id: existingCustomer?.id ?? null,
    });

    // Send welcome message with start button
    await send(restaurant.telegram_bot_token, chatId,
      `*🎉 مرحباً بك في ${restaurant.name}!*\n\nاختر للبدء:`,
      kbStartOrder()
    );

    log(`bare_start_menu_sent`, { userId, targetRestaurantId });
    return;
  }

  // Non-/start message - check for session
  let session = await getSession(String(userId), restaurantIdFromWebhook || undefined);

  if (!session) {
    log(`message_no_session`, { userId, text: text.slice(0, 50), restaurantIdFromWebhook });

    // Use restaurant ID from webhook if available
    let targetRestaurantId = restaurantIdFromWebhook;

    if (!targetRestaurantId) {
      // Fallback: find any restaurant with bot token
      const { data: restaurants } = await supabase
        .from("restaurants")
        .select("id, name, telegram_bot_token, currency, loyalty_enabled")
        .not("telegram_bot_token", "is", null)
        .neq("telegram_bot_token", "")
        .limit(1);

      if (restaurants && restaurants.length > 0) {
        targetRestaurantId = restaurants[0].id;
      }
    }

    if (!targetRestaurantId) {
      log(`message_no_restaurant`, { userId });
      return;
    }

    // Get restaurant data
    const { data: restaurant } = await supabase
      .from("restaurants")
      .select("id, name, telegram_bot_token, currency, loyalty_enabled, is_closed, closed_message, is_suspended, telegram_menu_images")
      .eq("id", targetRestaurantId)
      .maybeSingle();

    if (!restaurant?.telegram_bot_token) {
      log(`message_no_token`, { userId, targetRestaurantId });
      return;
    }

    // Suspension or closed mode — non-/start no-session handler
    if (restaurant.is_suspended || restaurant.is_closed) {
      const closedMsg = restaurant.closed_message?.trim() || "المطعم مغلق حالياً. سنعود قريباً! 🔒";
      await tg(restaurant.telegram_bot_token, "sendMessage", { chat_id: chatId, text: closedMsg });
      return;
    }

    // Check for existing customer
    const existingCustomer = await loadCustomerByTelegramId(targetRestaurantId, String(userId));

    // Create session
    await saveSession(targetRestaurantId, String(userId), {
      state: S.IDLE,
      cart: [],
      checkout_data: {},
      current_category_id: null,
      customer_id: existingCustomer?.id ?? null,
    });

    // Send welcome message
    await send(restaurant.telegram_bot_token, chatId,
      `👋 *مرحباً!*\n\nاضغط للبدء:`,
      kbStartOrder()
    );

    return;
  }

  const token = session.restaurants?.telegram_bot_token;
  const cur   = currencyLabel(session.restaurants?.currency);

  if (!token) {
    log(`message_no_token`, { userId, restaurantId: session.restaurant_id });
    return;
  }

  // Wrapper that automatically passes the session's updated_at for optimistic concurrency
  const saveSess = (patch: Parameters<typeof saveSession>[2]) =>
    saveSession(session.restaurant_id, String(userId), patch, session.updated_at);

  const state = session.state;

  log(`message_state`, { userId, state });

  // ── Registration flow ──────────────────────────────────────────────────────
  if (state === S.REG_NAME) {
    const name = text.slice(0, 60);
    if (!name) {
      await send(token, chatId, "يرجى إدخال اسمك.");
      return;
    }
    await saveSess({
      state: S.REG_PHONE,
      checkout_data: { ...(session.checkout_data ?? {}), _reg_name: name } as CheckoutData,
    });
    await send(token, chatId, `✅ تم تسجيل الاسم: *${name}*\n\n📱 *أدخل رقم هاتفك:*`);
    log(`reg_name_saved`, { userId, name });
    return;
  }

  if (state === S.REG_PHONE) {
    const phone = text.replace(/\s/g, "").slice(0, 15);
    const cd    = (session.checkout_data ?? {}) as CheckoutData;
    const name  = cd._reg_name ?? "عميل";

    log(`reg_phone_creating_customer`, { userId, name, phone });

    // Check for existing customer by phone+restaurant
    const { data: existingCust } = await supabase
      .from("customers")
      .select("id, name")
      .eq("restaurant_id", session.restaurant_id)
      .eq("phone", phone)
      .maybeSingle();
    perf().mark("checkExistingCustomer");

    let newCustomer: { id: string; name: string } | null = null;
    let customerError: string | null = null;

    if (existingCust) {
      // Update existing customer's telegram_id
      const { data: updated, error: updErr } = await supabase
        .from("customers")
        .update({ name, telegram_id: String(userId), updated_at: new Date().toISOString() })
        .eq("id", existingCust.id)
        .select("id, name")
        .maybeSingle();
      perf().mark("updateExistingCustomer");
      if (updErr) { customerError = updErr.message; }
      else { newCustomer = updated; }
    } else {
      // Insert new customer
      const { error: insErr } = await supabase
        .from("customers")
        .insert({
          restaurant_id: session.restaurant_id,
          name,
          phone,
          telegram_id: String(userId),
          channel:      "telegram",
          status:       "new",
          total_orders: 0,
          total_spent:  0,
        });
      if (insErr) {
        customerError = insErr.message;
        log(`reg_phone_insert_error`, { error: insErr.message, code: insErr.code, details: insErr.details, hint: insErr.hint });
      } else {
        // Fetch the newly created customer
        const { data: fetched, error: fetchErr } = await supabase
          .from("customers")
          .select("id, name")
          .eq("restaurant_id", session.restaurant_id)
          .eq("telegram_id", String(userId))
          .maybeSingle();
        perf().mark("fetchNewCustomer");
        if (fetchErr) { customerError = fetchErr.message; }
        else { newCustomer = fetched; }
      }
    }

    if (customerError || !newCustomer) {
      const errMsg = customerError ?? "No customer row returned";
      log(`reg_phone_customer_failed`, { error: errMsg, userId, phone });
      await send(token, chatId, `❌ حدث خطأ في إنشاء الحساب: ${errMsg}\n\nحاول مرة أخرى بكتابة /start`);
      return;
    }

    log(`reg_phone_customer_created`, { customerId: newCustomer.id });

    await saveSess({
      state:       S.MAIN_MENU,
      customer_id: newCustomer.id,
      checkout_data: {},
    });

    const restData = session.restaurants;
    const welcome  = `✅ *تم التسجيل بنجاح!*\n\nأهلاً *${name}*! 🎉\nيمكنك الآن الطلب.\n\nاختر من القائمة:`;
    const sentMsg  = await send(token, chatId, welcome, kbMain(restData?.loyalty_enabled ?? true));
    await saveSess({ message_id: String(sentMsg?.result?.message_id ?? "") });
    log(`reg_phone_complete`, { userId, customerId: newCustomer.id });
    return;
  }

  // ── Checkout flow ──────────────────────────────────────────────────────────
  if (state === S.CHECKOUT_ADDRESS) {
    const address = text.trim().slice(0, 200);

    // MANDATORY: Address cannot be empty
    if (!address || address.length < 5) {
      await send(token, chatId, "⚠️ *يرجى إدخال عنوان تفصيلي صحيح*\n\n📍 أدخل عنوان التوصيل:\n_(اسم الشارع، رقم المبنى، أي علامة مميزة)_");
      return;
    }

    const cd = { ...(session.checkout_data ?? {}), address } as CheckoutData;
    await saveSess({ state: S.CHECKOUT_NOTES, checkout_data: cd });
    await send(token, chatId, "📝 *أضف ملاحظات على الطلب:*\n_(اختياري)_", kbSkipNotes());
    log(`checkout_address_saved`, { userId, address });
    return;
  }

  if (state === S.CHECKOUT_NOTES) {
    const cd = { ...(session.checkout_data ?? {}), notes: text.slice(0, 200) } as CheckoutData;
    await saveSess({ state: S.CONFIRM, checkout_data: cd });
    await showConfirmation(token, chatId, { ...session, checkout_data: cd }, cur);
    log(`checkout_notes_saved`, { userId });
    return;
  }

  // Post-order state - check actual order status from DB
  if (state === S.POST_ORDER) {
    // Look up the most recent order for this customer to determine real status
    const { data: recentOrder } = await supabase
      .from("orders")
      .select("status, order_number")
      .eq("restaurant_id", session.restaurant_id)
      .eq("customer_id", session.customer_id)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    perf().mark("postOrderCheck");

    if (recentOrder && (recentOrder.status === "delivered" || recentOrder.status === "cancelled")) {
      // Order is already done — reset session and show start button
      await resetSessionForNewOrder(session.restaurant_id, String(userId), session.customer_id);
      await send(token, chatId,
        recentOrder.status === "delivered"
          ? `✅ *تم توصيل طلبك بنجاح!*\n\nشكراً لاختيارك! 🙏\n\nيمكنك طلب المزيد في أي وقت:`
          : `❌ *تم إلغاء الطلب*\n\nنعتذر عن الإزعاج. يمكنك طلب جديد:`,
        kbStartOrder()
      );
      return;
    }

    // Order is genuinely still in progress
    await send(token, chatId,
      `📋 *طلبك قيد المعالجة*\n\nسيتم إشعارك بتحديثات حالة الطلب.\nانتظر حتى يتم التوصيل أو الإلغاء لطلب جديد.`
    );
    return;
  }

  // Idle state - show start button
  if (state === S.IDLE) {
    await send(token, chatId,
      `👋 *أهلاً بك!*\n\nاضغط للبدء:`,
      kbStartOrder()
    );
    return;
  }

  // Recovery: customer sent a text message while in a callback-only state
  // (e.g. MAIN_MENU, BROWSING_MENU, VIEWING_CATEGORY, CART, VIEWING_REWARDS, CONFIRM)
  // This happens most often after closed mode — the customer has no usable keyboard.
  // If the restaurant is open, reset to IDLE and show the Start Order button.
  // If still closed, send the closed message.
  if (session.restaurants?.is_suspended || session.restaurants?.is_closed) {
    const closedMsg = session.restaurants?.closed_message?.trim() || "المطعم مغلق حالياً. سنعود قريباً! 🔒";
    await send(token, chatId, closedMsg);
    return;
  }

  await resetSessionForNewOrder(session.restaurant_id, String(userId), session.customer_id);
  await send(token, chatId,
    `👋 *أهلاً بك!*\n\nاضغط للبدء:`,
    kbStartOrder()
  );
  log(`message_state_recovery`, { userId, prevState: state });
  return;
}
