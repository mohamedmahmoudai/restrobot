/*
  # Add Telegram Sessions Table

  1. New Table
    - `telegram_sessions` — stores cart state and checkout flow for each telegram user per restaurant
      - `id` (uuid, primary key)
      - `restaurant_id` (uuid, foreign key to restaurants)
      - `telegram_user_id` (text, Telegram user ID)
      - `state` (text, current flow state: idle, browsing_category, cart, checkout_name, checkout_phone, checkout_address, checkout_notes, confirm)
      - `current_category_id` (uuid, current category being browsed)
      - `cart` (jsonb, cart items with menu_item_id, name, price, quantity)
      - `checkout_data` (jsonb, collected checkout info: name, phone, address, notes)
      - `message_id` (text, last message ID for updating)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - RLS enabled, only service role can access (edge function uses service role)
    - No direct user access needed

  3. Notes
    - Sessions are per-user per-restaurant
    - Cart stores complete item data for stateless rendering
    - TTL handled by application logic (can be cleaned up after order)
*/

CREATE TABLE IF NOT EXISTS telegram_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  telegram_user_id text NOT NULL,
  state text NOT NULL DEFAULT 'idle',
  current_category_id uuid REFERENCES menu_categories(id) ON DELETE SET NULL,
  cart jsonb NOT NULL DEFAULT '[]'::jsonb,
  checkout_data jsonb NOT NULL DEFAULT '{}'::jsonb,
  message_id text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(restaurant_id, telegram_user_id)
);

-- Index for fast lookup
CREATE INDEX IF NOT EXISTS telegram_sessions_lookup_idx ON telegram_sessions(restaurant_id, telegram_user_id);

ALTER TABLE telegram_sessions ENABLE ROW LEVEL SECURITY;

-- Service role only (edge function)
CREATE POLICY "Service role full access"
  ON telegram_sessions FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);
