/*
  # Create delivery_zones table

  1. New Tables
    - `delivery_zones`
      - `id` (uuid, primary key, auto-generated)
      - `restaurant_id` (uuid, foreign key to restaurants)
      - `name` (text, zone display name in Arabic)
      - `price` (numeric, delivery fee amount)
      - `created_at` (timestamptz, auto-generated)

  2. Security
    - Enable RLS on `delivery_zones`
    - SELECT: authenticated users can read zones for their restaurant
    - INSERT: authenticated users can add zones for their restaurant
    - UPDATE: authenticated users can update zones for their restaurant
    - DELETE: authenticated users can delete zones for their restaurant

  3. Notes
    - Each zone belongs to a restaurant via restaurant_id
    - price stores the delivery fee as a numeric value
    - All policies verify ownership through the restaurants table
*/

CREATE TABLE IF NOT EXISTS delivery_zones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT '',
  price numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE delivery_zones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Restaurant owners can read own delivery zones"
  ON delivery_zones FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = delivery_zones.restaurant_id
      AND restaurants.owner_id = auth.uid()
    )
  );

CREATE POLICY "Restaurant owners can insert own delivery zones"
  ON delivery_zones FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = delivery_zones.restaurant_id
      AND restaurants.owner_id = auth.uid()
    )
  );

CREATE POLICY "Restaurant owners can update own delivery zones"
  ON delivery_zones FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = delivery_zones.restaurant_id
      AND restaurants.owner_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = delivery_zones.restaurant_id
      AND restaurants.owner_id = auth.uid()
    )
  );

CREATE POLICY "Restaurant owners can delete own delivery zones"
  ON delivery_zones FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = delivery_zones.restaurant_id
      AND restaurants.owner_id = auth.uid()
    )
  );
