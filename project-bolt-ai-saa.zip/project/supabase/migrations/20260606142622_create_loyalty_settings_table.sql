CREATE TABLE IF NOT EXISTS loyalty_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  rule_type text NOT NULL DEFAULT 'amount',
  orders_threshold integer DEFAULT 10,
  orders_points integer DEFAULT 1,
  amount_threshold integer DEFAULT 10,
  amount_points integer DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(restaurant_id)
);

ALTER TABLE loyalty_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_settings" ON loyalty_settings FOR SELECT TO authenticated USING (restaurant_id IN (SELECT id FROM restaurants WHERE owner_id = auth.uid()));
CREATE POLICY "insert_own_settings" ON loyalty_settings FOR INSERT TO authenticated WITH CHECK (restaurant_id IN (SELECT id FROM restaurants WHERE owner_id = auth.uid()));
CREATE POLICY "update_own_settings" ON loyalty_settings FOR UPDATE TO authenticated USING (restaurant_id IN (SELECT id FROM restaurants WHERE owner_id = auth.uid())) WITH CHECK (restaurant_id IN (SELECT id FROM restaurants WHERE owner_id = auth.uid()));
CREATE POLICY "delete_own_settings" ON loyalty_settings FOR DELETE TO authenticated USING (restaurant_id IN (SELECT id FROM restaurants WHERE owner_id = auth.uid()));