ALTER TABLE restaurants ADD COLUMN IF NOT EXISTS subscription_plan text DEFAULT 'basic';
ALTER TABLE restaurants ADD COLUMN IF NOT EXISTS subscription_expires_at timestamptz;
ALTER TABLE restaurants ADD COLUMN IF NOT EXISTS is_suspended boolean DEFAULT false;
ALTER TABLE restaurants ADD COLUMN IF NOT EXISTS email text DEFAULT '';