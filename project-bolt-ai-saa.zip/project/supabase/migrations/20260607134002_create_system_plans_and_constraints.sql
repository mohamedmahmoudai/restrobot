CREATE TABLE system_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_name text NOT NULL,
  type text NOT NULL UNIQUE CHECK (type IN ('trial', 'basic', 'premium', 'enterprise')),
  price numeric(10,0) DEFAULT 0,
  features jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

INSERT INTO system_plans (plan_name, type, price, features) VALUES
  ('الخطة التجريبية', 'trial', 0, '["3 أيام مجاناً", "جميع المميزات الأساسية"]'::jsonb),
  ('الخطة الأساسية', 'basic', 599, '["طلبات غير محدودة", "لوحة تحكم كاملة", "برنامج الولاء", "تحليلات"]'::jsonb),
  ('الخطة الاحترافية', 'premium', 799, '["كل مميزات الأساسية", "تحليلات متقدمة", "دعم أولوية", "تكامل واتساب"]'::jsonb),
  ('خطة المطاعم الكبيرة', 'enterprise', 0, '["حلول مخصصة", "فروع متعددة", "دعم مخصص 24/7"]'::jsonb);

ALTER TABLE restaurants ALTER COLUMN name TYPE varchar(60);
ALTER TABLE menu_items ALTER COLUMN name TYPE varchar(60);
ALTER TABLE customers ALTER COLUMN name TYPE varchar(60);
ALTER TABLE delivery_zones ALTER COLUMN name TYPE varchar(60);
ALTER TABLE customers ALTER COLUMN phone TYPE varchar(15);
ALTER TABLE loyalty_transactions ALTER COLUMN points TYPE numeric(6,0);
ALTER TABLE loyalty_rewards ALTER COLUMN points_required TYPE numeric(6,0);

CREATE INDEX IF NOT EXISTS idx_restaurants_subscription ON restaurants(subscription_plan, is_active);
CREATE INDEX IF NOT EXISTS idx_customers_phone_unique ON customers(phone, restaurant_id);

ALTER TABLE customers ADD CONSTRAINT unique_phone_per_restaurant UNIQUE (phone, restaurant_id);