/*
# Loyalty & Rewards Engine — Phase 7

## Summary
Creates the complete loyalty system database schema for the RestroBot platform.
This includes customer points wallets, reward catalogs, tier systems, point transactions,
and reward redemptions with full multi-tenant isolation and audit logging.

## New Tables
1. `customer_points_wallet` — Per-customer points balance, lifetime points, redeemed points, tier, expiry tracking.
2. `reward_catalog` — Restaurant-defined rewards (free items, discounts) with point costs.
3. `reward_redemptions` — Records of customers redeeming rewards, with validation codes and status.
4. `customer_tiers` — Configurable tier thresholds per restaurant (Bronze, Silver, Gold, Platinum).
5. `points_transactions` — Full audit log of every point earn, redeem, expire, adjust event.
6. `loyalty_settings` (updated schema) — Per-restaurant loyalty configuration (points per currency unit, expiration, redemption limits).

## Security
- RLS enabled on all new tables.
- Restaurant-scoped policies using restaurant_id isolation.
- No cross-tenant data access possible.

## Triggers
- Auto-create wallet on new customer insert.
- Auto-update customer tier when points change.
- Auto-calculate points on order status = 'delivered'.
*/

-- ============================================================
-- 1. LOYALTY SETTINGS (expanded)
-- ============================================================
ALTER TABLE IF EXISTS loyalty_settings
ADD COLUMN IF NOT EXISTS points_per_currency_unit numeric NOT NULL DEFAULT 1,
ADD COLUMN IF NOT EXISTS currency_unit numeric NOT NULL DEFAULT 10,
ADD COLUMN IF NOT EXISTS points_expiration_days integer NOT NULL DEFAULT 365,
ADD COLUMN IF NOT EXISTS min_redemption_points integer NOT NULL DEFAULT 100,
ADD COLUMN IF NOT EXISTS max_redemption_per_order integer NOT NULL DEFAULT 1,
ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true;

-- ============================================================
-- 2. CUSTOMER POINTS WALLET
-- ============================================================
CREATE TABLE IF NOT EXISTS customer_points_wallet (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  current_points integer NOT NULL DEFAULT 0,
  lifetime_points integer NOT NULL DEFAULT 0,
  redeemed_points integer NOT NULL DEFAULT 0,
  current_tier text NOT NULL DEFAULT 'bronze',
  points_expiry_date timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(restaurant_id, customer_id)
);

CREATE INDEX IF NOT EXISTS idx_wallet_restaurant ON customer_points_wallet(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_wallet_customer ON customer_points_wallet(customer_id);
CREATE INDEX IF NOT EXISTS idx_wallet_tier ON customer_points_wallet(current_tier);

ALTER TABLE customer_points_wallet ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_wallet_own_restaurant" ON customer_points_wallet;
CREATE POLICY "select_wallet_own_restaurant" ON customer_points_wallet FOR SELECT
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = customer_points_wallet.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "insert_wallet_own_restaurant" ON customer_points_wallet;
CREATE POLICY "insert_wallet_own_restaurant" ON customer_points_wallet FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = customer_points_wallet.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "update_wallet_own_restaurant" ON customer_points_wallet;
CREATE POLICY "update_wallet_own_restaurant" ON customer_points_wallet FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = customer_points_wallet.restaurant_id AND restaurants.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = customer_points_wallet.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "delete_wallet_own_restaurant" ON customer_points_wallet;
CREATE POLICY "delete_wallet_own_restaurant" ON customer_points_wallet FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = customer_points_wallet.restaurant_id AND restaurants.owner_id = auth.uid()));

-- ============================================================
-- 3. REWARD CATALOG
-- ============================================================
CREATE TABLE IF NOT EXISTS reward_catalog (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  points_required integer NOT NULL DEFAULT 0,
  reward_type text NOT NULL DEFAULT 'free_item',
  reward_value numeric NOT NULL DEFAULT 0,
  reward_item_name text,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reward_catalog_restaurant ON reward_catalog(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_reward_catalog_active ON reward_catalog(restaurant_id, is_active);

ALTER TABLE reward_catalog ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_rewards_own_restaurant" ON reward_catalog;
CREATE POLICY "select_rewards_own_restaurant" ON reward_catalog FOR SELECT
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = reward_catalog.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "insert_rewards_own_restaurant" ON reward_catalog;
CREATE POLICY "insert_rewards_own_restaurant" ON reward_catalog FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = reward_catalog.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "update_rewards_own_restaurant" ON reward_catalog;
CREATE POLICY "update_rewards_own_restaurant" ON reward_catalog FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = reward_catalog.restaurant_id AND restaurants.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = reward_catalog.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "delete_rewards_own_restaurant" ON reward_catalog;
CREATE POLICY "delete_rewards_own_restaurant" ON reward_catalog FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = reward_catalog.restaurant_id AND restaurants.owner_id = auth.uid()));

-- ============================================================
-- 4. REWARD REDEMPTIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS reward_redemptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  reward_id uuid NOT NULL REFERENCES reward_catalog(id) ON DELETE CASCADE,
  points_used integer NOT NULL DEFAULT 0,
  redemption_code text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'pending',
  redeemed_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_redemptions_restaurant ON reward_redemptions(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_redemptions_customer ON reward_redemptions(customer_id);
CREATE INDEX IF NOT EXISTS idx_redemptions_code ON reward_redemptions(redemption_code);
CREATE INDEX IF NOT EXISTS idx_redemptions_status ON reward_redemptions(restaurant_id, status);

ALTER TABLE reward_redemptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_redemptions_own_restaurant" ON reward_redemptions;
CREATE POLICY "select_redemptions_own_restaurant" ON reward_redemptions FOR SELECT
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = reward_redemptions.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "insert_redemptions_own_restaurant" ON reward_redemptions;
CREATE POLICY "insert_redemptions_own_restaurant" ON reward_redemptions FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = reward_redemptions.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "update_redemptions_own_restaurant" ON reward_redemptions;
CREATE POLICY "update_redemptions_own_restaurant" ON reward_redemptions FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = reward_redemptions.restaurant_id AND restaurants.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = reward_redemptions.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "delete_redemptions_own_restaurant" ON reward_redemptions;
CREATE POLICY "delete_redemptions_own_restaurant" ON reward_redemptions FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = reward_redemptions.restaurant_id AND restaurants.owner_id = auth.uid()));

-- ============================================================
-- 5. CUSTOMER TIERS
-- ============================================================
CREATE TABLE IF NOT EXISTS customer_tiers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  tier_name text NOT NULL DEFAULT 'bronze',
  tier_label_ar text NOT NULL,
  min_points integer NOT NULL DEFAULT 0,
  max_points integer,
  color_hex text NOT NULL DEFAULT '#a16207',
  benefits text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(restaurant_id, tier_name)
);

CREATE INDEX IF NOT EXISTS idx_tiers_restaurant ON customer_tiers(restaurant_id);

ALTER TABLE customer_tiers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_tiers_own_restaurant" ON customer_tiers;
CREATE POLICY "select_tiers_own_restaurant" ON customer_tiers FOR SELECT
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = customer_tiers.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "insert_tiers_own_restaurant" ON customer_tiers;
CREATE POLICY "insert_tiers_own_restaurant" ON customer_tiers FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = customer_tiers.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "update_tiers_own_restaurant" ON customer_tiers;
CREATE POLICY "update_tiers_own_restaurant" ON customer_tiers FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = customer_tiers.restaurant_id AND restaurants.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = customer_tiers.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "delete_tiers_own_restaurant" ON customer_tiers;
CREATE POLICY "delete_tiers_own_restaurant" ON customer_tiers FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = customer_tiers.restaurant_id AND restaurants.owner_id = auth.uid()));

-- ============================================================
-- 6. POINTS TRANSACTIONS (Audit Log)
-- ============================================================
CREATE TABLE IF NOT EXISTS points_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  order_id uuid REFERENCES orders(id) ON DELETE SET NULL,
  reward_id uuid REFERENCES reward_catalog(id) ON DELETE SET NULL,
  redemption_id uuid REFERENCES reward_redemptions(id) ON DELETE SET NULL,
  type text NOT NULL,
  points integer NOT NULL,
  balance_after integer NOT NULL,
  notes text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_points_transactions_restaurant ON points_transactions(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_points_transactions_customer ON points_transactions(customer_id);
CREATE INDEX IF NOT EXISTS idx_points_transactions_type ON points_transactions(restaurant_id, type);
CREATE INDEX IF NOT EXISTS idx_points_transactions_created ON points_transactions(created_at);

ALTER TABLE points_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_transactions_own_restaurant" ON points_transactions;
CREATE POLICY "select_transactions_own_restaurant" ON points_transactions FOR SELECT
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = points_transactions.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "insert_transactions_own_restaurant" ON points_transactions;
CREATE POLICY "insert_transactions_own_restaurant" ON points_transactions FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = points_transactions.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "update_transactions_own_restaurant" ON points_transactions;
CREATE POLICY "update_transactions_own_restaurant" ON points_transactions FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = points_transactions.restaurant_id AND restaurants.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = points_transactions.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "delete_transactions_own_restaurant" ON points_transactions;
CREATE POLICY "delete_transactions_own_restaurant" ON points_transactions FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = points_transactions.restaurant_id AND restaurants.owner_id = auth.uid()));

-- ============================================================
-- 7. DEFAULT TIERS SEED
-- ============================================================
INSERT INTO customer_tiers (restaurant_id, tier_name, tier_label_ar, min_points, max_points, color_hex, sort_order)
SELECT r.id, 'bronze', 'برونزي', 0, 500, '#a16207', 1
FROM restaurants r
WHERE NOT EXISTS (SELECT 1 FROM customer_tiers t WHERE t.restaurant_id = r.id AND t.tier_name = 'bronze');

INSERT INTO customer_tiers (restaurant_id, tier_name, tier_label_ar, min_points, max_points, color_hex, sort_order)
SELECT r.id, 'silver', 'فضي', 501, 1500, '#64748b', 2
FROM restaurants r
WHERE NOT EXISTS (SELECT 1 FROM customer_tiers t WHERE t.restaurant_id = r.id AND t.tier_name = 'silver');

INSERT INTO customer_tiers (restaurant_id, tier_name, tier_label_ar, min_points, max_points, color_hex, sort_order)
SELECT r.id, 'gold', 'ذهبي', 1501, 5000, '#d97706', 3
FROM restaurants r
WHERE NOT EXISTS (SELECT 1 FROM customer_tiers t WHERE t.restaurant_id = r.id AND t.tier_name = 'gold');

INSERT INTO customer_tiers (restaurant_id, tier_name, tier_label_ar, min_points, max_points, color_hex, sort_order)
SELECT r.id, 'platinum', 'بلاتيني', 5001, NULL, '#0ea5e9', 4
FROM restaurants r
WHERE NOT EXISTS (SELECT 1 FROM customer_tiers t WHERE t.restaurant_id = r.id AND t.tier_name = 'platinum');

-- ============================================================
-- 8. AUTO-CREATE WALLET ON NEW CUSTOMER
-- ============================================================
CREATE OR REPLACE FUNCTION auto_create_wallet()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO customer_points_wallet (restaurant_id, customer_id, current_points, lifetime_points, redeemed_points, current_tier)
  VALUES (NEW.restaurant_id, NEW.id, 0, 0, 0, 'bronze');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_auto_create_wallet ON customers;
CREATE TRIGGER trg_auto_create_wallet
  AFTER INSERT ON customers
  FOR EACH ROW
  EXECUTE FUNCTION auto_create_wallet();

-- ============================================================
-- 9. AUTO-UPDATE TIER FUNCTION
-- ============================================================
CREATE OR REPLACE FUNCTION update_customer_tier()
RETURNS TRIGGER AS $$
DECLARE
  new_tier text;
  tier_rec record;
BEGIN
  SELECT tier_name INTO new_tier
  FROM customer_tiers
  WHERE restaurant_id = NEW.restaurant_id
    AND NEW.lifetime_points >= min_points
    AND (max_points IS NULL OR NEW.lifetime_points <= max_points)
  ORDER BY min_points DESC
  LIMIT 1;

  IF new_tier IS NOT NULL AND new_tier != NEW.current_tier THEN
    NEW.current_tier := new_tier;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_update_tier ON customer_points_wallet;
CREATE TRIGGER trg_update_tier
  BEFORE UPDATE ON customer_points_wallet
  FOR EACH ROW
  WHEN (NEW.lifetime_points IS DISTINCT FROM OLD.lifetime_points)
  EXECUTE FUNCTION update_customer_tier();

-- ============================================================
-- 10. AUTO-EARN POINTS ON DELIVERED ORDER
-- ============================================================
CREATE OR REPLACE FUNCTION auto_earn_points_on_delivery()
RETURNS TRIGGER AS $$
DECLARE
  ls record;
  earned integer;
  wallet_id uuid;
  current_bal integer;
BEGIN
  IF NEW.status = 'delivered' AND (OLD.status IS NULL OR OLD.status != 'delivered') THEN
    SELECT * INTO ls FROM loyalty_settings WHERE restaurant_id = NEW.restaurant_id LIMIT 1;
    IF FOUND AND ls.is_active THEN
      earned := FLOOR(NEW.total / ls.currency_unit * ls.points_per_currency_unit)::integer;
      IF earned > 0 THEN
        SELECT id, current_points INTO wallet_id, current_bal
        FROM customer_points_wallet
        WHERE restaurant_id = NEW.restaurant_id AND customer_id = NEW.customer_id;

        IF FOUND THEN
          UPDATE customer_points_wallet
          SET current_points = current_points + earned,
              lifetime_points = lifetime_points + earned,
              updated_at = now()
          WHERE id = wallet_id;

          INSERT INTO points_transactions (restaurant_id, customer_id, order_id, type, points, balance_after, notes)
          VALUES (NEW.restaurant_id, NEW.customer_id, NEW.id, 'earned', earned, current_bal + earned,
                  'نقاط تلقائية من الطلب ' || NEW.order_number);
        END IF;
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_auto_earn_points ON orders;
CREATE TRIGGER trg_auto_earn_points
  AFTER UPDATE ON orders
  FOR EACH ROW
  WHEN (NEW.status IS DISTINCT FROM OLD.status)
  EXECUTE FUNCTION auto_earn_points_on_delivery();
