/*
# Add customer status column

Adds a status column to the customers table to support blocking/verifying customers.
*/

ALTER TABLE IF EXISTS customers
ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'new';
