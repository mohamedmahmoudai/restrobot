/*
# Super Admin SaaS Control Center — Phase 11

## Summary
Creates the database tables needed for the complete Super Admin Control Center.
This includes support tickets, platform settings, announcements, and admin audit logs.

## New Tables
1. `support_tickets` — Restaurants can submit tickets (problems, feature requests, bug reports).
2. `platform_settings` — Global platform configuration editable by admin without code changes.
3. `announcements` — Admin-published announcements displayed in restaurant dashboards.
4. `admin_audit_logs` — Tracks every admin action for accountability.

## Security
- RLS enabled on all new tables.
- Restaurant-scoped policies for support_tickets.
- Admin-only access for platform_settings, announcements, audit_logs.
*/

-- ============================================================
-- 1. SUPPORT TICKETS
-- ============================================================
CREATE TABLE IF NOT EXISTS support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  type text NOT NULL DEFAULT 'problem',
  subject text NOT NULL,
  body text NOT NULL,
  status text NOT NULL DEFAULT 'open',
  priority text NOT NULL DEFAULT 'normal',
  admin_reply text,
  replied_at timestamptz,
  replied_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tickets_restaurant ON support_tickets(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON support_tickets(status);
CREATE INDEX IF NOT EXISTS idx_tickets_created ON support_tickets(created_at);

ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_tickets_own_restaurant" ON support_tickets;
CREATE POLICY "select_tickets_own_restaurant" ON support_tickets FOR SELECT
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = support_tickets.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "insert_tickets_own_restaurant" ON support_tickets;
CREATE POLICY "insert_tickets_own_restaurant" ON support_tickets FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = support_tickets.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "update_tickets_own_restaurant" ON support_tickets;
CREATE POLICY "update_tickets_own_restaurant" ON support_tickets FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = support_tickets.restaurant_id AND restaurants.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = support_tickets.restaurant_id AND restaurants.owner_id = auth.uid()));

DROP POLICY IF EXISTS "delete_tickets_own_restaurant" ON support_tickets;
CREATE POLICY "delete_tickets_own_restaurant" ON support_tickets FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = support_tickets.restaurant_id AND restaurants.owner_id = auth.uid()));

-- ============================================================
-- 2. PLATFORM SETTINGS
-- ============================================================
CREATE TABLE IF NOT EXISTS platform_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  value text NOT NULL,
  description text,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE platform_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_platform_settings" ON platform_settings;
CREATE POLICY "select_platform_settings" ON platform_settings FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_platform_settings_admin" ON platform_settings;
CREATE POLICY "insert_platform_settings_admin" ON platform_settings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'));

DROP POLICY IF EXISTS "update_platform_settings_admin" ON platform_settings;
CREATE POLICY "update_platform_settings_admin" ON platform_settings FOR UPDATE
  TO authenticated USING (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'))
  WITH CHECK (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'));

DROP POLICY IF EXISTS "delete_platform_settings_admin" ON platform_settings;
CREATE POLICY "delete_platform_settings_admin" ON platform_settings FOR DELETE
  TO authenticated USING (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'));

-- Seed default platform settings
INSERT INTO platform_settings (key, value, description)
VALUES
  ('platform_name', 'RestroBot', 'اسم المنصة'),
  ('support_email', 'support@restrobot.com', 'بريد الدعم'),
  ('support_whatsapp', '', 'رقم واتساب الدعم'),
  ('trial_duration_days', '14', 'مدة التجربة بالأيام'),
  ('trial_order_limit', '50', 'حد الطلبات في التجربة')
ON CONFLICT (key) DO NOTHING;

-- ============================================================
-- 3. ANNOUNCEMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text NOT NULL,
  type text NOT NULL DEFAULT 'info',
  is_active boolean NOT NULL DEFAULT true,
  target_audience text NOT NULL DEFAULT 'all',
  start_date timestamptz,
  end_date timestamptz,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_announcements_active ON announcements(is_active);
CREATE INDEX IF NOT EXISTS idx_announcements_dates ON announcements(start_date, end_date);

ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_announcements_all" ON announcements;
CREATE POLICY "select_announcements_all" ON announcements FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_announcements_admin" ON announcements;
CREATE POLICY "insert_announcements_admin" ON announcements FOR INSERT
  TO authenticated WITH CHECK (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'));

DROP POLICY IF EXISTS "update_announcements_admin" ON announcements;
CREATE POLICY "update_announcements_admin" ON announcements FOR UPDATE
  TO authenticated USING (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'))
  WITH CHECK (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'));

DROP POLICY IF EXISTS "delete_announcements_admin" ON announcements;
CREATE POLICY "delete_announcements_admin" ON announcements FOR DELETE
  TO authenticated USING (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'));

-- ============================================================
-- 4. ADMIN AUDIT LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS admin_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  admin_email text,
  action text NOT NULL,
  target_type text NOT NULL,
  target_id text,
  target_name text,
  details jsonb,
  ip_address text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_admin ON admin_audit_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON admin_audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_target ON admin_audit_logs(target_type, target_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON admin_audit_logs(created_at);

ALTER TABLE admin_audit_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_audit_logs_admin" ON admin_audit_logs;
CREATE POLICY "select_audit_logs_admin" ON admin_audit_logs FOR SELECT
  TO authenticated USING (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'));

DROP POLICY IF EXISTS "insert_audit_logs_admin" ON admin_audit_logs;
CREATE POLICY "insert_audit_logs_admin" ON admin_audit_logs FOR INSERT
  TO authenticated WITH CHECK (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'));

DROP POLICY IF EXISTS "update_audit_logs_admin" ON admin_audit_logs;
CREATE POLICY "update_audit_logs_admin" ON admin_audit_logs FOR UPDATE
  TO authenticated USING (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'))
  WITH CHECK (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'));

DROP POLICY IF EXISTS "delete_audit_logs_admin" ON admin_audit_logs;
CREATE POLICY "delete_audit_logs_admin" ON admin_audit_logs FOR DELETE
  TO authenticated USING (auth.uid() IN (SELECT id FROM auth.users WHERE email = 'admin@restrobot.com'));
