/*
# Realtime Order Pipeline — Phase 6
## Summary
Creates order_events table for audit trail and adds realtime notification support.
*/

-- ============================================================
-- ORDER EVENTS (Audit Trail)
-- ============================================================
CREATE TABLE IF NOT EXISTS order_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  old_status text,
  new_status text NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  user_email text,
  notes text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_order_events_order ON order_events(order_id);
CREATE INDEX IF NOT EXISTS idx_order_events_created ON order_events(created_at);

ALTER TABLE order_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "owners_read_order_events" ON order_events;
CREATE POLICY "owners_read_order_events" ON order_events FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM orders o
    JOIN restaurants r ON r.id = o.restaurant_id
    WHERE o.id = order_events.order_id AND r.owner_id = auth.uid()
  ));

DROP POLICY IF EXISTS "owners_insert_order_events" ON order_events;
CREATE POLICY "owners_insert_order_events" ON order_events FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM orders o
    JOIN restaurants r ON r.id = o.restaurant_id
    WHERE o.id = order_events.order_id AND r.owner_id = auth.uid()
  ));

-- ============================================================
-- TRIGGER: Auto-notify customer on order status change
-- ============================================================
CREATE OR REPLACE FUNCTION notify_customer_on_status_change()
RETURNS TRIGGER AS $$
DECLARE
  customer_telegram_id text;
  bot_token text;
  restaurant_name text;
  status_messages jsonb;
  msg text;
BEGIN
  -- Only act when status actually changes
  IF OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;

  -- Get customer telegram_id and bot token
  SELECT c.telegram_id, r.telegram_bot_token, r.name
  INTO customer_telegram_id, bot_token, restaurant_name
  FROM customers c
  JOIN restaurants r ON r.id = NEW.restaurant_id
  WHERE c.id = NEW.customer_id;

  IF customer_telegram_id IS NULL OR bot_token IS NULL THEN
    RETURN NEW;
  END IF;

  status_messages := '{
    "pending": "تم استلام طلبك بنجاح! سنبدأ التحضير قريباً.",
    "preparing": "طلبك قيد التحضير الآن!",
    "ready": "طلبك جاهز للاستلام/التوصيل!",
    "delivered": "تم توصيل طلبك بنجاح! شكراً لاختيارك.",
    "cancelled": "تم إلغاء طلبك. نعتذر عن الإزعاج."
  }'::jsonb;

  msg := status_messages->>NEW.status;
  IF msg IS NULL THEN
    msg := 'تحديث حالة طلبك: ' || NEW.status;
  END IF;

  -- Perform HTTP call to Telegram (fire-and-forget via pg_net if available, otherwise skip)
  -- We use pg_cron or just record the event; the webhook edge function handles actual sending
  PERFORM
    net.http_post(
      url := 'https://api.telegram.org/bot' || bot_token || '/sendMessage',
      headers := '{"Content-Type": "application/json"}'::jsonb,
      body := jsonb_build_object(
        'chat_id', customer_telegram_id,
        'text', '🔔 *' || restaurant_name || '*\n\n' || msg || '\n\nرقم الطلب: #' || NEW.order_number,
        'parse_mode', 'Markdown'
      )
    );

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Only create trigger if pg_net extension is available
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_net') THEN
    DROP TRIGGER IF EXISTS customer_status_notification ON orders;
    CREATE TRIGGER customer_status_notification
      AFTER UPDATE OF status ON orders
      FOR EACH ROW
      EXECUTE FUNCTION notify_customer_on_status_change();
  END IF;
END $$;
