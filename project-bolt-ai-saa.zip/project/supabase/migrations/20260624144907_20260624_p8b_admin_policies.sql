-- 2. Fix platform_settings — restrict to admins only (was: all authenticated)
DROP POLICY IF EXISTS "select_platform_settings" ON platform_settings;
DROP POLICY IF EXISTS "insert_platform_settings_admin" ON platform_settings;
DROP POLICY IF EXISTS "update_platform_settings_admin" ON platform_settings;
DROP POLICY IF EXISTS "delete_platform_settings_admin" ON platform_settings;

CREATE POLICY "admins_select_platform_settings" ON platform_settings
  FOR SELECT TO authenticated USING (is_platform_admin());

CREATE POLICY "admins_insert_platform_settings" ON platform_settings
  FOR INSERT TO authenticated WITH CHECK (is_platform_admin());

CREATE POLICY "admins_update_platform_settings" ON platform_settings
  FOR UPDATE TO authenticated
  USING (is_platform_admin()) WITH CHECK (is_platform_admin());

CREATE POLICY "admins_delete_platform_settings" ON platform_settings
  FOR DELETE TO authenticated USING (is_platform_admin());

-- 3. Fix announcements — write locked to admins, read open to authenticated
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_announcements_all" ON announcements;
DROP POLICY IF EXISTS "insert_announcements_admin" ON announcements;
DROP POLICY IF EXISTS "update_announcements_admin" ON announcements;
DROP POLICY IF EXISTS "delete_announcements_admin" ON announcements;

CREATE POLICY "authenticated_select_announcements" ON announcements
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "admins_insert_announcements" ON announcements
  FOR INSERT TO authenticated WITH CHECK (is_platform_admin());

CREATE POLICY "admins_update_announcements" ON announcements
  FOR UPDATE TO authenticated
  USING (is_platform_admin()) WITH CHECK (is_platform_admin());

CREATE POLICY "admins_delete_announcements" ON announcements
  FOR DELETE TO authenticated USING (is_platform_admin());

-- 4. Fix admin_audit_logs — replace email-hardcoded policies
ALTER TABLE admin_audit_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_audit_logs_admin" ON admin_audit_logs;
DROP POLICY IF EXISTS "insert_audit_logs_admin" ON admin_audit_logs;
DROP POLICY IF EXISTS "update_audit_logs_admin" ON admin_audit_logs;
DROP POLICY IF EXISTS "delete_audit_logs_admin" ON admin_audit_logs;

CREATE POLICY "admins_select_audit_logs" ON admin_audit_logs
  FOR SELECT TO authenticated USING (is_platform_admin());

CREATE POLICY "admins_insert_audit_logs" ON admin_audit_logs
  FOR INSERT TO authenticated WITH CHECK (is_platform_admin());

CREATE POLICY "admins_update_audit_logs" ON admin_audit_logs
  FOR UPDATE TO authenticated
  USING (is_platform_admin()) WITH CHECK (is_platform_admin());

CREATE POLICY "admins_delete_audit_logs" ON admin_audit_logs
  FOR DELETE TO authenticated USING (is_platform_admin());
