-- 5. Support tickets — full tenant CRUD + admin override
ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "owners_select_support_tickets" ON support_tickets;
DROP POLICY IF EXISTS "owners_insert_support_tickets" ON support_tickets;
DROP POLICY IF EXISTS "owners_update_support_tickets" ON support_tickets;
DROP POLICY IF EXISTS "owners_delete_support_tickets" ON support_tickets;
DROP POLICY IF EXISTS "admins_select_support_tickets" ON support_tickets;
DROP POLICY IF EXISTS "admins_update_support_tickets" ON support_tickets;

CREATE POLICY "owners_select_support_tickets" ON support_tickets
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_insert_support_tickets" ON support_tickets
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_update_support_tickets" ON support_tickets
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_delete_support_tickets" ON support_tickets
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "admins_select_support_tickets" ON support_tickets
  FOR SELECT TO authenticated USING (is_platform_admin());

CREATE POLICY "admins_update_support_tickets" ON support_tickets
  FOR UPDATE TO authenticated
  USING (is_platform_admin()) WITH CHECK (is_platform_admin());

-- 6. order_items — missing UPDATE + DELETE
DROP POLICY IF EXISTS "owners_update_order_items" ON order_items;
DROP POLICY IF EXISTS "owners_delete_order_items" ON order_items;

CREATE POLICY "owners_update_order_items" ON order_items
  FOR UPDATE TO authenticated
  USING (EXISTS (
    SELECT 1 FROM orders o JOIN restaurants r ON r.id = o.restaurant_id
    WHERE o.id = order_items.order_id AND r.owner_id = auth.uid()
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM orders o JOIN restaurants r ON r.id = o.restaurant_id
    WHERE o.id = order_items.order_id AND r.owner_id = auth.uid()
  ));

CREATE POLICY "owners_delete_order_items" ON order_items
  FOR DELETE TO authenticated
  USING (EXISTS (
    SELECT 1 FROM orders o JOIN restaurants r ON r.id = o.restaurant_id
    WHERE o.id = order_items.order_id AND r.owner_id = auth.uid()
  ));

-- 7. loyalty_transactions — missing UPDATE + DELETE
DROP POLICY IF EXISTS "owners_update_loyalty_transactions" ON loyalty_transactions;
DROP POLICY IF EXISTS "owners_delete_loyalty_transactions" ON loyalty_transactions;

CREATE POLICY "owners_update_loyalty_transactions" ON loyalty_transactions
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_delete_loyalty_transactions" ON loyalty_transactions
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

-- 8. notifications — missing INSERT
DROP POLICY IF EXISTS "owners_insert_notifications" ON notifications;

CREATE POLICY "owners_insert_notifications" ON notifications
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

-- 9. restaurants — add admin SELECT
DROP POLICY IF EXISTS "admins_select_restaurants" ON restaurants;

CREATE POLICY "admins_select_restaurants" ON restaurants
  FOR SELECT TO authenticated USING (is_platform_admin());
