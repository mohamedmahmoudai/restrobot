-- 10. system_plans — read for all authenticated, write for admins only
DROP POLICY IF EXISTS "system_plans_select" ON system_plans;
DROP POLICY IF EXISTS "system_plans_insert" ON system_plans;
DROP POLICY IF EXISTS "system_plans_update" ON system_plans;
DROP POLICY IF EXISTS "system_plans_delete" ON system_plans;
DROP POLICY IF EXISTS "authenticated_select_system_plans" ON system_plans;
DROP POLICY IF EXISTS "admins_insert_system_plans" ON system_plans;
DROP POLICY IF EXISTS "admins_update_system_plans" ON system_plans;
DROP POLICY IF EXISTS "admins_delete_system_plans" ON system_plans;

CREATE POLICY "authenticated_select_system_plans" ON system_plans
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "admins_insert_system_plans" ON system_plans
  FOR INSERT TO authenticated WITH CHECK (is_platform_admin());

CREATE POLICY "admins_update_system_plans" ON system_plans
  FOR UPDATE TO authenticated
  USING (is_platform_admin()) WITH CHECK (is_platform_admin());

CREATE POLICY "admins_delete_system_plans" ON system_plans
  FOR DELETE TO authenticated USING (is_platform_admin());

-- 11. customer_points_wallet — full isolation
ALTER TABLE customer_points_wallet ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "owners_select_wallets" ON customer_points_wallet;
DROP POLICY IF EXISTS "owners_insert_wallets" ON customer_points_wallet;
DROP POLICY IF EXISTS "owners_update_wallets" ON customer_points_wallet;
DROP POLICY IF EXISTS "owners_delete_wallets" ON customer_points_wallet;

CREATE POLICY "owners_select_wallets" ON customer_points_wallet
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_insert_wallets" ON customer_points_wallet
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_update_wallets" ON customer_points_wallet
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_delete_wallets" ON customer_points_wallet
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

-- 12. reward_catalog — full isolation
ALTER TABLE reward_catalog ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "owners_select_reward_catalog" ON reward_catalog;
DROP POLICY IF EXISTS "owners_insert_reward_catalog" ON reward_catalog;
DROP POLICY IF EXISTS "owners_update_reward_catalog" ON reward_catalog;
DROP POLICY IF EXISTS "owners_delete_reward_catalog" ON reward_catalog;

CREATE POLICY "owners_select_reward_catalog" ON reward_catalog
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_insert_reward_catalog" ON reward_catalog
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_update_reward_catalog" ON reward_catalog
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_delete_reward_catalog" ON reward_catalog
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

-- 13. reward_redemptions — full isolation
ALTER TABLE reward_redemptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "owners_select_redemptions" ON reward_redemptions;
DROP POLICY IF EXISTS "owners_insert_redemptions" ON reward_redemptions;
DROP POLICY IF EXISTS "owners_update_redemptions" ON reward_redemptions;
DROP POLICY IF EXISTS "owners_delete_redemptions" ON reward_redemptions;

CREATE POLICY "owners_select_redemptions" ON reward_redemptions
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_insert_redemptions" ON reward_redemptions
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_update_redemptions" ON reward_redemptions
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_delete_redemptions" ON reward_redemptions
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

-- 14. customer_tiers — full isolation
ALTER TABLE customer_tiers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "owners_select_tiers" ON customer_tiers;
DROP POLICY IF EXISTS "owners_insert_tiers" ON customer_tiers;
DROP POLICY IF EXISTS "owners_update_tiers" ON customer_tiers;
DROP POLICY IF EXISTS "owners_delete_tiers" ON customer_tiers;

CREATE POLICY "owners_select_tiers" ON customer_tiers
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_insert_tiers" ON customer_tiers
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_update_tiers" ON customer_tiers
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_delete_tiers" ON customer_tiers
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

-- 15. points_transactions — full isolation
ALTER TABLE points_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "owners_select_points_transactions" ON points_transactions;
DROP POLICY IF EXISTS "owners_insert_points_transactions" ON points_transactions;
DROP POLICY IF EXISTS "owners_update_points_transactions" ON points_transactions;
DROP POLICY IF EXISTS "owners_delete_points_transactions" ON points_transactions;

CREATE POLICY "owners_select_points_transactions" ON points_transactions
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_insert_points_transactions" ON points_transactions
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_update_points_transactions" ON points_transactions
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_delete_points_transactions" ON points_transactions
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));
