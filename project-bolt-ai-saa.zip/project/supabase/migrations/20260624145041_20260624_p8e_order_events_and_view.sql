-- 16. order_events — rewrite policies using restaurant_id directly + admin view
DROP POLICY IF EXISTS "owners_select_order_events" ON order_events;
DROP POLICY IF EXISTS "owners_insert_order_events" ON order_events;
DROP POLICY IF EXISTS "owners_read_order_events" ON order_events;
DROP POLICY IF EXISTS "admins_select_order_events" ON order_events;

-- Add restaurant_id to order_events if not present (needed for efficient RLS)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'order_events' AND column_name = 'restaurant_id'
  ) THEN
    ALTER TABLE order_events ADD COLUMN restaurant_id uuid REFERENCES restaurants(id) ON DELETE CASCADE;
    -- Backfill from orders
    UPDATE order_events oe
    SET restaurant_id = o.restaurant_id
    FROM orders o WHERE o.id = oe.order_id;
    CREATE INDEX IF NOT EXISTS order_events_restaurant_id_idx ON order_events(restaurant_id);
  END IF;
END $$;

CREATE POLICY "owners_select_order_events" ON order_events
  FOR SELECT TO authenticated
  USING (
    CASE
      WHEN restaurant_id IS NOT NULL
        THEN EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid())
      ELSE EXISTS (
        SELECT 1 FROM orders o JOIN restaurants r ON r.id = o.restaurant_id
        WHERE o.id = order_id AND r.owner_id = auth.uid()
      )
    END
  );

CREATE POLICY "owners_insert_order_events" ON order_events
  FOR INSERT TO authenticated
  WITH CHECK (
    CASE
      WHEN restaurant_id IS NOT NULL
        THEN EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid())
      ELSE EXISTS (
        SELECT 1 FROM orders o JOIN restaurants r ON r.id = o.restaurant_id
        WHERE o.id = order_id AND r.owner_id = auth.uid()
      )
    END
  );

CREATE POLICY "admins_select_order_events" ON order_events
  FOR SELECT TO authenticated USING (is_platform_admin());

-- 17. rls_coverage view for security dashboard
CREATE OR REPLACE VIEW rls_coverage AS
SELECT
  c.relname AS table_name,
  c.relrowsecurity AS rls_enabled,
  COUNT(p.polname)::integer AS policy_count
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
LEFT JOIN pg_policy p ON p.polrelid = c.oid
WHERE n.nspname = 'public' AND c.relkind = 'r'
GROUP BY c.relname, c.relrowsecurity
ORDER BY c.relname;

GRANT SELECT ON rls_coverage TO authenticated;
