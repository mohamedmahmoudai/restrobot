-- Phase 9: activity_logs table
CREATE TABLE IF NOT EXISTS activity_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  user_email text,
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id text,
  entity_name text,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS activity_logs_restaurant_id_idx ON activity_logs(restaurant_id);
CREATE INDEX IF NOT EXISTS activity_logs_created_at_idx ON activity_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS activity_logs_entity_type_idx ON activity_logs(entity_type);

ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "owners_select_activity_logs" ON activity_logs
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "owners_insert_activity_logs" ON activity_logs
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "admins_select_activity_logs" ON activity_logs
  FOR SELECT TO authenticated USING (is_platform_admin());

CREATE POLICY "service_role_activity_logs" ON activity_logs
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- Phase 9: add unread_count support to notifications (already has is_read)
-- Add DELETE policy to notifications
DROP POLICY IF EXISTS "owners_delete_notifications" ON notifications;
CREATE POLICY "owners_delete_notifications" ON notifications
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

-- Phase 9: add DELETE to orders (admin only) and analytics_snapshots
DROP POLICY IF EXISTS "admins_select_orders" ON orders;
CREATE POLICY "admins_select_orders" ON orders
  FOR SELECT TO authenticated USING (is_platform_admin());
