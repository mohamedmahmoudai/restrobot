-- Add missing columns to restaurants that are referenced in application code

ALTER TABLE restaurants
  ADD COLUMN IF NOT EXISTS cuisine_type text,
  ADD COLUMN IF NOT EXISTS onboarding_completed boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS has_used_trial boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS description text;
