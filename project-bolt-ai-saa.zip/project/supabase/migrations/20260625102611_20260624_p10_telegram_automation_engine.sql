-- Phase A: Telegram Automation Engine DB changes

-- 1. Add customer_id to telegram_sessions
ALTER TABLE telegram_sessions
  ADD COLUMN IF NOT EXISTS customer_id uuid REFERENCES customers(id) ON DELETE SET NULL;

-- 2. Add telegram_username to customers
ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS telegram_username text;

-- 3. Add discount to orders if missing
ALTER TABLE orders
  ADD COLUMN IF NOT EXISTS discount numeric DEFAULT 0;

-- 4. order_status_history table
CREATE TABLE IF NOT EXISTS order_status_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  old_status text,
  new_status text NOT NULL,
  notified_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS order_status_history_order_id_idx ON order_status_history(order_id);
CREATE INDEX IF NOT EXISTS order_status_history_created_at_idx ON order_status_history(created_at DESC);

ALTER TABLE order_status_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "owners_select_osh" ON order_status_history
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_id AND r.owner_id = auth.uid()));

CREATE POLICY "service_role_osh" ON order_status_history
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 5. Trigger: record status changes
CREATE OR REPLACE FUNCTION record_order_status_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    INSERT INTO order_status_history(order_id, restaurant_id, old_status, new_status)
    VALUES (NEW.id, NEW.restaurant_id, OLD.status, NEW.status);
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_order_status_change ON orders;
CREATE TRIGGER trg_order_status_change
  AFTER UPDATE OF status ON orders
  FOR EACH ROW EXECUTE FUNCTION record_order_status_change();

-- 6. Trigger: award loyalty points when order reaches 'delivered'
CREATE OR REPLACE FUNCTION award_loyalty_points_on_delivery()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_settings   loyalty_settings%ROWTYPE;
  v_points     integer;
  v_new_bal    integer;
  v_tier_name  text;
BEGIN
  IF NEW.status <> 'delivered' OR OLD.status = 'delivered' THEN RETURN NEW; END IF;
  IF NEW.customer_id IS NULL THEN RETURN NEW; END IF;

  SELECT * INTO v_settings FROM loyalty_settings
  WHERE restaurant_id = NEW.restaurant_id LIMIT 1;
  IF NOT FOUND OR NOT v_settings.is_active THEN RETURN NEW; END IF;

  v_points := GREATEST(1,
    FLOOR(NEW.total / COALESCE(v_settings.currency_unit, 10))
    * COALESCE(v_settings.points_per_currency_unit, 1)
  )::integer;

  INSERT INTO customer_points_wallet(restaurant_id, customer_id, current_points, lifetime_points, redeemed_points, current_tier)
  VALUES (NEW.restaurant_id, NEW.customer_id, v_points, v_points, 0, 'bronze')
  ON CONFLICT (restaurant_id, customer_id) DO UPDATE
    SET current_points  = customer_points_wallet.current_points + v_points,
        lifetime_points = customer_points_wallet.lifetime_points + v_points,
        updated_at      = now();

  SELECT current_points INTO v_new_bal FROM customer_points_wallet
  WHERE restaurant_id = NEW.restaurant_id AND customer_id = NEW.customer_id;

  INSERT INTO points_transactions(restaurant_id, customer_id, order_id, type, points, balance_after, notes)
  VALUES (NEW.restaurant_id, NEW.customer_id, NEW.id, 'earned', v_points, v_new_bal,
          'نقاط طلب #' || NEW.order_number);

  -- Upgrade tier
  SELECT tier_name INTO v_tier_name FROM customer_tiers
  WHERE restaurant_id = NEW.restaurant_id AND min_points <= v_new_bal
  ORDER BY min_points DESC LIMIT 1;

  IF v_tier_name IS NOT NULL THEN
    UPDATE customer_points_wallet SET current_tier = v_tier_name
    WHERE restaurant_id = NEW.restaurant_id AND customer_id = NEW.customer_id
      AND current_tier IS DISTINCT FROM v_tier_name;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_award_loyalty_points ON orders;
CREATE TRIGGER trg_award_loyalty_points
  AFTER UPDATE OF status ON orders
  FOR EACH ROW EXECUTE FUNCTION award_loyalty_points_on_delivery();

-- 7. Trigger: increment customer stats on new order (replaces broken RPC in order-intake)
CREATE OR REPLACE FUNCTION update_customer_stats_on_order()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF NEW.customer_id IS NOT NULL THEN
    UPDATE customers
    SET total_orders = COALESCE(total_orders, 0) + 1,
        total_spent  = COALESCE(total_spent, 0) + NEW.total
    WHERE id = NEW.customer_id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_customer_stats_on_order ON orders;
CREATE TRIGGER trg_customer_stats_on_order
  AFTER INSERT ON orders
  FOR EACH ROW EXECUTE FUNCTION update_customer_stats_on_order();
