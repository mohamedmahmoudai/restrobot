-- QA Fix: Add truly missing columns

-- 1. loyalty_settings — add missing columns
ALTER TABLE loyalty_settings
  ADD COLUMN IF NOT EXISTS welcome_bonus integer DEFAULT 0;

-- 2. customers — add status column for verified/blocked filtering
ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'active';

-- 3. delivery_zones — ensure min_order has a default
ALTER TABLE delivery_zones
  ADD COLUMN IF NOT EXISTS min_order numeric DEFAULT 0;

-- 4. restaurants — ensure all columns the frontend expects
ALTER TABLE restaurants
  ADD COLUMN IF NOT EXISTS subscription_expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS has_used_trial boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS whatsapp_webhook_url text,
  ADD COLUMN IF NOT EXISTS n8n_webhook_url text,
  ADD COLUMN IF NOT EXISTS is_suspended boolean DEFAULT false;

-- 5. Service-role RPC for super admin platform stats (bypasses RLS)
CREATE OR REPLACE FUNCTION get_platform_stats()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT is_platform_admin() THEN
    RAISE EXCEPTION 'Access denied';
  END IF;
  RETURN jsonb_build_object(
    'total_restaurants',          (SELECT COUNT(*)              FROM restaurants),
    'active_restaurants',         (SELECT COUNT(*)              FROM restaurants WHERE is_active = true),
    'total_customers',            (SELECT COUNT(*)              FROM customers),
    'total_orders',               (SELECT COUNT(*)              FROM orders),
    'pending_orders',             (SELECT COUNT(*)              FROM orders WHERE status = 'pending'),
    'monthly_revenue',            (SELECT COALESCE(SUM(total),0) FROM orders WHERE status='delivered' AND created_at >= date_trunc('month',now())),
    'new_restaurants_this_month', (SELECT COUNT(*)              FROM restaurants WHERE created_at >= date_trunc('month',now())),
    'new_customers_this_month',   (SELECT COUNT(*)              FROM customers   WHERE created_at >= date_trunc('month',now()))
  );
END;
$$;

-- 6. Admin list restaurants with stats
CREATE OR REPLACE FUNCTION admin_get_restaurants(
  p_limit  integer DEFAULT 50,
  p_offset integer DEFAULT 0,
  p_search text    DEFAULT ''
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_result jsonb;
BEGIN
  IF NOT is_platform_admin() THEN RAISE EXCEPTION 'Access denied'; END IF;
  SELECT jsonb_agg(row_to_json(r)) INTO v_result
  FROM (
    SELECT
      res.id, res.name, res.phone, res.address, res.is_active,
      res.subscription_plan, res.created_at, res.owner_id,
      res.is_suspended, res.onboarding_completed,
      au.email AS owner_email,
      (SELECT COUNT(*) FROM orders    o WHERE o.restaurant_id = res.id)::int        AS total_orders,
      (SELECT COUNT(*) FROM customers c WHERE c.restaurant_id = res.id)::int        AS total_customers,
      (SELECT COALESCE(SUM(o2.total),0) FROM orders o2 WHERE o2.restaurant_id = res.id AND o2.status='delivered') AS total_revenue
    FROM restaurants res
    LEFT JOIN auth.users au ON au.id = res.owner_id
    WHERE (p_search = '' OR res.name ILIKE '%'||p_search||'%' OR au.email ILIKE '%'||p_search||'%')
    ORDER BY res.created_at DESC
    LIMIT p_limit OFFSET p_offset
  ) r;
  RETURN COALESCE(v_result, '[]'::jsonb);
END;
$$;

-- 7. Admin toggle restaurant status
CREATE OR REPLACE FUNCTION admin_toggle_restaurant(
  p_restaurant_id uuid,
  p_is_active     boolean,
  p_is_suspended  boolean DEFAULT false
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT is_platform_admin() THEN RAISE EXCEPTION 'Access denied'; END IF;
  UPDATE restaurants
    SET is_active = p_is_active, is_suspended = p_is_suspended, updated_at = now()
  WHERE id = p_restaurant_id;
END;
$$;

GRANT EXECUTE ON FUNCTION get_platform_stats()                            TO authenticated;
GRANT EXECUTE ON FUNCTION admin_get_restaurants(integer,integer,text)     TO authenticated;
GRANT EXECUTE ON FUNCTION admin_toggle_restaurant(uuid,boolean,boolean)   TO authenticated;

-- 8. Storage policies for the three buckets
CREATE POLICY "public_read_restaurant_logos" ON storage.objects
  FOR SELECT TO public USING (bucket_id = 'restaurant-logos');
CREATE POLICY "auth_insert_restaurant_logos" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'restaurant-logos');
CREATE POLICY "auth_update_restaurant_logos" ON storage.objects
  FOR UPDATE TO authenticated USING (bucket_id = 'restaurant-logos');
CREATE POLICY "auth_delete_restaurant_logos" ON storage.objects
  FOR DELETE TO authenticated USING (bucket_id = 'restaurant-logos');

CREATE POLICY "public_read_menu_images" ON storage.objects
  FOR SELECT TO public USING (bucket_id = 'menu-images');
CREATE POLICY "auth_insert_menu_images" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'menu-images');
CREATE POLICY "auth_update_menu_images" ON storage.objects
  FOR UPDATE TO authenticated USING (bucket_id = 'menu-images');
CREATE POLICY "auth_delete_menu_images" ON storage.objects
  FOR DELETE TO authenticated USING (bucket_id = 'menu-images');

CREATE POLICY "public_read_category_images" ON storage.objects
  FOR SELECT TO public USING (bucket_id = 'category-images');
CREATE POLICY "auth_insert_category_images" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'category-images');
CREATE POLICY "auth_update_category_images" ON storage.objects
  FOR UPDATE TO authenticated USING (bucket_id = 'category-images');
CREATE POLICY "auth_delete_category_images" ON storage.objects
  FOR DELETE TO authenticated USING (bucket_id = 'category-images');
