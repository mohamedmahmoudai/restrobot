-- Create onboarding_progress table (missing from initial schema)
CREATE TABLE IF NOT EXISTS onboarding_progress (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id  uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  current_step   integer NOT NULL DEFAULT 1,
  completed_steps integer[] NOT NULL DEFAULT '{}',
  is_completed   boolean NOT NULL DEFAULT false,
  completed_at   timestamptz,
  step_data      jsonb NOT NULL DEFAULT '{}',
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (restaurant_id)
);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_onboarding_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_onboarding_updated_at ON onboarding_progress;
CREATE TRIGGER trg_onboarding_updated_at
  BEFORE UPDATE ON onboarding_progress
  FOR EACH ROW EXECUTE FUNCTION update_onboarding_updated_at();

-- Enable RLS
ALTER TABLE onboarding_progress ENABLE ROW LEVEL SECURITY;

-- RLS Policies: restaurant owner can do everything on their own row
CREATE POLICY "owner_select_onboarding_progress" ON onboarding_progress
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants r
      WHERE r.id = onboarding_progress.restaurant_id
        AND r.owner_id = auth.uid()
    )
  );

CREATE POLICY "owner_insert_onboarding_progress" ON onboarding_progress
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM restaurants r
      WHERE r.id = onboarding_progress.restaurant_id
        AND r.owner_id = auth.uid()
    )
  );

CREATE POLICY "owner_update_onboarding_progress" ON onboarding_progress
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants r
      WHERE r.id = onboarding_progress.restaurant_id
        AND r.owner_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM restaurants r
      WHERE r.id = onboarding_progress.restaurant_id
        AND r.owner_id = auth.uid()
    )
  );

CREATE POLICY "owner_delete_onboarding_progress" ON onboarding_progress
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM restaurants r
      WHERE r.id = onboarding_progress.restaurant_id
        AND r.owner_id = auth.uid()
    )
  );

-- Service role bypass for admin operations
CREATE POLICY "service_role_onboarding_progress" ON onboarding_progress
  FOR ALL TO service_role
  USING (true)
  WITH CHECK (true);
