-- Telegram integration refactor: auto-webhook, no manual chat_id

-- Add new columns to restaurants
ALTER TABLE restaurants
  ADD COLUMN IF NOT EXISTS telegram_bot_username    text,
  ADD COLUMN IF NOT EXISTS telegram_webhook_status  text DEFAULT 'not_configured',
  ADD COLUMN IF NOT EXISTS telegram_owner_chat_id   text,
  ADD COLUMN IF NOT EXISTS telegram_webhook_set_at  timestamptz;

-- telegram_webhook_status values:
--   'not_configured' — no token saved yet
--   'pending'        — token saved but webhook not yet registered
--   'active'         — webhook registered and responding
--   'error'          — webhook registration failed (error stored in a note)
--   'token_invalid'  — getMe returned 401
