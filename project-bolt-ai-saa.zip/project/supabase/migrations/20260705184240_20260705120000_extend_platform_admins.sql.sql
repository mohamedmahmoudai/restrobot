-- Extend platform_admins table with additional fields
ALTER TABLE platform_admins 
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS full_name text,
  ADD COLUMN IF NOT EXISTS role text NOT NULL DEFAULT 'admin',
  ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS last_login timestamptz,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

-- Add constraint for valid roles
ALTER TABLE platform_admins DROP CONSTRAINT IF EXISTS platform_admins_role_check;
ALTER TABLE platform_admins ADD CONSTRAINT platform_admins_role_check 
  CHECK (role IN ('admin', 'super_admin', 'support', 'viewer'));

-- Create unique index on email
CREATE UNIQUE INDEX IF NOT EXISTS platform_admins_email_idx ON platform_admins(email) WHERE email IS NOT NULL;

-- Update existing admin with email if exists
UPDATE platform_admins pa
SET email = au.email
FROM auth.users au
WHERE pa.user_id = au.id AND pa.email IS NULL;

-- Function to verify platform admin by user_id
CREATE OR REPLACE FUNCTION is_platform_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM platform_admins 
    WHERE user_id = auth.uid() 
    AND is_active = true
  );
$$;

-- Function to get platform admin profile
CREATE OR REPLACE FUNCTION get_platform_admin_profile()
RETURNS TABLE(id uuid, user_id uuid, email text, full_name text, role text, is_active boolean, last_login timestamptz, created_at timestamptz, updated_at timestamptz)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT pa.id, pa.user_id, pa.email, pa.full_name, pa.role, pa.is_active, pa.last_login, pa.created_at, pa.updated_at
  FROM platform_admins pa
  WHERE pa.user_id = auth.uid() AND pa.is_active = true;
$$;

-- RLS policies for platform_admins
DROP POLICY IF EXISTS admins_select_self ON platform_admins;
CREATE POLICY admins_select_self ON platform_admins
  FOR SELECT TO authenticated USING (user_id = auth.uid());

-- Drop existing policy if exists
DROP POLICY IF EXISTS admins_manage_all ON platform_admins;

-- Platform admins can manage all records (for super_admin role)
CREATE POLICY admins_manage_all ON platform_admins
  FOR ALL TO authenticated 
  USING (EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid() AND role = 'super_admin' AND is_active = true))
  WITH CHECK (EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid() AND role = 'super_admin' AND is_active = true));

-- Update last_login trigger
CREATE OR REPLACE FUNCTION update_platform_admin_last_login()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE platform_admins
  SET last_login = now(), updated_at = now()
  WHERE user_id = NEW.id
  AND EXISTS (SELECT 1 FROM platform_admins WHERE user_id = NEW.id);
  RETURN NEW;
END;
$$;

-- Trigger to update last_login on auth login
DROP TRIGGER IF EXISTS on_admin_login ON auth.users;
CREATE TRIGGER on_admin_login
  AFTER INSERT OR UPDATE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION update_platform_admin_last_login();