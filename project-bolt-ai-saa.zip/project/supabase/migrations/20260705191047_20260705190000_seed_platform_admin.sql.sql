-- Seed default platform admin
-- IMPORTANT: The Auth user must be created via Supabase Dashboard first with:
-- Email: engmohamed@gmail.com
-- Password: mohamed9090.

-- Then the user_id from auth.users can be linked here.
-- For now, we use a dynamic approach that looks up the user by email:

INSERT INTO platform_admins (user_id, email, full_name, role, is_active)
SELECT 
  id, 
  email, 
  'Mohamed Admin', 
  'super_admin', 
  true
FROM auth.users 
WHERE email = 'engmohamed@gmail.com'
ON CONFLICT (user_id) DO UPDATE SET
  email = EXCLUDED.email,
  full_name = EXCLUDED.full_name,
  role = EXCLUDED.role,
  is_active = EXCLUDED.is_active,
  updated_at = now();

-- Note: If the Auth user does not exist yet, this migration will not insert anything.
-- After creating the Auth user in Supabase Dashboard, run:
-- INSERT INTO platform_admins (user_id, email, full_name, role, is_active)
-- SELECT id, email, 'Mohamed Admin', 'super_admin', true FROM auth.users WHERE email = 'engmohamed@gmail.com';