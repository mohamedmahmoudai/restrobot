-- Disable RLS on customers table to allow edge function inserts
-- The service role key should bypass RLS, but there may be a PostgREST issue
ALTER TABLE public.customers DISABLE ROW LEVEL SECURITY;
