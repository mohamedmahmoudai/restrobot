-- Create a function to auto-create a customer from a telegram session
-- This is a fallback for when the edge function's customer insert fails
CREATE OR REPLACE FUNCTION auto_create_customer_from_session()
RETURNS TRIGGER AS $$
DECLARE
  v_customer_id uuid;
BEGIN
  -- Only act when transitioning to main_menu with no customer_id
  IF NEW.state = 'main_menu' AND NEW.customer_id IS NULL THEN
    -- Try to find an existing customer by telegram_user_id
    SELECT id INTO v_customer_id
    FROM customers
    WHERE restaurant_id = NEW.restaurant_id
      AND telegram_id = NEW.telegram_user_id
    LIMIT 1;

    IF v_customer_id IS NULL THEN
      -- No existing customer, create one
      -- Use a placeholder name if no name is available
      INSERT INTO customers (restaurant_id, name, phone, telegram_id, channel, status, total_orders, total_spent)
      VALUES (
        NEW.restaurant_id,
        COALESCE((NEW.checkout_data->>'_reg_name')::text, 'عميل Telegram'),
        COALESCE('010' || NEW.telegram_user_id, ''),
        NEW.telegram_user_id,
        'telegram',
        'new',
        0,
        0
      )
      RETURNING id INTO v_customer_id;
    END IF;

    -- Update the session with the customer_id
    NEW.customer_id := v_customer_id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create the trigger
CREATE TRIGGER trg_auto_create_customer
BEFORE UPDATE ON telegram_sessions
FOR EACH ROW
EXECUTE FUNCTION auto_create_customer_from_session();
