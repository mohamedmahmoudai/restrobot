-- Also add BEFORE INSERT trigger for the same function
-- PostgREST upsert uses INSERT ON CONFLICT DO UPDATE which may fire INSERT triggers
DROP TRIGGER IF EXISTS trg_auto_create_customer ON telegram_sessions;

CREATE TRIGGER trg_auto_create_customer
BEFORE INSERT OR UPDATE ON telegram_sessions
FOR EACH ROW
EXECUTE FUNCTION auto_create_customer_from_session();
