-- Re-enable RLS on customers table
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
