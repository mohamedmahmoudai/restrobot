-- ============================================================
-- FIX: Eliminate duplicate Telegram notifications
--
-- ROOT CAUSE: The trigger `notify_customer_on_status_change` sends a Telegram
-- message directly via net.http_post. The Cashier frontend ALSO calls the
-- telegram-notify edge function. This results in TWO messages per status change.
--
-- SOLUTION: Drop the DB trigger. The telegram-notify edge function becomes the
-- SINGLE notification path, called by the Cashier frontend.
-- ============================================================

DROP TRIGGER IF EXISTS customer_status_notification ON orders;
DROP FUNCTION IF EXISTS notify_customer_on_status_change();

-- ============================================================
-- FIX: Create trigger to populate order_events on status change
--
-- The order_events table is read by the Cashier UI to display audit trail.
-- Previously, Cashier.tsx manually inserted order_events, but this was removed
-- to prevent duplicates. No DB trigger existed to replace it.
-- This trigger is now the SINGLE OWNER of order_events inserts.
-- ============================================================

CREATE OR REPLACE FUNCTION record_order_event()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    INSERT INTO order_events (order_id, restaurant_id, old_status, new_status)
    VALUES (NEW.id, NEW.restaurant_id, OLD.status, NEW.status);
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_record_order_event ON orders;
CREATE TRIGGER trg_record_order_event
  AFTER UPDATE OF status ON orders
  FOR EACH ROW EXECUTE FUNCTION record_order_event();

-- ============================================================
-- FIX: Remove auto_create_customer_from_session trigger
--
-- ROOT CAUSE: This trigger creates customers from telegram_sessions BEFORE
-- INSERT/UPDATE, racing with the edge function's own customer creation during
-- registration. This causes duplicate customers or incorrect customer data.
--
-- SOLUTION: The telegram-webhook edge function is the SINGLE OWNER of customer
-- creation during registration. The DB trigger is removed.
-- ============================================================

DROP TRIGGER IF EXISTS trg_auto_create_customer ON telegram_sessions;
DROP FUNCTION IF EXISTS auto_create_customer_from_session();
