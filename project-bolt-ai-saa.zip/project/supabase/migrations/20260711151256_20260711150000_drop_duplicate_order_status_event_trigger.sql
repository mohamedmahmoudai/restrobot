-- Drop duplicate trigger — order_status_event and trg_record_order_event both
-- call record_order_event(), causing duplicate order_events inserts.
-- Keep trg_record_order_event (the one we created in the cleanup migration).
DROP TRIGGER IF EXISTS order_status_event ON orders;
