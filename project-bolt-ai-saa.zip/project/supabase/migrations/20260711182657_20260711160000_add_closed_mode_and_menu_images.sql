-- ============================================================
-- Feature 1: Restaurant Closed Mode
-- Feature 3: Telegram Menu Images
--
-- Adds two new columns to the restaurants table:
-- 1. is_closed (boolean, default false) — when true, the telegram
--    webhook will block ordering and send the closed_message instead.
-- 2. closed_message (text) — the message to send when closed.
-- 3. telegram_menu_images (jsonb, default '[]') — array of image URLs
--    to send to the customer before showing categories.
--
-- These columns are nullable with safe defaults so existing rows and
-- all existing queries continue to work without modification.
-- ============================================================

ALTER TABLE restaurants
  ADD COLUMN IF NOT EXISTS is_closed boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS closed_message text DEFAULT '',
  ADD COLUMN IF NOT EXISTS telegram_menu_images jsonb DEFAULT '[]'::jsonb;
