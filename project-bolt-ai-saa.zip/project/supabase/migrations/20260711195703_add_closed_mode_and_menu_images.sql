ALTER TABLE restaurants
  ADD COLUMN IF NOT EXISTS is_closed boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS closed_message text DEFAULT '',
  ADD COLUMN IF NOT EXISTS telegram_menu_images jsonb DEFAULT '[]'::jsonb;
