-- Phase 3: Extend system_plans with subscription billing columns
-- The SuperAdminPlans page references columns that don't exist yet (is_active, name_ar, price_monthly, etc.)
-- This migration adds them without dropping or renaming existing columns.

ALTER TABLE system_plans
  ADD COLUMN IF NOT EXISTS name_ar text,
  ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS is_trial boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS price_weekly numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS price_monthly numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS price_yearly numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS duration_days integer NOT NULL DEFAULT 30,
  ADD COLUMN IF NOT EXISTS max_orders integer,
  ADD COLUMN IF NOT EXISTS max_branches integer,
  ADD COLUMN IF NOT EXISTS max_users integer,
  ADD COLUMN IF NOT EXISTS max_menu_items integer,
  ADD COLUMN IF NOT EXISTS sort_order integer NOT NULL DEFAULT 0;

-- Backfill name_ar from plan_name for existing rows
UPDATE system_plans SET name_ar = plan_name WHERE name_ar IS NULL;

-- Backfill is_trial from type
UPDATE system_plans SET is_trial = true WHERE type = 'trial' AND is_trial = false;

-- Backfill price_monthly from price for existing rows
UPDATE system_plans SET price_monthly = price WHERE price_monthly = 0 AND price > 0;

-- Set sort_order based on price
UPDATE system_plans SET sort_order = 1 WHERE type = 'trial';
UPDATE system_plans SET sort_order = 2 WHERE type = 'basic';
UPDATE system_plans SET sort_order = 3 WHERE type = 'premium';
UPDATE system_plans SET sort_order = 4 WHERE type = 'enterprise';
