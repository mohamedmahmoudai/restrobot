-- Phase 3: Create restaurant_subscriptions and payment_requests tables
-- These tables store subscription lifecycle and payment proof submissions.

CREATE TABLE IF NOT EXISTS restaurant_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  plan_id uuid NOT NULL REFERENCES system_plans(id) ON DELETE CASCADE,
  billing_cycle text NOT NULL DEFAULT 'monthly',
  status text NOT NULL DEFAULT 'pending_payment',
  starts_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  orders_used integer NOT NULL DEFAULT 0,
  trial_used boolean NOT NULL DEFAULT false,
  payment_status text NOT NULL DEFAULT 'pending',
  payment_proof_url text,
  payment_notes text,
  admin_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_restaurant_subscriptions_restaurant ON restaurant_subscriptions(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_restaurant_subscriptions_status ON restaurant_subscriptions(status);

CREATE TABLE IF NOT EXISTS payment_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  plan_id uuid NOT NULL REFERENCES system_plans(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending',
  amount numeric NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'ج.م',
  payment_proof_url text NOT NULL,
  notes text,
  admin_notes text,
  reviewed_by uuid,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_payment_requests_restaurant ON payment_requests(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_payment_requests_status ON payment_requests(status);

-- RLS
ALTER TABLE restaurant_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_requests ENABLE ROW LEVEL SECURITY;

-- restaurant_subscriptions: owners can CRUD their own
CREATE POLICY "owners_select_subscriptions" ON restaurant_subscriptions FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_subscriptions.restaurant_id AND r.owner_id = auth.uid())
  );
CREATE POLICY "owners_insert_subscriptions" ON restaurant_subscriptions FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_subscriptions.restaurant_id AND r.owner_id = auth.uid())
  );
CREATE POLICY "owners_update_subscriptions" ON restaurant_subscriptions FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_subscriptions.restaurant_id AND r.owner_id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM restaurants r WHERE r.id = restaurant_subscriptions.restaurant_id AND r.owner_id = auth.uid())
  );
CREATE POLICY "admins_select_subscriptions" ON restaurant_subscriptions FOR SELECT
  TO authenticated USING (is_platform_admin());
CREATE POLICY "admins_update_subscriptions" ON restaurant_subscriptions FOR UPDATE
  TO authenticated USING (is_platform_admin()) WITH CHECK (is_platform_admin());

-- payment_requests: owners can read/insert their own, admins can read/update all
CREATE POLICY "owners_select_payments" ON payment_requests FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM restaurants r WHERE r.id = payment_requests.restaurant_id AND r.owner_id = auth.uid())
  );
CREATE POLICY "owners_insert_payments" ON payment_requests FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM restaurants r WHERE r.id = payment_requests.restaurant_id AND r.owner_id = auth.uid())
  );
CREATE POLICY "admins_select_payments" ON payment_requests FOR SELECT
  TO authenticated USING (is_platform_admin());
CREATE POLICY "admins_update_payments" ON payment_requests FOR UPDATE
  TO authenticated USING (is_platform_admin()) WITH CHECK (is_platform_admin());
