-- Add delivery_fee column to orders (needed for manual orders with delivery zones)
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery_fee numeric NOT NULL DEFAULT 0;
