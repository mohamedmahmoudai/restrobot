-- Add DELETE policy on orders for owners (needed for draft order deletion)
CREATE POLICY "owners_delete_own_orders" ON orders FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM restaurants r WHERE r.id = orders.restaurant_id AND r.owner_id = auth.uid())
  );
