/*
# Fix system_plans constraint + complete RLS policies

## Changes
1. Replaces the outdated `system_plans_type_check` constraint to support: free, paid, enterprise, custom, trial, basic, premium
2. Adds missing RLS policies (DELETE, UPDATE) for: analytics_snapshots, order_events, order_status_history, subscription_history, subscription_requests
3. Seeds a Free plan if none exists

## Security
- All 5 tables get complete CRUD RLS policies following the existing project model:
  - Restaurant owners: SELECT/INSERT/UPDATE their own data (via restaurant_id → restaurants.owner_id = auth.uid())
  - Platform admins: full CRUD via platform_admins check
  - No public/anon access
- Realtime continues working (RLS applies to realtime the same way)
*/

-- ═══════════════════════════════════════════════════════════════════════════
-- 1. Fix system_plans_type_check constraint
-- ═══════════════════════════════════════════════════════════════════════════

ALTER TABLE system_plans DROP CONSTRAINT IF EXISTS system_plans_type_check;
ALTER TABLE system_plans ADD CONSTRAINT system_plans_type_check
  CHECK (type = ANY (ARRAY['trial'::text, 'basic'::text, 'premium'::text, 'enterprise'::text, 'free'::text, 'paid'::text, 'custom'::text]));

-- ═══════════════════════════════════════════════════════════════════════════
-- 2. Complete RLS policies for analytics_snapshots
-- ═══════════════════════════════════════════════════════════════════════════

-- DELETE: owners can delete their own, admins can delete any
DROP POLICY IF EXISTS "owners_delete_analytics_snapshots" ON analytics_snapshots;
CREATE POLICY "owners_delete_analytics_snapshots" ON analytics_snapshots FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = analytics_snapshots.restaurant_id AND restaurants.owner_id = auth.uid())
    OR EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid())
  );

-- ═══════════════════════════════════════════════════════════════════════════
-- 3. Complete RLS policies for order_events
-- ═══════════════════════════════════════════════════════════════════════════

-- UPDATE: owners can update their own, admins can update any
DROP POLICY IF EXISTS "owners_update_order_events" ON order_events;
CREATE POLICY "owners_update_order_events" ON order_events FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = order_events.restaurant_id AND restaurants.owner_id = auth.uid())
    OR EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = order_events.restaurant_id AND restaurants.owner_id = auth.uid())
    OR EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid())
  );

-- DELETE: owners can delete their own, admins can delete any
DROP POLICY IF EXISTS "owners_delete_order_events" ON order_events;
CREATE POLICY "owners_delete_order_events" ON order_events FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = order_events.restaurant_id AND restaurants.owner_id = auth.uid())
    OR EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid())
  );

-- ═══════════════════════════════════════════════════════════════════════════
-- 4. Complete RLS policies for order_status_history
-- ═══════════════════════════════════════════════════════════════════════════

-- INSERT: owners can insert their own
DROP POLICY IF EXISTS "owners_insert_osh" ON order_status_history;
CREATE POLICY "owners_insert_osh" ON order_status_history FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = order_status_history.restaurant_id AND restaurants.owner_id = auth.uid())
    OR EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid())
  );

-- UPDATE: owners can update their own, admins can update any
DROP POLICY IF EXISTS "owners_update_osh" ON order_status_history;
CREATE POLICY "owners_update_osh" ON order_status_history FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = order_status_history.restaurant_id AND restaurants.owner_id = auth.uid())
    OR EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = order_status_history.restaurant_id AND restaurants.owner_id = auth.uid())
    OR EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid())
  );

-- DELETE: owners can delete their own, admins can delete any
DROP POLICY IF EXISTS "owners_delete_osh" ON order_status_history;
CREATE POLICY "owners_delete_osh" ON order_status_history FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = order_status_history.restaurant_id AND restaurants.owner_id = auth.uid())
    OR EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid())
  );

-- Drop the service_role ALL policy (replace with proper authenticated policies)
DROP POLICY IF EXISTS "service_role_osh" ON order_status_history;

-- ═══════════════════════════════════════════════════════════════════════════
-- 5. Complete RLS policies for subscription_history
-- ═══════════════════════════════════════════════════════════════════════════

-- UPDATE: admins only
DROP POLICY IF EXISTS "admin_update_subscription_history" ON subscription_history;
CREATE POLICY "admin_update_subscription_history" ON subscription_history FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid()));

-- DELETE: owners can delete their own, admins can delete any
DROP POLICY IF EXISTS "owner_delete_subscription_history" ON subscription_history;
CREATE POLICY "owner_delete_subscription_history" ON subscription_history FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = subscription_history.restaurant_id AND restaurants.owner_id = auth.uid())
    OR EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid())
  );

-- ═══════════════════════════════════════════════════════════════════════════
-- 6. Complete RLS policies for subscription_requests
-- ═══════════════════════════════════════════════════════════════════════════

-- DELETE: admins only (requests are removed by admin or cascade)
DROP POLICY IF EXISTS "admin_delete_subscription_requests" ON subscription_requests;
CREATE POLICY "admin_delete_subscription_requests" ON subscription_requests FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM platform_admins WHERE user_id = auth.uid()));

-- ═══════════════════════════════════════════════════════════════════════════
-- 7. Seed a Free plan if none exists
-- ═══════════════════════════════════════════════════════════════════════════

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM system_plans WHERE plan_type = 'free' OR type = 'free') THEN
    INSERT INTO system_plans (
      plan_name, name_ar, type, plan_type, internal_code, description,
      price, price_monthly, price_weekly, price_yearly,
      duration_days, is_active, is_trial, sort_order,
      badge, plan_color, plan_icon, show_on_landing, can_subscribe,
      supports_monthly, trial_days, auto_renew,
      max_orders, max_branches, max_users, max_menu_items, max_categories, max_customers
    ) VALUES (
      'Free', 'مجاني', 'free', 'free', 'free',
      'ابدأ مجاناً مع المميزات الأساسية',
      0, 0, 0, 0,
      365, true, false, 0,
      'free', '#10b981', 'Gift',
      true, true,
      true, 0, false,
      100, 1, 1, 20, 3, 50
    );
  END IF;
END $$;

-- Seed plan_features for the free plan
DO $$
DECLARE
  v_free uuid;
BEGIN
  SELECT id INTO v_free FROM system_plans WHERE plan_type = 'free' OR type = 'free' LIMIT 1;
  IF v_free IS NOT NULL THEN
    INSERT INTO plan_features (plan_id, feature_id)
    SELECT v_free, id FROM feature_definitions WHERE key IN (
      'telegram_ordering', 'manual_pos', 'delivery_zones', 'takeaway', 'dine_in',
      'qr_menu', 'online_menu', 'pos_system', 'realtime_orders', 'order_history',
      'restaurant_profile', 'receipt_printing'
    )
    ON CONFLICT DO NOTHING;
  END IF;
END $$;
