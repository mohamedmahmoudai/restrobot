/*
# Fix anon read access for system_plans

1. Problem
   - The landing page (public, no auth) queries system_plans but the SELECT policy
     is scoped to `authenticated` only, so anon gets zero rows.
   - This is why the pricing section on the landing page appears empty.

2. Changes
   - Drop the existing `authenticated_select_system_plans` policy.
   - Create a new `anon_read_system_plans` SELECT policy scoped to `anon, authenticated`
     so both public visitors and signed-in users can read active plans.
   - All other policies (INSERT/UPDATE/DELETE) remain admin-only (authenticated + platform_admins check).

3. Security
   - SELECT is intentionally public: plans are marketing data shown on the landing page.
   - Writes remain restricted to platform admins.
*/

DROP POLICY IF EXISTS "authenticated_select_system_plans" ON system_plans;
DROP POLICY IF EXISTS "anon_read_system_plans" ON system_plans;

CREATE POLICY "anon_read_system_plans"
ON system_plans FOR SELECT
TO anon, authenticated
USING (true);
